<?php
require_once 'includes/database.php';
$db = getDB();
requireReportAccess();
$title = 'Detail Perhitungan SLA';

$kontrak_id = (int)($_GET['kontrak_id'] ?? 0);
$ulp_filter = $_GET['ulp_id'] ?? ''; // '' = semua, 'gabungan' = ulp_id NULL, angka = ulp tertentu

require_once 'includes/kontrak_selector.php';
$sel = kontrakSelectorInit($db, $kontrak_id);
$filterJenis = $sel['jenis']; $filterUnit = $sel['unit'];
$kontrak = $kontrak_id ? dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$kontrak_id]) : null;

$ulpList = [];
if ($kontrak_id) {
    $ulpList = dbAll($db, "SELECT * FROM ulp WHERE kontrak_id=? ORDER BY nama_ulp", [$kontrak_id]);
}

$entries = [];
if ($kontrak_id) {
    $sql = "SELECT e.*, u.nama_ulp FROM sla_entries e LEFT JOIN ulp u ON e.ulp_id = u.id WHERE e.kontrak_id=?";
    $bind = [$kontrak_id];
    if ($ulp_filter === 'gabungan') {
        $sql .= " AND e.ulp_id IS NULL";
    } elseif ($ulp_filter !== '' && ctype_digit((string)$ulp_filter)) {
        $sql .= " AND e.ulp_id=?";
        $bind[] = (int)$ulp_filter;
    }
    $sql .= " ORDER BY e.kategori, e.no_urut, e.ulp_id";
    $entries = dbAll($db, $sql, $bind);
}

$grouped = [];
foreach ($entries as $e) $grouped[$e['kategori']][] = $e;

$katLabel = [
    'TEKNIS'     => ['label' => 'SLA Teknis',        'icon' => 'bi-lightning-charge', 'color' => 'var(--blue)'],
    'K3'         => ['label' => 'SLA K3',             'icon' => 'bi-shield-check',      'color' => '#10b981'],
    'KECELAKAAN' => ['label' => 'Kecelakaan Kerja',   'icon' => 'bi-exclamation-octagon', 'color' => '#f59e0b'],
    'ILP'        => ['label' => 'SLA ILP',            'icon' => 'bi-bank',               'color' => '#7c3aed'],
];

include 'includes/header.php';
?>

<!-- Selector -->
<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title"><i class="bi bi-calculator" style="color:var(--blue);"></i> Detail Perhitungan SLA</div>
            <div class="card-subtitle">Lihat persis bagaimana angka persentase & nilai bobot tiap indikator diperoleh</div>
        </div>
        <?php if ($kontrak_id && !empty($entries)): ?>
        <a href="export_detail_perhitungan.php?kontrak_id=<?= (int)$kontrak_id ?><?= $ulp_filter !== '' ? '&ulp_id=' . urlencode((string)$ulp_filter) : '' ?>" class="btn btn-outline" style="border-color:#1D6F42;color:#1D6F42;white-space:nowrap;"><i class="bi bi-file-earmark-excel"></i> Export Excel</a>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <?php renderKontrakSelectorFields($sel, 'detail_perhitungan.php', ['btnLabel' => 'Lihat Detail']); ?>
        <?php if ($kontrak_id): ?>
        <div class="form-group" style="margin:14px 0 0;max-width:320px;">
            <label>Level Data</label>
            <select class="form-control" onchange="window.location='detail_perhitungan.php?kontrak_id=<?= $kontrak_id ?>&ulp_id='+this.value">
                <option value="" <?= $ulp_filter===''?'selected':'' ?>>Semua (Gabungan + Per ULP)</option>
                <option value="gabungan" <?= $ulp_filter==='gabungan'?'selected':'' ?>>Gabungan saja</option>
                <?php foreach ($ulpList as $u): ?>
                <option value="<?= $u['id'] ?>" <?= (string)$ulp_filter===(string)$u['id']?'selected':'' ?>><?= htmlspecialchars((string)($u['nama_ulp'] ?? '')) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php renderKontrakListCard($sel, 'detail_perhitungan.php', ['btnLabel' => 'Lihat Detail']); ?>

<?php if ($kontrak && !empty($grouped)): ?>

<div class="card" style="background:linear-gradient(135deg,#003087,#0055b3);color:#fff;">
    <div class="card-body">
        <div style="font-size:12px;opacity:0.7;margin-bottom:6px;">DETAIL PERHITUNGAN SLA</div>
        <div style="font-size:15px;font-weight:800;word-break:break-word;"><?= htmlspecialchars((string)($kontrak['nama_kontrak'] ?? '')) ?></div>
        <div style="font-size:12.5px;opacity:0.85;margin-top:4px;">
            Periode <?= ucwords(strtolower($kontrak['periode_bulan'])) ?> <?= $kontrak['tahun'] ?> &bull; <?= htmlspecialchars((string)($kontrak['tahap'] ?? '')) ?>
        </div>
    </div>
</div>

<div class="alert alert-info" style="display:flex;align-items:flex-start;gap:10px;">
    <i class="bi bi-info-circle" style="font-size:16px;margin-top:1px;"></i>
    <div style="font-size:12.5px;line-height:1.6;">
        Setiap indikator di bawah menampilkan <b>Target</b>, <b>Realisasi</b>, <b>Persentase Pencapaian</b>, <b>Bobot</b>, dan <b>Nilai Bobot</b> beserta
        <b>rumus perhitungannya</b> — supaya proses audit lebih mudah dan hasil sistem lebih bisa dipercaya.
    </div>
</div>

<?php foreach ($grouped as $kat => $ents):
    $info = $katLabel[$kat] ?? ['label'=>$kat,'icon'=>'bi-list-check','color'=>'var(--blue)'];
?>
<div class="card">
    <div class="card-header" style="padding:12px 16px;">
        <div class="card-title" style="font-size:13px;"><i class="bi <?= $info['icon'] ?>" style="color:<?= $info['color'] ?>;"></i> <?= htmlspecialchars((string)($info['label'] ?? '')) ?></div>
        <div class="card-subtitle" style="font-size:11px;"><?= count($ents) ?> indikator</div>
    </div>
    <div class="card-body" style="display:flex;flex-direction:column;gap:10px;">
        <?php foreach ($ents as $i => $e):
            $target = (float)$e['target'];
            $belumDinilai = $e['persen_pencapaian'] === null;
            $realisasi = $belumDinilai ? null : (float)$e['realisasi'];
            $pct = $belumDinilai ? null : (float)$e['persen_pencapaian'];
            $bobot = (float)$e['bobot'];
            $nilaiBobot = $belumDinilai ? null : (float)$e['nilai_bobot'];
            $rumusPct = $belumDinilai ? null : formulaPencapaian($e['polaritas'], $target, $realisasi, $pct);
            $rumusNb  = $belumDinilai ? null : formulaNilaiBobot($pct, $bobot, $nilaiBobot);
        ?>
        <div style="border:1px solid var(--g200,#e2e8f0);border-radius:10px;padding:14px 16px;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;flex-wrap:wrap;margin-bottom:10px;">
                <div>
                    <div style="font-weight:700;font-size:13px;"><?= htmlspecialchars($e['kriteria'] ?: $e['ruang_lingkup']) ?></div>
                    <div style="font-size:11px;color:#64748b;">
                        <?= htmlspecialchars((string)($e['ruang_lingkup'] ?? '')) ?>
                        &bull; <?= $e['nama_ulp'] ? htmlspecialchars((string)($e['nama_ulp'] ?? '')) : 'Gabungan' ?>
                        &bull; <span class="badge <?= $e['polaritas']=='Positif'?'badge-positif':'badge-negatif' ?>" style="font-size:10px;"><?= $e['polaritas'] ?></span>
                    </div>
                </div>
                <?php if ($belumDinilai): ?>
                <span style="background:#f1f5f9;color:#94a3b8;border:1px solid #e2e8f0;font-size:12px;font-weight:700;padding:4px 12px;border-radius:8px;white-space:nowrap;"><i class="bi bi-hourglass-split"></i> Belum Dinilai</span>
                <?php else: ?>
                <span style="<?= pctBadgeStyle($pct) ?>font-size:13px;font-weight:800;padding:4px 12px;border-radius:8px;"><?= number_format($pct,2) ?>%</span>
                <?php endif; ?>
            </div>

            <?php if ($belumDinilai): ?>
            <div style="background:#f8fafc;border-radius:8px;padding:10px 12px;font-size:12px;color:#64748b;margin-bottom:0;">
                <i class="bi bi-info-circle"></i> Realisasi untuk indikator ini belum diisi, jadi belum ikut dihitung dalam skor SLA (bukan dianggap gagal/0%).
                Target saat ini: <b><?= rtrim(rtrim(number_format($target,4),'0'),'.') ?> <?= htmlspecialchars((string)($e['satuan'] ?? '')) ?></b>
                &bull; Bobot: <b><?= rtrim(rtrim(number_format($bobot,4),'0'),'.') ?></b>
            </div>
            <?php else: ?>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(100px,1fr));gap:8px;margin-bottom:10px;">
                <div style="background:#f8fafc;border-radius:8px;padding:8px 10px;">
                    <div style="font-size:10px;color:#64748b;text-transform:uppercase;">Target</div>
                    <div style="font-size:14px;color:#1e293b;"><?= rtrim(rtrim(number_format($target,4),'0'),'.') ?> <span style="font-size:10px;color:#94a3b8;"><?= htmlspecialchars((string)($e['satuan'] ?? '')) ?></span></div>
                </div>
                <div style="background:#f8fafc;border-radius:8px;padding:8px 10px;">
                    <div style="font-size:10px;color:#64748b;text-transform:uppercase;">Realisasi</div>
                    <div style="font-size:14px;color:#1e293b;"><?= rtrim(rtrim(number_format($realisasi,4),'0'),'.') ?> <span style="font-size:10px;color:#94a3b8;"><?= htmlspecialchars((string)($e['satuan'] ?? '')) ?></span></div>
                </div>
                <div style="background:#f8fafc;border-radius:8px;padding:8px 10px;">
                    <div style="font-size:10px;color:#64748b;font-weight:700;text-transform:uppercase;">Persentase</div>
                    <div style="font-size:14px;font-weight:800;color:<?= $pct>=90?'#166534':($pct>=70?'#854d0e':'#991b1b') ?>;"><?= number_format($pct,2) ?>%</div>
                </div>
                <div style="background:#f8fafc;border-radius:8px;padding:8px 10px;">
                    <div style="font-size:10px;color:#64748b;font-weight:700;text-transform:uppercase;">Bobot</div>
                    <div style="font-size:14px;font-weight:800;color:#1e293b;"><?= rtrim(rtrim(number_format($bobot,4),'0'),'.') ?></div>
                </div>
                <div style="background:#eaf3ff;border-radius:8px;padding:8px 10px;">
                    <div style="font-size:10px;color:#0066AE;font-weight:700;text-transform:uppercase;">Nilai Bobot</div>
                    <div style="font-size:14px;font-weight:800;color:#0066AE;"><?= number_format($nilaiBobot,2) ?></div>
                </div>
            </div>

            <div style="background:#0f172a;color:#e2e8f0;border-radius:8px;padding:10px 12px;font-size:11.5px;line-height:1.7;font-family:'Courier New',monospace;">
                <div style="color:#94a3b8;font-weight:700;text-transform:uppercase;font-size:10px;margin-bottom:4px;"><i class="bi bi-calculator"></i> Cara Perhitungan</div>
                <div>% Pencapaian &nbsp;=&nbsp; <?= htmlspecialchars($rumusPct) ?></div>
                <div>Nilai Bobot &nbsp;&nbsp;=&nbsp; Persentase × Bobot &nbsp;=&nbsp; <?= htmlspecialchars($rumusNb) ?></div>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endforeach; ?>

<?php elseif ($kontrak_id): ?>
<div class="alert alert-info">
    Belum ada indikator SLA untuk kontrak ini. Silakan <a href="input_sla.php?kontrak_id=<?= $kontrak_id ?>">input target &amp; realisasi SLA</a> terlebih dahulu.
</div>
<?php else: ?>
<div class="card">
    <div style="text-align:center;padding:40px;">
        <div style="font-size:48px;"><i class="bi bi-calculator" style="color:var(--blue);"></i></div>
        <div style="font-size:16px;font-weight:700;color:var(--pln-blue);margin-top:12px;">Pilih Project untuk Lihat Detail Perhitungan</div>
    </div>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
