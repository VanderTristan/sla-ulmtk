<?php
/**
 * export_csv.php — Export Data SLA sebuah kontrak ke file .csv, satu tabel
 * rata (flat) dengan kolom yang sama seperti export_excel.php:
 * BIDANG/PROJECT/JENIS SLA/LINGKUP PEKERJAAN/LINGKUP SLA/KRITERIA/
 * POLARITAS/SATUAN/TARGET/REALISASI + 3 kolom hasil perhitungan aplikasi
 * (% Pencapaian, Bobot, Nilai Bobot) di paling kanan.
 *
 * Dipanggil dari: rekap_sla.php -> tombol "Export CSV"
 * Contoh URL: export_csv.php?kontrak_id=6
 */
require_once 'includes/database.php';

$db = getDB();
requireReportAccess();

$kontrak_id = (int)($_GET['kontrak_id'] ?? 0);
if (!$kontrak_id) {
    http_response_code(400);
    die('Parameter kontrak_id wajib diisi.');
}

$kontrak = dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$kontrak_id]);
if (!$kontrak) {
    http_response_code(404);
    die('Kontrak tidak ditemukan.');
}

function getCatEntriesCsv(PDO $db, int $kontrak_id, string $kat): array {
    return dbAll($db, "SELECT * FROM sla_entries WHERE kontrak_id=? AND ulp_id IS NULL AND kategori=? ORDER BY no_urut", [$kontrak_id, $kat]);
}

$katLabel = ['TEKNIS' => 'TEKNIS', 'K3' => 'K3', 'KECELAKAAN' => 'KECELAKAAN', 'ILP' => 'ILP'];
$header = ['BIDANG', 'PROJECT', 'JENIS SLA', 'LINGKUP PEKERJAAN', 'LINGKUP SLA', 'KRITERIA', 'POLARITAS', 'SATUAN', 'TARGET', 'REALISASI', '% Pencapaian', 'Bobot', 'Nilai Bobot'];
$bidang  = (string)($kontrak['jenis_kontrak'] ?? '');
$project = (string)($kontrak['nama_kontrak'] ?? '');

$rows = [$header];
foreach ($katLabel as $kat => $label) {
    $entries = getCatEntriesCsv($db, $kontrak_id, $kat);
    foreach ($entries as $e) {
        $belumDinilai = $e['persen_pencapaian'] === null;
        $rows[] = [
            $bidang,
            $project,
            $label,
            (string)($e['ruang_lingkup'] ?? ''),
            (string)($e['kriteria'] ?? ''),
            (string)($e['target_kinerja'] ?? ''),
            (string)($e['polaritas'] ?? ''),
            (string)($e['satuan'] ?? ''),
            (float)($e['target'] ?? 0),
            $belumDinilai ? 'Belum Dinilai' : (float)$e['realisasi'],
            $belumDinilai ? 'Belum Dinilai' : round((float)$e['persen_pencapaian'], 2),
            (float)($e['bobot'] ?? 0),
            $belumDinilai ? 'Belum Dinilai' : round((float)$e['nilai_bobot'], 2),
        ];
    }
}
if (count($rows) === 1) {
    $rows[] = ['-', '-', '-', 'Belum ada data entry untuk kontrak ini', '', '', '', '', '', '', '', '', ''];
}

logAudit($db, 'export', 'rekap_sla', "Export CSV rekap SLA kontrak_id=$kontrak_id");

$safeFileName = preg_replace('/[^A-Za-z0-9_-]+/', '_', $project ?: 'kontrak');
$filename = 'Data_SLA_' . substr($safeFileName, 0, 60) . '_' . date('Ymd') . '.csv';

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

// BOM UTF-8 supaya karakter (misal simbol %, huruf non-ASCII) tampil benar
// saat file dibuka langsung di Microsoft Excel.
echo "\xEF\xBB\xBF";

$out = fopen('php://output', 'w');
foreach ($rows as $row) {
    fputcsv($out, $row);
}
fclose($out);
exit;
