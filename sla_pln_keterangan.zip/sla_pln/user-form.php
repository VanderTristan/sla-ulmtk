<?php
require_once 'includes/database.php';
require_once 'includes/auth.php';

requireAdmin();

$db     = getDB();
$id     = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$data   = ['id' => 0, 'nama' => '', 'username' => '', 'email' => '', 'role' => 'Viewer', 'status' => 'Aktif'];
$isEdit = false;

if ($id > 0) {
    $found = dbRow($db, "SELECT id, nama, username, email, role, status FROM app_users WHERE id = ?", [$id]);
    if ($found) { $data = $found; $isEdit = true; }
}

$title = $isEdit ? 'Edit User' : 'Tambah User';
require 'includes/header.php';
?>

<div class="card" style="max-width:700px;margin-left:auto;margin-right:auto;">
    <div class="card-header">
        <div>
            <div class="card-title">
                <i class="bi bi-<?= $isEdit ? 'pencil-square' : 'person-plus' ?>" style="color:var(--blue);"></i>
                <?= $isEdit ? 'Edit User' : 'Tambah User Baru' ?>
            </div>
            <div class="card-subtitle"><?= $isEdit ? 'Perbarui data pengguna' : 'Buat akun pengguna baru' ?></div>
        </div>
        <a class="btn btn-secondary btn-sm" href="users.php">
            <i class="bi bi-arrow-left"></i> Kembali
        </a>
    </div>

    <div class="card-body">
        <form method="post" action="user-save.php">
            <?= csrfField() ?>
            <input type="hidden" name="id" value="<?= (int)$data['id'] ?>">

            <!-- Baris 1: Nama + Username -->
            <div class="form-row form-row-2" style="margin-bottom:14px;">
                <div class="form-group" style="margin-bottom:0;">
                    <label>Nama Lengkap <span style="color:var(--red);">*</span></label>
                    <input class="form-control" type="text" name="nama" required
                           placeholder="Nama lengkap" value="<?= h($data['nama']) ?>">
                </div>
                <div class="form-group" style="margin-bottom:0;">
                    <label>Username <span style="color:var(--red);">*</span></label>
                    <input class="form-control" type="text" name="username" required
                           placeholder="username" value="<?= h($data['username']) ?>">
                </div>
            </div>

            <!-- Baris 2: Email + Role -->
            <div class="form-row form-row-2" style="margin-bottom:14px;">
                <div class="form-group" style="margin-bottom:0;">
                    <label>Email <span style="color:var(--red);">*</span></label>
                    <input class="form-control" type="email" name="email" required
                           placeholder="email@company.com" value="<?= h($data['email']) ?>">
                </div>
                <div class="form-group" style="margin-bottom:0;">
                    <label>Role <span style="color:var(--red);">*</span></label>
                    <select class="form-control" name="role">
                        <?php foreach (['SuperAdmin', 'Admin', 'Monitoring', 'Viewer', 'Koordinator'] as $r): ?>
                            <option value="<?= h($r) ?>" <?= $data['role'] === $r ? 'selected' : '' ?>><?= h(roleLabel($r)) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <!-- Baris 3: Password + Konfirmasi -->
            <div class="form-row form-row-2" style="margin-bottom:14px;">
                <div class="form-group" style="margin-bottom:0;">
                    <label>
                        Password
                        <?php if ($isEdit): ?>
                            <small style="font-weight:400;color:var(--text-muted);">(kosongkan jika tidak diubah)</small>
                        <?php else: ?>
                            <span style="color:var(--red);">*</span>
                        <?php endif; ?>
                    </label>
                    <input class="form-control" type="password" name="password"
                           placeholder="Minimal 6 karakter" <?= $isEdit ? '' : 'required' ?>>
                </div>
                <div class="form-group" style="margin-bottom:0;">
                    <label>
                        Konfirmasi Password
                        <?php if (!$isEdit): ?><span style="color:var(--red);">*</span><?php endif; ?>
                    </label>
                    <input class="form-control" type="password" name="password_confirm"
                           placeholder="Ulangi password" <?= $isEdit ? '' : 'required' ?>>
                </div>
            </div>

            <!-- Baris 4: Status (separuh lebar) -->
            <div class="form-group" style="max-width:calc(50% - 7px);margin-bottom:0;">
                <label>Status</label>
                <select class="form-control" name="status">
                    <?php foreach (['Aktif', 'Nonaktif'] as $st): ?>
                        <option <?= $data['status'] === $st ? 'selected' : '' ?>><?= h($st) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Tombol aksi -->
            <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:24px;
                        padding-top:16px;border-top:1px solid var(--border);">
                <a class="btn btn-secondary" href="users.php">Batal</a>
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check-lg"></i> Simpan User
                </button>
            </div>
        </form>
    </div>
</div>

<?php require 'includes/footer.php'; ?>
