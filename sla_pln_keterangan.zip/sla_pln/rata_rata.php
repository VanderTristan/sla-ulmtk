<?php
require_once 'includes/database.php';
$db = getDB();
requireReportAccess();
$title = 'Rata-Rata SLA';
$kontrak_id = (int)($_GET['kontrak_id'] ?? 0);

require_once 'includes/kontrak_selector.php';
$sel = kontrakSelectorInit($db, $kontrak_id);
$filterJenis = $sel['jenis']; $filterUnit = $sel['unit']; $unitOptions = $sel['unitOptions'];
$kontrak = $kontrak_id ? dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$kontrak_id]) : null;

// Per-ULP statistics
$ulpStats = [];
if ($kontrak_id) {
    $ulps_list = dbAll($db, "SELECT * FROM ulp WHERE kontrak_id=? ORDER BY nama_ulp", [$kontrak_id]);
    foreach ($ulps_list as $u) {
        $uid = $u['id'];
        $cats = ['TEKNIS','K3','KECELAKAAN','ILP'];
        $data = ['ulp'=>$u,'cats'=>[],'avg_total'=>0];
        foreach($cats as $cat) {
            $r = dbRow($db, "SELECT SUM(bobot) as bobot_asli, COUNT(*) as cnt, SUM(nilai_bobot) as total_bobot FROM sla_entries WHERE kontrak_id=? AND ulp_id=? AND kategori=?", [$kontrak_id, $uid, $cat]);
            $bobotAsli = (float)($r['bobot_asli'] ?? 0);
            $r['avg_pct'] = $bobotAsli > 0 ? ((float)($r['total_bobot'] ?? 0) / $bobotAsli) : 0;
            $data['cats'][$cat] = $r;
        }
        // Total-berbobot (bukan rata-rata sederhana 4 kategori) — konsisten dengan
        // rekapOverallPct() di database.php, supaya kategori dengan bobot lebih besar
        // memang lebih berpengaruh ke skor akhir per-ULP ini.
        $bobotAsliTotalUlp = array_sum(array_column($data['cats'], 'bobot_asli'));
        $nilaiBobotTotalUlp = array_sum(array_map(fn($c) => (float)($c['total_bobot'] ?? 0), $data['cats']));
        $data['avg_total'] = $bobotAsliTotalUlp > 0 ? ($nilaiBobotTotalUlp / $bobotAsliTotalUlp) : 0;
        $ulpStats[] = $data;
    }
}

// Tren bulanan keseluruhan (all kontrak)
$monthlyRows = dbAll($db, "
    SELECT k.periode_bulan, k.tahun, k.nama_kontrak,
           r.sla_teknis, r.sla_k3, r.sla_kecelakaan, r.sla_ilp,
           r.sla_overall as avg_sla
    FROM rekap_sla r JOIN kontrak k ON r.kontrak_id=k.id
    ORDER BY k.tahun, k.id
");

// Indicator avg analysis
$indicatorAvg = [];
if ($kontrak_id) {
    $cats = ['TEKNIS','K3','KECELAKAAN','ILP'];
    foreach($cats as $cat) {
        $q_rows = dbAll($db, "SELECT ruang_lingkup, kriteria, AVG(persen_pencapaian) as avg_pct, MIN(persen_pencapaian) as min_pct, MAX(persen_pencapaian) as max_pct FROM sla_entries WHERE kontrak_id=? AND kategori=? GROUP BY ruang_lingkup, kriteria ORDER BY avg_pct ASC", [$kontrak_id, $cat]);
        foreach ($q_rows as $r) {
            $r['kategori'] = $cat;
            $indicatorAvg[] = $r;
        }
    }
}

function pBar($pct, $w=100) {
    $cls = $pct>=90?'good':($pct>=70?'warn':'bad');
    return "<div class='progress-bar' style='width:{$w}px'><div class='progress-fill $cls' style='width:".min(100,max(0,$pct))."%'></div></div><div class='progress-label $cls'>".number_format($pct,1)."%</div>";
}

include 'includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div class="card-title">📈 Analisis Rata-Rata SLA</div>
        <?php if (!empty($monthlyRows) || $kontrak_id): ?>
        <a href="export_rata_rata.php<?= $kontrak_id ? '?kontrak_id=' . (int)$kontrak_id : '' ?>" class="btn btn-outline no-print" style="border-color:#1D6F42;color:#1D6F42;white-space:nowrap;"><i class="bi bi-file-earmark-excel"></i> Export Excel</a>
        <?php endif; ?>
    </div>
    <div class="card-body">
    <?php renderKontrakSelectorFields($sel, 'rata_rata.php', ['btnLabel' => 'Lihat Analisis', 'bidangAll' => '-- Semua Bidang (Trend) --']); ?>
    <?= renderFilterBreadcrumb([
        'Bidang'  => $filterJenis !== 'ALL' ? ucfirst(strtolower($filterJenis)) : null,
        'Project' => $filterUnit && $filterUnit !== 'none' ? (array_column($unitOptions,'nama','id')[$filterUnit] ?? null) : ($filterUnit === 'none' ? 'Belum Ditentukan' : null),
        'Kontrak' => $kontrak ? kontrakSelectLabel($kontrak) : null,
    ], 'rata_rata.php') ?>
    </div>
</div>

<?php renderKontrakListCard($sel, 'rata_rata.php', ['btnLabel' => 'Lihat Analisis']); ?>

<?php if(!empty($monthlyRows)): ?>
<!-- Monthly Trend Table -->
<div class="card">
    <div class="card-header">
        <div class="card-title">📅 Trend SLA Bulanan</div>
        <div class="card-subtitle"><?= count($monthlyRows) ?> periode tersedia</div>
    </div>
    <div class="table-wrap">
    <table>
        <thead>
            <tr><th>#</th><th>Periode</th><th>Project</th><th>SLA Teknis</th><th>SLA K3</th><th>SLA Kecelakaan</th><th>SLA ILP</th><th>Rata-Rata</th></tr>
        </thead>
        <tbody>
        <?php foreach($monthlyRows as $i=>$m): ?>
        <tr>
            <td><?= $i+1 ?></td>
            <td><b><?= htmlspecialchars((string)($m['periode_bulan'] ?? '')) ?> <?= $m['tahun'] ?></b></td>
            <td><?= htmlspecialchars($m['nama_kontrak'] ?? '-') ?></td>
            <td><?= pBar($m['sla_teknis'],90) ?></td>
            <td><?= pBar($m['sla_k3'],90) ?></td>
            <td><?= pBar($m['sla_kecelakaan'],90) ?></td>
            <td><?= pBar($m['sla_ilp'],90) ?></td>
            <td><?= pBar($m['avg_sla'],90) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if(count($monthlyRows)>1):
            $avgT = array_sum(array_column($monthlyRows,'sla_teknis'))/count($monthlyRows);
            $avgK = array_sum(array_column($monthlyRows,'sla_k3'))/count($monthlyRows);
            $avgE = array_sum(array_column($monthlyRows,'sla_kecelakaan'))/count($monthlyRows);
            $avgI = array_sum(array_column($monthlyRows,'sla_ilp'))/count($monthlyRows);
            $avgA = array_sum(array_column($monthlyRows,'avg_sla'))/count($monthlyRows);
        ?>
        <tr style="background:#003087;color:#fff;font-weight:900;">
            <td colspan="3">RATA-RATA KESELURUHAN</td>
            <td><?= number_format($avgT,2) ?>%</td>
            <td><?= number_format($avgK,2) ?>%</td>
            <td><?= number_format($avgE,2) ?>%</td>
            <td><?= number_format($avgI,2) ?>%</td>
            <td><?= number_format($avgA,2) ?>%</td>
        </tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>
<?php endif; ?>

<?php if(!empty($ulpStats)): ?>
<!-- Per ULP Comparison -->
<div class="card">
    <div class="card-header">
        <div class="card-title">🏢 Perbandingan SLA Antar ULP</div>
        <div class="card-subtitle">Periode: <?= htmlspecialchars((string)($kontrak['periode_bulan'] ?? '')) ?> <?= $kontrak['tahun'] ?></div>
    </div>
    <div class="table-wrap">
    <table>
        <thead>
            <tr><th>#</th><th>ULP</th><th>SLA Teknis</th><th>SLA K3</th><th>Kecelakaan</th><th>SLA ILP</th><th>Rata-Rata</th><th>Status</th></tr>
        </thead>
        <tbody>
        <?php 
        usort($ulpStats, fn($a,$b) => $b['avg_total'] <=> $a['avg_total']);
        foreach($ulpStats as $i=>$us): 
            $avg = $us['avg_total'];
        ?>
        <tr>
            <td><?= $i+1 ?></td>
            <td><b><?= htmlspecialchars((string)($us['ulp']['nama_ulp'] ?? '')) ?></b><br><small class="text-muted"><?= htmlspecialchars((string)($us['ulp']['manager_pln'] ?? '')) ?></small></td>
            <?php foreach(['TEKNIS','K3','KECELAKAAN','ILP'] as $cat): 
                $p = (float)($us['cats'][$cat]['avg_pct'] ?? 0);
            ?>
            <td><?= pBar($p, 90) ?></td>
            <?php endforeach; ?>
            <td><?= pBar($avg, 90) ?></td>
            <td>
                <?php if($avg>=90): ?>
                <span class="badge" style="background:#d4f5e4;color:#27ae60;">✅ BAIK</span>
                <?php elseif($avg>=70): ?>
                <span class="badge" style="background:#fff3cd;color:#7d5a00;">⚠️ CUKUP</span>
                <?php else: ?>
                <span class="badge" style="background:#fde8e8;color:#c0392b;">❌ KURANG</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</div>
<?php endif; ?>

<?php if(!empty($indicatorAvg)): ?>
<!-- Worst Performing Indicators -->
<div class="card">
    <div class="card-header">
        <div class="card-title">⚠️ Indikator dengan Pencapaian Terendah</div>
        <div class="card-subtitle">Berdasarkan rata-rata semua ULP - diurutkan dari terendah</div>
    </div>
    <div class="table-wrap">
    <table>
        <thead>
            <tr><th>#</th><th>Kategori</th><th>Ruang Lingkup</th><th>Kriteria</th><th>Rata-Rata</th><th>Min</th><th>Max</th></tr>
        </thead>
        <tbody>
        <?php $worst = array_slice($indicatorAvg, 0, 10); $no=1; foreach($worst as $ind): ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><span class="badge badge-teknis"><?= $ind['kategori'] ?></span></td>
            <td style="font-size:12px;font-weight:700;"><?= htmlspecialchars((string)($ind['ruang_lingkup'] ?? '')) ?></td>
            <td style="font-size:11px;"><?= htmlspecialchars(mb_strimwidth((string)($ind['kriteria'] ?? ''),0,60,'...')) ?></td>
            <td><?= pBar($ind['avg_pct'],100) ?></td>
            <td style="font-size:12px;color:var(--pln-red);"><?= number_format($ind['min_pct'],2) ?>%</td>
            <td style="font-size:12px;color:var(--pln-green);"><?= number_format($ind['max_pct'],2) ?>%</td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</div>
<?php endif; ?>

<?php if(empty($monthlyRows) && empty($ulpStats)): ?>
<div class="card">
    <div style="text-align:center;padding:40px;">
        <div style="font-size:48px;">📈</div>
        <div style="font-size:16px;font-weight:700;color:var(--pln-blue);margin-top:12px;">Belum ada data untuk dianalisis</div>
        <div style="color:var(--text-light);margin-top:8px;">Input realisasi SLA terlebih dahulu</div>
        <a href="input_sla.php" class="btn btn-primary" style="margin-top:16px;">✏️ Target & Realisasi</a>
    </div>
</div>
<?php endif; ?>

<?php if (count($monthlyRows) > 0): ?>
<!-- ── CHARTS ────────────────────────────────────────────── -->
<div class="chart-grid-2">
    <!-- Tren rata-rata SLA keseluruhan -->
    <div class="card" style="margin-bottom:0;">
        <div class="card-header">
            <div>
                <div class="card-title"><i class="bi bi-graph-up-arrow" style="color:var(--blue);"></i> Tren Rata-Rata SLA</div>
                <div class="card-subtitle">Rata-rata 4 kategori per kontrak</div>
            </div>
        </div>
        <div class="card-body"><div class="chart-wrap" style="--chart-h:260px;"><canvas id="chartRataRata"></canvas></div></div>
    </div>

    <!-- Radar / perbandingan kategori SLA per kontrak -->
    <div class="card" style="margin-bottom:0;">
        <div class="card-header">
            <div>
                <div class="card-title"><i class="bi bi-layers" style="color:var(--blue);"></i> Perbandingan Kategori SLA</div>
                <div class="card-subtitle">Teknis, K3, Kecelakaan, ILP per kontrak</div>
            </div>
        </div>
        <div class="card-body"><div class="chart-wrap" style="--chart-h:260px;"><canvas id="chartKategoriRata"></canvas></div></div>
    </div>
</div>

<?php if ($kontrak_id && count($ulpStats) > 0): ?>
<!-- Chart: SLA per ULP -->
<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title"><i class="bi bi-building" style="color:var(--blue);"></i> Rata-Rata SLA per ULP</div>
            <div class="card-subtitle">Kontrak: <?= htmlspecialchars($kontrak['nama_kontrak'] ?? '') ?> — <?= htmlspecialchars($kontrak['periode_bulan'] ?? '') ?> <?= $kontrak['tahun'] ?? '' ?></div>
        </div>
    </div>
    <div class="card-body"><div class="chart-wrap" style="--chart-h:260px;"><canvas id="chartULP"></canvas></div></div>
</div>
<?php endif; ?>

<?php
$labelsM = []; $avgSLAM = []; $teknisM = []; $k3M = []; $kelM = []; $ilpM = [];
foreach ($monthlyRows as $row) {
    $labelsM[]  = ($row['nama_kontrak'] ?? '') . ' ' . ($row['periode_bulan'] ?? '') . ' ' . ($row['tahun'] ?? '');
    $avgSLAM[]  = round((float)$row['avg_sla'], 2);
    $teknisM[]  = round((float)$row['sla_teknis'], 2);
    $k3M[]      = round((float)$row['sla_k3'], 2);
    $kelM[]     = round((float)$row['sla_kecelakaan'], 2);
    $ilpM[]     = round((float)$row['sla_ilp'], 2);
}
$labelsULP = []; $avgULP = [];
foreach ($ulpStats as $u) {
    $labelsULP[] = $u['ulp']['nama_ulp'] ?? 'ULP';
    $avgULP[]    = round((float)$u['avg_total'], 2);
}
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script src="assets/js/chart-helpers.js"></script>
<script>
(function(){
    SLAChart.init();

    var labelsM = <?= json_encode($labelsM) ?>;
    var avgSLA  = <?= json_encode($avgSLAM) ?>;
    var teknis  = <?= json_encode($teknisM) ?>;
    var k3      = <?= json_encode($k3M) ?>;
    var kel     = <?= json_encode($kelM) ?>;
    var ilp     = <?= json_encode($ilpM) ?>;

    // Tren rata-rata
    SLAChart.line(document.getElementById('chartRataRata'), {
        labels: labelsM,
        datasets: [{ label: 'Rata-rata SLA', data: avgSLA, borderColor: '#0066AE', backgroundColor: 'rgba(0,102,174,0.08)', fill: true }],
        ref: 100, tickLen: 18
    });

    // Perbandingan kategori
    SLAChart.line(document.getElementById('chartKategoriRata'), {
        labels: labelsM,
        datasets: [
            { label: 'Teknis',     data: teknis, borderColor: '#0066AE' },
            { label: 'K3',         data: k3,     borderColor: '#10b981' },
            { label: 'Kecelakaan', data: kel,    borderColor: '#F5A623', borderDash: [4, 3] },
            { label: 'ILP',        data: ilp,    borderColor: '#7c3aed', borderDash: [2, 3] }
        ],
        legend: true, ref: 100, tickLen: 18
    });

    <?php if ($kontrak_id && count($labelsULP) > 0): ?>
    // Per ULP
    SLAChart.bar(document.getElementById('chartULP'), {
        labels: <?= json_encode($labelsULP) ?>,
        datasets: [{ label: 'Rata-rata SLA', data: <?= json_encode($avgULP) ?>, backgroundColor: <?= json_encode(array_map(fn($v) => $v >= 90 ? 'rgba(16,185,129,0.82)' : ($v >= 70 ? 'rgba(245,166,35,0.82)' : 'rgba(220,38,38,0.82)'), $avgULP)) ?> }],
        ref: 100
    });
    <?php endif; ?>
})();
</script>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
