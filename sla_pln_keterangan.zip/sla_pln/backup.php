<?php
require_once 'includes/database.php';
require_once 'includes/backup.php';
requireAdmin();
$db = getDB();
$title = 'Backup Database';

// Backup manual (tombol "Backup Sekarang")
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['act'] ?? '') === 'backup_now') {
    csrfVerify();
    $result = createDatabaseBackup();
    if ($result['success']) {
        logAudit($db, 'create', 'backup', "Backup manual dibuat: {$result['file']} (" . formatUkuranBackup($result['size']) . ")");
        setFlash('success', '✅ Backup database berhasil dibuat: ' . $result['file']);
    } else {
        logAudit($db, 'create', 'backup', 'Backup manual GAGAL: ' . $result['message']);
        setFlash('danger', '❌ Backup database gagal: ' . $result['message']);
    }
    header('Location: backup.php'); exit;
}

// Hapus file backup
if (($_GET['act'] ?? '') === 'hapus' && !empty($_GET['file'])) {
    csrfVerify();
    $file = (string)$_GET['file'];
    if (deleteDatabaseBackup($file)) {
        logAudit($db, 'delete', 'backup', "Hapus file backup: $file");
        setFlash('success', 'File backup dihapus.');
    } else {
        setFlash('danger', 'File backup tidak ditemukan atau gagal dihapus.');
    }
    header('Location: backup.php'); exit;
}

// Unduh file backup
if (($_GET['act'] ?? '') === 'download' && !empty($_GET['file'])) {
    csrfVerify();
    $path = backupFilePath((string)$_GET['file']);
    if (!$path) {
        setFlash('danger', 'File backup tidak ditemukan.');
        header('Location: backup.php'); exit;
    }
    logAudit($db, 'read', 'backup', 'Unduh file backup: ' . basename($path));
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($path) . '"');
    header('Content-Length: ' . filesize($path));
    header('X-Content-Type-Options: nosniff');
    readfile($path);
    exit;
}

$backups       = listDatabaseBackups();
$totalSize     = array_sum(array_column($backups, 'size'));
$retentionDays = backupRetentionDays();
$cronToken     = getenv('BACKUP_CRON_TOKEN') ?: '';
$scriptPath    = realpath(__DIR__ . '/backup_database.php') ?: (__DIR__ . '/backup_database.php');
$cronLogPath   = dirname($scriptPath) . '/storage/backup/cron.log';
$cronUrl       = ($_SERVER['REQUEST_SCHEME'] ?? (!empty($_SERVER['HTTPS']) ? 'https' : 'http')) . '://'
               . ($_SERVER['HTTP_HOST'] ?? 'domain-anda') . '/backup_database.php?token=' . $cronToken;

include 'includes/header.php';
?>

<div class="card" style="margin-bottom:20px;">
    <div class="card-header">
        <div>
            <div class="card-title">💾 Backup Database</div>
            <div class="card-subtitle">Cadangkan seluruh data aplikasi (struktur &amp; isi tabel), manual atau terjadwal otomatis</div>
        </div>
        <form method="post" id="formBackupNow">
            <?= csrfField() ?>
            <input type="hidden" name="act" value="backup_now">
            <button type="submit" id="btnBackupNow" class="btn btn-primary"><i class="bi bi-database-fill-add"></i> Backup Sekarang</button>
        </form>
    </div>
    <div class="card-body">
        <div style="display:flex;gap:24px;flex-wrap:wrap;">
            <div><div class="text-muted" style="font-size:12px;">TOTAL FILE BACKUP</div><div style="font-size:20px;font-weight:700;"><?= count($backups) ?></div></div>
            <div><div class="text-muted" style="font-size:12px;">TOTAL UKURAN</div><div style="font-size:20px;font-weight:700;"><?= h(formatUkuranBackup($totalSize)) ?></div></div>
            <div><div class="text-muted" style="font-size:12px;">RETENSI</div><div style="font-size:20px;font-weight:700;"><?= (int)$retentionDays ?> hari</div></div>
        </div>
        <p class="text-muted" style="font-size:13px;margin-top:10px;margin-bottom:0;">
            File backup yang lebih lama dari <?= (int)$retentionDays ?> hari otomatis dihapus setiap kali proses backup berjalan.
            Ubah lewat variabel <code>BACKUP_RETENTION_DAYS</code> di file <code>.env</code>.
        </p>
    </div>
</div>

<div class="card" style="margin-bottom:20px;">
    <div class="card-header"><div><div class="card-title">⏰ Penjadwalan Otomatis (Cron)</div><div class="card-subtitle">Supaya backup berjalan sendiri setiap hari tanpa perlu dibuka manual</div></div></div>
    <div class="card-body">
        <p><strong>A. Server dengan akses SSH:</strong></p>
        <pre style="background:#f8fafc;padding:12px;border-radius:8px;overflow-x:auto;">crontab -e
# lalu tambahkan baris (contoh: backup tiap hari jam 01:00):
0 1 * * * php <?= h($scriptPath) ?> >> <?= h($cronLogPath) ?> 2>&1</pre>

        <p><strong>B. Shared hosting / cPanel — fitur "Cron Jobs":</strong></p>
        <pre style="background:#f8fafc;padding:12px;border-radius:8px;overflow-x:auto;">Command : php -q <?= h($scriptPath) ?>
Jadwal  : setiap hari jam 01:00 (atau sesuai kebutuhan)</pre>

        <p><strong>C. Hosting yang hanya punya "Cron via URL" (tanpa akses SSH):</strong></p>
        <?php if ($cronToken): ?>
        <pre style="background:#f8fafc;padding:12px;border-radius:8px;overflow-x:auto;word-break:break-all;"><?= h($cronUrl) ?></pre>
        <p class="text-muted" style="font-size:13px;">Jadwalkan URL di atas diakses otomatis (mis. tiap hari jam 01:00) lewat fitur cron hosting Anda.</p>
        <?php else: ?>
        <div class="alert alert-info" style="margin:0;">
            Isi <code>BACKUP_CRON_TOKEN</code> pada file <code>.env</code> dengan token rahasia (string acak, panjang), lalu muat ulang halaman ini untuk melihat URL cron opsi C.
        </div>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <div class="card-header"><div><div class="card-title">🗂️ Riwayat File Backup</div><div class="card-subtitle">Total <?= count($backups) ?> file tersimpan</div></div></div>
    <?php if (empty($backups)): ?>
    <div class="alert alert-info" style="margin:16px;">Belum ada file backup. Klik "Backup Sekarang" untuk membuat yang pertama.</div>
    <?php else: ?>
    <div class="table-wrap">
    <table>
        <thead><tr><th>#</th><th>Nama File</th><th>Ukuran</th><th>Dibuat</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($backups as $i => $b): ?>
        <tr>
            <td><?= $i + 1 ?></td>
            <td><i class="bi bi-file-earmark-zip"></i> <?= h($b['name']) ?></td>
            <td><?= h(formatUkuranBackup($b['size'])) ?></td>
            <td><?= h(date('d M Y H:i', $b['time'])) ?></td>
            <td>
                <div class="aksi-btn-group">
                    <a href="<?= h(csrfUrl('backup.php?act=download&file=' . urlencode($b['name']))) ?>" class="btn btn-secondary btn-sm"><i class="bi bi-download"></i> Unduh</a>
                    <a href="#" onclick="return confirmDelete('<?= h(csrfUrl('backup.php?act=hapus&file=' . urlencode($b['name']))) ?>','file backup <?= h($b['name']) ?>')" class="btn btn-danger btn-sm"><i class="bi bi-trash"></i> Hapus</a>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var form = document.getElementById('formBackupNow');
    var btn  = document.getElementById('btnBackupNow');
    if (btn && form) {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            showConfirm({
                title: 'Backup Database',
                message: 'Buat backup database sekarang? Proses ini bisa memakan waktu beberapa detik tergantung ukuran data.',
                icon: '💾',
                btnLabel: 'Ya, Backup Sekarang',
                btnClass: 'btn-primary'
            }, function () { form.submit(); });
        });
    }
});
</script>

<?php include 'includes/footer.php'; ?>
