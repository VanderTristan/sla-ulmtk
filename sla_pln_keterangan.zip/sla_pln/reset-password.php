<?php
/**
 * reset-password.php
 *
 * Halaman untuk mengatur password baru lewat link yang dikirim ke email
 * (lihat forgot-password.php). Token hanya berlaku 60 menit dan hanya bisa
 * dipakai sekali — langsung dihapus dari database setelah password berhasil diganti.
 */
require_once __DIR__ . '/includes/database.php';
$db = getDB();

if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$token = $_GET['token'] ?? $_POST['token'] ?? '';
$flash = getFlash();

$user = null;
if ($token !== '') {
    $user = dbRow($db, "SELECT id, nama, email FROM app_users
        WHERE reset_token = ? AND reset_token_expires IS NOT NULL AND reset_token_expires > NOW() LIMIT 1", [$token]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfVerify();
    if (!$user) {
        setFlash('danger', 'Link reset password tidak valid atau sudah kedaluwarsa. Silakan minta link baru.');
        header('Location: forgot-password.php');
        exit;
    }

    $password1 = (string)($_POST['password'] ?? '');
    $password2 = (string)($_POST['password_confirm'] ?? '');

    if (strlen($password1) < 8) {
        setFlash('danger', 'Password baru minimal 8 karakter.');
        header('Location: reset-password.php?token=' . urlencode($token));
        exit;
    }
    if ($password1 !== $password2) {
        setFlash('danger', 'Konfirmasi password tidak sama dengan password baru.');
        header('Location: reset-password.php?token=' . urlencode($token));
        exit;
    }

    $hash = password_hash($password1, PASSWORD_DEFAULT);
    dbExec($db, "UPDATE app_users SET password = ?, must_change_password = 0, reset_token = NULL, reset_token_expires = NULL WHERE id = ?",
        [$hash, $user['id']]);
    logAudit($db, 'reset_password', 'auth', 'Password berhasil direset lewat email untuk user_id=' . $user['id']);

    setFlash('success', 'Password berhasil diganti. Silakan masuk dengan password baru Anda.');
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atur Ulang Password — SLA Monitoring</title>
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16.png">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicon-180.png">
    <link rel="shortcut icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page">
    <div class="login-wrap">
        <div class="login-card">
            <div class="login-brand">
                <img src="assets/img/logo.png" alt="PLN Nusa Daya" style="height:64px;width:auto;object-fit:contain;display:block;margin:0 auto 12px;">
                <div class="login-sub">Atur Ulang Password</div>
            </div>

            <?= renderFlash($flash, 'margin-bottom:16px;') ?>

            <?php if (!$user): ?>
                <div class="alert alert-danger" style="margin-bottom:16px;">
                    <i class="bi bi-x-circle"></i>
                    <div>Link reset password tidak valid atau sudah kedaluwarsa.</div>
                </div>
                <div class="login-hint"><a href="forgot-password.php">Minta link reset password baru</a></div>
            <?php else: ?>
                <p style="font-size:13px;color:var(--text-light);margin-bottom:16px;">
                    Halo <b><?= h($user['nama']) ?></b>, masukkan password baru untuk akun Anda.
                </p>
                <form method="post" action="reset-password.php">
                    <?= csrfField() ?>
                    <input type="hidden" name="token" value="<?= h($token) ?>">
                    <div class="form-group">
                        <label>Password Baru</label>
                        <input type="password" name="password" placeholder="Minimal 8 karakter" required minlength="8" autofocus>
                    </div>
                    <div class="form-group">
                        <label>Konfirmasi Password Baru</label>
                        <input type="password" name="password_confirm" placeholder="Ulangi password baru" required minlength="8">
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan Password Baru</button>
                </form>
                <div class="login-hint"><a href="login.php">&larr; Kembali ke halaman login</a></div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
