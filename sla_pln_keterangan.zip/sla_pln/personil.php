<?php
require_once 'includes/database.php';
require_once 'includes/auth.php';

// Team Leader (Admin): kelola penuh. Manager UL (Monitoring): hanya lihat.
requireKendaraanPersonilAccess();
$canManage = canManageKendaraanPersonil();

$db = getDB();
$title = 'Data Personil';

$act = $_GET['act'] ?? 'list';
$id  = (int)($_GET['id'] ?? 0);

// Manager UL tidak boleh akses form tambah/edit/hapus
if (!$canManage && $act !== 'list') {
    setFlash('danger', 'Akses ditolak. Role Manager UL hanya dapat melihat data personil.');
    header('Location: personil.php'); exit;
}

$kontrakList = dbAll($db, "SELECT id, nama_kontrak, periode_bulan, tahun, tahap, jenis_kontrak FROM kontrak ORDER BY FIELD(jenis_kontrak,'DISTRIBUSI','TRANSMISI','PEMBANGKIT'), nama_kontrak ASC, tahun DESC, FIELD(periode_bulan,'JANUARI','FEBRUARI','MARET','APRIL','MEI','JUNI','JULI','AGUSTUS','SEPTEMBER','OKTOBER','NOVEMBER','DESEMBER') DESC, id DESC");

// Daftar ULP per kontrak (tabel `ulp` — sama persis dengan yang dipakai Input SLA
// di menu Data Kontrak), dikelompokkan per kontrak_id untuk dropdown ULP dinamis
// di form tambah/edit (menyesuaikan begitu Kontrak dipilih).
$ulpByKontrak = [];
foreach (dbAll($db, "SELECT id, kontrak_id, nama_ulp FROM ulp ORDER BY nama_ulp") as $u) {
    $ulpByKontrak[(int)$u['kontrak_id']][] = ['id' => (int)$u['id'], 'nama_ulp' => $u['nama_ulp']];
}

// ── DELETE ──────────────────────────────────────────────
if ($act === 'hapus' && $id) {
    if (!$canManage) { http_response_code(403); die('Akses ditolak.'); }
    csrfVerify();
    $old = dbRow($db, "SELECT * FROM personil WHERE id=?", [$id]);
    dbExec($db, "DELETE FROM personil WHERE id=?", [$id]);
    logAudit($db, 'delete', 'personil', "Hapus personil id=$id", $old ?: null, null);
    setFlash('success', '🗑️ Data personil berhasil dihapus.');
    header('Location: personil.php'); exit;
}

// ── SAVE (tambah / update) ─────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$canManage) { http_response_code(403); die('Akses ditolak.'); }
    csrfVerify();
    $fields = [
        'kontrak_id'   => (int)($_POST['kontrak_id'] ?? 0),
        'ulp_id'       => (int)($_POST['ulp_id'] ?? 0) ?: null,
        'nama_ulp'     => trim($_POST['nama_ulp'] ?? ''),
        'nama_kp'      => trim($_POST['nama_kp'] ?? ''),
        'daftar_tim'   => trim($_POST['daftar_tim'] ?? ''),
        'nama_petugas' => trim($_POST['nama_petugas'] ?? ''),
        'jabatan'      => trim($_POST['jabatan'] ?? ''),
        'no_hp'        => trim($_POST['no_hp'] ?? ''),
    ];
    // Lepas link ULP kalau ternyata bukan milik kontrak yang dipilih (mis. operator
    // ganti Kontrak setelah sempat memilih ULP) — nama_ulp yang sudah keisi tetap dipakai.
    if ($fields['ulp_id'] && !dbVal($db, "SELECT COUNT(*) FROM ulp WHERE id=? AND kontrak_id=?", [$fields['ulp_id'], $fields['kontrak_id']])) {
        $fields['ulp_id'] = null;
    }
    if (!$fields['kontrak_id'] || $fields['nama_petugas'] === '') {
        setFlash('danger', 'Kontrak dan Nama Petugas wajib diisi.');
        header('Location: personil.php?act=' . ($id ? 'edit&id=' . $id : 'tambah')); exit;
    }

    // Cek data double: nama petugas yang sama pada kontrak yang sama
    $dupPersonil = (bool)dbVal($db,
        "SELECT COUNT(*) FROM personil WHERE kontrak_id=? AND LOWER(TRIM(nama_petugas))=LOWER(TRIM(?)) AND id<>?",
        [$fields['kontrak_id'], $fields['nama_petugas'], $id]);
    if ($dupPersonil) {
        setFlash('danger', "⚠️ Data gagal disimpan: Petugas \"{$fields['nama_petugas']}\" sudah terdaftar pada kontrak ini.");
        header('Location: personil.php?act=' . ($id ? 'edit&id=' . $id : 'tambah')); exit;
    }

    if ($id) {
        $old = dbRow($db, "SELECT * FROM personil WHERE id=?", [$id]);
        $sets = implode(',', array_map(fn($k) => "$k=?", array_keys($fields)));
        $vals = array_values($fields);
        $vals[] = $id;
        dbExec($db, "UPDATE personil SET $sets WHERE id=?", $vals);
        [$lama, $baru] = diffFields($old ?: [], $fields);
        logAudit($db, 'update', 'personil', "Update personil id=$id", $lama ?: null, $baru ?: null);
        $msg = 'success_update';
    } else {
        $cols = implode(',', array_keys($fields));
        $phs  = implode(',', array_fill(0, count($fields), '?'));
        dbExec($db, "INSERT INTO personil ($cols) VALUES ($phs)", array_values($fields));
        logAudit($db, 'create', 'personil', "Tambah personil: " . $fields['nama_petugas'], null, $fields);
        $msg = 'success_create';
    }
    setFlash('success', $msg === 'success_create' ? '✅ Data personil berhasil ditambahkan.' : '✅ Data personil berhasil diperbarui.');
    header("Location: personil.php"); exit;
}

$editData = null;
if ($act === 'edit' && $id) {
    $editData = dbRow($db, "SELECT * FROM personil WHERE id=?", [$id]);
}

// ── LIST + FILTER ───────────────────────────────────────
$kontrak_id = (int)($_GET['kontrak_id'] ?? 0);
$q          = trim($_GET['q'] ?? '');

require_once 'includes/kontrak_selector.php';
$sel = kontrakSelectorInit($db, $kontrak_id);

$where  = [];
$params = [];
if ($kontrak_id) {
    $where[] = "p.kontrak_id = ?";
    $params[] = $kontrak_id;
} elseif ($sel['unit'] !== '') {
    // Project dipilih tapi belum memilih kontrak tertentu -> tampilkan data semua kontrak di Project itu
    $pUnit = [];
    $wUnit = ksUnitWhere($sel['jenis'], $sel['unit'], $pUnit);
    $where[] = "p.kontrak_id IN (SELECT id FROM kontrak WHERE $wUnit)";
    $params = array_merge($params, $pUnit);
}
if ($q !== '') {
    $where[] = "(p.nama_petugas LIKE ? OR p.jabatan LIKE ? OR p.nama_ulp LIKE ? OR u.nama_ulp LIKE ? OR p.nama_kp LIKE ?)";
    $like = "%$q%";
    array_push($params, $like, $like, $like, $like, $like);
}
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$personilList = dbAll($db, "
    SELECT p.*, c.nama_kontrak AS kontrak_nama, c.periode_bulan, c.tahun,
           u.nama_ulp AS ulp_terhubung,
           COALESCE(u.nama_ulp, p.nama_ulp) AS ulp_tampil
    FROM personil p
    JOIN kontrak c ON c.id = p.kontrak_id
    LEFT JOIN ulp u ON u.id = p.ulp_id
    $whereSql
    ORDER BY c.id DESC, ulp_tampil, p.id
", $params);

require 'includes/header.php';
?>

<?php if ($act !== 'list'): ?>
<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title"><?= $editData ? '✏️ Edit Personil' : '➕ Tambah Personil' ?></div>
            <div class="card-subtitle">Data petugas / personil per kontrak</div>
        </div>
        <a href="personil.php" class="btn btn-outline btn-sm">← Kembali</a>
    </div>
    <div class="card-body">
    <form method="POST">
        <?= csrfField() ?>
        <input type="hidden" name="ulp_id" id="ulp_id" value="<?= h((string)($editData['ulp_id'] ?? '')) ?>">
        <div class="form-grid">
            <div class="form-group" style="grid-column:1/-1">
                <label>Kontrak <span style="color:var(--pln-red);">*</span></label>
                <select class="form-control" name="kontrak_id" id="kontrak_id_field" required data-kontrak-picker data-placeholder="-- Pilih Project --">
                    <option value="">-- Pilih Project --</option>
                    <?php foreach ($kontrakList as $k): ?>
                    <option value="<?= $k['id'] ?>" <?= ($editData['kontrak_id'] ?? 0) == $k['id'] ? 'selected' : '' ?> <?= kontrakOptionAttrs($k) ?>>
                        <?= h(kontrakSelectLabel($k)) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="grid-column:1/-1">
                <label>Pilih dari Data ULP kontrak ini (opsional)</label>
                <select class="form-control" id="ulp_picker">
                    <option value="">-- Isi manual / Gabungan --</option>
                </select>
                <div style="font-size:11px;color:var(--text-light);margin-top:4px;">Menyesuaikan otomatis dengan daftar ULP yang dipakai di menu Input SLA untuk kontrak ini. Pilih untuk isi otomatis field "Nama ULP" di bawah (tetap bisa diubah manual). Kelola daftarnya di menu <a href="input_ulp.php" target="_blank">Data ULP</a>.</div>
            </div>
            <div class="form-group">
                <label>Nama ULP</label>
                <input class="form-control" name="nama_ulp" id="nama_ulp_field" value="<?= h($editData['nama_ulp'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Nama KP/KJ</label>
                <input class="form-control" name="nama_kp" value="<?= h($editData['nama_kp'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Tim</label>
                <input class="form-control" name="daftar_tim" value="<?= h($editData['daftar_tim'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Nama Petugas <span style="color:var(--pln-red);">*</span></label>
                <input class="form-control" name="nama_petugas" required value="<?= h($editData['nama_petugas'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Jabatan</label>
                <input class="form-control" name="jabatan" placeholder="Mis. KOORDINATOR / PELAYANAN TEKNIK / K3" value="<?= h($editData['jabatan'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>No. HP</label>
                <input class="form-control" name="no_hp" value="<?= h($editData['no_hp'] ?? '') ?>">
            </div>
        </div>
        <hr class="divider">
        <div style="display:flex;gap:10px;justify-content:flex-end;">
            <a href="personil.php" class="btn btn-outline">Batal</a>
            <button type="submit" class="btn btn-primary">💾 Simpan Personil</button>
        </div>
    </form>
    <script>
    var ulpByKontrak = <?= json_encode($ulpByKontrak, JSON_UNESCAPED_UNICODE) ?>;
    var editUlpId = <?= json_encode((int)($editData['ulp_id'] ?? 0)) ?>;

    function isiPilihanUlp(kontrakId, selectedUlpId) {
        var picker = document.getElementById('ulp_picker');
        picker.innerHTML = '<option value="">-- Isi manual / Gabungan --</option>';
        var list = ulpByKontrak[String(kontrakId)] || [];
        list.forEach(function (u) {
            var opt = document.createElement('option');
            opt.value = u.id;
            opt.textContent = u.nama_ulp;
            if (selectedUlpId && parseInt(selectedUlpId, 10) === u.id) opt.selected = true;
            picker.appendChild(opt);
        });
    }

    document.getElementById('ulp_picker').addEventListener('change', function () {
        var opt = this.options[this.selectedIndex];
        document.getElementById('ulp_id').value = opt.value || '';
        var f = document.getElementById('nama_ulp_field');
        if (opt.value) f.value = opt.textContent;
        f.readOnly = !!opt.value;   // dipilih dari dropdown -> nama dikunci, tidak bisa salah ketik
    });

    document.getElementById('kontrak_id_field').addEventListener('change', function () {
        document.getElementById('ulp_id').value = '';
        isiPilihanUlp(this.value, null);
        document.getElementById('nama_ulp_field').readOnly = false;
    });

    isiPilihanUlp(document.getElementById('kontrak_id_field').value, editUlpId);
    if (editUlpId) document.getElementById('nama_ulp_field').readOnly = true;
    </script>
    </div>
</div>

<?php else: ?>

<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title"><i class="bi bi-people"></i> Data Personil</div>
            <div class="card-subtitle">Total <?= count($personilList) ?> orang</div>
        </div>
        <?php if ($canManage): ?>
        <a href="personil.php?act=tambah" class="btn btn-primary">+ Tambah Personil</a>
        <?php else: ?>
        <span class="badge badge-info" style="padding:6px 12px;font-size:12px;"><i class="bi bi-eye"></i> Mode Lihat Saja</span>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <?php renderKontrakSelectorFields($sel, 'personil.php', ['btnLabel' => 'Lihat Personil']); ?>
        <div style="height:14px;"></div>
        <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
            <?php foreach (["jenis" => $sel["jenis"] !== "ALL" ? $sel["jenis"] : "", "unit_id" => $sel["unit"], "kontrak_id" => $kontrak_id ?: ""] as $hn => $hv): if ($hv === "") continue; ?>
            <input type="hidden" name="<?= $hn ?>" value="<?= h((string)$hv) ?>">
            <?php endforeach; ?>
            <div class="form-group" style="flex:1;min-width:220px;">
                <label>Cari (nama, jabatan, ULP)</label>
                <input class="form-control" type="text" name="q" value="<?= h($q) ?>" placeholder="Mis. KOORDINATOR / TONDANO / nama petugas">
            </div>
            <div class="form-group">
                <button class="btn btn-primary" type="submit"><i class="bi bi-search"></i> Cari</button>
                <a href="personil.php" class="btn btn-outline">Reset</a>
            </div>
        </form>
    </div>
</div>

<?php renderKontrakListCard($sel, 'personil.php', ['btnLabel' => 'Lihat Personil']); ?>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Kontrak</th>
                    <th>Nama ULP</th>
                    <th>Nama KP/KJ</th>
                    <th>Tim</th>
                    <th>Nama Petugas</th>
                    <th>Jabatan</th>
                    <th>No. HP</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($personilList as $i => $r):
                    $jab = strtoupper((string)$r['jabatan']);
                    $jabClass = match(true) {
                        str_contains($jab, 'MANAGER') || str_contains($jab, 'KOORDINATOR') => 'badge-purple',
                        str_contains($jab, 'K3')                                            => 'badge-danger',
                        str_contains($jab, 'PELAYANAN TEKNIK')                              => 'badge-info',
                        default                                                             => 'badge-warning',
                    };
                ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td style="font-size:11px;"><?= h($r['kontrak_nama'] ?? '-') ?><br><span style="color:var(--gray-400);"><?= h($r['periode_bulan']) ?> <?= $r['tahun'] ?></span></td>
                    <td>
                        <?= h($r['ulp_tampil'] ?? '-') ?>
                        <?php if ($r['ulp_terhubung']): ?>
                        <br><span class="badge badge-success" style="font-size:9px;">🔗 Data ULP</span>
                        <?php endif; ?>
                    </td>
                    <td><?= h($r['nama_kp'] ?? '-') ?></td>
                    <td><?= h($r['daftar_tim'] ?? '-') ?></td>
                    <td><strong><?= h($r['nama_petugas']) ?></strong></td>
                    <td><span class="badge <?= $jabClass ?>"><?= h($r['jabatan'] ?? '-') ?></span></td>
                    <td><?= h((string)($r['no_hp'] ?? '-')) ?></td>
                    <td>
                        <?php if ($canManage): ?>
                        <div class="aksi-btn-group">
                            <a href="personil.php?act=edit&id=<?= $r['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="#" onclick="confirmDelete('<?= csrfUrl('personil.php?act=hapus&id=' . $r['id']) ?>','personil ini')" class="btn btn-danger btn-sm">Hapus</a>
                        </div>
                        <?php else: ?>
                        <span style="color:var(--gray-400);font-size:12px;">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($personilList)): ?>
                <tr><td colspan="9" style="text-align:center;color:var(--gray-400);padding:24px;">Tidak ada data personil yang cocok.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php require 'includes/footer.php'; ?>