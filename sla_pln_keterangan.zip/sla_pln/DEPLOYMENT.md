# Checklist Deploy ke Produksi — SLA PLN Nusa Daya

Ikuti urutan ini sebelum sistem dipakai untuk data SLA resmi perusahaan.

## 1. Server & PHP
- [ ] PHP 8.0+ dengan ekstensi `pdo_mysql`, `mbstring`, `fileinfo` aktif.
- [ ] Web server (Apache/Nginx) mengarah ke folder `sla_pln_out/` sebagai document root.
- [ ] HTTPS aktif (sertifikat SSL/TLS) — wajib, karena cookie sesi diset `secure` otomatis saat HTTPS terdeteksi.
- [ ] Pastikan `.htaccess` aktif (Apache: `AllowOverride All`) supaya file `.env`, `*.sql`, `README.txt`, `DEPLOYMENT.md` tidak bisa diakses langsung lewat browser.

## 2. Database
- [ ] Buat database MySQL/MariaDB khusus, bukan menumpang database lain.
- [ ] Buat **user MySQL khusus** untuk aplikasi (bukan `root`), dengan privilege terbatas hanya ke database ini:
  ```sql
  CREATE USER 'sla_pln_app'@'%' IDENTIFIED BY 'password_kuat_unik';
  GRANT SELECT, INSERT, UPDATE, DELETE ON sla_pln.* TO 'sla_pln_app'@'%';
  FLUSH PRIVILEGES;
  ```
- [ ] Aktifkan **backup otomatis harian** sebelum sistem dipakai untuk data resmi. Sudah tersedia built-in di aplikasi ini:
  - Halaman **Backup Database** (menu Admin) untuk backup manual kapan saja + kelola/unduh/hapus file backup.
  - Skrip `backup_database.php` untuk dijadwalkan otomatis lewat cron — lihat instruksi lengkap (3 opsi sesuai jenis hosting) di komentar awal file tersebut, atau langsung di halaman **Backup Database**.
  - File backup (`.sql.gz`) disimpan di `storage/backup/` (folder ini sudah diproteksi `Require all denied`, tidak bisa diakses langsung lewat browser) dan otomatis dihapus setelah `BACKUP_RETENTION_DAYS` hari (atur di `.env`, default 30 hari).

## 3. Konfigurasi Environment
- [ ] Copy `.env.example` menjadi `.env`, isi dengan kredensial produksi (DB host/port/nama/user/password server produksi).
- [ ] Set `APP_ENV=production` di `.env` — ini menonaktifkan tampilan error PHP ke browser.
- [ ] **Jangan** commit file `.env` ke Git/SVN/source control apa pun.

## 4. Akun & Password
- [ ] Login pertama kali dengan akun `admin` default, lalu **segera ganti password** lewat menu Kelola User (sistem akan menampilkan banner pengingat sampai diganti).
- [ ] Buat akun untuk masing-masing user sesuai role (Admin/Monitoring/Viewer) — jangan bagi-pakai satu akun admin untuk banyak orang, supaya audit log tetap akurat.
- [ ] Nonaktifkan (status "Nonaktif") akun yang tidak lagi dipakai, bukan dihapus, supaya riwayat data tetap konsisten.

## 5. Keamanan yang Sudah Diterapkan
- [x] Semua query database pakai prepared statement (PDO) — aman dari SQL injection.
- [x] Password user di-hash dengan `password_hash()` (bcrypt).
- [x] Proteksi CSRF di semua form dan aksi hapus (token tervalidasi server-side).
- [x] Cookie sesi: `HttpOnly`, `SameSite=Lax`, otomatis `Secure` saat HTTPS.
- [x] Rate limiting login: 5x gagal dalam 15 menit → terkunci sementara (per username & per IP).
- [x] Audit log (tabel `audit_log`) mencatat create/update/delete/login pada modul-modul utama.
- [x] Kredensial database tidak lagi hardcoded di kode, dimuat dari `.env`.

## 6. Uji Coba Sebelum Go-Live
- [ ] Uji seluruh modul di environment **staging** dulu (bukan langsung produksi): Kontrak, Vendor, Indikator, Input Monitoring Harian, Rekap SLA, Cetak Laporan (Harian/Mingguan/Bulanan/Tahunan).
- [ ] Validasi hasil perhitungan SLA & denda terhadap contoh kasus nyata/Excel sebelum dipakai sebagai acuan resmi pembayaran tagihan vendor.
- [ ] Cek halaman dari beberapa role (Admin, Monitoring, Viewer) untuk memastikan pembatasan akses sesuai.

## 7. Notifikasi Email (opsional, disarankan)
Aplikasi bisa mengirim email otomatis untuk 3 hal: (1) ke Manager UL/Team Leader saat ada data harian baru menunggu verifikasi, (2) ke Petugas saat data hariannya Disetujui/Ditolak, (3) link reset password saat user lupa password. Lihat `.env.example` bagian **EMAIL / SMTP** untuk daftar lengkap variabel.
- [ ] Isi `MAIL_HOST`, `MAIL_PORT`, `MAIL_ENCRYPTION`, `MAIL_USERNAME`, `MAIL_PASSWORD`, `MAIL_FROM_EMAIL`, `MAIL_FROM_NAME` di `.env` sesuai penyedia SMTP (Gmail App Password, atau SMTP dari hosting/cPanel).
- [ ] Set `MAIL_ENABLED=1` untuk mengaktifkan. Selama `0`, semua fitur email di-skip otomatis (aplikasi tetap jalan normal).
- [ ] Isi `APP_URL` dengan URL produksi (mis. `https://sla.plnnusadaya.co.id`) supaya link di dalam email mengarah ke domain yang benar.
- [ ] Pastikan setiap akun user (menu Kelola User) sudah diisi alamat email yang valid & aktif dipakai — notifikasi dikirim ke email yang tercatat di akun masing-masing.
- [ ] Uji kirim email di staging dulu (coba fitur "Lupa Password" di halaman login) sebelum go-live.

## 8. Operasional Lanjutan (disarankan, di luar lingkup kode ini)
- [ ] Pantau `audit_log` secara berkala untuk aktivitas tidak wajar.
- [ ] Siapkan SOP penggantian password berkala dan SOP saat karyawan resign (nonaktifkan akun).
- [ ] Pertimbangkan menambahkan two-factor authentication (2FA) untuk akun Admin jika kebutuhan compliance perusahaan mengharuskan.
