<?php
require_once 'includes/database.php';
require_once 'includes/auth.php';

// Hanya Admin yang boleh akses
requireAdmin();

$db = getDB();
$title = 'Kelola User';

$userList = dbAll($db, "SELECT * FROM app_users ORDER BY id");

require 'includes/header.php';
?>

<div style="display:flex;justify-content:flex-end;margin-bottom:14px;">
    <a class="btn btn-primary" href="user-form.php">
        <i class="bi bi-plus-lg"></i> Tambah User
    </a>
</div>

<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title">Kelola Pengguna</div>
            <div class="card-subtitle">Daftar semua pengguna yang terdaftar di sistem</div>
        </div>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($userList as $i => $u):
                    $roleClass = match($u['role']) {
                        'SuperAdmin' => 'badge-danger',
                        'Admin'      => 'badge-purple',
                        'Monitoring' => 'badge-info',
                        'Koordinator'=> 'badge-success',
                        default      => 'badge-warning',
                    };
                ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><strong><?= h($u['nama']) ?></strong></td>
                    <td><?= h($u['username']) ?></td>
                    <td><?= h($u['email']) ?></td>
                    <td><span class="badge <?= $roleClass ?>"><?= h(roleLabel($u['role'])) ?></span></td>
                    <td><span class="badge <?= $u['status'] === 'Aktif' ? 'badge-success' : 'badge-danger' ?>"><?= h($u['status']) ?></span></td>
                    <td>
                        <a class="btn btn-sm btn-secondary" href="user-form.php?id=<?= (int)$u['id'] ?>" title="Edit">
                            <i class="bi bi-pencil"></i> Edit
                        </a>
                        <?php if ((int)$u['id'] !== (int)(currentUser()['id'] ?? 0)): ?>
                        <a class="btn btn-sm btn-danger" style="margin-left:4px;" href="#" title="Hapus"
                           onclick="showConfirm({
                               title:'Hapus User',
                               message:'Yakin hapus user <strong><?= h(addslashes($u['nama'])) ?></strong>? Tindakan ini tidak dapat dibatalkan.',
                               icon:'🗑️',
                               btnLabel:'Ya, Hapus',
                               btnClass:'btn-danger'
                           }, function(){ window.location='<?= csrfUrl('user-delete.php?id=' . (int)$u['id']) ?>'; });
                           return false;">
                            <i class="bi bi-trash"></i> Hapus
                        </a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($userList)): ?>
                <tr><td colspan="7" style="text-align:center;color:var(--gray-400);padding:24px;">Belum ada data pengguna.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require 'includes/footer.php'; ?>
