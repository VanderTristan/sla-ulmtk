<?php
/**
 * export_input_sla.php — Export halaman "Input SLA" sebuah kontrak ke file .xlsx.
 *
 * Isinya sama dengan tabel di Input SLA (Target, Realisasi, % Pencapaian, Catatan)
 * lengkap dengan WAKTU INPUT Target & Realisasi (sampai detik), untuk KEDUA periode
 * sekaligus (Periode 1 & Periode 2) supaya satu file sudah cukup untuk satu bulan.
 *
 * Yang diekspor adalah data yang SUDAH TERSIMPAN di database (bukan isian yang
 * baru diketik tapi belum disimpan).
 *
 * Dipanggil dari: input_harian.php -> tombol "Export Excel"
 * Contoh URL: export_input_sla.php?kontrak_id=6
 *
 * Hak akses mengikuti halaman Input SLA (requireInputAccess), bukan halaman laporan —
 * supaya petugas yang menginput data juga bisa mengunduh isiannya sendiri.
 */
require_once 'includes/database.php';
require_once 'includes/xlsx_writer.php';

$db = getDB();
requireInputAccess();

$kontrak_id = (int)($_GET['kontrak_id'] ?? 0);
if (!$kontrak_id) {
    http_response_code(400);
    die('Parameter kontrak_id wajib diisi.');
}
$kontrak = dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$kontrak_id]);
if (!$kontrak) {
    http_response_code(404);
    die('Kontrak tidak ditemukan.');
}

$fmtWaktu = static function ($v): string {
    return !empty($v) ? date('d/m/Y H:i:s', strtotime((string)$v)) : '';
};
$angka = static function ($v) {
    return ($v === null || $v === '') ? '' : (float)$v;
};

// Indikator level kontrak (Gabungan) — sama dengan yang tampil di halaman Input SLA
$entries = dbAll($db,
    "SELECT * FROM sla_entries WHERE kontrak_id=? AND ulp_id IS NULL ORDER BY kategori, no_urut", [$kontrak_id]);

// Data per periode (1 & 2) untuk semua indikator, diambil sekali jalan
$harian = []; // [sla_entry_id][periode] => row
if ($entries) {
    $ids = array_map('intval', array_column($entries, 'id'));
    $ph  = implode(',', array_fill(0, count($ids), '?'));
    foreach (dbAll($db,
        "SELECT sla_entry_id, periode, nilai_harian, catatan, updated_at
         FROM monitoring_harian WHERE sla_entry_id IN ($ph) AND periode IN (1,2)", $ids) as $h) {
        $harian[(int)$h['sla_entry_id']][(int)$h['periode']] = $h;
    }
}

$katLabel = ['TEKNIS' => 'TEKNIS', 'K3' => 'K3', 'KECELAKAAN' => 'KECELAKAAN KERJA', 'ILP' => 'ILP'];

$header = [
    'KATEGORI', 'NO', 'RUANG LINGKUP', 'KRITERIA', 'SATUAN', 'POLARITAS',
    'TARGET', 'REALISASI PERIODE 1', 'REALISASI PERIODE 2',
    'REALISASI BULANAN', '% PENCAPAIAN',
    'CATATAN PERIODE 1', 'CATATAN PERIODE 2',
];
$rows = [$header];
$kategoriUrut = array_keys($katLabel);
usort($entries, static function ($a, $b) use ($kategoriUrut) {
    $ka = array_search($a['kategori'], $kategoriUrut, true); if ($ka === false) $ka = 99;
    $kb = array_search($b['kategori'], $kategoriUrut, true); if ($kb === false) $kb = 99;
    return $ka <=> $kb ?: strnatcmp((string)$a['no_urut'], (string)$b['no_urut']);
});
foreach ($entries as $e) {
    $p1 = $harian[(int)$e['id']][1] ?? null;
    $p2 = $harian[(int)$e['id']][2] ?? null;
    $belumDinilai = $e['persen_pencapaian'] === null;
    $rows[] = [
        $katLabel[$e['kategori']] ?? (string)$e['kategori'],
        (string)($e['no_urut'] ?? ''),
        (string)($e['ruang_lingkup'] ?? ''),
        (string)($e['kriteria'] ?? ''),
        (string)($e['satuan'] ?? ''),
        (string)($e['polaritas'] ?? ''),
        $angka($e['target']),
        $p1 ? $angka($p1['nilai_harian']) : '',
        $p2 ? $angka($p2['nilai_harian']) : '',
        $angka($e['realisasi']),
        $belumDinilai ? 'Belum Dinilai' : round((float)$e['persen_pencapaian'], 2),
        (string)($p1['catatan'] ?? ''),
        (string)($p2['catatan'] ?? ''),
    ];
}
if (count($rows) === 1) {
    $rows[] = ['-', '', 'Kontrak ini belum punya indikator SLA', '', '', '', '', '', '', '', '', '', ''];
}

$xlsx = new SimpleXlsxWriter();

// ── Sheet 1: Info kontrak & waktu simpan terakhir tiap periode
$statusPeriode = getStatusPeriodeInput($db, $kontrak_id);
$info = [['Keterangan', 'Isi']];
$info[] = ['Nama Kontrak', (string)($kontrak['nama_kontrak'] ?? '')];
$info[] = ['Vendor', (string)($kontrak['vendor'] ?? '')];
$info[] = ['Bidang', (string)($kontrak['jenis_kontrak'] ?? '')];
$info[] = ['Periode Kontrak', trim((string)($kontrak['periode_bulan'] ?? '') . ' ' . (string)($kontrak['tahun'] ?? ''))];
$info[] = ['Tahap', (string)($kontrak['tahap'] ?? '')];
foreach ([1 => 'tgl 1-15', 2 => 'tgl 16-akhir bulan'] as $p => $rentang) {
    $s = $statusPeriode[$p] ?? null;
    $info[] = ["Periode $p ($rentang) — indikator terisi", $s ? ($s['terisi'] . ' dari ' . $s['total']) : 'Belum ada data'];
    $info[] = ["Periode $p — waktu input kontrak (terakhir disimpan)", $s ? $fmtWaktu($s['terakhir_input']) : ''];
}
$info[] = ['Diekspor pada', date('d/m/Y H:i:s')];
$user = currentUser();
$info[] = ['Diekspor oleh', (string)($user['nama'] ?? ($user['username'] ?? ''))];

$xlsx->addSheet('Input SLA', $rows, true, [18, 7, 26, 44, 10, 11, 10, 13, 13, 13, 12, 28, 28]);
$xlsx->addSheet('Info Kontrak', $info, true, [42, 44]);

logAudit($db, 'export', 'monitoring_harian', "Export Excel Input SLA kontrak_id=$kontrak_id");

$safeFileName = preg_replace('/[^A-Za-z0-9_-]+/', '_', (string)($kontrak['nama_kontrak'] ?? 'kontrak'));
$filename = 'Input_SLA_' . substr($safeFileName, 0, 60) . '_' . date('Ymd') . '.xlsx';
$xlsx->download($filename);
