<?php
/**
 * theme_save.php
 * Endpoint AJAX kecil untuk menyimpan preferensi mode tampilan
 * (light/dark) ke akun user yang login — dipanggil oleh tombol
 * toggle tema di topbar (lihat includes/header.php). Dengan begini
 * pilihan tema ikut terbawa walau user pindah browser/device,
 * bukan cuma tersimpan di localStorage.
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/database.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'Belum login.']);
    exit;
}

$token = $_POST['csrf_token'] ?? '';
if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Token keamanan tidak valid.']);
    exit;
}

$theme = ($_POST['theme'] ?? '') === 'dark' ? 'dark' : 'light';

$db = getDB();
$userId = (int)(currentUser()['id'] ?? 0);
if ($userId > 0) {
    dbExec($db, "UPDATE app_users SET theme_preference=? WHERE id=?", [$theme, $userId]);
    $_SESSION['user']['theme_preference'] = $theme;
}

echo json_encode(['ok' => true, 'theme' => $theme]);
