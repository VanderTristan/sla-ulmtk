<?php
require_once 'includes/database.php';
require_once 'includes/auth.php';

requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: users.php');
    exit;
}

csrfVerify();

$db = getDB();

$id              = (int)($_POST['id'] ?? 0);
$nama            = trim($_POST['nama'] ?? '');
$username        = trim($_POST['username'] ?? '');
$email           = trim($_POST['email'] ?? '');
$role            = $_POST['role'] ?? 'Viewer';
if (!in_array($role, ['SuperAdmin', 'Admin', 'Monitoring', 'Viewer', 'Koordinator'], true)) {
    $role = 'Viewer';
}
$status          = $_POST['status'] ?? 'Aktif';
$password        = (string)($_POST['password'] ?? '');
$passwordConfirm = (string)($_POST['password_confirm'] ?? '');

$backUrl = 'user-form.php' . ($id ? '?id=' . $id : '');

if ($nama === '' || $username === '' || $email === '') {
    setFlash('danger', 'Nama, username, dan email wajib diisi.');
    header('Location: ' . $backUrl);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    setFlash('danger', 'Format email tidak valid.');
    header('Location: ' . $backUrl);
    exit;
}

// Username harus unik (kecuali milik user yang sedang diedit)
$check = $db->prepare("SELECT id FROM app_users WHERE username = ? AND id != ?");
$check->execute([$username, $id]);
if ($check->fetch()) {
    setFlash('danger', 'Username "' . h($username) . '" sudah digunakan.');
    header('Location: ' . $backUrl);
    exit;
}

// Validasi password
if ($id === 0 && $password === '') {
    setFlash('danger', 'Password wajib diisi untuk user baru.');
    header('Location: ' . $backUrl);
    exit;
}
if ($password !== '' && strlen($password) < 6) {
    setFlash('danger', 'Password minimal 6 karakter.');
    header('Location: ' . $backUrl);
    exit;
}
if ($password !== '' && $password !== $passwordConfirm) {
    setFlash('danger', 'Konfirmasi password tidak sama.');
    header('Location: ' . $backUrl);
    exit;
}

if ($id > 0) {
    $oldUser = dbRow($db, "SELECT nama, username, email, role, status FROM app_users WHERE id=?", [$id]);
    $newFields = ['nama'=>$nama, 'username'=>$username, 'email'=>$email, 'role'=>$role, 'status'=>$status];
    [$lamaC, $baruC] = diffFields($oldUser ?: [], $newFields);
    if ($password !== '') {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        dbExec($db, "UPDATE app_users SET nama=?, username=?, email=?, role=?, status=?, password=?, must_change_password=0 WHERE id=?",
            [$nama, $username, $email, $role, $status, $hash, $id]);
        $lamaC['password'] = '(tersembunyi)'; $baruC['password'] = '(diganti)';
        logAudit($db, 'update', 'user', "Update user id=$id (password diganti)", $lamaC ?: null, $baruC ?: null);
    } else {
        dbExec($db, "UPDATE app_users SET nama=?, username=?, email=?, role=?, status=? WHERE id=?",
            [$nama, $username, $email, $role, $status, $id]);
        logAudit($db, 'update', 'user', "Update user id=$id", $lamaC ?: null, $baruC ?: null);
    }
    // Jika user yang sedang login mengubah passwordnya sendiri, perbarui flag di session
    if ($id === (int)(currentUser()['id'] ?? 0)) {
        $_SESSION['user']['must_change_password'] = false;
    }
    setFlash('success', 'User "' . $nama . '" berhasil diperbarui.');
} else {
    $hash = password_hash($password, PASSWORD_DEFAULT);
    dbExec($db, "INSERT INTO app_users (nama, username, email, password, role, status) VALUES (?, ?, ?, ?, ?, ?)",
        [$nama, $username, $email, $hash, $role, $status]);
    logAudit($db, 'create', 'user', "Tambah user: $username", null, ['nama'=>$nama,'username'=>$username,'email'=>$email,'role'=>$role,'status'=>$status]);
    setFlash('success', 'User "' . $nama . '" berhasil ditambahkan.');
}

header('Location: users.php');
exit;
