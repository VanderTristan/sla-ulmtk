<?php
/**
 * ulp_master.php
 *
 * Master ULP — daftar ULP GLOBAL (nama, Manager PLN, Koordinator ND) yang bisa
 * dipakai ulang di banyak kontrak, supaya operator tidak perlu ketik ulang data
 * yang sama tiap kali menambah ULP baru untuk kontrak lain.
 *
 * Ini TERPISAH dari Data ULP per-kontrak (menu "Data ULP" / input_ulp.php):
 * - Master ULP (di sini): daftar global, cuma referensi/sumber isian cepat.
 * - Data ULP per-kontrak: tetap seperti sebelumnya (tiap kontrak punya ULP-nya
 *   sendiri, masing-masing dengan salinan sheet SLA & realisasi sendiri untuk
 *   Rekap ULP per Bulan). Field-nya sengaja disamakan (nama_ulp, manager_pln,
 *   koordinator_nd) supaya bisa saling isi otomatis.
 */
require_once 'includes/database.php';
// Akses disamakan dengan Data ULP: Super Admin & Petugas (Viewer/Koordinator)
// kelola penuh; Team Leader & Manager UL boleh lihat (read-only) saja.
requireUlpAccess();
$canManage = canManageUlp();
$db = getDB();
$title = 'Master ULP';

$act = $_GET['act'] ?? 'list';
$id  = (int)($_GET['id'] ?? 0);

// Team Leader / Manager UL tidak boleh akses form tambah/edit
if (!$canManage && $act !== 'list') {
    setFlash('danger', 'Akses ditolak. Role Team Leader/Manager UL hanya dapat melihat Master ULP.');
    header('Location: ulp_master.php'); exit;
}

// ── DELETE ──────────────────────────────────────────────
if ($act === 'hapus' && $id) {
    if (!$canManage) { http_response_code(403); die('Akses ditolak.'); }
    csrfVerify();
    $old = dbRow($db, "SELECT * FROM ulp_master WHERE id=?", [$id]);
    // ULP per-kontrak yang sudah terlanjur pakai master ini otomatis dilepas
    // (ulp_master_id jadi kosong), datanya sendiri TIDAK ikut terhapus.
    dbExec($db, "UPDATE ulp SET ulp_master_id=NULL WHERE ulp_master_id=?", [$id]);
    dbExec($db, "DELETE FROM ulp_master WHERE id=?", [$id]);
    logAudit($db, 'delete', 'ulp_master', "Hapus master ULP id=$id", $old ?: null, null);
    setFlash('success', '🗑️ Master ULP berhasil dihapus.');
    header('Location: ulp_master.php'); exit;
}

// ── SAVE (tambah / update) ──────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$canManage) { http_response_code(403); die('Akses ditolak.'); }
    csrfVerify();
    $fields = [
        'nama_ulp'       => trim($_POST['nama_ulp'] ?? ''),
        'manager_pln'    => trim($_POST['manager_pln'] ?? '') ?: null,
        'koordinator_nd' => trim($_POST['koordinator_nd'] ?? '') ?: null,
        'keterangan'     => trim($_POST['keterangan'] ?? '') ?: null,
        'is_active'      => isset($_POST['is_active']) ? 1 : 0,
    ];
    if ($fields['nama_ulp'] === '') {
        setFlash('danger', 'Nama ULP wajib diisi.');
        header('Location: ulp_master.php?act=' . ($id ? 'edit&id=' . $id : 'tambah')); exit;
    }

    $dup = (bool)dbVal($db,
        "SELECT COUNT(*) FROM ulp_master WHERE LOWER(TRIM(nama_ulp))=LOWER(TRIM(?)) AND id<>?",
        [$fields['nama_ulp'], $id]);
    if ($dup) {
        setFlash('danger', "⚠️ ULP dengan nama \"{$fields['nama_ulp']}\" sudah ada di Master ULP.");
        header('Location: ulp_master.php?act=' . ($id ? 'edit&id=' . $id : 'tambah')); exit;
    }

    if ($id) {
        $old = dbRow($db, "SELECT * FROM ulp_master WHERE id=?", [$id]);
        $sets = implode(',', array_map(fn($k) => "$k=?", array_keys($fields)));
        $vals = array_values($fields);
        $vals[] = $id;
        dbExec($db, "UPDATE ulp_master SET $sets WHERE id=?", $vals);
        [$lama, $baru] = diffFields($old ?: [], $fields);
        logAudit($db, 'update', 'ulp_master', "Update master ULP id=$id", $lama ?: null, $baru ?: null);
        $msg = 'success_update';
    } else {
        $cols = implode(',', array_keys($fields));
        $phs  = implode(',', array_fill(0, count($fields), '?'));
        dbExec($db, "INSERT INTO ulp_master ($cols) VALUES ($phs)", array_values($fields));
        logAudit($db, 'create', 'ulp_master', "Tambah master ULP: {$fields['nama_ulp']}", null, $fields);
        $msg = 'success_create';
    }
    setFlash('success', $msg === 'success_create' ? '✅ Master ULP berhasil ditambahkan.' : '✅ Master ULP berhasil diperbarui.');
    header("Location: ulp_master.php"); exit;
}

$editData = null;
if ($act === 'edit' && $id) {
    $editData = dbRow($db, "SELECT * FROM ulp_master WHERE id=?", [$id]);
}

$ulpMasterList = dbAll($db, "SELECT m.*, (SELECT COUNT(*) FROM ulp u WHERE u.ulp_master_id=m.id) AS jml_dipakai
                              FROM ulp_master m ORDER BY m.nama_ulp");

require 'includes/header.php';
?>

<?php if ($act !== 'list'): ?>
<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title"><?= $editData ? '✏️ Edit Master ULP' : '➕ Tambah Master ULP' ?></div>
            <div class="card-subtitle">Daftar ULP global, bisa dipakai ulang di banyak kontrak lewat menu "Data ULP".</div>
        </div>
        <a href="ulp_master.php" class="btn btn-outline btn-sm">← Kembali</a>
    </div>
    <div class="card-body">
    <form method="POST">
        <?= csrfField() ?>
        <div class="form-grid">
            <div class="form-group" style="grid-column:1/-1">
                <label>Nama ULP</label>
                <input class="form-control" name="nama_ulp" required placeholder="Mis. ULP Manado" value="<?= h($editData['nama_ulp'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Manager PLN</label>
                <input class="form-control" name="manager_pln" value="<?= h($editData['manager_pln'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Koordinator ND</label>
                <input class="form-control" name="koordinator_nd" value="<?= h($editData['koordinator_nd'] ?? '') ?>">
            </div>
            <div class="form-group" style="grid-column:1/-1">
                <label>Keterangan (opsional)</label>
                <input class="form-control" name="keterangan" placeholder="Deskripsi singkat ULP ini" value="<?= h($editData['keterangan'] ?? '') ?>">
            </div>
            <div class="form-group" style="display:flex;align-items:end;">
                <label style="display:flex;align-items:center;gap:8px;margin:0;">
                    <input type="checkbox" name="is_active" value="1" <?= ($editData['is_active'] ?? 1) ? 'checked' : '' ?>>
                    Aktif (tampil di pilihan Master ULP pada Data ULP)
                </label>
            </div>
        </div>
        <hr class="divider">
        <div style="display:flex;gap:10px;justify-content:flex-end;">
            <a href="ulp_master.php" class="btn btn-outline">Batal</a>
            <button type="submit" class="btn btn-primary">💾 Simpan Master ULP</button>
        </div>
    </form>
    </div>
</div>

<?php else: ?>

<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title"><i class="bi bi-geo-alt"></i> Master ULP</div>
            <div class="card-subtitle">Daftar ULP global (nama, Manager PLN, Koordinator ND) yang bisa dipilih cepat saat mengisi Data ULP di tiap kontrak. <b>Beda dengan menu Unit Kerja</b> — Unit Kerja (mis. "Unit Layanan Manado") menentukan template SLA kontrak, sementara Master ULP di sini cuma sub-area pendukung per-kontrak, tidak menggantikan Data ULP per-kontrak yang sudah ada.</div>
        </div>
        <?php if ($canManage): ?>
        <a href="ulp_master.php?act=tambah" class="btn btn-primary">+ Tambah Master ULP</a>
        <?php endif; ?>
    </div>
    <?php if (!$canManage): ?>
    <div class="alert alert-info" style="margin:0 16px 16px;">👁️ Role Anda (Team Leader/Manager UL) hanya bisa melihat Master ULP ini, tidak bisa menambah/mengubah/menghapus.</div>
    <?php endif; ?>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama ULP</th>
                    <th>Manager PLN</th>
                    <th>Koordinator ND</th>
                    <th>Keterangan</th>
                    <th>Dipakai di Kontrak</th>
                    <th>Status</th>
                    <?php if ($canManage): ?><th>Aksi</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($ulpMasterList as $i => $r): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><b><?= h($r['nama_ulp']) ?></b></td>
                    <td><?= h($r['manager_pln'] ?? '-') ?></td>
                    <td><?= h($r['koordinator_nd'] ?? '-') ?></td>
                    <td style="color:var(--text-light);font-size:12px;"><?= h($r['keterangan'] ?? '-') ?></td>
                    <td><?= (int)$r['jml_dipakai'] ?> kontrak</td>
                    <td>
                        <?php if ($r['is_active']): ?>
                        <span class="badge badge-success">Aktif</span>
                        <?php else: ?>
                        <span class="badge badge-danger">Nonaktif</span>
                        <?php endif; ?>
                    </td>
                    <?php if ($canManage): ?>
                    <td>
                        <div class="aksi-btn-group">
                            <a href="ulp_master.php?act=edit&id=<?= $r['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="#" onclick="confirmDelete('<?= csrfUrl('ulp_master.php?act=hapus&id=' . $r['id']) ?>','master ULP ini')" class="btn btn-danger btn-sm">Hapus</a>
                        </div>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($ulpMasterList)): ?>
                <tr><td colspan="8" style="text-align:center;color:var(--gray-400);padding:24px;"><?= $canManage ? 'Belum ada Master ULP. Klik "+ Tambah Master ULP" untuk menambahkan.' : 'Belum ada Master ULP.' ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php require 'includes/footer.php'; ?>
