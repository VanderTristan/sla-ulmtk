<?php
/**
 * export_excel.php — Export Rekap SLA sebuah kontrak ke file .xlsx asli
 * (bisa dibuka & diolah langsung di Microsoft Excel / Google Sheets),
 * berbeda dari cetak.php yang cuma "Cetak ke PDF" lewat browser.
 *
 * Dipanggil dari: rekap_sla.php -> tombol "Export Excel"
 * Contoh URL: export_excel.php?kontrak_id=6
 */
require_once 'includes/database.php';
require_once 'includes/xlsx_writer.php';

$db = getDB();
requireReportAccess();

$kontrak_id = (int)($_GET['kontrak_id'] ?? 0);
if (!$kontrak_id) {
    http_response_code(400);
    die('Parameter kontrak_id wajib diisi.');
}

$kontrak = dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$kontrak_id]);
if (!$kontrak) {
    http_response_code(404);
    die('Kontrak tidak ditemukan.');
}

$rekap = dbRow($db, "SELECT * FROM rekap_sla WHERE kontrak_id=?", [$kontrak_id]);

function getCatEntriesExport(PDO $db, int $kontrak_id, string $kat): array {
    return dbAll($db, "SELECT * FROM sla_entries WHERE kontrak_id=? AND ulp_id IS NULL AND kategori=? ORDER BY no_urut", [$kontrak_id, $kat]);
}

$xlsx = new SimpleXlsxWriter();

// ── Sheet 1: Ringkasan ──────────────────────────────────────
$ringkasan = [];
$ringkasan[] = ['Nama Kontrak', (string)($kontrak['nama_kontrak'] ?? '')];
$ringkasan[] = ['Vendor', (string)($kontrak['vendor'] ?? '')];
$ringkasan[] = ['Periode', (string)($kontrak['periode_bulan'] ?? '') . ' ' . (string)($kontrak['tahun'] ?? '')];
$ringkasan[] = ['Tahap', (string)($kontrak['tahap'] ?? '')];
$ringkasan[] = ['Jenis Kontrak', (string)($kontrak['jenis_kontrak'] ?? '')];
$ringkasan[] = [];
$ringkasan[] = ['Kategori SLA', 'Persentase (%)'];
$ringkasan[] = ['Teknis', round((float)($rekap['sla_teknis'] ?? 0), 2)];
$ringkasan[] = ['K3 (Keselamatan & Kesehatan Kerja)', round((float)($rekap['sla_k3'] ?? 0), 2)];
$ringkasan[] = ['Kecelakaan Kerja', round((float)($rekap['sla_kecelakaan'] ?? 0), 2)];
$ringkasan[] = ['ILP (Integritas Layanan Publik)', round((float)($rekap['sla_ilp'] ?? 0), 2)];
$overallAvg = rekapOverallPct($rekap);
$ringkasan[] = ['TOTAL SLA (BERBOBOT)', round($overallAvg, 2)];
$ringkasan[] = ['Total Nilai Bobot', round((float)($rekap['total_bobot'] ?? 0), 2)];
$xlsx->addSheet('Ringkasan', $ringkasan, true, [32, 26]);

// ── Sheet Data SLA — satu tabel rata (flat), kolomnya mengikuti format
//    "Performance_UNit.xlsx" (BIDANG/PROJECT/JENIS SLA/LINGKUP PEKERJAAN/
//    LINGKUP SLA/KRITERIA/POLARITAS/SATUAN/TARGET/REALISASI), ditambah
//    3 kolom hasil perhitungan aplikasi (% Pencapaian, Bobot, Nilai Bobot)
//    di paling kanan supaya tetap berguna untuk analisis tanpa mengubah
//    urutan kolom utama yang diminta.
$katLabel = ['TEKNIS' => 'TEKNIS', 'K3' => 'K3', 'KECELAKAAN' => 'KECELAKAAN', 'ILP' => 'ILP'];
$header = ['BIDANG', 'PROJECT', 'JENIS SLA', 'LINGKUP PEKERJAAN', 'LINGKUP SLA', 'KRITERIA', 'POLARITAS', 'SATUAN', 'TARGET', 'REALISASI', '% Pencapaian', 'Bobot', 'Nilai Bobot'];
$flatRows = [$header];
$bidang  = (string)($kontrak['jenis_kontrak'] ?? '');
$project = (string)($kontrak['nama_kontrak'] ?? '');
foreach ($katLabel as $kat => $label) {
    $entries = getCatEntriesExport($db, $kontrak_id, $kat);
    foreach ($entries as $e) {
        $belumDinilai = $e['persen_pencapaian'] === null;
        $flatRows[] = [
            $bidang,
            $project,
            $label,
            (string)($e['ruang_lingkup'] ?? ''),
            (string)($e['kriteria'] ?? ''),
            (string)($e['target_kinerja'] ?? ''),
            (string)($e['polaritas'] ?? ''),
            (string)($e['satuan'] ?? ''),
            (float)($e['target'] ?? 0),
            $belumDinilai ? 'Belum Dinilai' : (float)$e['realisasi'],
            $belumDinilai ? 'Belum Dinilai' : round((float)$e['persen_pencapaian'], 2),
            (float)($e['bobot'] ?? 0),
            $belumDinilai ? 'Belum Dinilai' : round((float)$e['nilai_bobot'], 2),
        ];
    }
}
if (count($flatRows) === 1) {
    $flatRows[] = ['-', '-', '-', 'Belum ada data entry untuk kontrak ini', '', '', '', '', '', '', '', '', ''];
}
$xlsx->addSheet('Data SLA', $flatRows, true, [12, 22, 10, 26, 30, 30, 10, 10, 10, 10, 12, 8, 12]);

// ── Sheet Per ULP ────────────────────────────────────────────
$ulps = dbAll($db, "SELECT * FROM ulp WHERE kontrak_id=?", [$kontrak_id]);
if (!empty($ulps)) {
    $ulpRows = [['No', 'Nama ULP', 'Manager PLN', 'Koordinator ND', 'SLA Teknis (%)', 'SLA K3 (%)', 'Kecelakaan (%)', 'SLA ILP (%)']];
    $no = 1;
    foreach ($ulps as $u) {
        $uid = $u['id'];
        $cats = ['TEKNIS', 'K3', 'KECELAKAAN', 'ILP'];
        $pcts = [];
        foreach ($cats as $cat) {
            $r = dbRow($db, "SELECT SUM(bobot) as bobot_asli, SUM(nilai_bobot) as bobot FROM sla_entries WHERE kontrak_id=? AND ulp_id=? AND kategori=? AND realisasi IS NOT NULL", [$kontrak_id, $uid, $cat]);
            $bobotAsli = (float)($r['bobot_asli'] ?? 0);
            $pcts[$cat] = $bobotAsli > 0 ? round(((float)($r['bobot'] ?? 0) / $bobotAsli), 2) : 0;
        }
        $ulpRows[] = [
            $no++,
            (string)($u['nama_ulp'] ?? ''),
            (string)($u['manager_pln'] ?? ''),
            (string)($u['koordinator_nd'] ?? ''),
            $pcts['TEKNIS'],
            $pcts['K3'],
            $pcts['KECELAKAAN'],
            $pcts['ILP'],
        ];
    }
    $xlsx->addSheet('Per ULP', $ulpRows, true, [5, 26, 24, 24, 12, 10, 12, 10]);
}

logAudit($db, 'export', 'rekap_sla', "Export Excel rekap SLA kontrak_id=$kontrak_id");

$safeFileName = preg_replace('/[^A-Za-z0-9_-]+/', '_', (string)($kontrak['nama_kontrak'] ?? 'kontrak'));
$filename = 'Rekap_SLA_' . substr($safeFileName, 0, 60) . '_' . date('Ymd') . '.xlsx';
$xlsx->download($filename);
