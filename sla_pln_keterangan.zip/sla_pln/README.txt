===================================================
  SLA PLN Nusa Daya Monitoring - Setup Guide (MySQL)
===================================================

REQUIREMENTS:
- PHP 8.0+ dengan ekstensi PDO dan PDO_MySQL
- MySQL/MariaDB
- XAMPP / Laragon / server lain

-----------------------------------------
LANGKAH SETUP (DEVELOPMENT / LOKAL)
-----------------------------------------

1. BUAT DATABASE MySQL:
   > CREATE DATABASE sla_pln CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

2. KONFIGURASI KONEKSI:
   File ".env" di root folder sudah disiapkan untuk environment lokal
   (root/tanpa password, port 3307 — sesuaikan dengan XAMPP/Laragon kamu).
   Jika belum ada file ".env", copy dari ".env.example" lalu sesuaikan.

3. TABEL akan dibuat OTOMATIS saat pertama kali halaman dibuka.

4. IMPORT DATA (opsional - jika ingin migrate dari SQLite):
   Jalankan file: data/migration.sql di phpMyAdmin atau MySQL CLI:
   > mysql -u root -P 3307 sla_pln < data/migration.sql

5. LETAKKAN folder sla_pln/ di:
   - XAMPP: C:/xampp/htdocs/sla_pln/
   - Laragon: C:/laragon/www/sla_pln/

6. AKSES via browser:
   http://localhost/sla_pln/

7. LOGIN PERTAMA KALI:
   Tabel app_users akan dibuat otomatis beserta SATU akun admin sementara:
     Username : admin
     Password : (lihat catatan rilis internal / tanyakan tim yang men-deploy)
   Sistem akan menampilkan banner peringatan wajib ganti password setelah
   login pertama — segera ganti lewat menu Kelola User sebelum dipakai
   untuk data produksi.

-----------------------------------------
DEPLOY KE SERVER PRODUKSI?
-----------------------------------------
Jangan langsung pakai konfigurasi development di atas untuk server
produksi perusahaan. Ikuti checklist lengkap di file DEPLOYMENT.md.

===================================================
