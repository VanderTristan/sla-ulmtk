<?php
require_once 'includes/database.php';
$db = getDB();
requireReportAccess();
$title = 'Rekap SLA';
$kontrak_id = (int)($_GET['kontrak_id'] ?? 0);

// Proses: tombol hitung ulang SLA otomatis dari akumulasi data monitoring harian
if (($_GET['act'] ?? '') === 'hitung_ulang' && $kontrak_id) {
    csrfVerify();
    recalcRealisasiHarian($db, $kontrak_id);
    logAudit($db, 'recalc', 'rekap_sla', "Hitung ulang dari data harian kontrak_id=$kontrak_id");
    setFlash('success', '✅ SLA berhasil dihitung ulang berdasarkan data monitoring harian.');
    header("Location: rekap_sla.php?kontrak_id=$kontrak_id"); exit;
}

require_once 'includes/kontrak_selector.php';
$sel = kontrakSelectorInit($db, $kontrak_id);
$filterJenis = $sel['jenis']; $filterUnit = $sel['unit'];

$kontrak = $kontrak_id ? dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$kontrak_id]) : null;
$rekap = $kontrak_id ? dbRow($db, "SELECT * FROM rekap_sla WHERE kontrak_id=?", [$kontrak_id]) : null;

// ULP SLA summary
$ulpSummary = [];
if ($kontrak_id) {
    $ulps_list = dbAll($db, "SELECT * FROM ulp WHERE kontrak_id=?", [$kontrak_id]);
    foreach ($ulps_list as $u) {
        $uid = $u['id'];
        $cats = ['TEKNIS','K3','KECELAKAAN','ILP'];
        $sum = ['ulp'=>$u];
        foreach($cats as $cat) {
            $r = dbRow($db, "SELECT SUM(bobot) as bobot_asli, SUM(nilai_bobot) as bobot FROM sla_entries WHERE kontrak_id=? AND ulp_id=? AND kategori=? AND realisasi IS NOT NULL", [$kontrak_id, $uid, $cat]);
            $bobotAsli = (float)($r['bobot_asli'] ?? 0);
            $r['pct'] = $bobotAsli > 0 ? ((float)($r['bobot'] ?? 0) / $bobotAsli) : 0;
            $sum[$cat] = $r;
        }
        $ulpSummary[] = $sum;
    }
}

// Rekap entries by category
function getCatEntries($db, $kontrak_id, $kat) {
    $rows = dbAll($db, "SELECT * FROM sla_entries WHERE kontrak_id=? AND ulp_id IS NULL AND kategori=? ORDER BY no_urut", [$kontrak_id, $kat]);
    return $rows;
}

function pctBadge($pct) {
    if ($pct >= 90) return '<span style="color:var(--pln-green);font-weight:800;">'.number_format($pct,2).'%</span>';
    if ($pct >= 70) return '<span style="color:#b8970a;font-weight:800;">'.number_format($pct,2).'%</span>';
    return '<span style="color:var(--pln-red);font-weight:800;">'.number_format($pct,2).'%</span>';
}

include 'includes/header.php';
?>

<!-- Selector -->
<div class="card">
    <div class="card-header">
        <div class="card-title">📊 Rekap SLA - Service Level Agreement</div>
    </div>
    <div class="card-body">
    <?php renderKontrakSelectorFields($sel, 'rekap_sla.php', ['btnLabel' => 'Lihat Rekap']); ?>
    </div>
</div>

<?php renderKontrakListCard($sel, 'rekap_sla.php', ['btnLabel' => 'Lihat Rekap']); ?>

<?php if($kontrak && $rekap): ?>
<!-- Header Info -->
<div class="card" style="background:linear-gradient(135deg,#003087,#0055b3);color:#fff;">
    <div class="card-body">
    <div style="margin-bottom:12px;font-size:13px;opacity:0.7;">SERVICE LEVEL AGREEMENT (SLA)</div>
    <div style="font-size:15px;font-weight:800;margin-bottom:6px;word-break:break-word;"><?= htmlspecialchars((string)($kontrak['nama_kontrak'] ?? '')) ?></div>
    <div style="font-size:13px;opacity:0.85;">
        PERIODE BULAN <?= strtoupper($kontrak['periode_bulan']) ?> <?= $kontrak['tahun'] ?> - <?= $kontrak['tahap'] ?>
        &bull; <span style="background:rgba(255,255,255,0.2);padding:2px 10px;border-radius:10px;font-size:11px;">
            <?= badgeJenisKontrak($kontrak['jenis_kontrak'] ?? 'DISTRIBUSI') ?>
        </span><br>
        Pelaksana: <?= htmlspecialchars((string)($kontrak['vendor'] ?? '')) ?> &bull; Perjanjian: <?= htmlspecialchars((string)($kontrak['no_kontrak_1'] ?? '')) ?>
    </div>
    </div>
</div>

<!-- Summary Boxes -->
<div class="stats-grid">
    <?php
    $cats = [
        ['TEKNIS','SLA Teknis','⚡',$rekap['sla_teknis']??0],
        ['K3','SLA K3','🦺',$rekap['sla_k3']??0],
        ['KECELAKAAN','Kecelakaan Kerja','⚠️',$rekap['sla_kecelakaan']??0],
        ['ILP','SLA ILP','🏛️',$rekap['sla_ilp']??0],
    ];
    foreach($cats as [$kat,$label,$icon,$pct]):
        $cls = $pct>=90?'green':($pct>=70?'yellow':'red');
    ?>
    <div class="stat-card <?= $cls ?>">
        <div class="stat-value <?= $pct>=90?'green':($pct>=70?'warn':'bad') ?>"><?= number_format($pct,2) ?>%</div>
        <div class="stat-label"><?= $icon ?> <?= $label ?></div>
        <div style="margin-top:10px;">
            <div class="progress-bar"><div class="progress-fill <?= $pct>=90?'good':($pct>=70?'warn':'bad') ?>" style="width:<?= min(100,$pct) ?>%"></div></div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Total -->
<div class="card">
    <div class="card-header">
        <div class="card-title">📋 Ringkasan Nilai SLA</div>
        <a href="input_harian.php?kontrak_id=<?= $kontrak_id ?>" class="btn btn-outline btn-sm no-print">✏️ Edit Input</a>
    </div>
    <div class="table-wrap">
    <table>
        <thead>
            <tr><th>No</th><th>Kategori SLA</th><th>Jumlah SLA (%)</th><th>Jumlah Nilai Bobot</th></tr>
        </thead>
        <tbody>
            <tr><td>1</td><td>Teknis</td><td><?= pctBadge($rekap['sla_teknis']??0) ?></td><td><b><?= number_format($rekap['sla_teknis']??0 * 22, 2) ?></b></td></tr>
            <tr><td>2</td><td>K3 (Keselamatan dan Kesehatan Kerja)</td><td><?= pctBadge($rekap['sla_k3']??0) ?></td><td><b><?= number_format(($rekap['sla_k3']??0)/100*1200, 2) ?></b></td></tr>
            <tr><td>3</td><td>Kecelakaan Kerja</td><td><?= pctBadge($rekap['sla_kecelakaan']??0) ?></td><td><b><?= number_format(($rekap['sla_kecelakaan']??0)/100*200, 2) ?></b></td></tr>
            <tr><td>4</td><td>ILP (Integritas Layanan Publik)</td><td><?= pctBadge($rekap['sla_ilp']??0) ?></td><td><b><?= number_format(($rekap['sla_ilp']??0)/100*300, 2) ?></b></td></tr>
            <tr style="background:#f0f4ff;font-weight:800;font-size:14px;">
                <td colspan="2">TOTAL</td>
                <td><?= pctBadge(rekapOverallPct($rekap)) ?></td>
                <td><?= number_format($rekap['total_bobot']??0, 2) ?></td>
            </tr>
        </tbody>
    </table>
    </div>
</div>

<!-- Detail Teknis -->
<?php
$katDetails = [
    'TEKNIS' => ['A. SLA TEKNIS','⚡'],
    'K3' => ['B. SLA K3 (Keselamatan dan Kesehatan Kerja)','🦺'],
    'KECELAKAAN' => ['C. Kecelakaan Kerja','⚠️'],
    'ILP' => ['D. Integritas Layanan Publik','🏛️'],
];
?>

<!-- Semua kategori tampil berurutan ke bawah. Bilah ini hanya pintasan untuk lompat ke bagian tertentu. -->
<div class="tabs no-print rekap-jump" id="rekapJump">
    <?php foreach($katDetails as $kat=>[$lbl,$ico]): ?>
    <a class="tab-btn" href="#tab-<?= $kat ?>"><?= $ico ?> <?= explode('.',$lbl)[1] ?? $lbl ?></a>
    <?php endforeach; ?>
    <?php if(!empty($ulpSummary)): ?>
    <a class="tab-btn" href="#tab-ulp">🏢 Per ULP</a>
    <?php endif; ?>
</div>

<?php $first=true; foreach($katDetails as $kat=>[$lbl,$ico]): 
    $entries = getCatEntries($db, $kontrak_id, $kat);
    $entriesDinilai = array_values(array_filter($entries, fn($e) => $e['persen_pencapaian'] !== null));
    $totalBobot = array_sum(array_column($entriesDinilai,'nilai_bobot'));
    $avgPct = count($entriesDinilai) > 0 ? array_sum(array_column($entriesDinilai,'persen_pencapaian'))/count($entriesDinilai) : 0;
?>
<div id="tab-<?= $kat ?>" class="rekap-section">
<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title"><?= $ico ?> <?= $lbl ?></div>
            <div class="card-subtitle">Rata-rata pencapaian: <b><?= number_format($avgPct,2) ?>%</b> &bull; Total bobot: <b><?= number_format($totalBobot,2) ?></b>
                <?php if (count($entriesDinilai) < count($entries)): ?> &bull; <span style="color:#b8970a;"><?= count($entries)-count($entriesDinilai) ?> indikator belum dinilai</span><?php endif; ?>
            </div>
        </div>
        <div class="sla-gauge">
            <div class="sla-pct <?= $avgPct>=90?'excellent':($avgPct>=75?'good':($avgPct>=60?'warn':'bad')) ?>"><?= number_format($avgPct,1) ?>%</div>
        </div>
    </div>
    <?php if(!empty($entries)): ?>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Ruang Lingkup</th>
                <th>Target Kinerja</th>
                <th>Sat.</th>
                <th>Polaritas<?= helpTip(HELP_POLARITAS) ?></th>
                <th>Bobot</th>
                <th>Target</th>
                <th>Realisasi</th>
                <th>% Pencapaian</th>
                <th>Nilai Bobot</th>
            </tr>
        </thead>
        <tbody>
        <?php $no=1; foreach($entries as $e): 
            $pct = $e['persen_pencapaian'] !== null ? (float)$e['persen_pencapaian'] : null;
        ?>
        <tr>
            <td><?= $no++ ?></td>
            <td>
                <div style="font-size:12px;font-weight:700;"><?= htmlspecialchars((string)($e['ruang_lingkup'] ?? '')) ?></div>
                <div style="font-size:11px;color:var(--text-light);"><?= htmlspecialchars((string)($e['kriteria'] ?? '')) ?></div>
            </td>
            <td style="font-size:11px;"><?= htmlspecialchars(mb_strimwidth((string)($e['target_kinerja'] ?? ''),0,60,'...')) ?></td>
            <td><?= htmlspecialchars((string)($e['satuan'] ?? '')) ?></td>
            <td><span class="badge <?= $e['polaritas']=='Positif'?'badge-positif':'badge-negatif' ?>"><?= $e['polaritas'] ?></span></td>
            <td><?= $e['bobot'] ?></td>
            <td><?= number_format($e['target'],4) ?></td>
            <td><?= $e['realisasi'] !== null ? number_format($e['realisasi'],4) : '<span style="color:#cbd5e1;">–</span>' ?></td>
            <td>
                <?php if ($pct === null): ?>
                <span class="badge" style="background:#f1f5f9;color:#94a3b8;border:1px solid #e2e8f0;white-space:nowrap;"><i class="bi bi-hourglass-split"></i> Belum Dinilai</span>
                <?php else: ?>
                <div class="progress-bar" style="min-width:80px;"><div class="progress-fill <?= $pct>=90?'good':($pct>=70?'warn':'bad') ?>" style="width:<?= min(100,max(0,$pct)) ?>%"></div></div>
                <div class="progress-label <?= $pct>=90?'good':($pct>=70?'warn':'bad') ?>"><?= number_format($pct,2) ?>%</div>
                <?php endif; ?>
            </td>
            <td><b><?= $e['nilai_bobot'] !== null ? number_format($e['nilai_bobot'],2) : '<span style="color:#cbd5e1;">–</span>' ?></b></td>
        </tr>
        <?php endforeach; ?>
        <tr style="background:#f0f4ff;font-weight:800;">
            <td colspan="9" style="text-align:right;">TOTAL</td>
            <td><?= number_format($totalBobot,2) ?></td>
        </tr>
        </tbody>
    </table>
    </div>
    <?php else: ?>
    <div class="alert alert-info">Belum ada data entry untuk kategori ini. <a href="input_harian.php?kontrak_id=<?= $kontrak_id ?>">Input sekarang</a></div>
    <?php endif; ?>
</div>
</div>
<?php $first=false; endforeach; ?>

<!-- Per ULP tab -->
<?php if(!empty($ulpSummary)): ?>
<div id="tab-ulp" class="rekap-section">
<div class="card">
    <div class="card-header">
        <div class="card-title">🏢 Resume SLA Per ULP</div>
        <div class="card-subtitle"><?= count($ulpSummary) ?> ULP</div>
    </div>
    <div class="table-wrap">
    <table>
        <thead>
            <tr><th>#</th><th>Nama ULP</th><th>Manager PLN</th><th>SLA Teknis</th><th>SLA K3</th><th>Kecelakaan</th><th>SLA ILP</th><th>Aksi</th></tr>
        </thead>
        <tbody>
        <?php foreach($ulpSummary as $i=>$us): 
            $u = $us['ulp'];
        ?>
        <tr>
            <td><?= $i+1 ?></td>
            <td><b><?= htmlspecialchars((string)($u['nama_ulp'] ?? '')) ?></b></td>
            <td style="font-size:12px;"><?= htmlspecialchars((string)($u['manager_pln'] ?? '')) ?></td>
            <?php foreach(['TEKNIS','K3','KECELAKAAN','ILP'] as $kat):
                $pct = (float)($us[$kat]['pct'] ?? 0);
            ?>
            <td>
                <div class="progress-bar" style="min-width:80px;"><div class="progress-fill <?= $pct>=90?'good':($pct>=70?'warn':'bad') ?>" style="width:<?= min(100,$pct) ?>%"></div></div>
                <div class="progress-label <?= $pct>=90?'good':($pct>=70?'warn':'bad') ?>"><?= number_format($pct,2) ?>%</div>
            </td>
            <?php endforeach; ?>
            <td>
                <a href="input_sla.php?kontrak_id=<?= $kontrak_id ?>&ulp_id=<?= $u['id'] ?>" class="btn btn-primary btn-sm">Input</a>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</div>
</div>
<?php endif; ?>

<style>
.rekap-jump { position:sticky; top:var(--topbar-h,60px); z-index:40; }
.rekap-section { scroll-margin-top:calc(var(--topbar-h,60px) + 70px); }
.rekap-jump .tab-btn { text-decoration:none; }
html { scroll-behavior:smooth; }
</style>
<script>
(function () {
    var links = Array.prototype.slice.call(document.querySelectorAll('#rekapJump .tab-btn'));
    if (!links.length) return;
    function setActive(id) {
        links.forEach(function (a) { a.classList.toggle('active', a.getAttribute('href') === '#' + id); });
    }
    function onScroll() {
        var secs = Array.prototype.slice.call(document.querySelectorAll('.rekap-section'));
        var current = secs.length ? secs[0].id : null;
        secs.forEach(function (s) { if (s.getBoundingClientRect().top <= 160) current = s.id; });
        if (current) setActive(current);
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
})();
</script>

<!-- Action buttons -->
<div style="display:flex;gap:10px;margin-top:20px;" class="no-print">
    <a href="input_harian.php?kontrak_id=<?= $kontrak_id ?>" class="btn btn-info" style="background:#0066AE;color:#fff;">📅 Input SLA</a>
    <a href="<?= csrfUrl('rekap_sla.php?kontrak_id=' . $kontrak_id . '&act=hitung_ulang') ?>" onclick="return confirm('Hitung ulang SLA dari akumulasi data monitoring harian bulan ini?')" class="btn btn-outline">🔄 Hitung Ulang dari Data Harian</a>
    <a href="detail_perhitungan.php?kontrak_id=<?= $kontrak_id ?>" class="btn btn-outline"><i class="bi bi-calculator"></i> Detail Perhitungan</a>
    <a href="rata_rata.php?kontrak_id=<?= $kontrak_id ?>" class="btn btn-primary">📈 Analisis Rata-Rata</a>
    <a href="cetak.php?kontrak_id=<?= $kontrak_id ?>" class="btn btn-success">🖨️ Cetak Laporan</a>
    <a href="export_excel.php?kontrak_id=<?= $kontrak_id ?>" class="btn btn-outline" style="border-color:#1D6F42;color:#1D6F42;"><i class="bi bi-file-earmark-excel"></i> Export Excel</a>
    <a href="export_csv.php?kontrak_id=<?= $kontrak_id ?>" class="btn btn-outline" style="border-color:#64748b;color:#64748b;"><i class="bi bi-filetype-csv"></i> Export CSV</a>
</div>

<?php elseif($kontrak_id): ?>
<div class="alert alert-info">
    Belum ada data rekap SLA. Silakan <a href="input_harian.php?kontrak_id=<?= $kontrak_id ?>">isi Input SLA</a> terlebih dahulu.
</div>
<?php else: ?>
<div class="card">
    <div style="text-align:center;padding:40px;">
        <div style="font-size:48px;">📊</div>
        <div style="font-size:16px;font-weight:700;color:var(--pln-blue);margin-top:12px;">Pilih Project untuk Lihat Rekap SLA</div>
    </div>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
