-- ============================================================
--  Pembersihan database SLA PLN (MariaDB / XAMPP)
--  WAJIB backup dulu (menu Backup di aplikasi) sebelum menjalankan.
--  Aman dijalankan berulang kali.
-- ============================================================

-- 1) Tabel riwayat harian: sebelumnya hanya dipakai grafik "Monitoring SLA Harian"
--    yang sudah dihapus. Berisi data riwayat lama (tidak ada lagi yang membacanya).
DROP TABLE IF EXISTS sla_history;

-- 2) Tabel vendor lama (vendor sekarang cukup kolom teks kontrak.vendor)
DROP TABLE IF EXISTS vendor;
ALTER TABLE kontrak DROP COLUMN IF EXISTS vendor_id;

-- 3) Kolom lama yang tidak dipakai kode
ALTER TABLE kendaraan
  DROP COLUMN IF EXISTS nomor_rangka,
  DROP COLUMN IF EXISTS nomor_mesin,
  DROP COLUMN IF EXISTS nama_pemilik;

ALTER TABLE monitoring_harian
  DROP COLUMN IF EXISTS verified_by,
  DROP COLUMN IF EXISTS verified_at,
  DROP COLUMN IF EXISTS catatan_verifikasi,
  DROP COLUMN IF EXISTS approved_by,
  DROP COLUMN IF EXISTS approved_at,
  DROP COLUMN IF EXISTS catatan_approval,
  DROP COLUMN IF EXISTS status;

ALTER TABLE rekap_sla
  DROP COLUMN IF EXISTS denda_teknis,
  DROP COLUMN IF EXISTS denda_k3,
  DROP COLUMN IF EXISTS denda_kecelakaan,
  DROP COLUMN IF EXISTS denda_ilp,
  DROP COLUMN IF EXISTS total_denda;

-- 4) (Opsional) bersihkan log percobaan login lama
-- DELETE FROM login_attempts WHERE created_at < NOW() - INTERVAL 30 DAY;
