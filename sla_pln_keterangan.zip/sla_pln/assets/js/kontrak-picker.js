/**
 * kontrak-picker.js
 * Meningkatkan <select data-kontrak-picker> (native) menjadi dropdown "Pilih
 * Project" kustom yang lebih gampang dicari: tiap baris menampilkan jenis
 * kontrak (badge) + nama project + bulan/periode di baris utama (karena itu
 * yang paling sering dipakai untuk mencari), lalu tahap sebagai info
 * pendukung di baris kedua. Select native tetap ada (disembunyikan) supaya
 * semua atribut/onchange yang sudah dipasang di halaman (mis.
 * onchange="location.href=...+this.value") tetap berfungsi apa adanya —
 * widget ini hanya lapisan tampilan.
 */
(function () {
    function badgeClass(jenis) {
        jenis = (jenis || 'DISTRIBUSI').toUpperCase();
        if (jenis === 'TRANSMISI') return 'badge badge-transmisi';
        if (jenis === 'PEMBANGKIT') return 'badge badge-pembangkit';
        return 'badge badge-distribusi';
    }

    function buildOptionRow(opt) {
        var periode = opt.getAttribute('data-periode') || '';
        var tahap = opt.getAttribute('data-tahap') || '';
        var jenis = opt.getAttribute('data-jenis') || 'DISTRIBUSI';
        var nama = opt.getAttribute('data-nama') || '';

        var row = document.createElement('button');
        row.type = 'button';
        row.className = 'kpicker-option';
        row.dataset.value = opt.value;

        // Baris utama: jenis kontrak + nama project, dengan bulan/periode
        // langsung di sebelah nama supaya project yang sama di bulan
        // berbeda tetap gampang dibedakan sekilas.
        var meta = document.createElement('div');
        meta.className = 'kpicker-option-meta';
        meta.innerHTML =
            '<span class="' + badgeClass(jenis) + '">' + escapeHtml(jenis) + '</span>' +
            (nama ? '<span class="kpicker-option-project">' + escapeHtml(nama) + '</span>' : '') +
            (periode ? '<span class="kpicker-option-periode">— ' + escapeHtml(periode) + '</span>' : '');
        row.appendChild(meta);

        // Baris kedua: info pendukung (tahap) — lebih kecil.
        var subParts = [];
        if (tahap) subParts.push('Tahap ' + tahap);
        if (subParts.length) {
            var subEl = document.createElement('div');
            subEl.className = 'kpicker-option-sub';
            subEl.textContent = subParts.join(' · ');
            row.appendChild(subEl);
        }

        row.dataset.searchText = (jenis + ' ' + nama + ' ' + periode + ' ' + tahap).toLowerCase();
        return row;
    }

    function escapeHtml(s) {
        var d = document.createElement('div');
        d.textContent = s;
        return d.innerHTML;
    }

    function renderButtonContent(btnText, selectedOption, placeholder) {
        btnText.innerHTML = '';
        if (!selectedOption || !selectedOption.value) {
            var ph = document.createElement('span');
            ph.className = 'kpicker-btn-placeholder';
            ph.textContent = placeholder;
            btnText.appendChild(ph);
            return;
        }
        var periode = selectedOption.getAttribute('data-periode') || '';
        var tahap = selectedOption.getAttribute('data-tahap') || '';
        var jenis = selectedOption.getAttribute('data-jenis') || 'DISTRIBUSI';
        var nama = selectedOption.getAttribute('data-nama') || '';

        var meta = document.createElement('div');
        meta.className = 'kpicker-btn-meta';
        meta.innerHTML =
            '<span class="' + badgeClass(jenis) + '">' + escapeHtml(jenis) + '</span>' +
            (nama ? '<span>' + escapeHtml(nama) + '</span>' : '') +
            (periode ? '<span>— ' + escapeHtml(periode) + '</span>' : '');
        btnText.appendChild(meta);

        var subParts = [];
        if (tahap) subParts.push('Tahap ' + tahap);
        if (subParts.length) {
            var namaEl = document.createElement('div');
            namaEl.className = 'kpicker-btn-name';
            namaEl.textContent = subParts.join(' · ');
            btnText.appendChild(namaEl);
        }
    }

    function enhance(select) {
        if (select.dataset.kpickerReady) return;
        select.dataset.kpickerReady = '1';

        var placeholder = select.getAttribute('data-placeholder') || 'Pilih Project';
        var options = Array.prototype.filter.call(select.options, function (o) { return o.value !== ''; });

        var wrap = document.createElement('div');
        wrap.className = 'kpicker';

        select.classList.add('kpicker-native');
        select.parentNode.insertBefore(wrap, select);
        wrap.appendChild(select);

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'kpicker-btn';
        var btnText = document.createElement('div');
        btnText.className = 'kpicker-btn-text';
        btn.appendChild(btnText);
        var caret = document.createElement('span');
        caret.className = 'kpicker-btn-caret';
        caret.innerHTML = '&#9662;';
        btn.appendChild(caret);
        wrap.appendChild(btn);

        var panel = document.createElement('div');
        panel.className = 'kpicker-panel';
        var searchWrap = document.createElement('div');
        searchWrap.className = 'kpicker-search-wrap';
        var search = document.createElement('input');
        search.type = 'text';
        search.className = 'kpicker-search';
        search.placeholder = 'Cari jenis, nama project, atau bulan…';
        searchWrap.appendChild(search);
        panel.appendChild(searchWrap);
        var list = document.createElement('div');
        list.className = 'kpicker-list';
        panel.appendChild(list);
        wrap.appendChild(panel);

        var rows = [];
        options.forEach(function (opt) {
            var row = buildOptionRow(opt);
            if (opt.value === select.value) row.classList.add('selected');
            row.addEventListener('click', function () {
                select.value = opt.value;
                select.dispatchEvent(new Event('change', { bubbles: true }));
                rows.forEach(function (r) { r.classList.remove('selected'); });
                row.classList.add('selected');
                renderButtonContent(btnText, opt, placeholder);
                closePanel();
            });
            rows.push(row);
            list.appendChild(row);
        });

        if (!rows.length) {
            var empty = document.createElement('div');
            empty.className = 'kpicker-empty';
            empty.textContent = 'Belum ada kontrak.';
            list.appendChild(empty);
        }

        renderButtonContent(btnText, select.selectedIndex >= 0 ? select.options[select.selectedIndex] : null, placeholder);

        var overflowFixEls = [];
        function releaseAncestorOverflow() {
            // Cegah panel dropdown terpotong oleh elemen induk yang memakai
            // overflow:hidden (mis. .card, .kontrak-tabs, dsb — dipakai untuk
            // sudut membulat). Overflow dilonggarkan sementara selama panel
            // terbuka, lalu dikembalikan persis seperti semula saat ditutup.
            overflowFixEls = [];
            var el = wrap.parentElement;
            while (el && el !== document.body) {
                var cs = getComputedStyle(el);
                if (cs.overflow !== 'visible' || cs.overflowX !== 'visible' || cs.overflowY !== 'visible') {
                    overflowFixEls.push({
                        el: el,
                        overflow: el.style.overflow,
                        overflowX: el.style.overflowX,
                        overflowY: el.style.overflowY
                    });
                    el.style.overflow = 'visible';
                }
                el = el.parentElement;
            }
        }
        function restoreAncestorOverflow() {
            overflowFixEls.forEach(function (o) {
                o.el.style.overflow = o.overflow;
                o.el.style.overflowX = o.overflowX;
                o.el.style.overflowY = o.overflowY;
            });
            overflowFixEls = [];
        }
        function positionPanel() {
            // Sebelumnya panel SELALU dibuka ke bawah (top:100%) apa pun posisi
            // tombolnya, sehingga kalau tombol berada di bagian bawah layar/HP,
            // panel jadi terpotong atau keluar dari layar (tidak kelihatan sama
            // sekali). Di sini kita ukur dulu sisa ruang di atas & bawah tombol,
            // lalu buka ke arah yang ruangnya lebih cukup, dan batasi tinggi
            // panel (kpicker-list) supaya selalu pas dalam layar.
            var btnRect   = btn.getBoundingClientRect();
            var vh        = window.innerHeight || document.documentElement.clientHeight;
            var margin    = 12; // jarak aman ke tepi layar
            var spaceBelow = vh - btnRect.bottom - margin;
            var spaceAbove = btnRect.top - margin;
            var searchAreaH = searchWrap.offsetHeight || 46;

            var flipUp = spaceBelow < 160 && spaceAbove > spaceBelow;
            wrap.classList.toggle('kpicker-flip-up', flipUp);

            var available = (flipUp ? spaceAbove : spaceBelow) - searchAreaH;
            // Jangan terlalu kecil ataupun tak terbatas — clamp ke rentang wajar.
            list.style.maxHeight = Math.max(120, Math.min(available, 280)) + 'px';
        }
        function openPanel() {
            wrap.classList.add('open');
            search.value = '';
            rows.forEach(function (r) { r.style.display = ''; });
            releaseAncestorOverflow();
            positionPanel();
            setTimeout(function () { search.focus(); }, 0);
        }
        function closePanel() {
            wrap.classList.remove('open');
            wrap.classList.remove('kpicker-flip-up');
            restoreAncestorOverflow();
        }
        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            wrap.classList.contains('open') ? closePanel() : openPanel();
        });
        search.addEventListener('input', function () {
            var q = search.value.toLowerCase().trim();
            rows.forEach(function (r) {
                r.style.display = !q || r.dataset.searchText.indexOf(q) !== -1 ? '' : 'none';
            });
        });
        search.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') closePanel();
        });
        document.addEventListener('click', function (e) {
            if (!wrap.contains(e.target)) closePanel();
        });
        window.addEventListener('resize', function () {
            if (wrap.classList.contains('open')) positionPanel();
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('select[data-kontrak-picker]').forEach(enhance);
    });
})();
