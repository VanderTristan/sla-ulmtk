/**
 * assets/js/chart-helpers.js
 *
 * Pembantu bersama untuk SEMUA grafik Chart.js (Dashboard, Rekap SLA, Rata-Rata,
 * Laporan Grafik) supaya tampilannya konsisten dan tidak terkesan "dipaksakan".
 *
 * Prinsip:
 *  - Sumbu mengikuti DATA, bukan dipaksa 0–100%. Nilai di atas 100% tetap tampil
 *    utuh (pencapaian SLA boleh > 100%). Garis acuan "Target 100%" hanya muncul
 *    kalau memang berada di dalam rentang sumbu.
 *  - Grafik batang selalu mulai dari 0 (jujur secara visual); grafik garis
 *    memakai rentang yang pas dengan data, tidak dipepetkan ke 0–100.
 *  - Data kosong menampilkan "Belum ada data", bukan sumbu kosong.
 *  - Nama panjang dibungkus ke beberapa baris (tidak dipotong "…") dan tetap utuh di tooltip.
 *  - Nilai ditulis di ujung batang supaya tidak perlu hover untuk membaca angka.
 *
 * Wajib dipanggil setelah chart.umd.min.js. Pakai: SLAChart.init(); lalu
 * SLAChart.line(canvas, {...}) / SLAChart.bar(canvas, {...}).
 */
(function (w) {
    'use strict';

    var dark = document.documentElement.getAttribute('data-theme') === 'dark';
    var C = {
        tick:  dark ? '#93a3b8' : '#64748b',
        grid:  dark ? '#223141' : '#eef2f6',
        label: dark ? '#cbd6e2' : '#374151',
        ref:   dark ? '#64748b' : '#94a3b8'
    };

    function nums(arrs) {
        var out = [];
        arrs.forEach(function (a) {
            (a || []).forEach(function (v) {
                if (typeof v === 'number' && isFinite(v)) out.push(v);
            });
        });
        return out;
    }

    // Rentang sumbu garis yang pas dengan data (kelipatan 5, minimal selebar 10 poin).
    function lineRange(arrs) {
        var v = nums(arrs);
        if (!v.length) return { min: 0, max: 100 };
        var lo = Math.min.apply(null, v), hi = Math.max.apply(null, v);
        if (hi >= 90) hi = Math.max(hi, 100);            // sertakan target bila data sudah mendekati
        if (hi - lo < 10) { var mid = (hi + lo) / 2; lo = mid - 5; hi = mid + 5; }
        lo = Math.floor((lo - 3) / 5) * 5;
        hi = Math.ceil((hi + 3) / 5) * 5;
        return { min: lo, max: hi };
    }

    // Bungkus nama panjang ke beberapa baris (bukan dipotong "…"), supaya nama tetap utuh
    // dan terbaca natural. Pemisah " • " selalu jadi baris baru. Pemotongan baru dipakai
    // sebagai jalan terakhir kalau nama melebihi maxLines baris.
    function wrap(text, width, maxLines) {
        text = String(text == null ? '' : text).trim();
        maxLines = maxLines || 3;
        var lines = [];
        text.split(/\s+[•|]\s+/).forEach(function (part) {
            var cur = '';
            part.split(/\s+/).forEach(function (w) {
                if (!cur) cur = w;
                else if ((cur + ' ' + w).length <= width) cur += ' ' + w;
                else { lines.push(cur); cur = w; }
            });
            if (cur) lines.push(cur);
        });
        if (lines.length > maxLines) {
            var rest = lines.slice(maxLines - 1).join(' ');
            lines = lines.slice(0, maxLines - 1);
            lines.push(rest.length > width ? rest.slice(0, width - 1) + '…' : rest);
        }
        return lines.length > 1 ? lines : (lines[0] || '');
    }

    // ── Plugin: pesan saat data kosong ───────────────────────────────────
    var noData = {
        id: 'slaNoData',
        afterDraw: function (chart) {
            var has = chart.data.datasets.some(function (ds) {
                return (ds.data || []).some(function (v) { return typeof v === 'number' && isFinite(v); });
            });
            if (has) return;
            var a = chart.chartArea, ctx = chart.ctx;
            ctx.save();
            ctx.fillStyle = C.tick;
            ctx.font = '12px "Segoe UI", system-ui, sans-serif';
            ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            ctx.fillText('Belum ada data', (a.left + a.right) / 2, (a.top + a.bottom) / 2);
            ctx.restore();
        }
    };

    // ── Plugin: garis acuan (mis. Target 100%) — hanya bila masuk rentang sumbu ──
    var refLine = {
        id: 'slaRefLine',
        afterDatasetsDraw: function (chart, args, opts) {
            if (!opts || opts.value == null) return;
            var axis = opts.axis || 'y', scale = chart.scales[axis];
            if (!scale || opts.value < scale.min || opts.value > scale.max) return;
            var px = scale.getPixelForValue(opts.value), a = chart.chartArea, ctx = chart.ctx;
            ctx.save();
            ctx.strokeStyle = C.ref; ctx.lineWidth = 1; ctx.setLineDash([5, 4]);
            ctx.beginPath();
            if (axis === 'y') { ctx.moveTo(a.left, px); ctx.lineTo(a.right, px); }
            else              { ctx.moveTo(px, a.top);  ctx.lineTo(px, a.bottom); }
            ctx.stroke(); ctx.setLineDash([]);
            ctx.fillStyle = C.ref; ctx.font = '10px "Segoe UI", system-ui, sans-serif';
            if (axis === 'y') { ctx.textAlign = 'right'; ctx.textBaseline = 'bottom'; ctx.fillText(opts.label || '', a.right - 2, px - 3); }
            else              { ctx.textAlign = 'left';  ctx.textBaseline = 'top';    ctx.fillText(opts.label || '', px + 4, a.top + 2); }
            ctx.restore();
        }
    };

    // ── Plugin: angka di ujung batang ────────────────────────────────────
    var valueLabels = {
        id: 'slaValueLabels',
        afterDatasetsDraw: function (chart, args, opts) {
            if (!opts || !opts.enabled) return;
            var horizontal = chart.options.indexAxis === 'y', ctx = chart.ctx;
            ctx.save();
            ctx.fillStyle = C.label; ctx.font = '600 10px "Segoe UI", system-ui, sans-serif';
            chart.data.datasets.forEach(function (ds, i) {
                var meta = chart.getDatasetMeta(i);
                if (meta.hidden) return;
                meta.data.forEach(function (bar, idx) {
                    var v = ds.data[idx];
                    if (typeof v !== 'number' || !isFinite(v)) return;
                    var txt = v.toFixed(1) + '%';
                    if (horizontal) { ctx.textAlign = 'left';   ctx.textBaseline = 'middle'; ctx.fillText(txt, bar.x + 5, bar.y); }
                    else            { ctx.textAlign = 'center'; ctx.textBaseline = 'bottom'; ctx.fillText(txt, bar.x, bar.y - 4); }
                });
            });
            ctx.restore();
        }
    };

    function tooltipLabel(ctx) {
        var v = ctx.parsed[ctx.chart.options.indexAxis === 'y' ? 'x' : 'y'];
        if (typeof v !== 'number') return '';
        return (ctx.dataset.label ? ctx.dataset.label + ': ' : '') + v.toFixed(2) + '%';
    }

    function legendOpts(show) {
        return { display: !!show, position: 'bottom', labels: { boxWidth: 10, boxHeight: 10, padding: 12, usePointStyle: true, font: { size: 11 } } };
    }

    function colorsFor(values) {
        return values.map(function (v) {
            return v >= 90 ? 'rgba(16,185,129,0.82)' : (v >= 70 ? 'rgba(245,158,11,0.82)' : 'rgba(220,38,38,0.82)');
        });
    }

    // ── Grafik garis ─────────────────────────────────────────────────────
    function line(canvas, cfg) {
        if (!canvas) return null;
        var n = (cfg.labels || []).length;
        var range = lineRange(cfg.datasets.map(function (d) { return d.data; }));
        var datasets = cfg.datasets.map(function (d) {
            return Object.assign({
                borderWidth: 2.2, tension: 0.2, spanGaps: true,
                pointRadius: n === 1 ? 5 : (n > 18 ? 0 : 3), pointHoverRadius: 5,
                backgroundColor: 'transparent', fill: false
            }, d);
        });
        var plugins = {
            legend: legendOpts(cfg.legend),
            tooltip: { mode: 'index', intersect: false, padding: 8, callbacks: { label: tooltipLabel } },
            slaRefLine: cfg.ref != null ? { value: cfg.ref, axis: 'y', label: 'Target ' + cfg.ref + '%' } : false
        };
        return new Chart(canvas, {
            type: 'line',
            data: { labels: cfg.labels, datasets: datasets },
            options: {
                responsive: true, maintainAspectRatio: false,
                animation: { duration: 450 }, interaction: { mode: 'index', intersect: false },
                layout: { padding: { top: 6, right: 6 } },
                plugins: plugins,
                scales: {
                    x: {
                        grid: { display: false }, border: { display: false },
                        ticks: {
                            autoSkip: true, maxRotation: 0, minRotation: 0, font: { size: 10 },
                            callback: function (v) { return wrap(this.getLabelForValue(v), cfg.tickLen || 14, 3); }
                        }
                    },
                    y: {
                        min: range.min, max: range.max, border: { display: false }, grid: { color: C.grid },
                        ticks: { maxTicksLimit: 6, font: { size: 10 }, callback: function (v) { return v + '%'; } }
                    }
                }
            }
        });
    }

    // ── Grafik batang (vertikal / horizontal) ────────────────────────────
    function bar(canvas, cfg) {
        if (!canvas) return null;
        var horizontal = !!cfg.horizontal;
        var datasets = cfg.datasets.map(function (d) {
            return Object.assign({
                borderRadius: 5, borderSkipped: false,
                maxBarThickness: horizontal ? 26 : 44, barPercentage: 0.8, categoryPercentage: 0.8
            }, d);
        });
        var valueScale = {
            beginAtZero: true, grace: '12%', border: { display: false }, grid: { color: C.grid },
            ticks: { maxTicksLimit: 6, font: { size: 10 }, callback: function (v) { return v + '%'; } }
        };
        var catScale = horizontal
            ? { grid: { display: false }, border: { display: false },
                ticks: { font: { size: 11 }, color: C.label, callback: function (v) { return wrap(this.getLabelForValue(v), cfg.tickLen || 26, 3); } } }
            : { grid: { display: false }, border: { display: false },
                ticks: { autoSkip: true, maxRotation: 0, font: { size: 10 }, callback: function (v) { return wrap(this.getLabelForValue(v), cfg.tickLen || 12, 3); } } };
        var oneDataset = datasets.length === 1;
        return new Chart(canvas, {
            type: 'bar',
            data: { labels: cfg.labels, datasets: datasets },
            options: {
                indexAxis: horizontal ? 'y' : 'x',
                responsive: true, maintainAspectRatio: false, animation: { duration: 450 },
                layout: { padding: { top: 14, right: horizontal ? 8 : 6 } },
                plugins: {
                    legend: legendOpts(cfg.legend),
                    tooltip: { mode: oneDataset ? 'nearest' : 'index', intersect: oneDataset, padding: 8, callbacks: { label: tooltipLabel } },
                    slaRefLine: cfg.ref != null ? { value: cfg.ref, axis: horizontal ? 'x' : 'y', label: 'Target ' + cfg.ref + '%' } : false,
                    slaValueLabels: { enabled: cfg.valueLabels !== false && oneDataset && (cfg.labels || []).length <= (horizontal ? 40 : 12) }
                },
                scales: horizontal ? { x: valueScale, y: catScale } : { x: catScale, y: valueScale }
            }
        });
    }

    function init() {
        Chart.defaults.font.family = "'Segoe UI', system-ui, sans-serif";
        Chart.defaults.font.size = 11;
        Chart.defaults.color = C.tick;
        Chart.register(noData, refLine, valueLabels);
    }

    w.SLAChart = { init: init, line: line, bar: bar, colorsFor: colorsFor, colors: C };
})(window);
