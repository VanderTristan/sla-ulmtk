<?php
/**
 * includes/kontrak_tabs.php
 *
 * Tab navigasi yang menghubungkan halaman kontrak (Data Kontrak + Target & Realisasi,
 * sudah digabung jadi satu) dengan halaman Monitoring Harian, untuk kontrak yang sama.
 *
 * Variabel yang harus tersedia sebelum include:
 *   $kontrak_id (int)  — wajib > 0
 *   $kontrakTabActive (string) — salah satu: 'kontrak' | 'harian'
 *   $kontrakTabHideRingkasan (bool, opsional) — true = kartu "Ringkasan Kontrak" tidak ditampilkan
 */
if (!empty($kontrak_id)):
    $kInfo = $kontrak ?? dbRow($db, "SELECT nama_kontrak, periode_bulan, tahun, tahap FROM kontrak WHERE id=?", [$kontrak_id]);
?>
<div class="kontrak-tabs">
    <div class="kontrak-tabs-label">
        <i class="bi bi-link-45deg"></i>
        Kontrak: <b><?= htmlspecialchars(($kInfo['nama_kontrak'] ?? '-') . ' — ' . ($kInfo['periode_bulan'] ?? '') . ' ' . ($kInfo['tahun'] ?? '')) ?></b>
    </div>
    <div class="kontrak-tabs-nav">
        <a class="kontrak-tab<?= $kontrakTabActive==='kontrak'?' active':'' ?>" href="kontrak.php?act=edit&id=<?= $kontrak_id ?>">
            <i class="bi bi-file-earmark-text"></i> Data Kontrak & Target/Realisasi
        </a>
        <a class="kontrak-tab<?= $kontrakTabActive==='harian'?' active':'' ?>" href="input_harian.php?kontrak_id=<?= $kontrak_id ?>">
            <i class="bi bi-calendar2-check"></i> Input SLA
        </a>
    </div>
</div>

<?php $ringkasan = empty($kontrakTabHideRingkasan) ? getRingkasanKontrak($db, (int)$kontrak_id) : null; if ($ringkasan): ?>
<div class="card" style="margin-bottom:16px;">
    <div class="card-header">
        <div class="card-title" style="font-size:13px;">📄 Ringkasan Kontrak</div>
    </div>
    <div class="stats-grid" style="grid-template-columns:repeat(4,1fr);padding:0 16px 16px;margin-bottom:0;">
        <div class="stat-card">
            <div class="stat-label">Nama Vendor</div>
            <div class="stat-value" style="font-size:14px;"><?= htmlspecialchars(mb_strimwidth((string)($ringkasan['vendor'] ?? ''),0,28,'…')) ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Nilai Kontrak</div>
            <div class="stat-value" style="font-size:14px;">Rp <?= number_format($ringkasan['nilai_kontrak'],0,',','.') ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Periode</div>
            <div class="stat-value" style="font-size:14px;"><?= htmlspecialchars((string)($ringkasan['periode'] ?? '')) ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Jumlah Indikator</div>
            <div class="stat-value" style="font-size:14px;"><?= $ringkasan['jumlah_indikator'] ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Total Bobot</div>
            <div class="stat-value" style="font-size:14px;"><?= number_format($ringkasan['total_bobot'],2) ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Progress SLA</div>
            <div class="stat-value <?= $ringkasan['status_class'] ?>" style="font-size:14px;"><?= number_format($ringkasan['progress_sla'],2) ?>%</div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Status</div>
            <div class="stat-value <?= $ringkasan['status_class'] ?>" style="font-size:14px;"><?= htmlspecialchars((string)($ringkasan['status_label'] ?? '')) ?></div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php endif; ?>
