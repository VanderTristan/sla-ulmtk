<?php
/**
 * xlsx_writer.php — Penulis file .xlsx NATIF & ringan, tanpa dependensi
 * eksternal (tanpa Composer / PhpSpreadsheet). Cukup butuh ekstensi PHP
 * "zip" yang sudah aktif secara default di XAMPP/Laragon.
 *
 * Cara pakai singkat:
 *   $xlsx = new SimpleXlsxWriter();
 *   $xlsx->addSheet('Ringkasan', $rows, $boldHeaderRow = true);
 *   $xlsx->addSheet('Detail Teknis', $rows2);
 *   $xlsx->download('laporan.xlsx'); // langsung kirim ke browser & exit
 *
 * Format $rows: array of array. Baris pertama biasanya header (opsional,
 * ditebalkan otomatis kalau $boldHeaderRow true). Nilai numerik otomatis
 * ditulis sebagai angka (bisa dihitung ulang di Excel), sisanya sebagai teks.
 */
class SimpleXlsxWriter
{
    /** @var array<int, array{name:string, rows:array, boldHeader:bool, colWidths:array}> */
    private array $sheets = [];

    public function addSheet(string $name, array $rows, bool $boldHeaderRow = true, array $colWidths = []): void
    {
        // Nama sheet Excel maksimal 31 karakter & tidak boleh berisi karakter tertentu
        $safeName = substr(preg_replace('/[\\\\\/\?\*\[\]:]/', ' ', $name), 0, 31);
        $this->sheets[] = [
            'name'       => $safeName ?: 'Sheet',
            'rows'       => $rows,
            'boldHeader' => $boldHeaderRow,
            'colWidths'  => $colWidths,
        ];
    }

    private function esc(string $s): string
    {
        return htmlspecialchars($s, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }

    private function colLetter(int $index): string
    {
        // index 0-based -> A, B, ... Z, AA, AB, ...
        $letter = '';
        $index++;
        while ($index > 0) {
            $rem = ($index - 1) % 26;
            $letter = chr(65 + $rem) . $letter;
            $index = intdiv($index - 1, 26);
        }
        return $letter;
    }

    private function buildSheetXml(array $sheet): string
    {
        $rowsXml = '';
        $rowNum = 1;
        $maxCol = 0;
        foreach ($sheet['rows'] as $rIdx => $row) {
            $isHeaderRow = $sheet['boldHeader'] && $rIdx === 0;
            $cellsXml = '';
            $colIdx = 0;
            foreach ($row as $val) {
                $ref = $this->colLetter($colIdx) . $rowNum;
                $styleAttr = $isHeaderRow ? ' s="1"' : '';
                if ($val === null || $val === '') {
                    $cellsXml .= "<c r=\"$ref\"$styleAttr/>";
                } elseif (is_int($val) || is_float($val)) {
                    // Hanya nilai PHP bertipe int/float asli yang ditulis sebagai angka,
                    // supaya string ber-leading-zero (no. HP, no. kontrak, plat nomor, dst
                    // yang datang dari database sebagai string) TIDAK ikut terpotong nolnya.
                    $cellsXml .= "<c r=\"$ref\"$styleAttr><v>" . (0 + $val) . "</v></c>";
                } else {
                    $text = $this->esc((string)$val);
                    $cellsXml .= "<c r=\"$ref\" t=\"inlineStr\"$styleAttr><is><t xml:space=\"preserve\">$text</t></is></c>";
                }
                $colIdx++;
            }
            $maxCol = max($maxCol, $colIdx);
            $rowsXml .= "<row r=\"$rowNum\">$cellsXml</row>";
            $rowNum++;
        }

        $colsXml = '';
        if (!empty($sheet['colWidths'])) {
            $colsXml = '<cols>';
            foreach ($sheet['colWidths'] as $i => $w) {
                $c = $i + 1;
                $colsXml .= "<col min=\"$c\" max=\"$c\" width=\"$w\" customWidth=\"1\"/>";
            }
            $colsXml .= '</cols>';
        }

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . $colsXml
            . '<sheetData>' . $rowsXml . '</sheetData>'
            . '</worksheet>';
    }

    private function buildStylesXml(): string
    {
        // Style index 0 = default, index 1 = bold header dengan background abu-abu muda
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<fonts count="2">'
            . '<font><sz val="10"/><name val="Calibri"/></font>'
            . '<font><b/><sz val="10"/><name val="Calibri"/></font>'
            . '</fonts>'
            . '<fills count="2">'
            . '<fill><patternFill patternType="none"/></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FFE6EEF9"/><bgColor indexed="64"/></patternFill></fill>'
            . '</fills>'
            . '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . '<cellXfs count="2">'
            . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            . '<xf numFmtId="0" fontId="1" fillId="1" borderId="0" xfId="0" applyFont="1" applyFill="1"/>'
            . '</cellXfs>'
            . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
            . '</styleSheet>';
    }

    /**
     * Simpan xlsx ke path file (dipakai internal oleh download()).
     */
    private function writeToFile(string $path): void
    {
        if (!class_exists('ZipArchive')) {
            throw new RuntimeException('Ekstensi PHP "zip" tidak aktif di server ini. Aktifkan extension=zip di php.ini untuk memakai fitur export Excel.');
        }

        $zip = new ZipArchive();
        if ($zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new RuntimeException('Gagal membuat file xlsx sementara.');
        }

        $zip->addFromString('[Content_Types].xml', $this->buildContentTypesXml());
        $zip->addFromString('_rels/.rels', $this->buildRootRelsXml());
        $zip->addFromString('xl/workbook.xml', $this->buildWorkbookXml());
        $zip->addFromString('xl/_rels/workbook.xml.rels', $this->buildWorkbookRelsXml());
        $zip->addFromString('xl/styles.xml', $this->buildStylesXml());

        foreach ($this->sheets as $i => $sheet) {
            $n = $i + 1;
            $zip->addFromString("xl/worksheets/sheet{$n}.xml", $this->buildSheetXml($sheet));
        }

        $zip->close();
    }

    private function buildContentTypesXml(): string
    {
        $overrides = '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';
        foreach ($this->sheets as $i => $sheet) {
            $n = $i + 1;
            $overrides .= "<Override PartName=\"/xl/worksheets/sheet{$n}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>";
        }
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . $overrides
            . '</Types>';
    }

    private function buildRootRelsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '</Relationships>';
    }

    private function buildWorkbookXml(): string
    {
        $sheetsXml = '';
        foreach ($this->sheets as $i => $sheet) {
            $n = $i + 1;
            $sheetsXml .= '<sheet name="' . $this->esc($sheet['name']) . "\" sheetId=\"$n\" r:id=\"rId$n\"/>";
        }
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            . 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheets>' . $sheetsXml . '</sheets>'
            . '</workbook>';
    }

    private function buildWorkbookRelsXml(): string
    {
        $relsXml = '<Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';
        foreach ($this->sheets as $i => $sheet) {
            $n = $i + 1;
            $relsXml .= "<Relationship Id=\"rId$n\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet{$n}.xml\"/>";
        }
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . $relsXml
            . '</Relationships>';
    }

    /**
     * Kirim file xlsx langsung sebagai download ke browser lalu exit.
     */
    public function download(string $filename): void
    {
        $tmp = tempnam(sys_get_temp_dir(), 'xlsx_');
        $this->writeToFile($tmp);

        if (ob_get_level()) { ob_end_clean(); }
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($tmp));
        header('Cache-Control: max-age=0');
        readfile($tmp);
        unlink($tmp);
        exit;
    }
}
