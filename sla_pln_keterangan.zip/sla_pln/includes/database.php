<?php
// ============================================================
//  Konfigurasi MySQL (PDO) — dimuat dari file .env (lihat .env.example)
//  Jangan hardcode kredensial database di kode untuk environment produksi.
//  PENTING: file .env harus dimuat SEBELUM auth.php, karena auth.php
//  membaca APP_ENV dari .env untuk menentukan apakah error PHP
//  ditampilkan (development) atau disembunyikan (production).
// ============================================================
if (!function_exists('loadEnvFile')) {
    function loadEnvFile(string $path): void {
        if (!is_readable($path)) return;
        foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#' || !str_contains($line, '=')) continue;
            [$k, $v] = array_map('trim', explode('=', $line, 2));
            $v = trim($v, "\"'");
            if (getenv($k) === false) {
                putenv("$k=$v");
                $_ENV[$k] = $v;
            }
        }
    }
}
loadEnvFile(__DIR__ . '/../.env');

require_once __DIR__ . '/auth.php';

define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_NAME') ?: 'sla_pln');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');

function getDB(): PDO {
    static $db = null;
    if ($db === null) {
        $dsn = 'mysql:host='.DB_HOST.';port='.DB_PORT.';dbname='.DB_NAME.';charset=utf8mb4';
        $db = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
        initDB($db);
    }
    return $db;
}

function initDB(PDO $db): void {
    $db->exec("SET FOREIGN_KEY_CHECKS=0");
    $db->exec("
    CREATE TABLE IF NOT EXISTS app_users (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        nama        VARCHAR(100)    NOT NULL,
        username    VARCHAR(50)     NOT NULL UNIQUE,
        email       VARCHAR(100)    NOT NULL,
        password    VARCHAR(255)    NOT NULL,
        foto        VARCHAR(255)    DEFAULT NULL,
        role        VARCHAR(30)     NOT NULL DEFAULT 'Viewer',
        status      VARCHAR(20)     NOT NULL DEFAULT 'Aktif',
        must_change_password TINYINT(1) NOT NULL DEFAULT 0,
        created_at  TIMESTAMP       DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    try {
        $db->exec("ALTER TABLE app_users ADD COLUMN must_change_password TINYINT(1) NOT NULL DEFAULT 0");
    } catch (Exception $e) { /* kolom sudah ada, abaikan */ }
    // ------------------------------------------------------------
    //  RESET PASSWORD LEWAT EMAIL (lihat forgot-password.php & reset-password.php)
    // ------------------------------------------------------------
    try {
        $db->exec("ALTER TABLE app_users ADD COLUMN reset_token VARCHAR(64) DEFAULT NULL");
        $db->exec("ALTER TABLE app_users ADD COLUMN reset_token_expires DATETIME DEFAULT NULL");
    } catch (Exception $e) { /* kolom sudah ada, abaikan */ }
    // ------------------------------------------------------------
    //  PREFERENSI MODE TAMPILAN (light/dark) — dipatri ke akun user,
    //  bukan cuma di browser, supaya konsisten dibawa lintas device.
    //  Dipakai oleh includes/header.php & theme_save.php.
    // ------------------------------------------------------------
    try {
        $db->exec("ALTER TABLE app_users ADD COLUMN theme_preference VARCHAR(5) NOT NULL DEFAULT 'light'");
    } catch (Exception $e) { /* kolom sudah ada, abaikan */ }
    // Akun admin default — password sementara: admin123
    // WAJIB diganti setelah login pertama kali (sistem akan mengingatkan otomatis).
    // Role 'SuperAdmin' = akses penuh ke semua fitur (kelola user, backup, dll).
    $db->exec("
    INSERT INTO app_users (nama, username, email, password, role, status, must_change_password)
    SELECT 'Administrator', 'admin', 'admin@plnnusadaya.co.id',
           '\$2y\$10\$JKEJm4I57INm9DCThsKWBODLijG3NpIgGJpqTDYXAOEsasUkxVWpm',
           'SuperAdmin', 'Aktif', 1
    WHERE NOT EXISTS (SELECT 1 FROM app_users WHERE username='admin')
    ");
    // Migrasi untuk instalasi lama: akun 'admin' yang masih berperan 'Admin'
    // (Team Leader lama, sebelum role Super Admin ada) dinaikkan otomatis
    // menjadi 'SuperAdmin' supaya akun instalasi awal tidak kehilangan akses.
    try {
        $db->exec("UPDATE app_users SET role='SuperAdmin' WHERE username='admin' AND role='Admin'");
    } catch (Exception $e) { /* abaikan */ }

    // ------------------------------------------------------------
    //  KEAMANAN: RATE LIMIT LOGIN & AUDIT LOG
    // ------------------------------------------------------------
    $db->exec("
    CREATE TABLE IF NOT EXISTS login_attempts (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        username    VARCHAR(50) NOT NULL,
        ip_address  VARCHAR(64) NOT NULL,
        success     TINYINT(1) NOT NULL DEFAULT 0,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_username_time (username, created_at),
        INDEX idx_ip_time (ip_address, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $db->exec("
    CREATE TABLE IF NOT EXISTS audit_log (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        user_id     INT DEFAULT NULL,
        username    VARCHAR(50) DEFAULT NULL,
        aksi        VARCHAR(50) NOT NULL,
        modul       VARCHAR(50) NOT NULL,
        detail      TEXT,
        data_lama   TEXT DEFAULT NULL,
        data_baru   TEXT DEFAULT NULL,
        alasan      TEXT DEFAULT NULL,
        ip_address  VARCHAR(64) DEFAULT NULL,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_modul_time (modul, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    // Migrasi ringan: tambahkan kolom data_lama/data_baru/alasan kalau tabel sudah ada sebelumnya
    try {
        $cols = $db->query("SHOW COLUMNS FROM audit_log")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('data_lama', $cols, true)) $db->exec("ALTER TABLE audit_log ADD COLUMN data_lama TEXT DEFAULT NULL AFTER detail");
        if (!in_array('data_baru', $cols, true)) $db->exec("ALTER TABLE audit_log ADD COLUMN data_baru TEXT DEFAULT NULL AFTER data_lama");
        if (!in_array('alasan', $cols, true)) $db->exec("ALTER TABLE audit_log ADD COLUMN alasan TEXT DEFAULT NULL AFTER data_baru");
    } catch (Throwable $e) { /* abaikan kalau gagal cek, tabel baru pasti sudah lengkap */ }
    $db->exec("
    CREATE TABLE IF NOT EXISTS kontrak (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nama_kontrak TEXT,
        no_kontrak_1 VARCHAR(255),
        no_kontrak_2 VARCHAR(255),
        tgl_kontrak VARCHAR(100),
        vendor VARCHAR(255),
        up3 VARCHAR(255),
        periode_bulan VARCHAR(50),
        tahun INT,
        tahap VARCHAR(50),
        jenis_kontrak VARCHAR(50) DEFAULT 'DISTRIBUSI',
        nilai_tagihan_tahap1 DOUBLE DEFAULT 0,
        nilai_tagihan_tahap2 DOUBLE DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    // Tambah kolom jenis_kontrak jika belum ada (untuk DB yang sudah ada)
    try {
        $db->exec("ALTER TABLE kontrak ADD COLUMN jenis_kontrak VARCHAR(50) DEFAULT 'DISTRIBUSI' AFTER tahap");
    } catch (Exception $e) { /* kolom sudah ada, abaikan */ }
    // Tambah kolom unit_id jika belum ada (relasi ke master Unit Kerja, mis. OPGI/GP — lihat blok "UNIT KERJA" di bawah)
    try {
        $db->exec("ALTER TABLE kontrak ADD COLUMN unit_id INT DEFAULT NULL AFTER jenis_kontrak");
    } catch (Exception $e) { /* kolom sudah ada, abaikan */ }

    // ------------------------------------------------------------
    //  BERSIH-BERSIH: tabel & kolom yang sempat dibuat untuk fitur
    //  "master data vendor" tapi tidak pernah dipakai di aplikasi
    //  (tidak ada dropdown/laporan/join yang membacanya — nama vendor
    //  di seluruh aplikasi tetap pakai kolom teks bebas kontrak.vendor).
    //  Migrasi sekali-jalan ini aman diulang berkali-kali (idempotent).
    // ------------------------------------------------------------
    try { $db->exec("ALTER TABLE kontrak DROP COLUMN vendor_id"); } catch (Exception $e) { /* kolom sudah tidak ada, abaikan */ }
    try { $db->exec("DROP TABLE IF EXISTS vendor"); } catch (Exception $e) { /* tabel sudah tidak ada, abaikan */ }

    $db->exec("
    CREATE TABLE IF NOT EXISTS ulp (
        id INT AUTO_INCREMENT PRIMARY KEY,
        kontrak_id INT,
        nama_ulp VARCHAR(255),
        manager_pln VARCHAR(255),
        koordinator_nd VARCHAR(255),
        FOREIGN KEY(kontrak_id) REFERENCES kontrak(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    // Tambah kolom ulp_master_id jika belum ada (relasi opsional ke Master ULP —
    // lihat blok "MASTER DATA: ULP (GLOBAL)" di bawah). Nullable & tanpa FK constraint
    // (sama seperti kontrak.unit_id) supaya data ULP per-kontrak yang sudah diketik
    // manual sebelumnya tetap jalan walau tidak dikaitkan ke master mana pun.
    try {
        $db->exec("ALTER TABLE ulp ADD COLUMN ulp_master_id INT DEFAULT NULL AFTER kontrak_id");
    } catch (Exception $e) { /* kolom sudah ada, abaikan */ }

    // ------------------------------------------------------------
    //  MASTER DATA: ULP (GLOBAL) — daftar ULP yang bisa dipakai ulang di
    //  banyak kontrak (mis. ULP Manado, ULP Tomohon, dst), supaya operator
    //  tidak perlu ketik ulang nama+manager+koordinator tiap kali bikin
    //  Data ULP baru untuk kontrak lain. Data ULP PER-KONTRAK (tabel `ulp`
    //  di atas) tetap ada apa adanya — field & fungsinya (realisasi SLA per
    //  ULP, Rekap ULP per Bulan) tidak berubah; Master ULP ini cuma sumber
    //  isian cepat (opsional), bukan pengganti.
    // ------------------------------------------------------------
    $db->exec("
    CREATE TABLE IF NOT EXISTS ulp_master (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nama_ulp VARCHAR(255) NOT NULL,
        manager_pln VARCHAR(255),
        koordinator_nd VARCHAR(255),
        keterangan VARCHAR(255),
        is_active TINYINT(1) DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    // Bersihkan contoh seed lama ("ULP Manado", "ULP Bitung") yang namanya
    // sama/mirip dengan nama Unit Kerja ("Unit Layanan Manado" dkk) — dua konsep
    // beda level (Unit Kerja = penentu template SLA kontrak; Master ULP = sub-area
    // pendukung per-kontrak) yang namanya nyaris identik bikin operator bingung.
    // Cuma dihapus kalau belum pernah dipakai di kontrak manapun (aman, tidak
    // menghapus data yang sudah terlanjur dikaitkan).
    foreach (['ULP Manado', 'ULP Bitung'] as $namaLama) {
        $dipakai = (int)dbVal($db,
            "SELECT COUNT(*) FROM ulp u JOIN ulp_master m ON u.ulp_master_id=m.id WHERE LOWER(TRIM(m.nama_ulp))=LOWER(TRIM(?))",
            [$namaLama]);
        if ($dipakai === 0) {
            $db->prepare("DELETE FROM ulp_master WHERE LOWER(TRIM(nama_ulp))=LOWER(TRIM(?))")->execute([$namaLama]);
        }
    }
    // Contoh awal (seed) — nama-nama ULP sungguhan dari dokumen BA SLA Distribusi
    // (bukan nama kota yang sama dengan Unit Kerja, supaya tidak ketuker dengan
    // "Unit Layanan Manado/Tahuna" dkk). Silakan diedit/dihapus/ditambah bebas
    // lewat menu Master ULP.
    foreach (['ULP Kotamobagu', 'ULP Inobonto', 'ULP Bolmut', 'ULP Imandi', 'ULP Modayag', 'ULP Molibagu', 'ULP Tomohon', 'ULP Tondano'] as $namaContoh) {
        $db->prepare("
        INSERT INTO ulp_master (nama_ulp)
        SELECT ? WHERE NOT EXISTS (SELECT 1 FROM ulp_master WHERE LOWER(TRIM(nama_ulp))=LOWER(TRIM(?)))
        ")->execute([$namaContoh, $namaContoh]);
    }
    // ------------------------------------------------------------
    //  MASTER DATA: UNIT KERJA (mis. per jenis kontrak: Transmisi -> OPGI, GP dst,
    //  Pembangkit -> ...). Tiap kontrak nanti bisa dikaitkan
    //  ke SATU unit kerja sesuai jenis kontraknya. Unit-unit ini murni master data
    //  yang bisa ditambah/diubah bebas lewat halaman unit_kerja.php — cara input SLA
    //  per unit BISA dibuat berbeda-beda nanti dengan mengecek kontrak.unit_id.
    // ------------------------------------------------------------
    $db->exec("
    CREATE TABLE IF NOT EXISTS unit_kerja (
        id            INT AUTO_INCREMENT PRIMARY KEY,
        jenis_kontrak VARCHAR(50) NOT NULL DEFAULT 'DISTRIBUSI',
        kode          VARCHAR(30) NOT NULL,
        nama          VARCHAR(150) NOT NULL,
        keterangan    VARCHAR(255) DEFAULT NULL,
        urutan        INT DEFAULT 0,
        is_active     TINYINT(1) DEFAULT 1,
        created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_unit_jenis_kode (jenis_kontrak, kode)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    // Daftar Project (nama tampilan "resmi" per Bidang) — silakan ditambah/diubah
    // bebas lewat menu Unit Kerja. `kode` dipakai sebagai kunci internal pencarian
    // template SLA ($unitTemplates di bawah) dan SENGAJA tidak diubah lagi walau
    // `nama` (yang tampil ke user) berubah, supaya template yang sudah terpasang
    // di kontrak-kontrak lama tetap nyambung.
    $db->exec("
    INSERT INTO unit_kerja (jenis_kontrak, kode, nama, urutan)
    SELECT 'TRANSMISI', 'OPGI', 'O&M GI UPT MANADO', 1
    WHERE NOT EXISTS (SELECT 1 FROM unit_kerja WHERE jenis_kontrak='TRANSMISI' AND kode='OPGI')
    ");
    $db->exec("
    INSERT INTO unit_kerja (jenis_kontrak, kode, nama, urutan)
    SELECT 'TRANSMISI', 'GP', 'GROUND PATROL UPT MANADO', 2
    WHERE NOT EXISTS (SELECT 1 FROM unit_kerja WHERE jenis_kontrak='TRANSMISI' AND kode='GP')
    ");
    $db->exec("
    INSERT INTO unit_kerja (jenis_kontrak, kode, nama, urutan)
    SELECT 'TRANSMISI', 'HAR_TRANS', 'HAR. TRANS. UPT MANADO', 3
    WHERE NOT EXISTS (SELECT 1 FROM unit_kerja WHERE jenis_kontrak='TRANSMISI' AND kode='HAR_TRANS')
    ");
    $db->exec("
    INSERT INTO unit_kerja (jenis_kontrak, kode, nama, urutan)
    SELECT 'DISTRIBUSI', 'DISTRIBUSI', 'O&M DIST. KOTAMOBAGU', 1
    WHERE NOT EXISTS (SELECT 1 FROM unit_kerja WHERE jenis_kontrak='DISTRIBUSI' AND kode='DISTRIBUSI')
    ");
    $db->exec("
    INSERT INTO unit_kerja (jenis_kontrak, kode, nama, urutan)
    SELECT 'DISTRIBUSI', 'MANADO', 'O&M DIST. MANADO', 2
    WHERE NOT EXISTS (SELECT 1 FROM unit_kerja WHERE jenis_kontrak='DISTRIBUSI' AND kode='MANADO')
    ");
    $db->exec("
    INSERT INTO unit_kerja (jenis_kontrak, kode, nama, urutan)
    SELECT 'DISTRIBUSI', 'TAHUNA', 'O&M DIST. TAHUNA', 3
    WHERE NOT EXISTS (SELECT 1 FROM unit_kerja WHERE jenis_kontrak='DISTRIBUSI' AND kode='TAHUNA')
    ");
    $db->exec("
    INSERT INTO unit_kerja (jenis_kontrak, kode, nama, urutan)
    SELECT 'DISTRIBUSI', 'KEYPOINT_SCADA', 'HAR. KEYPOINT SCADA', 4
    WHERE NOT EXISTS (SELECT 1 FROM unit_kerja WHERE jenis_kontrak='DISTRIBUSI' AND kode='KEYPOINT_SCADA')
    ");
    $db->exec("
    INSERT INTO unit_kerja (jenis_kontrak, kode, nama, urutan)
    SELECT 'PEMBANGKIT', 'KIT_MINAHASA', 'O&M KIT MINAHASA', 1
    WHERE NOT EXISTS (SELECT 1 FROM unit_kerja WHERE jenis_kontrak='PEMBANGKIT' AND kode='KIT_MINAHASA')
    ");
    $db->exec("
    INSERT INTO unit_kerja (jenis_kontrak, kode, nama, urutan)
    SELECT 'PEMBANGKIT', 'KIT_LAHENDONG', 'O&M KIT. PLTP LAHENDONG', 2
    WHERE NOT EXISTS (SELECT 1 FROM unit_kerja WHERE jenis_kontrak='PEMBANGKIT' AND kode='KIT_LAHENDONG')
    ");
    // Migrasi nama untuk database yang sudah lebih dulu ter-seed dengan nama lama
    // ("OPGI", "GP", "Distribusi", "Unit Layanan Manado/Tahuna") — disamakan ke
    // penyebutan resmi di atas. Aman/idempotent: kalau nama sudah sama, tidak ngapa-ngapain.
    $renameUnitLama = [
        ['TRANSMISI', 'OPGI', 'O&M GI UPT MANADO'],
        ['TRANSMISI', 'GP', 'GROUND PATROL UPT MANADO'],
        ['DISTRIBUSI', 'DISTRIBUSI', 'O&M DIST. KOTAMOBAGU'],
        ['DISTRIBUSI', 'MANADO', 'O&M DIST. MANADO'],
        ['DISTRIBUSI', 'TAHUNA', 'O&M DIST. TAHUNA'],
    ];
    foreach ($renameUnitLama as [$jk, $kd, $namaBaru]) {
        $db->prepare("UPDATE unit_kerja SET nama=? WHERE jenis_kontrak=? AND kode=? AND nama<>?")
           ->execute([$namaBaru, $jk, $kd, $namaBaru]);
    }
    // ------------------------------------------------------------
    //  DATA KENDARAAN & PERSONIL (per kontrak)
    // ------------------------------------------------------------
    $db->exec("
    CREATE TABLE IF NOT EXISTS kendaraan (
        id                  INT AUTO_INCREMENT PRIMARY KEY,
        kontrak_id          INT NOT NULL,
        jenis_kendaraan     VARCHAR(50)  DEFAULT NULL,
        fungsi_kendaraan    VARCHAR(150) DEFAULT NULL,
        merk_type           VARCHAR(150) DEFAULT NULL,
        tahun               VARCHAR(10)  DEFAULT NULL,
        nomor_polisi        VARCHAR(30)  DEFAULT NULL,
        warna               VARCHAR(50)  DEFAULT NULL,
        lokasi              VARCHAR(150) DEFAULT NULL,
        nama_ulp            VARCHAR(150) DEFAULT NULL,
        nama_koordinator    VARCHAR(150) DEFAULT NULL,
        no_hp_koordinator   VARCHAR(30)  DEFAULT NULL,
        created_at          DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(kontrak_id) REFERENCES kontrak(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    // Kolom lama yang sudah tidak dipakai di form/tabel kendaraan — dibuang dari DB lama.
    foreach (['nomor_rangka', 'nomor_mesin', 'nama_pemilik'] as $kolomLama) {
        try { $db->exec("ALTER TABLE kendaraan DROP COLUMN $kolomLama"); }
        catch (Exception $e) { /* kolom sudah tidak ada, abaikan */ }
    }
    $db->exec("
    CREATE TABLE IF NOT EXISTS personil (
        id              INT AUTO_INCREMENT PRIMARY KEY,
        kontrak_id      INT NOT NULL,
        nama_ulp        VARCHAR(150) DEFAULT NULL,
        nama_kp         VARCHAR(150) DEFAULT NULL,
        daftar_tim      VARCHAR(150) DEFAULT NULL,
        nama_petugas    VARCHAR(150) NOT NULL,
        jabatan         VARCHAR(150) DEFAULT NULL,
        no_hp           VARCHAR(30)  DEFAULT NULL,
        created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(kontrak_id) REFERENCES kontrak(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    // Tambah kolom ulp_id jika belum ada — relasi OPSIONAL ke Data ULP per-kontrak
    // (tabel `ulp`, yang juga dipakai Input SLA/Target & Realisasi). Ini menyambungkan
    // Data Kendaraan & Data Personil ke ULP yang SAMA dengan yang dipakai input SLA,
    // supaya nanti bisa direkap/difilter per ULP secara konsisten (bukan cuma
    // mengandalkan ketikan bebas nama_ulp yang rawan beda ejaan). Nullable & tanpa
    // FK constraint keras (sama seperti ulp.ulp_master_id) supaya data lama yang
    // nama_ulp-nya cuma teks bebas (mis. "UP3 MANADO" / gabungan) tetap jalan.
    try {
        $db->exec("ALTER TABLE kendaraan ADD COLUMN ulp_id INT DEFAULT NULL AFTER kontrak_id");
    } catch (Exception $e) { /* kolom sudah ada, abaikan */ }
    try {
        $db->exec("ALTER TABLE personil ADD COLUMN ulp_id INT DEFAULT NULL AFTER kontrak_id");
    } catch (Exception $e) { /* kolom sudah ada, abaikan */ }

    $db->exec("
    CREATE TABLE IF NOT EXISTS sla_entries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        kontrak_id INT,
        ulp_id INT DEFAULT NULL,
        kategori VARCHAR(50),
        no_urut VARCHAR(20),
        ruang_lingkup TEXT,
        kriteria TEXT,
        target_kinerja TEXT,
        eviden TEXT DEFAULT NULL,
        polaritas VARCHAR(20),
        satuan VARCHAR(50),
        bobot DOUBLE DEFAULT 2,
        jenis_bobot VARCHAR(50) DEFAULT 'Prioritas 1',
        target DOUBLE DEFAULT 0,
        realisasi DOUBLE DEFAULT 0,
        persen_pencapaian DOUBLE DEFAULT 0,
        nilai_bobot DOUBLE DEFAULT 0,
        keterangan TEXT DEFAULT NULL,
        FOREIGN KEY(kontrak_id) REFERENCES kontrak(id) ON DELETE CASCADE,
        FOREIGN KEY(ulp_id)     REFERENCES ulp(id)     ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    // Tambah kolom keterangan jika belum ada (untuk DB yang sudah ada sebelumnya) —
    // dipakai untuk menjelaskan sebab indikator SLA belum mencapai target.
    try {
        $colsKet = $db->query("SHOW COLUMNS FROM sla_entries LIKE 'keterangan'")->fetchAll();
        if (empty($colsKet)) {
            $db->exec("ALTER TABLE sla_entries ADD COLUMN keterangan TEXT DEFAULT NULL AFTER nilai_bobot");
        }
    } catch (Exception $e) { /* abaikan kalau gagal cek/alter */ }
    // Tambah kolom eviden jika belum ada (untuk DB yang sudah ada sebelumnya) —
    // dokumen/bukti pendukung yang perlu dilampirkan untuk tiap indikator SLA
    // (mis. "Formulir checklist pemeriksaan APD"), sesuai BA SLA masing-masing Unit.
    try {
        $colsEviden = $db->query("SHOW COLUMNS FROM sla_entries LIKE 'eviden'")->fetchAll();
        if (empty($colsEviden)) {
            $db->exec("ALTER TABLE sla_entries ADD COLUMN eviden TEXT DEFAULT NULL AFTER target_kinerja");
        }
    } catch (Exception $e) { /* abaikan kalau gagal cek/alter */ }
    // Tambah kolom target_waktu_input jika belum ada — mencatat waktu persis (sampai detik)
    // kapan nilai Target indikator ini terakhir diubah. Waktu input Realisasi sudah
    // tercatat per periode di monitoring_harian.updated_at.
    try {
        $colsTW = $db->query("SHOW COLUMNS FROM sla_entries LIKE 'target_waktu_input'")->fetchAll();
        if (empty($colsTW)) {
            $db->exec("ALTER TABLE sla_entries ADD COLUMN target_waktu_input DATETIME DEFAULT NULL AFTER keterangan");
        }
    } catch (Exception $e) { /* abaikan kalau gagal cek/alter */ }
    // Ubah realisasi/persen_pencapaian/nilai_bobot supaya bisa NULL, sebagai penanda
    // "belum dinilai" (beda dengan realisasi = 0 yang berarti benar-benar hasilnya nol).
    // Sebelumnya kolom ini DEFAULT 0, jadi indikator yang belum sempat diisi ikut
    // dihitung sebagai GAGAL (0%) dalam skor SLA — ini yang diperbaiki di sini.
    try {
        $colNull = $db->query("SELECT IS_NULLABLE FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sla_entries' AND COLUMN_NAME = 'realisasi'")->fetch();
        if ($colNull && strtoupper($colNull['IS_NULLABLE']) !== 'YES') {
            $db->exec("ALTER TABLE sla_entries MODIFY realisasi DOUBLE NULL DEFAULT NULL");
            $db->exec("ALTER TABLE sla_entries MODIFY persen_pencapaian DOUBLE NULL DEFAULT NULL");
            $db->exec("ALTER TABLE sla_entries MODIFY nilai_bobot DOUBLE NULL DEFAULT NULL");
            // Migrasi data lama: baris yang polanya persis "belum pernah disentuh"
            // (realisasi, persen_pencapaian, nilai_bobot semuanya masih 0 — nilai default
            // bawaan sistem) diubah jadi NULL supaya tidak lagi dihitung sebagai gagal.
            // Catatan: kalau memang pernah ada indikator yang SENGAJA disimpan dengan
            // realisasi 0 (benar-benar gagal total), baris itu ikut ter-reset jadi
            // "Belum Dinilai" juga karena polanya sama persis di database — silakan isi
            // ulang manual kalau ada kasus seperti itu.
            $db->exec("UPDATE sla_entries SET realisasi = NULL, persen_pencapaian = NULL, nilai_bobot = NULL
                WHERE realisasi = 0 AND persen_pencapaian = 0 AND nilai_bobot = 0");
        }
    } catch (Exception $e) { /* abaikan kalau gagal cek/alter */ }
    $db->exec("
    CREATE TABLE IF NOT EXISTS rekap_sla (
        id INT AUTO_INCREMENT PRIMARY KEY,
        kontrak_id INT UNIQUE,
        sla_teknis DOUBLE DEFAULT 0,
        sla_k3 DOUBLE DEFAULT 0,
        sla_kecelakaan DOUBLE DEFAULT 0,
        sla_ilp DOUBLE DEFAULT 0,
        total_bobot DOUBLE DEFAULT 0,
        sla_overall DOUBLE DEFAULT 0,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY(kontrak_id) REFERENCES kontrak(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    // Kolom denda_teknis/denda_k3/denda_kecelakaan/denda_ilp/total_denda sudah tidak
    // dipakai (fitur denda dikonfirmasi tidak dipakai lagi) — dihapus dari DB lama juga
    // supaya skemanya bersih, bukan cuma dihilangkan dari definisi tabel di atas.
    foreach (['denda_teknis','denda_k3','denda_kecelakaan','denda_ilp','total_denda'] as $kolomLama) {
        try { $db->exec("ALTER TABLE rekap_sla DROP COLUMN $kolomLama"); }
        catch (Exception $e) { /* kolom sudah tidak ada, abaikan */ }
    }
    // Tambah kolom sla_overall jika belum ada (untuk DB lama yang dibuat sebelum kolom ini ditambahkan)
    try {
        $db->exec("ALTER TABLE rekap_sla ADD COLUMN sla_overall DOUBLE DEFAULT 0 AFTER total_bobot");
    } catch (Exception $e) { /* kolom sudah ada, abaikan */ }
    // Backfill sla_overall untuk data lama: skor keseluruhan HARUS dihitung sebagai
    // total nilai-berbobot semua indikator (lintas 4 kategori) dibagi total bobot
    // semua indikator tsb — BUKAN rata-rata sederhana (sla_teknis+sla_k3+sla_kecelakaan+sla_ilp)/4,
    // karena keempat kategori itu punya total bobot yang berbeda-beda (mis. TEKNIS jauh lebih
    // besar bobotnya dari KECELAKAAN/ILP), jadi kalau dirata-ratakan sama besar, kategori
    // berbobot kecil jadi berpengaruh berlebihan ke skor akhir. Idempotent — aman dijalankan tiap request.
    $db->exec("
    UPDATE rekap_sla r
    SET sla_overall = (
        SELECT CASE WHEN SUM(se.bobot) > 0 THEN SUM(se.nilai_bobot) / SUM(se.bobot) ELSE 0 END
        FROM sla_entries se
        WHERE se.kontrak_id = r.kontrak_id AND se.ulp_id IS NULL AND se.realisasi IS NOT NULL
    )
    WHERE r.sla_overall = 0 OR r.sla_overall IS NULL
    ");
    // ------------------------------------------------------------
    //  TRANSAKSI: INPUT MONITORING HARIAN
    // ------------------------------------------------------------
    $db->exec("
    CREATE TABLE IF NOT EXISTS monitoring_harian (
        id           INT AUTO_INCREMENT PRIMARY KEY,
        sla_entry_id INT NOT NULL,
        tanggal      DATE NOT NULL,
        periode      TINYINT(1) DEFAULT NULL,
        nilai_harian DOUBLE DEFAULT 0,
        catatan      VARCHAR(255) DEFAULT NULL,
        created_by   VARCHAR(100) DEFAULT NULL,
        created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_entry_periode (sla_entry_id, periode),
        FOREIGN KEY(sla_entry_id) REFERENCES sla_entries(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    // Migrasi ringan: bersihkan kolom lama utk field yang sudah tidak dipakai / tambahkan yang baru
    try {
        $cols = $db->query("SHOW COLUMNS FROM monitoring_harian")->fetchAll(PDO::FETCH_COLUMN);
        // Konsep approval dihapus — kolom-kolom ini tidak dipakai lagi, drop kalau masih ada dari instalasi lama.
        foreach (['catatan_approval', 'approved_at', 'approved_by', 'status', 'verified_by', 'verified_at', 'catatan_verifikasi'] as $kolomApproval) {
            if (in_array($kolomApproval, $cols, true)) {
                try { $db->exec("ALTER TABLE monitoring_harian DROP COLUMN `$kolomApproval`"); } catch (Throwable $e) { /* abaikan */ }
            }
        }
        // Email pembuat data — disimpan saat input supaya notifikasi bisa
        // dikirim ke alamat yang benar meskipun nama/akun pembuat berubah di kemudian hari.
        if (!in_array('created_by_email', $cols, true)) $db->exec("ALTER TABLE monitoring_harian ADD COLUMN created_by_email VARCHAR(100) DEFAULT NULL AFTER created_by");

        // Kolom "periode" (1 = 2 minggu pertama, 2 = 2 minggu akhir) — menggantikan skema lama
        // yang memaksa kolom `tanggal` selalu bernilai tgl 15 atau 25. Sekarang `tanggal`
        // bebas menyimpan TANGGAL INPUT SESUNGGUHNYA (kapan data itu benar-benar disimpan),
        // sedangkan `periode` yang menentukan itu masuk slot Periode 1 atau Periode 2.
        if (!in_array('periode', $cols, true)) {
            $db->exec("ALTER TABLE monitoring_harian ADD COLUMN periode TINYINT(1) DEFAULT NULL AFTER tanggal");
            // Backfill data lama: sebelumnya tanggal selalu persis tgl 15 (Periode 1) atau tgl 25 (Periode 2)
            $db->exec("UPDATE monitoring_harian SET periode = IF(DAY(tanggal) <= 15, 1, 2) WHERE periode IS NULL");
            // Ganti kunci unik dari (sla_entry_id, tanggal) -> (sla_entry_id, periode) supaya
            // 1 indikator hanya boleh punya 1 baris per PERIODE (bukan per tanggal persis),
            // sehingga tanggal bisa bebas diisi tanggal input asli tanpa membatasi penyimpanan.
            try { $db->exec("ALTER TABLE monitoring_harian DROP INDEX uq_entry_tanggal"); } catch (Throwable $e) { /* nama index lama mungkin sudah beda/hilang */ }
            try { $db->exec("ALTER TABLE monitoring_harian ADD UNIQUE KEY uq_entry_periode (sla_entry_id, periode)"); } catch (Throwable $e) { /* sudah ada */ }
        }
    } catch (Throwable $e) { /* abaikan kalau gagal cek, tabel baru pasti sudah lengkap */ }

    // ------------------------------------------------------------
    //  PENGUATAN INTEGRITAS DATA (dijalankan idempotent tiap request):
    //  1) Naikkan relasi "lunak" (kolom *_id tanpa FK) jadi FOREIGN KEY
    //     sungguhan supaya DB sendiri yang menjaga (bukan cuma disiplin kode),
    //     dan sekalian dapat index gratis dari FK-nya.
    //  2) Tambahkan UNIQUE KEY sebagai jaring pengaman terakhir untuk data
    //     yang seharusnya tidak boleh dobel (selama ini cuma dicek di PHP).
    //  3) Ketatkan kolom yang nilainya sebenarnya cuma beberapa pilihan tetap
    //     (mis. Positif/Negatif) jadi ENUM asli.
    //  Semua langkah di bawah aman dijalankan berulang kali (idempotent) dan
    //  tidak pernah menghapus data — kalau data yang ada belum rapi (mis. masih
    //  ada duplikat), langkah itu di-skip diam-diam, tidak mengganggu aplikasi.
    // ------------------------------------------------------------
    orphanCleanup($db, 'kontrak', 'unit_id', 'unit_kerja', 'id');
    addForeignKeyIfMissing($db, 'kontrak', 'unit_id', 'unit_kerja', 'id', 'SET NULL');

    orphanCleanup($db, 'ulp', 'ulp_master_id', 'ulp_master', 'id');
    addForeignKeyIfMissing($db, 'ulp', 'ulp_master_id', 'ulp_master', 'id', 'SET NULL');

    orphanCleanup($db, 'kendaraan', 'ulp_id', 'ulp', 'id');
    addForeignKeyIfMissing($db, 'kendaraan', 'ulp_id', 'ulp', 'id', 'SET NULL');

    orphanCleanup($db, 'personil', 'ulp_id', 'ulp', 'id');
    addForeignKeyIfMissing($db, 'personil', 'ulp_id', 'ulp', 'id', 'SET NULL');

    // UNIQUE KEY jaring pengaman — nama ULP tidak boleh dobel dalam 1 kontrak,
    // nama petugas tidak boleh dobel dalam 1 kontrak (selama ini cuma dicek di
    // PHP sebelum simpan; sekarang DB juga menolak kalau ada jalur lain yang
    // lupa memvalidasi, atau dua orang submit persis bersamaan).
    addUniqueKeyIfMissing($db, 'ulp', 'uq_ulp_kontrak_nama', ['kontrak_id', 'nama_ulp']);
    addUniqueKeyIfMissing($db, 'personil', 'uq_personil_kontrak_nama', ['kontrak_id', 'nama_petugas']);

    // Nomor polisi kendaraan seharusnya unik. Kosongkan dulu yang tersimpan
    // sebagai string kosong '' (bukan NULL) supaya tidak dianggap "dobel"
    // satu sama lain — UNIQUE KEY di MySQL/MariaDB mengizinkan banyak NULL,
    // tapi menganggap '' == '' sebagai duplikat.
    try { $db->exec("UPDATE kendaraan SET nomor_polisi=NULL WHERE nomor_polisi='' OR TRIM(nomor_polisi)=''"); } catch (Throwable $e) {}
    addUniqueKeyIfMissing($db, 'kendaraan', 'uq_kendaraan_nopol', ['nomor_polisi']);

    // Kolom yang isinya cuma beberapa pilihan tetap -> ENUM asli, supaya jalur
    // input mana pun (form, API, import) tidak bisa menyimpan nilai nyeleneh.
    // Hanya dijalankan kalau SEMUA data yang sudah ada memang cocok dengan
    // pilihan yang diizinkan (migrateColumnToEnum otomatis skip kalau tidak).
    try { $db->exec("UPDATE kendaraan SET jenis_kendaraan=NULL WHERE jenis_kendaraan='' OR TRIM(jenis_kendaraan)=''"); } catch (Throwable $e) {}
    migrateColumnToEnum($db, 'kendaraan', 'jenis_kendaraan', ['MOBIL', 'MOTOR'], true, null);
    migrateColumnToEnum($db, 'sla_entries', 'polaritas', ['Positif', 'Negatif'], false, 'Positif');

    $db->exec("SET FOREIGN_KEY_CHECKS=1");
}

/**
 * Set kolom jadi NULL kalau nilainya sudah tidak ada padanannya di tabel
 * rujukan (mis. unit_id menunjuk ke unit_kerja yang sudah dihapus manual
 * lewat DB). Dijalankan SEBELUM addForeignKeyIfMissing supaya ALTER TABLE
 * ADD FOREIGN KEY tidak gagal karena data "yatim" yang sudah terlanjur ada.
 */
function orphanCleanup(PDO $db, string $table, string $col, string $refTable, string $refCol): void
{
    try {
        $db->exec("UPDATE `$table` t LEFT JOIN `$refTable` r ON t.`$col` = r.`$refCol`
                   SET t.`$col` = NULL WHERE t.`$col` IS NOT NULL AND r.`$refCol` IS NULL");
    } catch (Throwable $e) { /* tabel/kolom belum ada dsb — abaikan, aman */ }
}

/** Tambah FOREIGN KEY kalau kolom itu belum punya FK sama sekali. Idempotent & aman —
 *  kalau masih gagal (mis. masih ada data yatim yang lolos cleanup), dibiarkan
 *  seperti sekarang (kolom tetap ada, cuma tanpa constraint keras) supaya
 *  aplikasi tidak pernah berhenti gara-gara migrasi ini. */
function addForeignKeyIfMissing(PDO $db, string $table, string $col, string $refTable, string $refCol, string $onDelete = 'SET NULL'): void
{
    try {
        $exists = (int)dbVal($db, "
            SELECT COUNT(*) FROM information_schema.KEY_COLUMN_USAGE
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?
              AND REFERENCED_TABLE_NAME IS NOT NULL
        ", [$table, $col]);
        if ($exists) return;
        $fkName = "fk_{$table}_{$col}";
        $db->exec("ALTER TABLE `$table` ADD CONSTRAINT `$fkName` FOREIGN KEY (`$col`) REFERENCES `$refTable`(`$refCol`) ON DELETE $onDelete");
    } catch (Throwable $e) { /* masih ada data yatim / constraint sudah ada dgn nama beda — biarkan, tidak fatal */ }
}

/** Tambah UNIQUE KEY kalau belum ada index dengan nama itu. Skip diam-diam kalau
 *  gagal (mis. data yang sudah ada ternyata masih ada duplikat) — data lama
 *  tidak pernah dihapus/diubah paksa hanya supaya constraint bisa terpasang. */
function addUniqueKeyIfMissing(PDO $db, string $table, string $indexName, array $columns): void
{
    try {
        $exists = (int)dbVal($db, "
            SELECT COUNT(*) FROM information_schema.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?
        ", [$table, $indexName]);
        if ($exists) return;
        $cols = implode(',', array_map(fn($c) => "`$c`", $columns));
        $db->exec("ALTER TABLE `$table` ADD UNIQUE KEY `$indexName` ($cols)");
    } catch (Throwable $e) { /* masih ada duplikat data lama — biarkan dulu, tidak fatal */ }
}

/** Ubah kolom VARCHAR yang nilainya sebenarnya cuma beberapa pilihan tetap
 *  jadi ENUM asli — TAPI hanya kalau seluruh data yang sudah ada memang cocok
 *  dengan daftar pilihan (kalau ada nilai lain di luar itu, di-skip diam-diam
 *  supaya tidak ada data yang terpotong/berubah tanpa sepengetahuan siapa pun). */
function migrateColumnToEnum(PDO $db, string $table, string $column, array $allowedValues, bool $nullable, ?string $default): void
{
    try {
        $type = dbVal($db, "
            SELECT DATA_TYPE FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?
        ", [$table, $column]);
        if (strtolower((string)$type) === 'enum') return; // sudah ENUM, tidak perlu diapa-apakan lagi

        $placeholders = implode(',', array_fill(0, count($allowedValues), '?'));
        $params = $allowedValues;
        $sql = "SELECT COUNT(*) FROM `$table` WHERE `$column` IS NOT NULL AND `$column` <> '' AND `$column` NOT IN ($placeholders)";
        $offCount = (int)dbVal($db, $sql, $params);
        if ($offCount > 0) return; // masih ada nilai di luar daftar -> jangan diutak-atik, biarkan VARCHAR

        $enumList = implode(',', array_map(fn($v) => "'" . str_replace("'", "''", $v) . "'", $allowedValues));
        $nullSql   = $nullable ? 'DEFAULT NULL' : 'NOT NULL' . ($default !== null ? " DEFAULT '" . str_replace("'", "''", $default) . "'" : '');
        $db->exec("ALTER TABLE `$table` MODIFY COLUMN `$column` ENUM($enumList) $nullSql");
    } catch (Throwable $e) { /* biarkan tetap VARCHAR kalau gagal — tidak fatal, aplikasi tetap jalan normal */ }
}

// ---------------------------------------------------------------
//  Helper: ambil satu baris / satu nilai (pengganti querySingle)
// ---------------------------------------------------------------

/**
 * Ambil satu baris sebagai array asosiatif.
 * @param PDO    $db
 * @param string $sql  Query SELECT, boleh pakai ? / :param
 * @param array  $bind Parameter binding (opsional)
 * @return array|null
 */
function dbRow(PDO $db, string $sql, array $bind = []): ?array {
    $st = $db->prepare($sql);
    $st->execute($bind);
    $row = $st->fetch();
    return $row ?: null;
}

/**
 * Ambil nilai satu kolom dari baris pertama.
 */
function dbVal(PDO $db, string $sql, array $bind = []) {
    $st = $db->prepare($sql);
    $st->execute($bind);
    $row = $st->fetch(PDO::FETCH_NUM);
    return $row ? $row[0] : null;
}

/**
 * Ambil semua baris sebagai array of arrays.
 */
function dbAll(PDO $db, string $sql, array $bind = []): array {
    $st = $db->prepare($sql);
    $st->execute($bind);
    return $st->fetchAll();
}

/**
 * Jalankan query non-SELECT (INSERT/UPDATE/DELETE).
 * Kembalikan jumlah baris terpengaruh.
 */
function dbExec(PDO $db, string $sql, array $bind = []): int {
    $st = $db->prepare($sql);
    $st->execute($bind);
    return $st->rowCount();
}

// ---------------------------------------------------------------
//  KEAMANAN: Rate Limit Login & Audit Log
// ---------------------------------------------------------------

function clientIp(): string {
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

/** Cek apakah username/IP sedang dikunci karena terlalu banyak percobaan login gagal. */
function isLoginLocked(PDO $db, string $username, string $ip, int $maxAttempt = 5, int $windowMinutes = 3): bool {
    $jml = dbVal($db,
        "SELECT COUNT(*) FROM login_attempts
         WHERE (username=? OR ip_address=?) AND success=0 AND created_at > (NOW() - INTERVAL ? MINUTE)",
        [$username, $ip, $windowMinutes]);
    return (int)$jml >= $maxAttempt;
}

function recordLoginAttempt(PDO $db, string $username, bool $success): void {
    dbExec($db, "INSERT INTO login_attempts (username, ip_address, success) VALUES (?,?,?)",
        [$username, clientIp(), $success ? 1 : 0]);
}

/**
 * Catat aktivitas penting (create/update/delete) untuk jejak audit.
 * $dataLama / $dataBaru: array asosiatif (akan disimpan sebagai JSON), opsional.
 * Hanya field yang benar-benar berubah yang perlu dikirim supaya log ringkas dan rapi.
 */
function logAudit(PDO $db, string $aksi, string $modul, string $detail = '', ?array $dataLama = null, ?array $dataBaru = null, ?string $alasan = null): void {
    $user = currentUser();
    $alasan = $alasan !== null ? trim($alasan) : null;
    if ($alasan === '') $alasan = null;
    dbExec($db, "INSERT INTO audit_log (user_id, username, aksi, modul, detail, data_lama, data_baru, alasan, ip_address) VALUES (?,?,?,?,?,?,?,?,?)",
        [
            $user['id'] ?? null,
            $user['username'] ?? 'system',
            $aksi,
            $modul,
            $detail,
            $dataLama !== null ? json_encode($dataLama, JSON_UNESCAPED_UNICODE) : null,
            $dataBaru !== null ? json_encode($dataBaru, JSON_UNESCAPED_UNICODE) : null,
            $alasan,
            clientIp(),
        ]);
}

/** Bandingkan dua array asosiatif (data lama vs baru), kembalikan hanya field yang berubah. */
function diffFields(array $lama, array $baru): array {
    $lamaChanged = [];
    $baruChanged = [];
    foreach ($baru as $k => $v) {
        $old = $lama[$k] ?? null;
        if ((string)$old !== (string)$v) {
            $lamaChanged[$k] = $old;
            $baruChanged[$k] = $v;
        }
    }
    return [$lamaChanged, $baruChanged];
}

// ---------------------------------------------------------------
//  Fungsi Bisnis
// ---------------------------------------------------------------

/**
 * Render badge teks (bukan emoji) untuk membedakan jenis kontrak Distribusi/Transmisi.
 * Dipakai di seluruh halaman supaya tampilannya konsisten dan rapi/profesional.
 */
function badgeJenisKontrak(?string $jenis): string {
    $jenis = strtoupper($jenis ?: 'DISTRIBUSI');
    if ($jenis === 'TRANSMISI') {
        return '<span class="badge badge-transmisi">TRANSMISI</span>';
    }
    if ($jenis === 'PEMBANGKIT') {
        return '<span class="badge badge-pembangkit">PEMBANGKIT</span>';
    }
    return '<span class="badge badge-distribusi">DISTRIBUSI</span>';
}

/**
 * Daftar Unit Kerja aktif, opsional difilter per jenis kontrak (DISTRIBUSI/TRANSMISI/PEMBANGKIT).
 * Dipakai untuk mengisi dropdown "Unit" pada form Data Kontrak, dan bisa dipakai nanti
 * untuk menentukan cara input SLA yang berbeda per unit (cek kontrak.unit_id).
 */
function getUnitKerjaList(PDO $db, ?string $jenisKontrak = null): array {
    if ($jenisKontrak) {
        return dbAll($db, "SELECT * FROM unit_kerja WHERE jenis_kontrak=? AND is_active=1 ORDER BY urutan, nama", [strtoupper($jenisKontrak)]);
    }
    return dbAll($db, "SELECT * FROM unit_kerja WHERE is_active=1 ORDER BY jenis_kontrak, urutan, nama");
}

/**
 * Daftar Master ULP aktif (global, tidak terikat kontrak tertentu) — dipakai
 * untuk mengisi dropdown "Pilih dari Master ULP" pada form Data ULP per-kontrak,
 * supaya operator bisa isi cepat (autofill nama/manager/koordinator) tanpa ketik
 * ulang. Tidak menggantikan data ULP per-kontrak yang sudah ada.
 */
function getUlpMasterList(PDO $db): array {
    return dbAll($db, "SELECT * FROM ulp_master WHERE is_active=1 ORDER BY nama_ulp");
}

/** Badge kecil nama Unit Kerja (mis. "OPGI"), dipakai di tabel Data Kontrak. */
function badgeUnitKerja(?string $namaUnit): string {
    if (!$namaUnit) return '';
    return '<span class="badge" style="background:var(--g100);color:var(--g700);border:1px solid var(--g200);">' . htmlspecialchars($namaUnit) . '</span>';
}

/**
 * Label teks polos (TANPA tag HTML) untuk <option> dropdown "Pilih Project".
 * <option> di semua browser hanya bisa menampilkan teks polos — HTML/badge yang
 * dimasukkan ke dalamnya akan tampil sebagai tulisan mentah "<span...>" yang berantakan.
 *
 * Urutan disusun supaya gampang dicari: Nama Project — Bulan Tahun (info lain).
 * Prefiks [JENIS] sengaja TIDAK ditampilkan lagi di sini karena Bidang (Distribusi/
 * Transmisi/Pembangkit) sudah dipilih terpisah lewat dropdown "Pilih Bidang" —
 * daftar Project yang muncul otomatis sudah sesuai bidang tsb, jadi prefiksnya
 * jadi redundan. Nama project ditaruh di depan karena itu yang paling sering
 * dipakai orang untuk mencari, dan bulan/periode ditaruh tepat di sebelahnya supaya
 * project yang sama di bulan berbeda tetap mudah dibedakan.
 */
function kontrakSelectLabel(array $k): string {
    $nama  = trim($k['nama_kontrak'] ?? '');
    if ($nama === '') $nama = '-';
    $namaShort = mb_strimwidth($nama, 0, 50, '…');

    $label = $namaShort;

    $periode = trim(($k['periode_bulan'] ?? '') . ' ' . ($k['tahun'] ?? ''));
    if ($periode !== '') $label .= ' — ' . $periode;

    $extra = [];
    if (!empty($k['tahap'])) $extra[] = 'Tahap ' . trim(str_ireplace('tahap', '', $k['tahap']));
    if ($extra) $label .= ' (' . implode(', ', $extra) . ')';

    return $label;
}

/**
 * Atribut data-* (untuk <option>) berisi info kontrak TANPA dipotong,
 * dipakai oleh widget pemilih kontrak (assets/js/kontrak-picker.js) supaya
 * daftar kontrak bisa ditampilkan lebih informatif & mudah dibaca (2 baris:
 * baris info + nama kontrak lengkap), bukan satu baris mentah yang terpotong.
 */
function kontrakOptionAttrs(array $k): string {
    $periode = trim(($k['periode_bulan'] ?? '') . ' ' . ($k['tahun'] ?? ''));
    $tahap = !empty($k['tahap']) ? trim(str_ireplace('tahap', '', $k['tahap'])) : '';
    $jenis = strtoupper(trim($k['jenis_kontrak'] ?? 'DISTRIBUSI'));
    $nama = trim($k['nama_kontrak'] ?? '');
    return 'data-periode="' . htmlspecialchars($periode) . '" '
         . 'data-tahap="' . htmlspecialchars($tahap) . '" '
         . 'data-jenis="' . htmlspecialchars($jenis) . '" '
         . 'data-nama="' . htmlspecialchars($nama) . '"';
}

/**
 * Filter kontrak bertingkat: Pilih Bidang -> Pilih Unit -> Pilih Project.
 * Ini SAMA PERSIS dengan cara mencari project di halaman Input SLA
 * (input_harian.php), supaya dipakai juga oleh halaman-halaman yang perlu
 * memilih 1 kontrak: Rekap SLA, Detail Perhitungan, dan Rata-Rata SLA.
 *
 * Baca $_GET['jenis'] & $_GET['unit_id'], lalu kembalikan:
 *   [0] $filterJenis  (ALL/DISTRIBUSI/TRANSMISI/PEMBANGKIT)
 *   [1] $filterUnit   ('' / 'none' / id unit)
 *   [2] $unitOptions  (daftar unit sesuai Bidang yang dipilih)
 *   [3] $kontrakList  (daftar kontrak sesuai Bidang+Unit yang dipilih)
 *
 * $kontrakAktifId (opsional): kalau kontrak yang sedang dibuka "hilang" dari
 * hasil filter (mis. dibuka lewat link kontrak_id langsung tanpa lewat
 * dropdown Bidang/Unit), kontrak itu tetap disisipkan supaya pilihannya
 * tidak hilang dari dropdown.
 */
function kontrakCascadeFilter(PDO $db, ?int $kontrakAktifId = null): array {
    $filterJenis = strtoupper(trim($_GET['jenis'] ?? 'ALL'));
    if (!in_array($filterJenis, ['ALL', 'DISTRIBUSI', 'TRANSMISI', 'PEMBANGKIT'], true)) $filterJenis = 'ALL';

    $filterUnit = trim($_GET['unit_id'] ?? '');
    if ($filterJenis === 'ALL') $filterUnit = ''; // unit tidak relevan kalau Bidang belum dipilih
    $unitOptions = ($filterJenis !== 'ALL') ? getUnitKerjaList($db, $filterJenis) : [];
    if ($filterUnit !== '' && $filterUnit !== 'none') {
        $validUnitIds = array_column($unitOptions, 'id');
        if (!in_array((int)$filterUnit, $validUnitIds, true)) $filterUnit = '';
    }

    $whereParts = [];
    $whereVals  = [];
    if ($filterJenis === 'DISTRIBUSI') {
        // Data lama tanpa jenis_kontrak dianggap DISTRIBUSI (default aplikasi)
        $whereParts[] = "(jenis_kontrak = 'DISTRIBUSI' OR jenis_kontrak IS NULL OR jenis_kontrak = '')";
    } elseif ($filterJenis !== 'ALL') {
        $whereParts[] = "jenis_kontrak = ?";
        $whereVals[]  = $filterJenis;
    }
    if ($filterUnit === 'none') {
        $whereParts[] = "unit_id IS NULL";
    } elseif ($filterUnit !== '') {
        $whereParts[] = "unit_id = ?";
        $whereVals[]  = (int)$filterUnit;
    }
    $whereSql = $whereParts ? ('WHERE ' . implode(' AND ', $whereParts)) : '';

    $kontrakList = dbAll($db, "SELECT id, nama_kontrak, periode_bulan, tahun, tahap, jenis_kontrak FROM kontrak $whereSql
        ORDER BY FIELD(jenis_kontrak,'DISTRIBUSI','TRANSMISI','PEMBANGKIT'), nama_kontrak ASC, tahun DESC, FIELD(periode_bulan,'JANUARI','FEBRUARI','MARET','APRIL','MEI','JUNI','JULI','AGUSTUS','SEPTEMBER','OKTOBER','NOVEMBER','DESEMBER') DESC, id DESC", $whereVals);

    if ($kontrakAktifId && !in_array($kontrakAktifId, array_column($kontrakList, 'id'), true)) {
        $aktif = dbRow($db, "SELECT id, nama_kontrak, periode_bulan, tahun, tahap, jenis_kontrak FROM kontrak WHERE id=?", [$kontrakAktifId]);
        if ($aktif) array_unshift($kontrakList, $aktif);
    }

    return [$filterJenis, $filterUnit, $unitOptions, $kontrakList];
}

/**
 * Ringkasan filter aktif (breadcrumb) + tombol Reset, dipakai bersama oleh
 * halaman-halaman yang punya filter Bidang/Unit/Project/Tahun (Rata-Rata SLA,
 * Laporan Grafik, Cetak Laporan) supaya pengguna selalu tahu persis sedang
 * melihat data yang mana, dan bisa kembali ke tampilan awal dengan satu klik.
 *
 * $parts: array asosiatif label => nilai (nilai kosong/null dilewati).
 * $resetUrl: URL halaman ini tanpa query string (mis. 'rata_rata.php').
 */
function renderFilterBreadcrumb(array $parts, string $resetUrl): string {
    $chips = [];
    foreach ($parts as $label => $value) {
        if ($value === null || $value === '') continue;
        $chips[] = '<span class="filter-chip"><b>' . htmlspecialchars($label) . ':</b> ' . htmlspecialchars((string)$value) . '</span>';
    }
    if (empty($chips)) {
        return '<div class="filter-breadcrumb filter-breadcrumb-empty">Menampilkan semua data — belum ada filter dipilih.</div>';
    }
    return '<div class="filter-breadcrumb">'
         . '<span class="filter-breadcrumb-label">🔎 Filter aktif:</span> '
         . implode(' ', $chips)
         . ' <a href="' . htmlspecialchars($resetUrl) . '" class="filter-reset-link">✕ Reset Filter</a>'
         . '</div>';
}

function hitungPencapaian(string $polaritas, float $target, ?float $realisasi): ?float {
    // Setara rumus Excel:
    // =IF(J="";"";IF(AND(I=0;J=0);1;IF(LOWER(G)="negatif";2-(J/I);J/I)))
    // (hasil dikalikan 100 karena aplikasi menyimpan dalam persen).
    // Sama persis dengan Excel: tidak ada batas atas (Positif boleh > 100%) maupun batas bawah
    // (Negatif boleh < 0% bila realisasi > 2x target).
    if ($realisasi === null) return null; // belum dinilai — jangan dihitung sebagai gagal
    if ($target == 0) {
        if ($realisasi == 0) return 100.0;                  // target 0 & realisasi 0 = tercapai penuh
        // Excel menghasilkan #DIV/0! di sini; aplikasi memakai aturan lama:
        return strtolower($polaritas) === 'negatif' ? 0.0 : 100.0;
    }
    if (strtolower($polaritas) === 'negatif') {
        return (2 - ($realisasi / $target)) * 100;           // tidak dibatasi 0% (realisasi > 2× target = negatif)
    }
    return ($realisasi / $target) * 100;                    // tidak dibatasi 100%
}

function hitungNilaiBobot(float $bobot, ?float $persen): ?float {
    if ($persen === null) return null;
    return ($persen / 100) * $bobot * 100;
}

/**
 * Menghasilkan teks rumus perhitungan persentase pencapaian & nilai bobot
 * untuk satu indikator SLA, dipakai di halaman Detail Perhitungan supaya
 * pengguna bisa melihat persis bagaimana angka SLA diperoleh (transparansi & audit).
 */
function formulaPencapaian(string $polaritas, float $target, float $realisasi, float $pct): string {
    $t = rtrim(rtrim(number_format($target, 4), '0'), '.');
    $r = rtrim(rtrim(number_format($realisasi, 4), '0'), '.');
    if ($t === '' || $t === '-') $t = '0';
    if ($r === '' || $r === '-') $r = '0';
    $neg = strtolower($polaritas) === 'negatif';

    if ($target == 0) {
        if ($realisasi == 0) {
            return "Target 0 & Realisasi 0 → tercapai penuh = 100%";
        }
        return $neg
            ? "Target 0 (tidak ada toleransi) tetapi Realisasi = {$r} → tidak tercapai = 0%"
            : "Target 0 & ada Realisasi ({$r}) → dianggap tercapai = 100%";
    }

    if ($neg) {
        return "(2 − Realisasi ÷ Target) × 100% = (2 − {$r} ÷ {$t}) × 100% = " . number_format($pct, 2) . '% (indikator Negatif: semakin kecil semakin baik' . ($realisasi > 2 * $target ? '; melampaui 2× target sehingga bernilai di bawah 0%' : '') . ')';
    }

    return "Realisasi ÷ Target × 100% = {$r} ÷ {$t} × 100% = " . number_format($pct, 2) . '%' . ($realisasi/$target*100 > 100 ? ' (melampaui target, tidak dibatasi 100%)' : '');
}

function formulaNilaiBobot(float $pct, float $bobot, float $nilaiBobot): string {
    return number_format($pct, 2) . '% × ' . rtrim(rtrim(number_format($bobot, 4), '0'), '.') . ' = ' . number_format($nilaiBobot, 2);
}

/** Ikon bantuan kecil "?" — teks muncul saat di-hover / diketuk. Dipakai untuk istilah yang membingungkan. */
function helpTip(string $teks): string {
    return '<span class="help-tip" tabindex="0" role="note" aria-label="' . htmlspecialchars($teks, ENT_QUOTES) . '" data-tip="' . htmlspecialchars($teks, ENT_QUOTES) . '">?</span>';
}
const HELP_POLARITAS = "Positif: semakin tinggi realisasi semakin baik.\nNegatif: semakin rendah realisasi semakin baik.";

/** Kelas kualitas berdasarkan ambang 90% / 70% — dipakai di banyak halaman (dashboard, rekap, detail perhitungan). */
function progressClass($pct) {
    if ($pct >= 90) return 'good';
    if ($pct >= 70) return 'warn';
    return 'bad';
}

/** Style badge warna berdasarkan persentase pencapaian — dipakai di banyak halaman. */
function pctBadgeStyle($pct) {
    // Pakai CSS variable (bukan hex mentah) supaya otomatis ikut berubah
    // saat mode gelap aktif (lihat override --green-lt/--amber-lt/--red-lt
    // di assets/css/style.css). Hex mentah sebelumnya (#dcfce7 dkk) tidak
    // cocok dengan pola tambalan mode gelap, jadi badge ini tetap terang
    // menyala di atas latar gelap.
    if ($pct >= 90) return 'background:var(--green-lt,#dcfce7);color:var(--green-dk,#166534);';
    if ($pct >= 70) return 'background:var(--amber-lt,#fef9c3);color:var(--amber,#854d0e);';
    return 'background:var(--red-lt,#fee2e2);color:var(--red,#991b1b);';
}

function insertDefaultSLA(PDO $db, int $kontrak_id, string $jenis_kontrak = 'DISTRIBUSI', ?string $unitKode = null): void {

    // ------------------------------------------------------------------
    // Template khusus per UNIT (mis. OPGI) — dipakai kalau kontrak sudah
    // menentukan Unit Kerja yang punya template sendiri (lihat $unitTemplates
    // di bawah). Beda dengan template umum per Jenis Kontrak: sudah menyertakan
    // EVIDEN (bukti dukung tiap indikator) sesuai BA SLA asli unit tsb.
    // Ruang Lingkup/Kriteria/Kinerja/Eviden diambil apa adanya dari BA SLA;
    // Bobot/Polaritas/Satuan/Target tetap memakai konvensi default aplikasi
    // (bukan disalin dari BA SLA) — supaya tetap bisa diisi manual sesuai
    // kesepakatan kontrak, sama seperti template umum.
    // Kelompok BA SLA OPGI dipetakan ke 4 kategori sistem (TEKNIS/K3/KECELAKAAN/ILP):
    //   Kesiapan SDM, Pengoperasian GI, Pemeliharaan GI  -> TEKNIS
    //   Penerapan K3                                     -> K3
    //   Pemenuhan Hak Normatif Ketenagakerjaan            -> ILP
    // Format tiap baris: [kategori, ruang_lingkup, kriteria, kinerja, eviden, polaritas, satuan, bobot, jenis_bobot, target, realisasi]
    // ------------------------------------------------------------------
    $defaultsOpgi = [
        ['TEKNIS','Kesiapan SDM','Mengenakan APD Lemngkap dan Layak','100% kesesuaian APD dengan persyaratan dan dalam kondisi laik','Formulir checklist pemeriksaan APD','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Kesiapan SDM','Melakukan Absensi shift melalui Tools Absensi Online dan atau manual','100% kehadiran','Dokumen Verifikasi kehadiran yang di ttd in pejabat ULTG yang bertanggung jawab','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Kesiapan SDM','Operator dan tenaga pemeliharaan memiliki serkom','100% kompetensi SDM sesuai dengan kualifikasi pekerjaan','Sertifikat kompetensi','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Kesiapan SDM','Melakukan CoC atau Knowledge Sharing / OBAMMA ( Operator Belajar Mengoperasikan dan Memelihara Aset ) untuk meningkatkan kompetensi Operator GI dan Tenaga Pemeliharaan','100% Akurasi kegiatan COC atau Knowledge Sharing dengan PLN sesuai dengan kebutuhan (syarat COC atau Knowledge Sharing ( OBAMMA) dihitung sebagai realisasi 70% kehadiran online maupun offline.. untuk perhitungan 1x bobot 100%.. Lebih dari 1x bobot 100%','Dokumentasi, daftar hadir kegiatan COC dgn baik offline atau online minimal kehadiran 70% (screenshoot, google form)','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pengoperasian Gardu Induk (GI)','Melaksanakan kegiatan pengoperasian peralatan Gardu Induk (kebutuhan sistem) atas perintah pengendali operasi sistem (Dispatcher) sesuai dengan seluruh Standard Operating Procedure (SOP) PLN, meliputi: a. Prosedur operasi sistem b. Prosedur komunikasi c. Prosedur K3','100% akurasi kegiatan pengoperasian peralatan GI (sistem) sesuai dengan SOP','Dokumen Pencatatan Manuver; BA Investigasi Kejadian Khusus','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pengoperasian Gardu Induk (GI)','Melaksanakan kegiatan pengoperasian peralatan Gardu Induk (kebutuhan Pemeliharaan/operasi aset) sesuai dengan seluruh SOP PLN meliputi: a. Prosedur operasi peralatan GI b. Prosedur Komunikasi c. Prosedur K3','Kondisi Pencapaian sebagai berikut : 1x kali kejadian diantara : a) Black Out b)Gangguan Meluas c) Kecelakaan Kerja mengakibatkan Meninggal/ cacat permanen maka bobot 0% jika tidak terdapat kejadian bobot 100%','Dokumen Pencatatan Manuver; BA Investigasi Kejadian Khusus','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pengoperasian Gardu Induk (GI)','Melaksanakan inspeksi level 1 (visual) kondisi peralatan GI dan melakukan pencatatan formulir hasil inspeksi level 1','100% kelengkapan pencatatan hasil inspeksi level 1 (visual) kondisi peralatan GI pada Formulir Hasil Inspeksi/Aplikasi CBM','Formulir Hasil Inspeksi/Aplikasi CBM','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pengoperasian Gardu Induk (GI)','Melaksanakan inspeksi level 2 (termasuk namun tidak terbatas pada thermovisi, pengukuran tegangan baterai, pengukuran tegangan relay mekanik, pengukuran arus bocor) dan melakukan pencatatan formulir hasil inspeksi level 2','100% kelengkapan pencatatan hasil inspeksi level 2 pada Formulir Hasil Inspeksi/Aplikasi CBM','Formulir Hasil Inspeksi/Aplikasi CBM','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pengoperasian Gardu Induk (GI)','Mencegah dan melaporkan anomali serta kondisi yang dapat membahayakan atau menimbulkan kerawanan terhadap pengoperasian GI','100% kelengkapan dan akurasi pengisian laporan ketidaksesuaian','Laporan ketidak sesuaian','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pengoperasian Gardu Induk (GI)','Melakukan tindakan pengamanan peralatan dan pelaporan dalam keadaan darurat sesuai Standard Operating Procedur (SOP) PLN','100% akurasi tindakan pengamanan peralatan sesuai dengan SOP atau pedoman pada masing- masing unit','Logsheet dan Dokumentasi','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pengoperasian Gardu Induk (GI)','Melakukan tindakan pengamanan peralatan dan pelaporan dalam keadaan darurat sesuai Standard Operating Procedur (SOP) PLN','100% pencapaian target waktu pelaporan sesuai SOP atau pedoman pada masing-masing unit','Laporan gangguan','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pengoperasian Gardu Induk (GI)','Melakukan pengelolaan seluruh dokumen hasil pengoperasian dan pemeliharaan','100% kelengkapan dokumen hasil pengoperasian dan pemeliharaan sesuai dengan periodenya (harian/mingguan/bulanan)','Dokumen fisik hasil, pengoperasian dan pemeliharaan (Format Form dokumen dari PLN) yang divalidasi oleh PLNND Region','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pengoperasian Gardu Induk (GI)','Melakukan Koordinasi dengan pihak PLN Distribusi (Piket Pengatur Beban setempat) bila akan dilakukan pekerjaan pada sisi 20 kV (incoming atau outgoing)','100% kelengkapan dan akurasi pengisian logsheet','Logsheet','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pengoperasian Gardu Induk (GI)','Melaksanakan pemeliharaan dan pembersihan (program 5S, CGS, ABH) terhadap fasilitas operasi GI (termasuk namun tidak terbatas pada penggantian lampu indikator, pembersihan baterai dan panel)','100% fasilitas ruangan GI dalam keadaan bersih dan terawat','Laporan Pemeliharaan dan Pembersihan (5S)','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pengoperasian Gardu Induk (GI)','Melaksanakan penyimpanan dan pembersihan terhadap peralatan kerja, peralatan uji, dan peralatan K3','100% kelengkapan dan akurasi pengisian checklist','Checklist','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pengoperasian Gardu Induk (GI)','Pencatatan angka-angka pengusahaan (VAC, A, MW, MVAR, kWh) di excel Logsheet GI melalui web maupun manual dan mencatat laporan gangguan/anomali peralatan (Seperti: Gangguan/ Alarm Pada Peralatan Catu Daya, Proteksi, Scada/SAS, dan Telekomunikasi )','100% kelengkapan dan akurasi pengisian logsheet','Logsheet','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pengoperasian Gardu Induk (GI)','Penyampaian informasi kondisi peralatan yang bersifat emergensi tidak dilaporkan secara Real Time (maksimal 10 menit setelah ditemukan kondisi anomali)','Tidak ada (0)laporan pelanggaran ILP','Dokumen laporan pelanggaran ILP','Negatif','Kali',2,'Prioritas 1',0,0],
        ['TEKNIS','Pengoperasian Gardu Induk (GI)','Terjadi gangguan karena ada pekerjaan yang telah diminta oleh UP3B/ UPT terkait untuk dikerjakan, namun pelaksanaannya ditunda sepihak oleh Pelaksana Pekerjaan','Tidak ada (0)laporan pelanggaran ILP','Dokumen laporan pelanggaran ILP','Negatif','Kali',2,'Prioritas 1',0,0],
        ['TEKNIS','Pengoperasian Gardu Induk (GI)','Melakukan pencatatan pada formulir gangguan yang disediakan PLN jika terjadi gangguan dan melaporkan ke Dispatcher & Manajer ULTG saat adanya gangguan','100% kelengkapan dan akurasi pengisian formulir gangguan','Formulir gangguan','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Gardu Induk (GI)','Melakukan Pemeliharaan di Gardu Induk dan Transmisi sesuai dengan Jadwal Pemeliharaan yang disusun oleh ULTG atau UPT / UP3B','100% pekerjaan yang dileah disusun oleh ULTG atau UPT / UP3B dilaksanakan','Dokumentasi dan Daftar Kehadiran TAD dalam kegiatan pemeliharaan Gardu Induk dan bukti penyelesaian SPK','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Gardu Induk (GI)','Membantu melaksanakan pemeliharaan emergency di transmisi maupun gardu Induk (275kV / 150 kV / 70 kV / 20 kV)','100% membantu pekerjaan yang dileah disusun oleh ULTG atau UPT / UP3B dilaksanakan','Dokumentasi dan Daftar Kehadiran TAD dalam kegiatan pemeliharaan emergency','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Gardu Induk (GI)','Membantu melaksanakan penelusuran gangguan di transmisi maupun gardu Induk (275kV / 150 kV / 70kV / 20 kV)','100% membantu pekerjaan yang dileah disusun oleh ULTG atau UPT / UP3B dilaksanakan','Dokumentasi dan Daftar Kehadiran TAD dalam kegiatan penelusuran gangguan','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Gardu Induk (GI)','Membuat laporan bulanan kegiatan pemeliharaan dan assesment Inspeksi Level 1 dan 2, selambat-lambatnya tanggal N+5','100% laporan bulanan disampaikan kepada MULTG','Dokumen laporan bulanan','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat kerja','Kualitas SDM dan Kompetensi Pekerja','100% kompetensi SDM sesuai dengan kualifikasi pekerjaan','Sertifikat kompetensi','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat kerja','Peralatan Kerja sesuai dengan persyaratan dan dalam kondisi laik','100% kesesuaian peralatan kerja dengan persyaratan dan dalam kondisi laik','Formulir checklist pemeriksaan alat kerja','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat kerja','Alat Keselamatan Kerja (APD, Rambu dan LOTO)','100% penyediaan alat pelindung diri sesuai resiko pekerjaan','Checklist APD','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat kerja','Alat Keselamatan Kerja (APD, Rambu dan LOTO)','100% Penyediaan rambu dan LOTO pada satuan kerja','Checklist rambu dan LOTO','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat kerja','Melakukan pekerjaan sesuai dengan prosedur dan instruksi kerja yang berlaku (SOP, IK, WP)','Nol (0) temuan pelanggaran prosedur dan instruksi kerja sesuai dengan sistem manajemen K3','Laporan inspeksi K3','Negatif','Temuan',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat kerja','Selama melaksanakan tugas, Petugas Operator dan Pemeliharaan tidak menggunakan pakaian seragam dan dilengkapi dengan tanda pengenal dan peralatan K3 dalam pelaksanaan pekerjaan','Tidak ada (0)laporan pelanggaran ILP','Dokumen laporan pelanggaran ILP','Negatif','Kali',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat kerja','Mengabaikan dan tidak mentaati peraturan K2, K3 dan standar mutu yang diterapkan di UPT / UP3B (ISO 9001, SMK3, OPI)','Tidak ada (0)laporan pelanggaran ILP','Dokumen laporan pelanggaran ILP','Negatif','Kali',2,'Prioritas 1',0,0],
        ['ILP','Pemenuhan Hak Normatif Ketenagakerjaan','Mengadakan hubungan kerja dengan Pekerja dalam bentuk Perjanjian Kerja Waktu Tertentu (PKWT) atau Perjanjian Kerja Waktu Tidak Tertentu (PKWTT)','100% ketersediaan dokumen Perjanjian Kerja (PKWT/ PKWTT) dengan seluruh Pekerja','Dokumen Perjanjian Kerja (PKWT/ PKWTT)','Positif','Persen',1,'Prioritas 2',0,0],
        ['ILP','Pemenuhan Hak Normatif Ketenagakerjaan','Membayarkan upah kepada para Pekerjanya paling lambat pada tanggal 1 setiap bulannya (n+1)','100% upah Pekerja terbayar paling lambat pada tanggal 1 setiap bulannya (n+1)','Bukti transfer & daftar pembayaran','Positif','Persen',1,'Prioritas 2',0,0],
        ['ILP','Pemenuhan Hak Normatif Ketenagakerjaan','Membayarkan Tunjangan Hari Raya Keagamaan (THRK) dan hak normatif lainnya sesuai peraturan perundang- undangan','100% THRK dan hak normatif lainnya terbayar sesuai peraturan perundang- undangan','Bukti transfer & daftar pembayaran','Positif','Persen',1,'Prioritas 2',0,0],
        ['ILP','Pemenuhan Hak Normatif Ketenagakerjaan','Membayar angsuran uang pengakhiran hubungan kerja (uang pesangon, uang penghargaan masa kerja, dan uang penggantian hak) atau uang kompensasi Pekerja sesuai dengan peraturan perundang- undangan dengan program Dana Pensiun Lembaga Keuangan (DPLK) yang dijamin LPS paling lambat pada tanggal 1 setiap bulannya','100% angsuran uang pengakhiran hubungan Pekerja terbayar sesuai peraturan perundang- undangan','Bukti transfer & daftar pembayaran','Positif','Persen',1,'Prioritas 2',0,0],
        ['ILP','Pemenuhan Hak Normatif Ketenagakerjaan','Mengikutsertakan Pekerja dalam program Badan Penyelenggaraan Jaminan Sosial (BPJS Kesehatan dan Ketenagakerjaan) dan membayar iuran tersebut sesuai peraturan perundang- undangan paling lambat pada tanggal 1 setiap bulannya','100% Pekerja terdaftar dalam program BPJS Kesehatan dan Ketenagakerjaan','Bukti transfer & daftar pembayaran','Positif','Persen',1,'Prioritas 2',0,0],
        ['ILP','Pemenuhan Hak Normatif Ketenagakerjaan','Mengikutsertakan Pekerja dalam program Badan Penyelenggaraan Jaminan Sosial (BPJS Kesehatan dan Ketenagakerjaan) dan membayar iuran tersebut sesuai peraturan perundang- undangan paling lambat pada tanggal 1 setiap bulannya','100% iuran BPJS Kesehatan dan Ketenagakerjaan terbayar sesuai peraturan perundang- undangan pada tanggal 1 setiap bulan','Bukti transfer & daftar pembayaran','Positif','Persen',1,'Prioritas 2',0,0],
        ['ILP','Pemenuhan Hak Normatif Ketenagakerjaan','Memberikan minimal 2 set seragam per tahun kepada Pekerja selama jangka waktu Perjanjian','100% ketersediaan bukti tanda terima pemberian seragam pada Pekerja','Bukti tanda terima pemberian seragam','Positif','Persen',1,'Prioritas 2',0,0],
        ['ILP','Pemenuhan Hak Normatif Ketenagakerjaan','Memastikan kelengkapan dan akurasi data Pekerja yang diinput pertama kali pada Aplikasi Alih Daya serta melakukan pengkinian data paling lambat 5 hari kerja umum sebelum tanggal dimulai Pelaksanaan Pekerjaan dan minggu ke-1 setiap bulan untuk masa Pelaksanaan Pekerjaan','100% akurasi dan kelengkapan atas data pada Aplikasi Alih Daya','Aplikasi Alih Daya','Positif','Persen',1,'Prioritas 2',0,0],
        ['ILP','Pemenuhan Hak Normatif Ketenagakerjaan','Memastikan kelengkapan dan akurasi data Pekerja yang diinput pertama kali pada Aplikasi Alih Daya serta melakukan pengkinian data paling lambat 5 hari kerja umum sebelum tanggal dimulai Pelaksanaan Pekerjaan dan minggu ke-1 setiap bulan untuk masa Pelaksanaan Pekerjaan','100% ketersediaan bukti data pemutakhiran','Bukti data pemutakhiran','Positif','Persen',1,'Prioritas 2',0,0],
        ['ILP','Pemenuhan Hak Normatif Ketenagakerjaan','Memenuhi kewajiban memiliki modal yang cukup untuk pembayaran operasional, termasuk namun tidak terbatas pada modal pemenuhan hak normatif ketenagakerjaan Pekerja selama 90 hari kalender berikutnya, dan selanjutnya sejak tagihan per bulan terakhir telah dibayarkan oleh Pihak Pertama','100% ketersediaan bukti rekening koran dalam nominal modal yang cukup untuk membayar operasional pekerjaan selama minimal 90 hari','Bukti Rekening Koran dari Bank atas nama PIHAK KEDUA yang berisi saldo untuk membayar operasional Pekerjaan selama 90 hari kalender berikutnya','Positif','Persen',1,'Prioritas 2',0,0],
        ['ILP','Pemenuhan Hak Normatif Ketenagakerjaan','Menyalurkan reward atas pencapaian service level agreement yang diberikan oleh PLN kepada Perusahaan Alih Daya paling sedikit sebesar 70% (tujuh puluh persen) kepada Tenaga Alih Daya berdasarkan capaian kinerja individual','100% ketersediaan bukti penyaluran reward and consequence atas pencapaian SLA','Bukti transfer & daftar pembayaran','Positif','Persen',1,'Prioritas 2',0,0],
        ['ILP','Pemenuhan Hak Normatif Ketenagakerjaan','Perusahaan Alih Daya dapat memberikan consequence kepada Tenaga Alih Daya dalam hal tidak mencapai service level agreement dengan tetap mematuhi peraturan perundang- undangan yang berlaku','100% ketersediaan bukti pemberian consequence kepada Tenaga Alih Daya','Bukti transfer & daftar pembayaran','Positif','Persen',1,'Prioritas 2',0,0],
        ['ILP','Pemenuhan Hak Normatif Ketenagakerjaan','Penyampaian berkas tagihan tahap I secara lengkap dan benar diterima oleh PLN UIP3B Sul maksimal tanggal 15 setiap bulannya','Berkas tagihan Tahap 1 lengkap dan benar','Tanda terima berkas tagihan','Negatif','Tanggal',1,'Prioritas 2',0,0],
    ];

    // ------------------------------------------------------------------
    // Template khusus untuk Unit GP (Ground Patrol) — Transmisi.
    // Diambil apa adanya dari BA SLA GP UPT Manado (Ruang Lingkup, Kriteria,
    // Target Kinerja, Evidence), mengikuti konvensi yang sama seperti OPGI:
    // Bobot/Polaritas/Satuan/Target tetap memakai konvensi default aplikasi
    // (bukan disalin dari nilai DENDA/PENCAPAIAN SLA di BA), supaya tetap
    // bisa diisi manual sesuai kesepakatan kontrak.
    // Kelompok BA SLA GP dipetakan ke kategori sistem (TEKNIS/K3/ILP):
    //   Jasa Inspeksi & Pelaporan Aset, Hasil dan Gangguan Transmisi -> TEKNIS
    //   Penerapan K3 di tempat kerja                                 -> K3
    //   Komitmen Integritas Layanan Publik (ILP)                     -> ILP
    // Format tiap baris sama seperti OPGI: [kategori, ruang_lingkup, kriteria, kinerja, eviden, polaritas, satuan, bobot, jenis_bobot, target, realisasi]
    // ------------------------------------------------------------------
    $defaultsGp = [
        ['TEKNIS','Jasa Inspeksi dan Pelaporan Aset Jaringan (SUTT/SUTET) / Jasa Inspeksi dan Pelaporan Aset Kabel (SKTT)','Pemeriksaan/Inspeksi anomali komponen saluran Jaringan.','Kecepatan Pencapaian 100% baik secara manual maupun menggunakan aplikasi (contoh: SRINTAMI)','Dokumen laporan','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Jasa Inspeksi dan Pelaporan Aset Jaringan (SUTT/SUTET) / Jasa Inspeksi dan Pelaporan Aset Kabel (SKTT)','Melaksanakan pemeriksaan jarak aman SUTT dan SKTT serta jarak bebas di Right of Way (ROW).','Kecepatan Pencapaian 100% baik secara manual maupun menggunakan aplikasi (contoh: SRINTAMI)','Dokumen laporan','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Jasa Inspeksi dan Pelaporan Aset Jaringan (SUTT/SUTET) / Jasa Inspeksi dan Pelaporan Aset Kabel (SKTT)','Pemeriksaan dan Pengawasan Tanam Tumbuh ataupun bangunan yang berpotensi gangguan','Kecepatan Pencapaian 100% baik secara manual maupun menggunakan aplikasi (contoh: SRINTAMI)','Dokumen laporan','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Jasa Inspeksi dan Pelaporan Aset Jaringan (SUTT/SUTET) / Jasa Inspeksi dan Pelaporan Aset Kabel (SKTT)','Melaksanakan pemeriksaan kelengkapan tower (member, pentanahan, dll)','Kecepatan Pencapaian 100% baik secara manual maupun menggunakan aplikasi (contoh: SRINTAMI)','Dokumen laporan','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Jasa Inspeksi dan Pelaporan Aset Jaringan (SUTT/SUTET) / Jasa Inspeksi dan Pelaporan Aset Kabel (SKTT)','Pemeriksaan/Inspeksi kelengkapan komponen saluran Jaringan (penghantar, isolator dan aksesoris)','Kecepatan Pencapaian 100% baik secara manual maupun menggunakan aplikasi (contoh: SRINTAMI)','Dokumen laporan','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Jasa Inspeksi dan Pelaporan Aset Jaringan (SUTT/SUTET) / Jasa Inspeksi dan Pelaporan Aset Kabel (SKTT)','Melaksanakan pemeriksaan kondisi pondasi tower, Pentanahan (termasuk pelaksanaan pengukuran pentanahan sebanyak 17% dari total tower per bulan) dan lingkungan sekitar tapak tower','Kecepatan Pencapaian 100% baik secara manual maupun menggunakan aplikasi (contoh: SRINTAMI)','Dokumen laporan','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Jasa Inspeksi dan Pelaporan Aset Jaringan (SUTT/SUTET) / Jasa Inspeksi dan Pelaporan Aset Kabel (SKTT)','Melaksanakan pembersihan lokasi tapak tower.','Kecepatan Pencapaian 100% baik secara manual maupun menggunakan aplikasi (contoh: SRINTAMI)','Dokumen laporan','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Jasa Inspeksi dan Pelaporan Aset Jaringan (SUTT/SUTET) / Jasa Inspeksi dan Pelaporan Aset Kabel (SKTT)','Mencegah dan melaporkan kondisi yang dapat membahayakan atau menimbulkan kerawanan terhadap tower dan jaringan dilengkapi dengan dokumentasi/foto (termasuk melakukan pemangkasan terhadap pohon yang mengancam keandalan jaringan)','Kecepatan Pencapaian 100% baik secara manual maupun menggunakan aplikasi (contoh: SRINTAMI)','Dokumen laporan','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Hasil dan Gangguan Transmisi','Ketidaksesuaian laporan dengan kondisi di jaringan','benar dan akurat','Harian, Mingguan, Bulanan','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Melaksanakan dan mentaati peraturan K3 dan lingkungan','Menggunakan alat pelindung diri (APD) dan mentaati peraturan K2 dan Lingkungan.','1) Surat Pernyataan / 2) Dokumentasi','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Mutu Peralatan Kerja/K3 yang disediakan oleh PIHAK KEDUA wajib dapat dipertanggungjawabkan mutunya sesuai dengan spesifikasi yang ditetapkan oleh PIHAK PERTAMA','Peralatan sesuai spesifikasi yang ditetapkan oleh PIHAK PERTAMA','Checklist','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Ketersediaan Peralatan Kerja / K3','Peralatan tersedia dengan lengkap sesuai yang dipersyaratkan oleh PIHAK PERTAMA (Sesuai checklist)','Checklist','Positif','Persen',2,'Prioritas 1',0,0],
        ['ILP','Komitmen Integritas Layanan Publik (ILP)','Meminta/menerima imbalan (gratifikasi) dari pelanggan yang dilayani dan/atau dari PIHAK PERTAMA secara langsung','Tidak ada (0) laporan pelanggaran ILP','Tidak ada (0) laporan pelanggaran ILP','Negatif','Kali',1,'Prioritas 2',0,0],
        ['ILP','Komitmen Integritas Layanan Publik (ILP)','Melakukan pungutan liar, Kolusi Korupsi atau Nepotisme dll; atau','Tidak ada (0) laporan pelanggaran ILP','Tidak ada (0) laporan pelanggaran ILP','Negatif','Kali',1,'Prioritas 2',0,0],
        ['ILP','Komitmen Integritas Layanan Publik (ILP)','Dengan sengaja tidak memberikan kemudahan, kecepatan dan transparansi terkait layanan publik','Tidak ada (0) laporan pelanggaran ILP','Tidak ada (0) laporan pelanggaran ILP','Negatif','Kali',1,'Prioritas 2',0,0],
    ];

    // ------------------------------------------------------------------
    // Template khusus untuk Unit DISTRIBUSI — diambil apa adanya dari BA/
    // Template Tagihan SLA UP3 Kotamobagu (Ruang Lingkup, Kriteria, Target
    // Kinerja, Eviden), mengikuti konvensi yang sama seperti OPGI/GP: Bobot &
    // Jenis Bobot disalin dari BA (memang sudah eksplisit di file), tapi Target
    // tetap dikosongkan (0) karena nilai target per ULP berbeda-beda dan harus
    // diisi manual sesuai kesepakatan/kontrak masing-masing.
    // Item "Inspeksi Jaringan Distribusi" pada BA punya 7 sub-jenis inspeksi
    // (Tier 1 & Tier 2, tiap jenis dengan Eviden dan Satuan sendiri) di bawah
    // satu Kriteria yang sama — dipecah jadi 7 baris terpisah, satu per sub-jenis,
    // supaya tetap sesuai skema 1-baris = 1-indikator pada aplikasi.
    // Kelompok BA dipetakan ke kategori sistem (TEKNIS/K3/KECELAKAAN/ILP):
    //   Pelayanan Teknik, Inspeksi Jaringan, Pemeliharaan Jaringan -> TEKNIS
    //   Penerapan K3 di tempat kerja                               -> K3
    //   Kecelakaan Kerja                                           -> KECELAKAAN
    //   Komitmen Integritas Layanan Publik (ILP)                   -> ILP
    // Format tiap baris sama seperti OPGI/GP: [kategori, ruang_lingkup, kriteria, kinerja, eviden, polaritas, satuan, bobot, jenis_bobot, target, realisasi]
    // ------------------------------------------------------------------
    $defaultsDistribusiUnit = [
        ['TEKNIS','Pelayanan Teknik','Melakukan penanganan gangguan','100% terpenuhinya rata-rata response time bulanan gangguan total sesuai dengan target yang ditetapkan pada masing-masing unit','EIS APKT Menu Rekapitulasi Gangguan all Respone-Dispatching','Negatif','Menit',2,'Prioritas 1',0,0],
        ['TEKNIS','Pelayanan Teknik','Melakukan penanganan gangguan','100% terpenuhinya rata-rata recovery time bulanan gangguan total sesuai dengan target yang ditetapkan pada masing-masing unit','EIS APKT Menu Rekapitulasi Gangguan all Recovery','Negatif','Menit',2,'Prioritas 1',0,0],
        ['TEKNIS','Pelayanan Teknik','Melakukan penanganan gangguan','100% terpenuhinya jumlah gangguan berulang bulanan gangguan total sesuai dengan target yang ditetapkan pada masing-masing unit','EIS APKT Menu Rekapitulasi Gangguan all Recovery','Negatif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pelayanan Teknik','Melakukan penanganan gangguan','100% terpenuhinya jumlah skip step bulanan gangguan total sesuai dengan target yang ditetapkan pada masing-masing unit','EIS APKT Menu Rekapitulasi dan/atau Laporan Hasil Investigasi','Negatif','Kali',2,'Prioritas 1',0,0],
        ['TEKNIS','Inspeksi Jaringan Distribusi','Melakukan inspeksi tier 1 dan tier 2 jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) — a. Inspeksi TM - Tier 1','100% tercapainya jumlah inspeksi jaringan, gardu distribusi, dan peralatan jaringan sesuai dengan target yang ditetapkan pada WO','Laporan EAM Maximo','Positif','Kms',2,'Prioritas 1',0,0],
        ['TEKNIS','Inspeksi Jaringan Distribusi','Melakukan inspeksi tier 1 dan tier 2 jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) — b. Inspeksi TR - Tier 1','100% tercapainya jumlah inspeksi jaringan, gardu distribusi, dan peralatan jaringan sesuai dengan target yang ditetapkan pada WO','Laporan Inspeksi JTR Tier 1','Positif','Kms',2,'Prioritas 1',0,0],
        ['TEKNIS','Inspeksi Jaringan Distribusi','Melakukan inspeksi tier 1 dan tier 2 jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) — c. Inspeksi Gardu - Tier 1','100% tercapainya jumlah inspeksi jaringan, gardu distribusi, dan peralatan jaringan sesuai dengan target yang ditetapkan pada WO','Laporan EAM Maximo','Positif','Titik',2,'Prioritas 1',0,0],
        ['TEKNIS','Inspeksi Jaringan Distribusi','Melakukan inspeksi tier 1 dan tier 2 jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) — d. Inspeksi TM - Tier 2 Thermovision','100% tercapainya jumlah inspeksi jaringan, gardu distribusi, dan peralatan jaringan sesuai dengan target yang ditetapkan pada WO','Laporan Inspeksi TM - Tier 2 Thermovision','Positif','Kms',2,'Prioritas 1',0,0],
        ['TEKNIS','Inspeksi Jaringan Distribusi','Melakukan inspeksi tier 1 dan tier 2 jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) — e. Inspeksi Gardu - Tier 2 Thermovision','100% tercapainya jumlah inspeksi jaringan, gardu distribusi, dan peralatan jaringan sesuai dengan target yang ditetapkan pada WO','Laporan Inspeksi Gardu - Tier 2 Thermovision','Positif','Titik',2,'Prioritas 1',0,0],
        ['TEKNIS','Inspeksi Jaringan Distribusi','Melakukan inspeksi tier 1 dan tier 2 jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) — f. Inspeksi TM - Tier 2 Partical Discharge','100% tercapainya jumlah inspeksi jaringan, gardu distribusi, dan peralatan jaringan sesuai dengan target yang ditetapkan pada WO','Laporan Inspeksi TM - Tier 2 Partical Discharge','Positif','Kms',2,'Prioritas 1',0,0],
        ['TEKNIS','Inspeksi Jaringan Distribusi','Melakukan inspeksi tier 1 dan tier 2 jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) — g. Inspeksi Gardu - Tier 2 Partical Discharge','100% tercapainya jumlah inspeksi jaringan, gardu distribusi, dan peralatan jaringan sesuai dengan target yang ditetapkan pada WO','Laporan Inspeksi Gardu - Tier 2 Partical Discharge','Positif','Titik',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Melakukan pemeliharaan jaringan, meliputi: Right of Way (ROW), Komponen dan peralatan, Konstruksi','100% terlaksananya pemeliharaan ROW sesuai dengan WO','Laporan ROW','Positif','Kms',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Melakukan pemeliharaan gardu distribusi, meliputi: Trafo dan panel bagi, Kubikel','100% terlaksananya pemeliharaan trafo dan panel bagi sesuai dengan WO','Laporan HAR Trafo','Positif','WO',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Melakukan pemeliharaan peralatan jaringan','100% terlaksanannya pemeliharaan peralatan jaringan sesuai dengan WO','Laporan HAR JTM','Positif','WO',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Memastikan kualitas pekerjaan pasca pemeliharaan jaringan dan gardu (Sampling maks 10%)','100% kesesuaian data hasil sampling yang dilakukan oleh PLN terhadap pekerjaan yang dilaporkan oleh Pihak Kedua','Berita Acara Sampling','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Memastikan kualitas pekerjaan pasca pemeliharaan jaringan dan gardu (garansi 30 hari)','Tidak ada (0) Gangguan Pasca pemeliharaan sesuai aset yang dipelihara dalam masa garansi yang ditentukan masing-masing unit (30 hari Garansi)','Laporan dan Hasil Sidang Engineering gangguan','Negatif','Gangguan Pasca Har',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Memastikan pencapaian kinerja distribusi: Gangguan penyulang zona 1, Gangguan penyulang zona 2','Kali Gangguan dalam 1 (satu) Periode bulanan. Gangguan yang diakibatkan sesuai KPI Unit masing-masing: SLA ROW SUTM, Flashover, Binatang di Kubikel, Gangguan Tidak Jelas','Laporan gangguan/Logsheet UP2D/DCC','Negatif','Kali Gangguan',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Kualitas SDM dan Kompetensi Pekerja','100% Kompetensi SDM sesuai dengan Kualifikasi pekerjaannya','Sertifikasi Atau Pelatihan','Positif','Sertifikat',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Peralatan Kerja sesuai dengan persyaratan dan dalam kondisi Laik','100% Kesesuaian peralatan kerja dengan persyaratan dan dalam kondisi Laik','Formulir Checklist Pemeriksaan alat kerja','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Alat Keselamatan Kerja (APD, Rambu, LOTO)','100% Penyediaan Alat Pelindung diri sesuai Risiko pekerjaan','Checklist APD','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Alat Keselamatan Kerja (APD, Rambu, LOTO)','100% Penyediaan Rambu dan LOTO pada Satuan Kerja','Checklist Rambu dan LOTO','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Melakukan pekerjaan sesuai dengan Prosedur dan Instruksi Kerja yang berlaku (SOP, IK, WP)','Nol temuan pelanggaran prosedur dan instruksi kerja sesuai dengan sistem Manajemen K3','Laporan Inspeksi K3','Negatif','Temuan',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Inspeksi K3 oleh Direksi dan Management Perusahaan Alih Daya','Pelaksanaan Inspeksi oleh Direksi dan Management Perusahaan Alih Daya 2 kali/bulan','Laporan Inspeksi K3','Positif','Kali',2,'Prioritas 1',0,0],
        ['KECELAKAAN','Kecelakaan Kerja','Kecelakaan Kerja','Nol temuan Kecelakaan Kerja','Laporan Investigasi','Negatif','Temuan',2,'Prioritas 1',0,0],
        ['ILP','Komitmen Integritas Layanan Publik (ILP)','Meminta/menerima imbalan (gratifikasi) dari pelanggan yang dilayani dan/atau dari PIHAK PERTAMA secara langsung','Tidak ada (0) laporan pelanggaran ILP','Dokumen laporan pelanggaran ILP','Negatif','Laporan',1,'Prioritas 2',0,0],
        ['ILP','Komitmen Integritas Layanan Publik (ILP)','Melakukan pungutan liar, Kolusi Korupsi atau Nepotisme dll; atau','Tidak ada (0) laporan pelanggaran ILP','Dokumen laporan pelanggaran ILP','Negatif','Laporan',1,'Prioritas 2',0,0],
        ['ILP','Komitmen Integritas Layanan Publik (ILP)','Dengan sengaja tidak memberikan kemudahan, kecepatan dan transparansi terkait layanan publik','Tidak ada (0) laporan pelanggaran ILP','Dokumen laporan pelanggaran ILP','Negatif','Laporan',1,'Prioritas 2',0,0],
    ];

    // ------------------------------------------------------------------
    // Template khusus untuk Unit Layanan MANADO (Bidang Distribusi) — diambil
    // dari Template Tagihan Tahap 2 Februari 2026 UP3 Manado. File sumber ini
    // TIDAK punya kolom Eviden pada tabel SLA-nya (hanya Ruang Lingkup, Kriteria,
    // Target Kinerja, Polaritas, Satuan) — Eviden diisi menyamakan dengan
    // dokumen bukti dukung standar yang sama seperti pada unit Distribusi
    // (Kotamobagu)/Tahuna, karena rumusan indikatornya identik (template SLA
    // Distribusi yang sama dipakai di semua UP3, hanya beda unit & target).
    // File Manado juga tidak memecah "Inspeksi Jaringan Distribusi" ke 7
    // sub-jenis inspeksi (Tier 1/2) seperti Kotamobagu/Tahuna — di sini
    // tetap 1 baris gabungan (Satuan %) sesuai apa adanya di file.
    // Bobot & Jenis Bobot tidak eksplisit di file ini sehingga memakai
    // konvensi default aplikasi (2/Prioritas 1 untuk TEKNIS&K3&KECELAKAAN,
    // 1/Prioritas 2 untuk ILP) — sama seperti unit lain. Target tetap 0.
    // ------------------------------------------------------------------
    $defaultsManado = [
        ['TEKNIS','Pelayanan Teknik','Melakukan penanganan gangguan','100% terpenuhinya rata-rata response time bulanan gangguan total sesuai dengan target yang ditetapkan pada masing-masing unit','EIS APKT Menu Rekapitulasi Gangguan all Respone-Dispatching','Negatif','Menit',2,'Prioritas 1',0,0],
        ['TEKNIS','Pelayanan Teknik','Melakukan penanganan gangguan','100% terpenuhinya rata-rata recovery time bulanan gangguan total sesuai dengan target yang ditetapkan pada masing-masing unit','EIS APKT Menu Rekapitulasi Gangguan all Recovery','Negatif','Menit',2,'Prioritas 1',0,0],
        ['TEKNIS','Pelayanan Teknik','Melakukan penanganan gangguan','100% terpenuhinya jumlah gangguan berulang bulanan gangguan total sesuai dengan target yang ditetapkan pada masing-masing unit','EIS APKT Menu Rekapitulasi Gangguan all Recovery','Negatif','Rasio',2,'Prioritas 1',0,0],
        ['TEKNIS','Pelayanan Teknik','Melakukan penanganan gangguan','100% terpenuhinya jumlah skip step bulanan gangguan total sesuai dengan target yang ditetapkan pada masing-masing unit','EIS APKT Menu Rekapitulasi dan/atau Laporan Hasil Investigasi','Negatif','Kali',2,'Prioritas 1',0,0],
        ['TEKNIS','Inspeksi Jaringan Distribusi','Melakukan inspeksi tier 1 dan tier 2 jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD)','100% tercapainya jumlah inspeksi jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) sesuai dengan target yang ditetapkan pada WO','Work Order (WO) dan terinput di Aplikasi Maximo','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Melakukan pemeliharaan jaringan, meliputi: Right of Way (ROW), Komponen dan peralatan, Konstruksi','100% terlaksananya pemeliharaan ROW sesuai dengan WO','Work Order (WO) dan terinput di Aplikasi Maximo','Positif','Kms',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Melakukan pemeliharaan gardu distribusi, meliputi: Trafo dan panel bagi, Kubikel','100% terlaksananya pemeliharaan trafo dan panel bagi sesuai dengan WO','Work Order (WO) dan terinput di Aplikasi Maximo','Positif','WO',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Melakukan pemeliharaan peralatan jaringan','100% terlaksanannya pemeliharaan peralatan jaringan sesuai dengan WO','Work Order (WO) dan terinput di Aplikasi Maximo','Positif','WO',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Memastikan kualitas pekerjaan pasca pemeliharaan jaringan dan gardu (Sampling maks 10%)','100% kesesuaian data hasil sampling yang dilakukan oleh PLN terhadap pekerjaan yang dilaporkan oleh Pihak Kedua','Berita Acara Sampling','Positif','Persen',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Memastikan kualitas pekerjaan pasca pemeliharaan jaringan dan gardu (garansi 30 hari)','Tidak ada (0) Gangguan Pasca pemeliharaan sesuai aset yang dipelihara dalam masa garansi yang ditentukan masing-masing unit (30 hari Garansi)','laporan dan Hasil Sidang Engineering gangguan','Negatif','Gangguan Pasca Har',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Memastikan pencapaian kinerja distribusi: Gangguan penyulang zona 1, Gangguan penyulang zona 2','Kali Gangguan dalam 1 (satu) Periode bulanan. Gangguan yang diakibatkan sesuai KPI Unit masing-masing: SLA ROW SUTM, Flashover, Binatang di Kubikel, Gangguan Tidak Jelas','laporan gangguan/Logsheet UP2D/DCC','Negatif','Kali Gangguan',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Kualitas SDM dan Kompetensi Pekerja','100% Kompetensi SDM sesuai dengan Kualifikasi pekerjaannya','Sertifikasi Atau Pelatihan','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Peralatan Kerja sesuai dengan persyaratan dan dalam kondisi Laik','100% Kesesuaian peralatan kerja dengan persyaratan dan dalam kondisi Laik','Formulir Checklist Pemeriksaan alat kerja','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Alat Keselamatan Kerja (APD, Rambu, LOTO)','100% Penyediaan Alat Pelindung diri sesuai Risiko pekerjaan','Checklist APD','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Alat Keselamatan Kerja (APD, Rambu, LOTO)','100% Penyediaan Rambu dan LOTO pada Satuan Kerja','Checklist Rambu dan LOTO','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Melakukan pekerjaan sesuai dengan Prosedur dan Instruksi Kerja yang berlaku (SOP, IK, WP)','Nol temuan pelanggaran prosedur dan instruksi kerja sesuai dengan sistem Manajemen K3','Laporan Inspeksi K3','Negatif','Temuan',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Inspeksi K3 oleh Direksi dan Management Perusahaan Alih Daya','Pelaksanaan Inspeksi oleh Direksi dan Management Perusahaan Alih Daya 2 kali/bulan','Laporan Inspeksi K3','Positif','Kali',2,'Prioritas 1',0,0],
        ['KECELAKAAN','Kejadian Kecelakaan','Nihil Kejadian Kecelakaan Kerja Luka Berat dan Fatality','Nol temuan Kecelakaan Kerja','Laporan Investigasi','Negatif','Temuan',2,'Prioritas 1',0,0],
        ['ILP','Komitmen Integritas Layanan Publik (ILP)','Meminta/menerima imbalan (gratifikasi) dari pelanggan yang dilayani dan/atau dari PIHAK PERTAMA secara langsung','Tidak ada (0) laporan pelanggaran ILP','Dokumen laporan pelanggaran ILP','Negatif','Laporan',1,'Prioritas 2',0,0],
        ['ILP','Komitmen Integritas Layanan Publik (ILP)','Melakukan pungutan liar, Kolusi Korupsi atau Nepotisme dll; atau','Tidak ada (0) laporan pelanggaran ILP','Dokumen laporan pelanggaran ILP','Negatif','Laporan',1,'Prioritas 2',0,0],
        ['ILP','Komitmen Integritas Layanan Publik (ILP)','Dengan sengaja tidak memberikan kemudahan, kecepatan dan transparansi terkait layanan publik','Tidak ada (0) laporan pelanggaran ILP','Dokumen laporan pelanggaran ILP','Negatif','Laporan',1,'Prioritas 2',0,0],
    ];

    // ------------------------------------------------------------------
    // Template khusus untuk Unit Layanan TAHUNA (Bidang Distribusi) — diambil
    // apa adanya dari sheet "Target SLA", Template Tagihan Tahap 2 Volume
    // Based UP3 Tahuna Januari 2026 (lengkap dengan Eviden & Bobot eksplisit,
    // sama seperti unit Distribusi/Kotamobagu). Item "Inspeksi Jaringan
    // Distribusi" pada file ini tetap punya 7 sub-jenis inspeksi (a-g), tapi
    // ke-7 sub-item memakai SATU Eviden yang sama (Work Order & Aplikasi
    // Maximo) — beda dengan Kotamobagu yang tiap sub-item punya Eviden
    // sendiri-sendiri. Target tetap 0 (diisi manual), Bobot/Jenis Bobot
    // disalin dari file karena memang eksplisit tercantum.
    // ------------------------------------------------------------------
    $defaultsTahuna = [
        ['TEKNIS','Pelayanan Teknik','Melakukan penanganan gangguan','100% terpenuhinya rata-rata response time bulanan gangguan total sesuai dengan target yang ditetapkan pada masing-masing unit','EIS APKT Menu Rekapitulasi Gangguan all Respone-Dispatching','Negatif','Menit',2,'Prioritas 1',0,0],
        ['TEKNIS','Pelayanan Teknik','Melakukan penanganan gangguan','100% terpenuhinya rata-rata recovery time bulanan gangguan total sesuai dengan target yang ditetapkan pada masing-masing unit','EIS APKT Menu Rekapitulasi Gangguan all Recovery','Negatif','Menit',2,'Prioritas 1',0,0],
        ['TEKNIS','Pelayanan Teknik','Melakukan penanganan gangguan','100% terpenuhinya jumlah gangguan berulang bulanan gangguan total sesuai dengan target yang ditetapkan pada masing-masing unit','EIS APKT Menu Rekapitulasi Gangguan all Recovery','Negatif','Rasio',2,'Prioritas 1',0,0],
        ['TEKNIS','Pelayanan Teknik','Melakukan penanganan gangguan','100% terpenuhinya jumlah skip step bulanan gangguan total sesuai dengan target yang ditetapkan pada masing-masing unit','EIS APKT Menu Rekapitulasi dan/atau Laporan Hasil Investigasi','Negatif','Kali',2,'Prioritas 1',0,0],
        ['TEKNIS','Inspeksi Jaringan Distribusi','Melakukan inspeksi tier 1 dan tier 2 jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) — a. Inspeksi TM - Tier 1','100% tercapainya jumlah inspeksi jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) sesuai dengan target yang ditetapkan pada WO','Work Order (WO) dan terinput di Aplikasi Maximo','Positif','Kms',2,'Prioritas 1',0,0],
        ['TEKNIS','Inspeksi Jaringan Distribusi','Melakukan inspeksi tier 1 dan tier 2 jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) — b. Pengukuran Gardu','100% tercapainya jumlah inspeksi jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) sesuai dengan target yang ditetapkan pada WO','Work Order (WO) dan terinput di Aplikasi Maximo','Positif','Kms',2,'Prioritas 1',0,0],
        ['TEKNIS','Inspeksi Jaringan Distribusi','Melakukan inspeksi tier 1 dan tier 2 jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) — c. Inspeksi Gardu - Tier 1','100% tercapainya jumlah inspeksi jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) sesuai dengan target yang ditetapkan pada WO','Work Order (WO) dan terinput di Aplikasi Maximo','Positif','Titik',2,'Prioritas 1',0,0],
        ['TEKNIS','Inspeksi Jaringan Distribusi','Melakukan inspeksi tier 1 dan tier 2 jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) — d. Inspeksi TM - Tier 2 Thermovision','100% tercapainya jumlah inspeksi jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) sesuai dengan target yang ditetapkan pada WO','Work Order (WO) dan terinput di Aplikasi Maximo','Positif','Kms',2,'Prioritas 1',0,0],
        ['TEKNIS','Inspeksi Jaringan Distribusi','Melakukan inspeksi tier 1 dan tier 2 jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) — e. Inspeksi Gardu - Tier 2 Thermovision','100% tercapainya jumlah inspeksi jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) sesuai dengan target yang ditetapkan pada WO','Work Order (WO) dan terinput di Aplikasi Maximo','Positif','Titik',2,'Prioritas 1',0,0],
        ['TEKNIS','Inspeksi Jaringan Distribusi','Melakukan inspeksi tier 1 dan tier 2 jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) — f. Inspeksi TM - Tier 2 Partical Discharge','100% tercapainya jumlah inspeksi jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) sesuai dengan target yang ditetapkan pada WO','Work Order (WO) dan terinput di Aplikasi Maximo','Positif','Kms',2,'Prioritas 1',0,0],
        ['TEKNIS','Inspeksi Jaringan Distribusi','Melakukan inspeksi tier 1 dan tier 2 jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) — g. Inspeksi Gardu - Tier 2 Partical Discharge','100% tercapainya jumlah inspeksi jaringan, gardu distribusi, dan peralatan jaringan (titik sambung, SSO, recloser, keypoint, CBO, PMFD, GFD) sesuai dengan target yang ditetapkan pada WO','Work Order (WO) dan terinput di Aplikasi Maximo','Positif','Titik',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Melakukan pemeliharaan jaringan, meliputi: Right of Way (ROW), Komponen dan peralatan, Konstruksi','100% terlaksananya pemeliharaan ROW sesuai dengan WO','Work Order (WO) dan terinput di Aplikasi Maximo','Positif','Kms',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Melakukan pemeliharaan gardu distribusi, meliputi: Trafo dan panel bagi, Kubikel','100% terlaksananya pemeliharaan trafo dan panel bagi sesuai dengan WO','Work Order (WO) dan terinput di Aplikasi Maximo','Positif','WO',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Melakukan pemeliharaan peralatan jaringan','100% terlaksanannya pemeliharaan peralatan jaringan sesuai dengan WO','Work Order (WO) dan terinput di Aplikasi','Positif','WO',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Memastikan kualitas pekerjaan pasca pemeliharaan jaringan dan gardu (Sampling maks 10%)','100% kesesuaian data hasil sampling yang dilakukan oleh PLN terhadap pekerjaan yang dilaporkan oleh Pihak Kedua','Berita Acara Sampling','Positif','Sampling',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Memastikan kualitas pekerjaan pasca pemeliharaan jaringan dan gardu (garansi 30 hari)','Tidak ada (0) Gangguan Pasca pemeliharaan sesuai aset yang dipelihara dalam masa garansi yang ditentukan masing-masing unit (30 hari Garansi)','laporan dan Hasil Sidang Engineering gangguan','Negatif','Gangguan Pasca Har',2,'Prioritas 1',0,0],
        ['TEKNIS','Pemeliharaan Jaringan Distribusi','Memastikan pencapaian kinerja distribusi: Gangguan penyulang zona 1, Gangguan penyulang zona 2','Kali Gangguan dalam 1 (satu) Periode bulanan. Gangguan yang diakibatkan sesuai KPI Unit masing-masing: SLA ROW SUTM, Flashover, Binatang di Kubikel, Gangguan Tidak Jelas','laporan gangguan/Logsheet UP2D/DCC','Negatif','Kali Gangguan',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Kualitas SDM dan Kompetensi Pekerja','100% Kompetensi SDM sesuai dengan Kualifikasi pekerjaannya','Sertifikasi Atau Pelatihan','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Peralatan Kerja sesuai dengan persyaratan dan dalam kondisi Laik','100% Kesesuaian peralatan kerja dengan persyaratan dan dalam kondisi Laik','Formulir Checklist Pemeriksaan alat kerja','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Alat Keselamatan Kerja (APD, Rambu, LOTO)','100% Penyediaan Alat Pelindung diri sesuai Risiko pekerjaan','Checklist APD','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Alat Keselamatan Kerja (APD, Rambu, LOTO)','100% Penyediaan Rambu dan LOTO pada Satuan Kerja','Checklist Rambu dan LOTO','Positif','Persen',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Melakukan pekerjaan sesuai dengan Prosedur dan Instruksi Kerja yang berlaku (SOP, IK, WP)','Nol temuan pelanggaran prosedur dan instruksi kerja sesuai dengan sistem Manajemen K3','Laporan Inspeksi K3','Negatif','Temuan',2,'Prioritas 1',0,0],
        ['K3','Penerapan Keselamatan dan Kesehatan Kerja (K3) di tempat Kerja','Inspeksi K3 oleh Direksi dan Management Perusahaan Alih Daya','Pelaksanaan Inspeksi oleh Direksi dan Management Perusahaan Alih Daya 2 kali/bulan','Laporan Inspeksi K3','Positif','Persen',2,'Prioritas 1',0,0],
        ['KECELAKAAN','Kecelakaan Kerja','Kecelakaan Kerja','Nol temuan Kecelakaan Kerja','Laporan Investigasi','Negatif','Temuan',2,'Prioritas 1',0,0],
        ['ILP','Komitmen Integritas Layanan Publik (ILP)','Meminta/menerima imbalan (gratifikasi) dari pelanggan yang dilayani dan/atau dari PIHAK PERTAMA secara langsung','Tidak ada (0) laporan pelanggaran ILP','Dokumen laporan pelanggaran ILP','Negatif','Laporan',1,'Prioritas 2',0,0],
        ['ILP','Komitmen Integritas Layanan Publik (ILP)','Melakukan pungutan liar, Kolusi Korupsi atau Nepotisme dll; atau','Tidak ada (0) laporan pelanggaran ILP','Dokumen laporan pelanggaran ILP','Negatif','Laporan',1,'Prioritas 2',0,0],
        ['ILP','Komitmen Integritas Layanan Publik (ILP)','Dengan sengaja tidak memberikan kemudahan, kecepatan dan transparansi terkait layanan publik','Tidak ada (0) laporan pelanggaran ILP','Dokumen laporan pelanggaran ILP','Negatif','Laporan',1,'Prioritas 2',0,0],
    ];

    // Catatan: HAR_TRANS, KEYPOINT_SCADA, KIT_MINAHASA, KIT_LAHENDONG SENGAJA
    // tidak didaftarkan di $unitTemplates di bawah — belum ada data SLA asli untuk
    // Project-project ini. Karena kode-nya tidak ada di $unitTemplates, kontrak yang
    // memakai unit ini otomatis jatuh ke template default per-Bidang (lihat
    // $defaultsDistribusi/$defaultsTransmisi/$defaultsPembangkit di bawah) sebagai
    // placeholder sementara — tinggal tambahkan entri baru di $unitTemplates begitu
    // data SLA aslinya dikirim, tanpa perlu mengubah apapun di bagian lain.
    // Daftar template per-Unit yang tersedia (kode Unit Kerja => template).
    // Tambahkan entri baru di sini setiap kali unit lain dikirim.
    $unitTemplates = [
        'OPGI'       => $defaultsOpgi,
        'GP'         => $defaultsGp,
        'KOTAMOBAGU' => $defaultsDistribusiUnit,
        'MANADO'     => $defaultsManado,
        'TAHUNA'     => $defaultsTahuna,
    ];
    $unitKodeNorm = $unitKode ? strtoupper(trim($unitKode)) : null;
    if ($unitKodeNorm !== null && isset($unitTemplates[$unitKodeNorm])) {
        $sqlUnit = "INSERT INTO sla_entries
            (kontrak_id, ulp_id, kategori, no_urut, ruang_lingkup, kriteria,
             target_kinerja, eviden, polaritas, satuan, bobot, jenis_bobot,
             target, realisasi, persen_pencapaian, nilai_bobot)
            VALUES (?,NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        $stUnit = $db->prepare($sqlUnit);
        $counterPerKategori = [];
        foreach ($unitTemplates[$unitKodeNorm] as $d) {
            [$kat,$ruang,$krit,$kinerja,$eviden,$pol,$sat,$bobot,$jenis,$target,$real] = $d;
            $counterPerKategori[$kat] = ($counterPerKategori[$kat] ?? 0) + 1;
            $noUrut = sprintf('%02d', $counterPerKategori[$kat]);
            $pct = ($target==0 && (float)$real==0) ? 100 : 0;
            $nb  = ($target==0 && (float)$real==0) ? $bobot*100 : 0;
            $stUnit->execute([$kontrak_id,$kat,$noUrut,$ruang,$krit,$kinerja,$eviden,$pol,$sat,$bobot,$jenis,$target,$real,$pct,$nb]);
        }
        return;
    }

    // Default SLA untuk DISTRIBUSI
    $defaultsDistribusi = [
        ['TEKNIS','1','Pelayanan Teknik','1.1','Response Time Gangguan','100% terpenuhinya rata-rata response time','Negatif','Menit',2,'Prioritas 1',30,0],
        ['TEKNIS','1','Pelayanan Teknik','1.2','Recovery Time Gangguan','100% terpenuhinya rata-rata recovery time','Negatif','Menit',2,'Prioritas 1',100,0],
        ['TEKNIS','1','Pelayanan Teknik','1.3','Gangguan Berulang','100% terpenuhinya jumlah gangguan berulang','Negatif','Rasio',2,'Prioritas 1',0.09,0],
        ['TEKNIS','1','Pelayanan Teknik','1.4','Skip Step','100% terpenuhinya jumlah skip step','Negatif','Kali',2,'Prioritas 1',0,0],
        ['TEKNIS','2','Inspeksi Jaringan Distribusi','2.1','Inspeksi Tier 1 & 2','100% tercapainya jumlah inspeksi jaringan, gardu distribusi','Positif','%',2,'Prioritas 1',100,0],
        ['TEKNIS','3','Pemeliharaan Jaringan Distribusi','3.1','Pemeliharaan ROW','100% terlaksananya pemeliharaan ROW sesuai WO','Positif','Kms',2,'Prioritas 1',100,0],
        ['TEKNIS','3','Pemeliharaan Jaringan Distribusi','3.2','Pemeliharaan Gardu','100% terlaksananya pemeliharaan trafo dan panel bagi sesuai WO','Positif','%',2,'Prioritas 1',100,0],
        ['TEKNIS','3','Pemeliharaan Jaringan Distribusi','3.3','Pemeliharaan Peralatan Jaringan','100% terlaksananya pemeliharaan peralatan jaringan sesuai WO','Positif','%',2,'Prioritas 1',100,0],
        ['TEKNIS','3','Pemeliharaan Jaringan Distribusi','3.4','Kesesuaian Sampling','100% kesesuaian data hasil sampling','Positif','%',2,'Prioritas 1',100,0],
        ['TEKNIS','3','Pemeliharaan Jaringan Distribusi','3.4b','Gangguan Pasca Pemeliharaan','Tidak ada gangguan pasca pemeliharaan (30 hari garansi)','Negatif','Gangguan',2,'Prioritas 1',0,0],
        ['TEKNIS','3','Pemeliharaan Jaringan Distribusi','3.5','Gangguan Penyulang','Kali gangguan dalam 1 periode bulanan','Negatif','Kali Gangguan',2,'Prioritas 1',0,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.1','Kompetensi SDM','100% Kompetensi SDM sesuai Kualifikasi','Positif','%',2,'Prioritas 1',100,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.2','Peralatan Kerja Laik','100% Kesesuaian peralatan kerja','Positif','%',2,'Prioritas 1',100,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.3a','APD Sesuai Risiko','100% Penyediaan APD sesuai risiko pekerjaan','Positif','%',2,'Prioritas 1',100,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.3b','Rambu dan LOTO','100% Penyediaan Rambu dan LOTO','Positif','%',2,'Prioritas 1',100,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.4','Prosedur dan IK','Nol temuan pelanggaran prosedur K3','Negatif','Temuan',2,'Prioritas 1',0,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.5','Inspeksi K3 Management','Inspeksi oleh Direksi 2 kali/bulan per ULP','Positif','Kali',2,'Prioritas 1',6,0],
        ['KECELAKAAN','2','Kejadian Kecelakaan','2.1','Nihil Kecelakaan','Nol temuan Kecelakaan Kerja Luka Berat/Fatality','Negatif','Temuan',2,'Prioritas 1',0,0],
        ['ILP','1','Komitmen ILP','1.1','Gratifikasi','Tidak ada laporan pelanggaran gratifikasi','Negatif','Laporan',1,'Prioritas 2',0,0],
        ['ILP','1','Komitmen ILP','1.2','Pungli/KKN','Tidak ada laporan pelanggaran Pungli/KKN','Negatif','Laporan',1,'Prioritas 2',0,0],
        ['ILP','1','Komitmen ILP','1.3','Layanan Publik','Tidak ada laporan pelanggaran layanan publik','Negatif','Laporan',1,'Prioritas 2',0,0],
    ];

    // Default SLA untuk TRANSMISI
    $defaultsTransmisi = [
        ['TEKNIS','1','Pelayanan Teknik Transmisi','1.1','Response Time Gangguan Transmisi','100% terpenuhinya rata-rata response time gangguan transmisi','Negatif','Menit',2,'Prioritas 1',60,0],
        ['TEKNIS','1','Pelayanan Teknik Transmisi','1.2','Recovery Time Gangguan Transmisi','100% terpenuhinya rata-rata recovery time gangguan transmisi','Negatif','Menit',2,'Prioritas 1',180,0],
        ['TEKNIS','1','Pelayanan Teknik Transmisi','1.3','Gangguan Berulang Transmisi','100% terpenuhinya jumlah gangguan berulang saluran transmisi','Negatif','Kali',2,'Prioritas 1',0,0],
        ['TEKNIS','2','Inspeksi Jaringan Transmisi','2.1','Inspeksi SUTET/SUTT','100% tercapainya jumlah inspeksi saluran udara tegangan tinggi','Positif','%',2,'Prioritas 1',100,0],
        ['TEKNIS','2','Inspeksi Jaringan Transmisi','2.2','Inspeksi GI/GIS','100% tercapainya jumlah inspeksi gardu induk','Positif','%',2,'Prioritas 1',100,0],
        ['TEKNIS','3','Pemeliharaan Jaringan Transmisi','3.1','Pemeliharaan ROW Transmisi','100% terlaksananya pemeliharaan ROW saluran transmisi sesuai WO','Positif','Kms',2,'Prioritas 1',100,0],
        ['TEKNIS','3','Pemeliharaan Jaringan Transmisi','3.2','Pemeliharaan Peralatan GI','100% terlaksananya pemeliharaan peralatan gardu induk sesuai WO','Positif','%',2,'Prioritas 1',100,0],
        ['TEKNIS','3','Pemeliharaan Jaringan Transmisi','3.3','Kesesuaian Data Aset','100% kesesuaian data aset hasil pemeliharaan','Positif','%',2,'Prioritas 1',100,0],
        ['TEKNIS','3','Pemeliharaan Jaringan Transmisi','3.4','Gangguan Pasca Pemeliharaan','Tidak ada gangguan pasca pemeliharaan (30 hari garansi)','Negatif','Gangguan',2,'Prioritas 1',0,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.1','Kompetensi SDM Transmisi','100% Kompetensi SDM sesuai Kualifikasi','Positif','%',2,'Prioritas 1',100,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.2','Peralatan Kerja Laik','100% Kesesuaian peralatan kerja transmisi','Positif','%',2,'Prioritas 1',100,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.3a','APD Sesuai Risiko','100% Penyediaan APD sesuai risiko pekerjaan tegangan tinggi','Positif','%',2,'Prioritas 1',100,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.3b','Rambu dan LOTO','100% Penyediaan Rambu dan LOTO','Positif','%',2,'Prioritas 1',100,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.4','Prosedur dan IK','Nol temuan pelanggaran prosedur K3','Negatif','Temuan',2,'Prioritas 1',0,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.5','Inspeksi K3 Management','Inspeksi oleh Direksi 2 kali/bulan','Positif','Kali',2,'Prioritas 1',4,0],
        ['KECELAKAAN','2','Kejadian Kecelakaan','2.1','Nihil Kecelakaan','Nol temuan Kecelakaan Kerja Luka Berat/Fatality','Negatif','Temuan',2,'Prioritas 1',0,0],
        ['ILP','1','Komitmen ILP','1.1','Gratifikasi','Tidak ada laporan pelanggaran gratifikasi','Negatif','Laporan',1,'Prioritas 2',0,0],
        ['ILP','1','Komitmen ILP','1.2','Pungli/KKN','Tidak ada laporan pelanggaran Pungli/KKN','Negatif','Laporan',1,'Prioritas 2',0,0],
        ['ILP','1','Komitmen ILP','1.3','Layanan Publik','Tidak ada laporan pelanggaran layanan publik','Negatif','Laporan',1,'Prioritas 2',0,0],
    ];

    // Default SLA untuk PEMBANGKIT — targetnya sengaja dikosongkan (0) karena
    // nilai target pembangkit tidak standar (tergantung jenis/kapasitas mesin),
    // sehingga harus diisi MANUAL oleh pengguna lewat form Target & Realisasi.
    $defaultsPembangkit = [
        ['TEKNIS','1','Pelayanan Teknik Pembangkit','1.1','Response Time Gangguan Pembangkit','Diisi manual sesuai kesepakatan kontrak','Negatif','Menit',2,'Prioritas 1',0,0],
        ['TEKNIS','1','Pelayanan Teknik Pembangkit','1.2','Recovery Time Gangguan Pembangkit','Diisi manual sesuai kesepakatan kontrak','Negatif','Menit',2,'Prioritas 1',0,0],
        ['TEKNIS','2','Kinerja Operasi Pembangkit','2.1','Availability Factor (AF)','Diisi manual sesuai kesepakatan kontrak','Positif','%',2,'Prioritas 1',0,0],
        ['TEKNIS','2','Kinerja Operasi Pembangkit','2.2','Equivalent Forced Outage Rate (EFOR)','Diisi manual sesuai kesepakatan kontrak','Negatif','%',2,'Prioritas 1',0,0],
        ['TEKNIS','3','Pemeliharaan Pembangkit','3.1','Pemeliharaan Preventif Mesin','Diisi manual sesuai kesepakatan kontrak','Positif','%',2,'Prioritas 1',0,0],
        ['TEKNIS','3','Pemeliharaan Pembangkit','3.2','Kesesuaian Sampling/Uji Kualitas','Diisi manual sesuai kesepakatan kontrak','Positif','%',2,'Prioritas 1',0,0],
        ['TEKNIS','3','Pemeliharaan Pembangkit','3.3','Gangguan Pasca Pemeliharaan','Diisi manual sesuai kesepakatan kontrak','Negatif','Gangguan',2,'Prioritas 1',0,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.1','Kompetensi SDM Pembangkit','Diisi manual sesuai kesepakatan kontrak','Positif','%',2,'Prioritas 1',0,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.2','Peralatan Kerja Laik','Diisi manual sesuai kesepakatan kontrak','Positif','%',2,'Prioritas 1',0,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.3a','APD Sesuai Risiko','Diisi manual sesuai kesepakatan kontrak','Positif','%',2,'Prioritas 1',0,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.3b','Rambu dan LOTO','Diisi manual sesuai kesepakatan kontrak','Positif','%',2,'Prioritas 1',0,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.4','Prosedur dan IK','Diisi manual sesuai kesepakatan kontrak','Negatif','Temuan',2,'Prioritas 1',0,0],
        ['K3','1','Penerapan K3 di Tempat Kerja','1.5','Inspeksi K3 Management','Diisi manual sesuai kesepakatan kontrak','Positif','Kali',2,'Prioritas 1',0,0],
        ['KECELAKAAN','2','Kejadian Kecelakaan','2.1','Nihil Kecelakaan','Diisi manual sesuai kesepakatan kontrak','Negatif','Temuan',2,'Prioritas 1',0,0],
        ['ILP','1','Komitmen ILP','1.1','Gratifikasi','Diisi manual sesuai kesepakatan kontrak','Negatif','Laporan',1,'Prioritas 2',0,0],
        ['ILP','1','Komitmen ILP','1.2','Pungli/KKN','Diisi manual sesuai kesepakatan kontrak','Negatif','Laporan',1,'Prioritas 2',0,0],
        ['ILP','1','Komitmen ILP','1.3','Layanan Publik','Diisi manual sesuai kesepakatan kontrak','Negatif','Laporan',1,'Prioritas 2',0,0],
    ];

    $defaults = match ($jenis_kontrak) {
        'TRANSMISI'  => $defaultsTransmisi,
        'PEMBANGKIT' => $defaultsPembangkit,
        default      => $defaultsDistribusi,
    };

    $sql = "INSERT INTO sla_entries
        (kontrak_id, ulp_id, kategori, no_urut, ruang_lingkup, kriteria,
         target_kinerja, polaritas, satuan, bobot, jenis_bobot,
         target, realisasi, persen_pencapaian, nilai_bobot)
        VALUES (?,NULL,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $st = $db->prepare($sql);

    foreach ($defaults as $d) {
        [$kat,$no,$ruang,$krit_no,$krit,$target_k,$pol,$sat,$bobot,$jenis,$target,$real] = $d;
        $pct = ($target==0 && (float)$real==0) ? 100 : 0;
        $nb  = ($target==0 && (float)$real==0) ? $bobot*100 : 0;
        $st->execute([$kontrak_id,$kat,$no,$ruang,$krit,$target_k,$pol,$sat,$bobot,$jenis,$target,$real,$pct,$nb]);
    }
}

// ---------------------------------------------------------------
//  TRANSAKSI & PROSES: MONITORING HARIAN -> PERHITUNGAN SLA OTOMATIS
// ---------------------------------------------------------------

const BULAN_NAMA_KE_NOMOR = [
    'JANUARI'=>1,'FEBRUARI'=>2,'MARET'=>3,'APRIL'=>4,'MEI'=>5,'JUNI'=>6,
    'JULI'=>7,'AGUSTUS'=>8,'SEPTEMBER'=>9,'OKTOBER'=>10,'NOVEMBER'=>11,'DESEMBER'=>12,
];

/**
 * Tentukan rentang tanggal (awal-akhir) periode_bulan+tahun sebuah kontrak.
 * @return array{0:string,1:string} [tgl_awal, tgl_akhir] format Y-m-d
 */
function getRentangPeriode(string $periode_bulan, int $tahun): array {
    $bulanNo = BULAN_NAMA_KE_NOMOR[strtoupper($periode_bulan)] ?? (int)date('n');
    $awal  = sprintf('%04d-%02d-01', $tahun, $bulanNo);
    $akhir = date('Y-m-t', strtotime($awal));
    return [$awal, $akhir];
}

/**
 * Tentukan metode agregasi data harian -> nilai bulanan berdasarkan satuan indikator.
 * Indikator waktu/rasio (Menit, Rasio) diagregasi dengan rata-rata,
 * indikator hitungan (%, Kali, Temuan, Laporan, Gangguan, Kms, dll) diagregasi dengan total.
 */
function metodeAgregasiHarian(string $satuan): string {
    $rataRata = ['Menit', 'Rasio'];
    return in_array($satuan, $rataRata, true) ? 'AVG' : 'SUM';
}

/**
 * Hitung ulang realisasi sla_entries (level kontrak, ulp_id IS NULL) berdasarkan
 * akumulasi data monitoring_harian pada bulan berjalan kontrak, lalu update rekap SLA.
 * Dipanggil otomatis setiap kali input harian disimpan, dan bisa dipanggil manual
 * lewat tombol "Hitung Ulang dari Data Harian" di Rekap SLA.
 */
function recalcRealisasiHarian(PDO $db, int $kontrak_id): void {
    $kontrak = dbRow($db, "SELECT periode_bulan, tahun FROM kontrak WHERE id=?", [$kontrak_id]);
    if (!$kontrak) return;
    [$awal, $akhir] = getRentangPeriode($kontrak['periode_bulan'] ?? '', (int)($kontrak['tahun'] ?? date('Y')));

    $entries = dbAll($db, "SELECT id, polaritas, target, satuan FROM sla_entries WHERE kontrak_id=? AND ulp_id IS NULL", [$kontrak_id]);

    foreach ($entries as $e) {
        $metode = metodeAgregasiHarian($e['satuan'] ?? '');
        // Diakumulasi berdasarkan PERIODE (1 & 2), bukan rentang tanggal — karena kolom
        // `tanggal` sekarang menyimpan tanggal input sesungguhnya (bisa kapan saja),
        // bukan lagi patokan tgl 15/25. Satu sla_entry_id sudah pasti hanya milik 1 kontrak/bulan.
        $agg = dbRow($db,
            "SELECT AVG(nilai_harian) AS avg_val, SUM(nilai_harian) AS sum_val, COUNT(*) AS jml
             FROM monitoring_harian WHERE sla_entry_id=? AND periode IS NOT NULL",
            [$e['id']]);

        if (!$agg || (int)$agg['jml'] === 0) continue; // belum ada data harian, jangan timpa realisasi manual

        $realisasi = $metode === 'AVG' ? (float)$agg['avg_val'] : (float)$agg['sum_val'];
        $pct = hitungPencapaian($e['polaritas'], (float)$e['target'], $realisasi);
        $bobotRow = dbRow($db, "SELECT bobot FROM sla_entries WHERE id=?", [$e['id']]);
        $nb = hitungNilaiBobot((float)($bobotRow['bobot'] ?? 0), $pct);

        dbExec($db, "UPDATE sla_entries SET realisasi=?, persen_pencapaian=?, nilai_bobot=? WHERE id=?",
            [$realisasi, $pct, $nb, $e['id']]);
    }

    updateRekapSLA($kontrak_id);
}

/**
 * Daftar id sla_entries (dari $entryIds) yang SUDAH punya data monitoring_harian.
 * Dipakai untuk mencegah tumpang-tindih antara 2 alur input yang menulis ke
 * kolom `realisasi` yang sama:
 *   1) Input SLA harian (input_harian.php) -> otomatis diagregasi oleh
 *      recalcRealisasiHarian() setiap kali disimpan.
 *   2) Form "Target & Realisasi" manual (kontrak.php) -> dulu bisa menimpa
 *      langsung nilai `realisasi`, lalu diam-diam tertimpa balik begitu ada
 *      input harian berikutnya (karena recalcRealisasiHarian menang terakhir).
 * Indikator yang sudah punya data harian dikunci di form manual supaya hanya
 * ada SATU sumber kebenaran (Input SLA harian) untuk realisasinya.
 */
function getEntriesWithHarianData(PDO $db, array $entryIds): array {
    $entryIds = array_values(array_unique(array_map('intval', $entryIds)));
    if (!$entryIds) return [];
    $placeholders = implode(',', array_fill(0, count($entryIds), '?'));
    $rows = dbAll($db,
        "SELECT DISTINCT sla_entry_id FROM monitoring_harian WHERE sla_entry_id IN ($placeholders) AND periode IS NOT NULL",
        $entryIds);
    return array_map('intval', array_column($rows, 'sla_entry_id'));
}

/**
 * Bobot maksimal (skala nilai_bobot, 0-100 per poin) untuk satu kategori pada satu kontrak,
 * dihitung dari baris "Gabungan" (ulp_id IS NULL) milik kontrak itu sendiri.
 * Menggantikan angka tetap (hardcoded) yang sebelumnya dipakai untuk semua kontrak.
 */
function getMaxBobotKategori(PDO $db, int $kontrak_id, string $kategori): float {
    $row = dbRow($db,
        "SELECT SUM(bobot) AS total_bobot FROM sla_entries WHERE kontrak_id=? AND kategori=? AND ulp_id IS NULL",
        [$kontrak_id, $kategori]);
    return (float)($row['total_bobot'] ?? 0) * 100;
}

/**
 * Menyamakan baris "Gabungan" (ulp_id IS NULL) dengan rata-rata target & realisasi
 * dari seluruh ULP untuk kategori+no_urut yang sama, lalu hitung ulang pencapaian & nilai bobotnya.
 * Dipanggil otomatis setiap kali data per-ULP disimpan, supaya Rekap SLA
 * (yang membaca baris Gabungan) selalu mencerminkan input per-ULP terbaru.
 */
function syncGabunganFromULP(int $kontrak_id, string $kategori, string $no_urut): void {
    $db = getDB();
    $ulpRows = dbAll($db,
        "SELECT target, realisasi FROM sla_entries
         WHERE kontrak_id=? AND kategori=? AND no_urut=? AND ulp_id IS NOT NULL",
        [$kontrak_id, $kategori, $no_urut]);
    if (!$ulpRows) return;

    $n = count($ulpRows);
    $avgTarget = array_sum(array_column($ulpRows, 'target')) / $n;

    // Realisasi Gabungan hanya dirata-rata dari ULP yang SUDAH dinilai
    // (realisasi tidak NULL) — supaya ULP yang belum diisi tidak ikut
    // menyeret turun rata-rata Gabungan seolah-olah gagal.
    $ulpTerisi = array_values(array_filter($ulpRows, fn($r) => $r['realisasi'] !== null));
    $avgRealisasi = !empty($ulpTerisi)
        ? array_sum(array_column($ulpTerisi, 'realisasi')) / count($ulpTerisi)
        : null;

    $gab = dbRow($db,
        "SELECT id, polaritas, bobot FROM sla_entries
         WHERE kontrak_id=? AND kategori=? AND no_urut=? AND ulp_id IS NULL",
        [$kontrak_id, $kategori, $no_urut]);
    if (!$gab) return;

    $pct = ($avgRealisasi === null) ? null : hitungPencapaian($gab['polaritas'], $avgTarget, $avgRealisasi);
    $nb = ($pct === null) ? null : hitungNilaiBobot((float)$gab['bobot'], $pct);

    dbExec($db, "UPDATE sla_entries SET target=?, realisasi=?, persen_pencapaian=?, nilai_bobot=? WHERE id=?",
        [$avgTarget, $avgRealisasi, $pct, $nb, $gab['id']]);
}

function updateRekapSLA(int $kontrak_id): void {
    $db = getDB();
    $categories = ['TEKNIS','K3','KECELAKAAN','ILP'];
    $totals = [];

    foreach ($categories as $cat) {
        $row = dbRow($db,
            "SELECT SUM(bobot) AS sum_bobot_asli, SUM(nilai_bobot) AS sum_bobot
             FROM sla_entries WHERE kontrak_id=? AND kategori=? AND ulp_id IS NULL AND realisasi IS NOT NULL",
            [$kontrak_id, $cat]);
        $bobotAsli = (float)($row['sum_bobot_asli'] ?? 0);
        $sumNilaiBobot = (float)($row['sum_bobot'] ?? 0);
        // % SLA kategori = rata-rata BERBOBOT (indikator bobot besar pengaruhnya lebih besar),
        // sesuai kolom "% Pencapaian Berbobot" pada dokumen BA SLA resmi PLN — BUKAN rata-rata
        // sederhana yang menyamaratakan semua indikator.
        $totals[$cat] = [
            'pct' => $bobotAsli > 0 ? ($sumNilaiBobot / $bobotAsli) : 0,
            'bobot' => $sumNilaiBobot,
        ];
    }

    $total_bobot = array_sum(array_column($totals,'bobot'));
    // Skor SLA keseluruhan kontrak (dipakai di Dashboard, Rekap SLA, Laporan Grafik, dst) —
    // dihitung dari TOTAL nilai-berbobot SEMUA indikator (lintas 4 kategori) dibagi TOTAL
    // bobot semua indikator tsb, BUKAN rata-rata sederhana 4 kategori (lihat catatan di atas
    // fungsi ini / di CREATE TABLE rekap_sla). Ini otomatis memberi porsi lebih besar ke
    // kategori yang total bobotnya lebih besar (biasanya TEKNIS), sesuai dokumen BA SLA resmi.
    $totalBobotAsliSemua = 0;
    foreach ($categories as $cat) {
        $row = dbRow($db,
            "SELECT SUM(bobot) AS sum_bobot_asli FROM sla_entries WHERE kontrak_id=? AND kategori=? AND ulp_id IS NULL AND realisasi IS NOT NULL",
            [$kontrak_id, $cat]);
        $totalBobotAsliSemua += (float)($row['sum_bobot_asli'] ?? 0);
    }
    $sla_overall = $totalBobotAsliSemua > 0 ? ($total_bobot / $totalBobotAsliSemua) : 0;

    $db->prepare("INSERT INTO rekap_sla
        (kontrak_id, sla_teknis, sla_k3, sla_kecelakaan, sla_ilp, total_bobot, sla_overall, updated_at)
        VALUES (?,?,?,?,?,?,?,NOW())
        ON DUPLICATE KEY UPDATE
         sla_teknis=VALUES(sla_teknis), sla_k3=VALUES(sla_k3),
         sla_kecelakaan=VALUES(sla_kecelakaan), sla_ilp=VALUES(sla_ilp),
         total_bobot=VALUES(total_bobot), sla_overall=VALUES(sla_overall), updated_at=NOW()")
    ->execute([$kontrak_id,
        $totals['TEKNIS']['pct'],$totals['K3']['pct'],
        $totals['KECELAKAAN']['pct'],$totals['ILP']['pct'],
        $total_bobot, $sla_overall]);
}

/**
 * Skor SLA keseluruhan (0-100) dari satu baris rekap_sla, dipakai di semua tempat
 * yang perlu menampilkan "SLA kontrak ini berapa %" (Dashboard, Rekap SLA, Laporan
 * Grafik, Cetak Laporan, Export Excel, dll) — SATU fungsi ini jadi rujukan tunggal
 * supaya tidak ada lagi tempat yang diam-diam pakai rata-rata sederhana ÷4.
 * Memakai kolom sla_overall (sudah dihitung berbobot lintas kategori oleh
 * updateRekapSLA()); kalau kolomnya kosong/belum ada (data sangat lama yang belum
 * sempat di-backfill), fallback ke rata-rata sederhana supaya tetap ada angka
 * ditampilkan, bukan kosong/error.
 */
function rekapOverallPct(?array $rekap): float {
    if (!$rekap) return 0.0;
    if (isset($rekap['sla_overall']) && (float)$rekap['sla_overall'] > 0) {
        return (float)$rekap['sla_overall'];
    }
    return (((float)($rekap['sla_teknis'] ?? 0)) + ((float)($rekap['sla_k3'] ?? 0))
        + ((float)($rekap['sla_kecelakaan'] ?? 0)) + ((float)($rekap['sla_ilp'] ?? 0))) / 4;
}

/**
 * Ambil status pengisian monitoring harian per tanggal dalam satu periode kontrak,
 * untuk ditampilkan sebagai kalender (Input Monitoring Harian).
 * Return: [ 'YYYY-MM-DD' => ['status' => kosong|belum_lengkap|lengkap, 'terisi' => int, 'total' => int] ]
 */
/**
 * Status pengisian per PERIODE (1 = 2 minggu pertama / tgl 1-15, 2 = 2 minggu akhir / tgl 16-akhir bulan)
 * untuk satu kontrak. Dipakai di tombol pemilih Periode 1/2 pada Input SLA, termasuk kapan
 * data periode itu pertama kali & terakhir diinput (created_at/updated_at), dan tanggal
 * input asli yang tersimpan (kolom `tanggal`, bukan tanggal 15/25).
 */
function getStatusPeriodeInput(PDO $db, int $kontrak_id): array {
    $jumlahIndikator = (int)dbVal($db,
        "SELECT COUNT(*) FROM sla_entries WHERE kontrak_id=? AND ulp_id IS NULL", [$kontrak_id]);

    $rows = dbAll($db,
        "SELECT mh.periode, COUNT(*) AS terisi,
                MIN(mh.created_at) AS pertama_input, MAX(mh.updated_at) AS terakhir_input,
                MAX(mh.tanggal) AS tanggal_terakhir
         FROM monitoring_harian mh
         JOIN sla_entries se ON se.id = mh.sla_entry_id
         WHERE se.kontrak_id=? AND se.ulp_id IS NULL AND mh.periode IS NOT NULL
         GROUP BY mh.periode", [$kontrak_id]);

    $out = [];
    foreach ($rows as $r) {
        $terisi = (int)$r['terisi'];
        $status = ($terisi >= $jumlahIndikator && $jumlahIndikator > 0) ? 'lengkap' : 'belum_lengkap';
        $out[(int)$r['periode']] = [
            'status' => $status, 'terisi' => $terisi, 'total' => $jumlahIndikator,
            'pertama_input' => $r['pertama_input'], 'terakhir_input' => $r['terakhir_input'],
            'tanggal_terakhir' => $r['tanggal_terakhir'],
        ];
    }
    return $out;
}

/**
 * Ambil ringkasan singkat sebuah kontrak untuk ditampilkan saat kontrak dibuka:
 * vendor, nilai kontrak, periode, jumlah indikator, total bobot, progress SLA,
 * dan status keseluruhan.
 */
function getRingkasanKontrak(PDO $db, int $kontrak_id): ?array {
    $kontrak = dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$kontrak_id]);
    if (!$kontrak) return null;
    $rekap = dbRow($db, "SELECT * FROM rekap_sla WHERE kontrak_id=?", [$kontrak_id]);

    $jumlahIndikator = (int)dbVal($db,
        "SELECT COUNT(*) FROM sla_entries WHERE kontrak_id=? AND ulp_id IS NULL", [$kontrak_id]);

    $progress = $rekap ? rekapOverallPct($rekap) : 0;

    if ($progress >= 90)      { $statusLabel = 'Sesuai SLA';      $statusCls = 'good'; }
    elseif ($progress >= 70)  { $statusLabel = 'Perlu Perhatian'; $statusCls = 'warn'; }
    else                      { $statusLabel = 'Tidak Tercapai';  $statusCls = 'bad';  }

    return [
        'vendor'            => $kontrak['vendor'] ?? '-',
        'nilai_kontrak'     => (float)($kontrak['nilai_tagihan_tahap1']??0) + (float)($kontrak['nilai_tagihan_tahap2']??0),
        'periode'           => trim(($kontrak['periode_bulan'] ?? '') . ' ' . ($kontrak['tahun'] ?? '') . ' - ' . ($kontrak['tahap'] ?? '')),
        'jumlah_indikator'  => $jumlahIndikator,
        'total_bobot'       => (float)($rekap['total_bobot'] ?? 0),
        'progress_sla'      => $progress,
        'status_label'      => $statusLabel,
        'status_class'      => $statusCls,
    ];
}
