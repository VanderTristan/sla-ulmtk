<?php
/**
 * includes/backup.php
 *
 * BACKUP DATABASE OTOMATIS — SLA PLN Nusa Daya
 * ------------------------------------------------------------
 * Membuat backup lengkap (struktur + isi tabel) database MySQL/MariaDB
 * aplikasi ini, disimpan sebagai file .sql (dikompresi .gz), dengan
 * retensi otomatis (file lama dihapus sesuai BACKUP_RETENTION_DAYS).
 *
 * Dipakai oleh:
 *   - backup_database.php  (dijalankan otomatis lewat cron)
 *   - backup.php            (halaman admin: backup manual + kelola file)
 *
 * Metode backup dipilih otomatis:
 *   1) mysqldump (lebih cepat & lengkap, termasuk routines/triggers) —
 *      dipakai jika binary tersedia dan exec() tidak dimatikan server.
 *   2) Fallback murni PHP (PDO) — dipakai kalau mysqldump/exec tidak
 *      tersedia, umum terjadi di shared hosting yang mematikan shell exec.
 *      Dengan begini backup tetap bisa jalan di hosting jenis apa pun.
 */

require_once __DIR__ . '/database.php';

define('BACKUP_DIR', __DIR__ . '/../storage/backup');

/** Berapa hari file backup disimpan sebelum dihapus otomatis (default 30 hari). Atur lewat .env: BACKUP_RETENTION_DAYS */
function backupRetentionDays(): int
{
    $v = getenv('BACKUP_RETENTION_DAYS');
    return ($v !== false && (int)$v > 0) ? (int)$v : 30;
}

/** Pastikan folder backup ada & terlindungi dari akses langsung lewat browser. */
function ensureBackupDir(): void
{
    if (!is_dir(BACKUP_DIR)) {
        mkdir(BACKUP_DIR, 0750, true);
    }
    $htaccess = BACKUP_DIR . '/.htaccess';
    if (!file_exists($htaccess)) {
        file_put_contents($htaccess, "Require all denied\n");
    }
    $indexGuard = BACKUP_DIR . '/index.php';
    if (!file_exists($indexGuard)) {
        file_put_contents($indexGuard, "<?php http_response_code(403); exit('Forbidden');\n");
    }
}

function backupLogPath(): string
{
    return BACKUP_DIR . '/backup.log';
}

function backupLog(string $msg): void
{
    ensureBackupDir();
    file_put_contents(backupLogPath(), '[' . date('Y-m-d H:i:s') . '] ' . $msg . PHP_EOL, FILE_APPEND | LOCK_EX);
}

/**
 * Buat satu file backup database (struktur + data), lalu kompresi & bersihkan file lama.
 * @return array{success:bool, file:?string, size:?int, method:string, message:string}
 */
function createDatabaseBackup(): array
{
    ensureBackupDir();

    $ts          = date('Ymd_His');
    $dbNameSafe  = preg_replace('/[^A-Za-z0-9_]/', '_', DB_NAME);
    $filenameSql = "backup_{$dbNameSafe}_{$ts}.sql";
    $pathSql     = BACKUP_DIR . '/' . $filenameSql;

    $method = 'php_native';
    $ok     = false;

    if (canUseMysqldump()) {
        $ok     = backupViaMysqldump($pathSql);
        $method = $ok ? 'mysqldump' : 'php_native';
    }
    if (!$ok) {
        $ok = backupViaPhpNative($pathSql);
    }

    if (!$ok || !file_exists($pathSql) || filesize($pathSql) === 0) {
        @unlink($pathSql);
        backupLog("GAGAL membuat backup (metode dicoba: $method).");
        return ['success' => false, 'file' => null, 'size' => null, 'method' => $method,
                 'message' => 'Gagal membuat file backup. Periksa hak akses folder storage/backup dan konfigurasi database.'];
    }

    $pathGz    = $pathSql . '.gz';
    $finalPath = $pathSql;
    if (gzipFile($pathSql, $pathGz)) {
        @unlink($pathSql);
        $finalPath = $pathGz;
    }

    $size = filesize($finalPath);
    backupLog('Backup berhasil: ' . basename($finalPath) . ' (' . formatUkuranBackup($size) . ", metode: $method)");

    $deleted = cleanupOldBackups();
    if ($deleted > 0) {
        backupLog("Retensi: $deleted file backup lama dihapus (lebih dari " . backupRetentionDays() . ' hari).');
    }

    return ['success' => true, 'file' => basename($finalPath), 'size' => $size, 'method' => $method,
             'message' => 'Backup berhasil dibuat.'];
}

/** Cek apakah mysqldump bisa dipakai di server ini (exec aktif & binary ditemukan). */
function canUseMysqldump(): bool
{
    if (!function_exists('exec')) return false;
    $disabled = array_map('trim', explode(',', (string)ini_get('disable_functions')));
    if (in_array('exec', $disabled, true)) return false;

    exec('command -v mysqldump 2>/dev/null', $out, $code);
    return $code === 0 && !empty($out);
}

/** Backup pakai binary mysqldump (metode utama, lebih cepat & lengkap). */
function backupViaMysqldump(string $pathSql): bool
{
    $host = escapeshellarg(DB_HOST);
    $port = escapeshellarg((string)DB_PORT);
    $user = escapeshellarg(DB_USER);
    $name = escapeshellarg(DB_NAME);

    // Password dikirim lewat environment variable MYSQL_PWD (bukan argumen CLI)
    // supaya tidak terlihat di daftar proses server (ps aux).
    putenv('MYSQL_PWD=' . DB_PASS);
    $cmd = "mysqldump --host=$host --port=$port --user=$user --single-transaction --routines --triggers --quick $name > "
         . escapeshellarg($pathSql) . ' 2>&1';
    exec($cmd, $out, $code);
    putenv('MYSQL_PWD'); // langsung hapus dari environment setelah dipakai

    return $code === 0;
}

/**
 * Backup murni PHP + PDO, tanpa bergantung pada binary mysqldump.
 * Otomatis dipakai sebagai fallback di hosting yang mematikan exec/shell_exec
 * (umum terjadi di shared hosting) supaya backup tetap bisa berjalan.
 */
function backupViaPhpNative(string $pathSql): bool
{
    $db = getDB();
    $fh = fopen($pathSql, 'w');
    if (!$fh) return false;

    fwrite($fh, "-- Backup database `" . DB_NAME . "` — SLA PLN Nusa Daya\n");
    fwrite($fh, '-- Dibuat otomatis: ' . date('Y-m-d H:i:s') . "\n");
    fwrite($fh, "-- Metode: PHP native (fallback tanpa mysqldump)\n\n");
    fwrite($fh, "SET FOREIGN_KEY_CHECKS=0;\nSET NAMES utf8mb4;\n\n");

    $tables = $db->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) {
        $tq = '`' . str_replace('`', '``', $table) . '`';

        $create    = $db->query("SHOW CREATE TABLE $tq")->fetch(PDO::FETCH_ASSOC);
        $createSql = $create['Create Table'] ?? null;
        if (!$createSql) continue;

        fwrite($fh, "-- --------------------------------------------------\n");
        fwrite($fh, "-- Struktur tabel `$table`\n");
        fwrite($fh, "-- --------------------------------------------------\n");
        fwrite($fh, "DROP TABLE IF EXISTS $tq;\n");
        fwrite($fh, $createSql . ";\n\n");

        $count = (int)$db->query("SELECT COUNT(*) FROM $tq")->fetchColumn();
        if ($count === 0) continue;

        fwrite($fh, "-- Data tabel `$table` ($count baris)\n");
        $columns = array_map(fn($c) => $c['Field'], $db->query("SHOW COLUMNS FROM $tq")->fetchAll(PDO::FETCH_ASSOC));
        $colList = '`' . implode('`,`', $columns) . '`';

        $chunkSize = 500;
        for ($offset = 0; $offset < $count; $offset += $chunkSize) {
            $rows = $db->query("SELECT * FROM $tq LIMIT $chunkSize OFFSET $offset")->fetchAll(PDO::FETCH_ASSOC);
            if (!$rows) break;

            $valueGroups = [];
            foreach ($rows as $row) {
                $vals = array_map(function ($v) use ($db) {
                    return $v === null ? 'NULL' : $db->quote((string)$v);
                }, array_values($row));
                $valueGroups[] = '(' . implode(',', $vals) . ')';
            }
            fwrite($fh, "INSERT INTO $tq ($colList) VALUES\n" . implode(",\n", $valueGroups) . ";\n");
        }
        fwrite($fh, "\n");
    }

    fwrite($fh, "SET FOREIGN_KEY_CHECKS=1;\n");
    fclose($fh);
    return true;
}

/** Kompresi file .sql menjadi .gz (hemat ruang penyimpanan). */
function gzipFile(string $src, string $dst): bool
{
    $in = @fopen($src, 'rb');
    if (!$in) return false;
    $out = @gzopen($dst, 'wb9');
    if (!$out) { fclose($in); return false; }

    while (!feof($in)) {
        gzwrite($out, fread($in, 512 * 1024));
    }
    fclose($in);
    gzclose($out);

    return file_exists($dst) && filesize($dst) > 0;
}

/** Hapus file backup yang lebih tua dari batas retensi. Return jumlah file yang dihapus. */
function cleanupOldBackups(): int
{
    ensureBackupDir();
    $limit   = time() - (backupRetentionDays() * 86400);
    $deleted = 0;
    foreach ((glob(BACKUP_DIR . '/backup_*.sql*') ?: []) as $file) {
        if (filemtime($file) < $limit) {
            @unlink($file);
            $deleted++;
        }
    }
    return $deleted;
}

/** Daftar semua file backup yang ada saat ini, terbaru lebih dulu. */
function listDatabaseBackups(): array
{
    ensureBackupDir();
    $result = [];
    foreach ((glob(BACKUP_DIR . '/backup_*.sql*') ?: []) as $f) {
        $result[] = ['name' => basename($f), 'size' => filesize($f), 'time' => filemtime($f)];
    }
    usort($result, fn($a, $b) => $b['time'] <=> $a['time']);
    return $result;
}

function formatUkuranBackup(int $bytes): string
{
    if ($bytes >= 1024 ** 3) return number_format($bytes / 1024 ** 3, 2) . ' GB';
    if ($bytes >= 1024 ** 2) return number_format($bytes / 1024 ** 2, 2) . ' MB';
    if ($bytes >= 1024)      return number_format($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

/** Validasi nama file backup (cegah path traversal) sebelum dipakai untuk unduh/hapus. */
function isValidBackupFilename(string $name): bool
{
    return (bool)preg_match('/^backup_[A-Za-z0-9_]+_\d{8}_\d{6}\.sql(\.gz)?$/', $name);
}

function backupFilePath(string $name): ?string
{
    if (!isValidBackupFilename($name)) return null;
    $path = BACKUP_DIR . '/' . $name;
    return file_exists($path) ? $path : null;
}

function deleteDatabaseBackup(string $name): bool
{
    $path = backupFilePath($name);
    if (!$path) return false;
    return @unlink($path);
}
