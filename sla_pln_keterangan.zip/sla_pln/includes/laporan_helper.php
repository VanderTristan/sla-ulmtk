<?php
/**
 * includes/laporan_helper.php — query & filter bersama untuk halaman
 * "Laporan SLA" (laporan.php) dan export-nya (laporan_export.php),
 * supaya tabel di layar, file Excel, dan hasil cetak PDF selalu sama.
 *
 * Filter sengaja dibuat sederhana: Tahun | Bulan | ULP | Indikator.
 */

const LAPORAN_BULAN = [1=>'JANUARI',2=>'FEBRUARI',3=>'MARET',4=>'APRIL',5=>'MEI',6=>'JUNI',
                       7=>'JULI',8=>'AGUSTUS',9=>'SEPTEMBER',10=>'OKTOBER',11=>'NOVEMBER',12=>'DESEMBER'];
const LAPORAN_MAX_BARIS = 3000;

/** Baca & validasi filter dari $_GET. Nilai kosong = "semua". */
function laporanFilter(): array {
    $bulan = strtoupper(trim((string)($_GET['bulan'] ?? '')));
    if (!in_array($bulan, LAPORAN_BULAN, true)) $bulan = '';
    $tahun = (int)($_GET['tahun'] ?? 0);
    if ($tahun < 2000 || $tahun > 2100) $tahun = 0;
    return [
        'tahun'     => $tahun,
        'bulan'     => $bulan,
        'ulp'       => trim((string)($_GET['ulp'] ?? '')),
        'indikator' => trim((string)($_GET['indikator'] ?? '')),
    ];
}

/** Pilihan untuk dropdown filter. */
function laporanOpsi(PDO $db): array {
    return [
        'tahun'     => array_column(dbAll($db, "SELECT DISTINCT tahun FROM kontrak WHERE tahun IS NOT NULL ORDER BY tahun DESC"), 'tahun'),
        'ulp'       => array_column(dbAll($db, "SELECT DISTINCT TRIM(nama_ulp) AS n FROM ulp WHERE nama_ulp IS NOT NULL AND TRIM(nama_ulp)<>'' ORDER BY n"), 'n'),
        'indikator' => array_column(dbAll($db, "SELECT DISTINCT kriteria FROM sla_entries WHERE ulp_id IS NOT NULL AND kriteria IS NOT NULL AND kriteria<>'' ORDER BY kriteria"), 'kriteria'),
    ];
}

/**
 * Ambil data laporan level ULP (satu baris = satu indikator di satu ULP).
 * Indikator yang realisasinya belum diisi (NULL) tetap tampil dengan status
 * "Belum diisi" — tidak dihitung sebagai gagal.
 */
function laporanRows(PDO $db, array $f, int $limit = LAPORAN_MAX_BARIS): array {
    $where = ["e.ulp_id IS NOT NULL"];
    $bind  = [];
    if ($f['tahun'])     { $where[] = "k.tahun = ?";                  $bind[] = $f['tahun']; }
    if ($f['bulan'])     { $where[] = "UPPER(k.periode_bulan) = ?";   $bind[] = $f['bulan']; }
    if ($f['ulp'] !== ''){ $where[] = "TRIM(u.nama_ulp) = ?";         $bind[] = $f['ulp']; }
    if ($f['indikator'] !== '') { $where[] = "e.kriteria = ?";        $bind[] = $f['indikator']; }

    $sql = "SELECT k.nama_kontrak, k.periode_bulan, k.tahun, u.nama_ulp,
                   e.kategori, e.ruang_lingkup, e.kriteria, e.satuan, e.polaritas,
                   e.target, e.realisasi, e.persen_pencapaian
            FROM sla_entries e
            JOIN ulp u     ON e.ulp_id = u.id
            JOIN kontrak k ON e.kontrak_id = k.id
            WHERE " . implode(' AND ', $where) . "
            ORDER BY k.tahun DESC,
                     FIELD(UPPER(k.periode_bulan),'JANUARI','FEBRUARI','MARET','APRIL','MEI','JUNI','JULI','AGUSTUS','SEPTEMBER','OKTOBER','NOVEMBER','DESEMBER') DESC,
                     k.nama_kontrak, u.nama_ulp, e.kategori, e.no_urut
            LIMIT " . (int)$limit;
    return dbAll($db, $sql, $bind);
}

/** Teks status untuk satu baris laporan. */
function laporanStatus(?float $pct): string {
    if ($pct === null) return 'Belum diisi';
    return $pct >= 100 ? 'Tercapai' : 'Belum tercapai';
}

/** Ringkasan filter aktif sebagai teks (untuk judul cetak / sheet Excel). */
function laporanFilterLabel(array $f): string {
    $p = [];
    if ($f['tahun'])         $p[] = 'Tahun ' . $f['tahun'];
    if ($f['bulan'])         $p[] = 'Bulan ' . ucwords(strtolower($f['bulan']));
    if ($f['ulp'] !== '')    $p[] = 'ULP ' . $f['ulp'];
    if ($f['indikator'] !== '') $p[] = 'Indikator ' . $f['indikator'];
    return $p ? implode(' • ', $p) : 'Semua data';
}
