<?php
/**
 * includes/mailer.php
 *
 * Modul pengiriman email — dipakai untuk 3 notifikasi:
 *   1. Ke Manager UL / Team Leader saat ada data monitoring harian baru yang menunggu verifikasi.
 *   2. Ke Petugas saat data monitoring hariannya Disetujui / Ditolak oleh Manager UL.
 *   3. Reset password lewat link email (lihat forgot-password.php & reset-password.php).
 *
 * Konfigurasi SMTP diambil dari file .env (lihat .env.example bagian EMAIL / SMTP).
 * Kalau MAIL_ENABLED kosong/"0" atau konfigurasi SMTP belum diisi, pengiriman email
 * di-skip secara diam-diam (tidak melempar error) supaya fitur lain di aplikasi tetap
 * berjalan normal walau email belum dikonfigurasi oleh admin.
 */

require_once __DIR__ . '/../vendor/phpmailer/phpmailer/src/Exception.php';
require_once __DIR__ . '/../vendor/phpmailer/phpmailer/src/PHPMailer.php';
require_once __DIR__ . '/../vendor/phpmailer/phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

/** Apakah fitur email aktif & sudah dikonfigurasi lengkap di .env? */
function mailAktif(): bool
{
    return (getenv('MAIL_ENABLED') === '1')
        && getenv('MAIL_HOST')
        && getenv('MAIL_USERNAME')
        && getenv('MAIL_PASSWORD')
        && getenv('MAIL_FROM_EMAIL');
}

/**
 * Kirim satu email lewat SMTP (PHPMailer).
 * Selalu aman dipanggil: kalau gagal (SMTP belum dikonfigurasi, server down, dll),
 * fungsi ini hanya mencatat ke error log PHP dan mengembalikan false —
 * TIDAK PERNAH menghentikan alur aplikasi (input/dll tetap tersimpan).
 *
 * @param string $toEmail
 * @param string $toName
 * @param string $subject
 * @param string $htmlBody   Isi email dalam HTML sederhana
 */
function kirimEmail(string $toEmail, string $toName, string $subject, string $htmlBody): bool
{
    if (!mailAktif()) {
        return false;
    }
    if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
        error_log("kirimEmail: alamat tujuan tidak valid ($toEmail), dilewati.");
        return false;
    }

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = getenv('MAIL_HOST');
        $mail->SMTPAuth   = true;
        $mail->Username   = getenv('MAIL_USERNAME');
        $mail->Password   = getenv('MAIL_PASSWORD');
        $secure = strtolower(getenv('MAIL_ENCRYPTION') ?: 'tls');
        if ($secure === 'ssl') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        } else {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        }
        $mail->Port       = (int)(getenv('MAIL_PORT') ?: 587);
        $mail->CharSet    = 'UTF-8';
        $mail->Timeout    = 10;

        $mail->setFrom(getenv('MAIL_FROM_EMAIL'), getenv('MAIL_FROM_NAME') ?: 'SLA Monitoring PLN Nusa Daya');
        $mail->addAddress($toEmail, $toName);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $htmlBody;
        $mail->AltBody  = strip_tags(str_replace(['<br>', '<br/>', '<br />'], "\n", $htmlBody));

        $mail->send();
        return true;
    } catch (PHPMailerException $e) {
        error_log('kirimEmail gagal: ' . $mail->ErrorInfo);
        return false;
    } catch (Throwable $e) {
        error_log('kirimEmail gagal: ' . $e->getMessage());
        return false;
    }
}

/** Bungkus isi email dengan template HTML sederhana & konsisten (header/footer) supaya rapi di inbox. */
function templateEmail(string $judul, string $isiHtml): string
{
    $tahun = date('Y');
    return '
    <div style="font-family:Segoe UI,Arial,sans-serif;max-width:600px;margin:0 auto;background:#f4f6f8;padding:24px;">
        <div style="background:#ffffff;border-radius:8px;overflow:hidden;border:1px solid #e2e8f0;">
            <div style="background:#0a3d62;padding:18px 24px;">
                <span style="color:#ffffff;font-size:16px;font-weight:700;">⚡ SLA Monitoring — PLN Nusa Daya</span>
            </div>
            <div style="padding:24px;color:#1f2937;font-size:14px;line-height:1.6;">
                <h2 style="margin-top:0;font-size:17px;color:#0a3d62;">' . htmlspecialchars($judul) . '</h2>
                ' . $isiHtml . '
            </div>
            <div style="padding:14px 24px;background:#f8fafc;border-top:1px solid #e2e8f0;font-size:11px;color:#94a3b8;">
                Email ini dikirim otomatis oleh sistem SLA Monitoring PLN Nusa Daya. Mohon tidak membalas email ini.
                &copy; ' . $tahun . ' PT PLN Nusa Daya.
            </div>
        </div>
    </div>';
}

// =====================================================================
//  RESET PASSWORD LEWAT EMAIL
// =====================================================================

function kirimEmailResetPassword(string $toEmail, string $toName, string $token): bool
{
    $link = baseUrlAplikasi() . '/reset-password.php?token=' . urlencode($token);
    $isi = '
        <p>Halo ' . htmlspecialchars($toName) . ',</p>
        <p>Kami menerima permintaan untuk mengatur ulang password akun Anda di sistem SLA Monitoring PLN Nusa Daya.</p>
        <p style="margin-top:20px;"><a href="' . htmlspecialchars($link) . '" style="background:#0a3d62;color:#ffffff;padding:10px 18px;border-radius:6px;text-decoration:none;font-weight:600;">Atur Ulang Password</a></p>
        <p style="margin-top:16px;font-size:12px;color:#64748b;">Link ini hanya berlaku selama 60 menit. Kalau Anda tidak merasa meminta reset password, abaikan saja email ini — password Anda tidak akan berubah.</p>';
    $html = templateEmail('🔑 Reset Password', $isi);
    return kirimEmail($toEmail, $toName, '[SLA Monitoring] Permintaan Reset Password', $html);
}

/**
 * Base URL aplikasi (tanpa trailing slash), dipakai untuk membuat link di dalam email.
 * Diambil dari APP_URL di .env kalau diisi; kalau kosong, dideteksi otomatis dari request saat ini.
 */
function baseUrlAplikasi(): string
{
    $fromEnv = getenv('APP_URL');
    if ($fromEnv) return rtrim($fromEnv, '/');

    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $scheme = $isHttps ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
    return "$scheme://$host$dir";
}
