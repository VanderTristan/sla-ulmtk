<?php
/**
 * includes/auth.php
 *
 * Fungsi autentikasi & session — disalin dari project sla-app(3)
 * agar perilaku login pada sla_pln identik.
 */

// ------------------------------------------------------------
//  KONFIGURASI ENVIRONMENT (production-safe defaults)
//  APP_ENV diisi lewat .env: 'production' atau 'development'
// ------------------------------------------------------------
if (!defined('APP_ENV')) {
    define('APP_ENV', getenv('APP_ENV') ?: 'production');
}
if (APP_ENV === 'production') {
    error_reporting(E_ALL);
    ini_set('display_errors', '0');   // jangan tampilkan error ke browser
    ini_set('log_errors', '1');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
}

// ------------------------------------------------------------
//  HARDENING SESSION COOKIE — harus diset SEBELUM session_start()
// ------------------------------------------------------------
if (session_status() === PHP_SESSION_NONE) {
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $isHttps,   // hanya kirim cookie via HTTPS jika sudah HTTPS
        'httponly' => true,       // cookie tidak bisa diakses JavaScript (mitigasi XSS)
        'samesite' => 'Lax',      // mitigasi CSRF lintas situs
    ]);
    session_start();
}

// ------------------------------------------------------------
//  ESCAPE OUTPUT
// ------------------------------------------------------------
if (!function_exists('h')) {
    function h(?string $str): string
    {
        return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
    }
}

// ------------------------------------------------------------
//  CSRF PROTECTION
//  Setiap form POST & aksi hapus (link GET) wajib menyertakan token ini.
// ------------------------------------------------------------
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** Cetak hidden input CSRF — panggil di dalam <form> */
function csrfField(): string
{
    return '<input type="hidden" name="csrf_token" value="' . h(csrfToken()) . '">';
}

/** Tambahkan token CSRF ke URL aksi (untuk link GET seperti hapus) */
function csrfUrl(string $url): string
{
    $sep = str_contains($url, '?') ? '&' : '?';
    return $url . $sep . 'csrf_token=' . urlencode(csrfToken());
}

/**
 * Validasi token CSRF dari POST atau GET. Hentikan eksekusi jika tidak valid.
 * Panggil di baris paling atas SETIAP blok yang mengubah data (create/update/delete).
 */
function csrfVerify(): void
{
    $token = $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
    if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        die('Permintaan ditolak: token keamanan (CSRF) tidak valid atau kedaluwarsa. Silakan muat ulang halaman dan coba lagi.');
    }
}

// ------------------------------------------------------------
//  FLASH MESSAGE (pesan notifikasi antar-halaman via session)
// ------------------------------------------------------------
function setFlash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash(): ?array
{
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Render satu flash message dengan tampilan seragam di semua halaman:
 * ikon sesuai tipe, tombol tutup, dan (untuk success/info) hilang otomatis
 * lewat script di includes/footer.php. Tipe di luar success/danger/warning/info
 * dianggap info.
 */
function renderFlash(?array $flash, string $style = ''): string
{
    if (!$flash || ($flash['message'] ?? '') === '') return '';
    $type = in_array($flash['type'] ?? '', ['success', 'danger', 'warning', 'info'], true) ? $flash['type'] : 'info';
    $icon = [
        'success' => 'bi-check-circle-fill',
        'danger'  => 'bi-x-octagon-fill',
        'warning' => 'bi-exclamation-triangle-fill',
        'info'    => 'bi-info-circle-fill',
    ][$type];
    $auto = in_array($type, ['success', 'info'], true) ? ' data-autohide="6000"' : '';
    return '<div class="alert alert-' . $type . ' alert-flash" role="alert"' . $auto
         . ($style !== '' ? ' style="' . htmlspecialchars($style, ENT_QUOTES, 'UTF-8') . '"' : '') . '>'
         . '<i class="bi ' . $icon . '"></i>'
         . '<div class="alert-flash-text">' . htmlspecialchars((string)$flash['message'], ENT_QUOTES, 'UTF-8') . '</div>'
         . '<button type="button" class="alert-close" aria-label="Tutup" onclick="this.parentNode.remove()">&times;</button>'
         . '</div>';
}

// ------------------------------------------------------------
//  AUTENTIKASI / LOGIN GUARD
// ------------------------------------------------------------
function isLoggedIn(): bool
{
    return !empty($_SESSION['user']);
}

function currentUser(): ?array
{
    return $_SESSION['user'] ?? null;
}

/**
 * Panggil di paling atas setiap halaman/aksi yang wajib login.
 * Jika belum login, redirect ke login.php (menyimpan URL tujuan
 * supaya setelah login user diarahkan balik ke halaman semula).
 */
function requireLogin(): void
{
    if (!isLoggedIn()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'] ?? 'index.php';
        header('Location: login.php');
        exit;
    }
}

function isSuperAdmin(): bool
{
    $user = currentUser();
    return isset($user['role']) && $user['role'] === 'SuperAdmin';
}

/**
 * isAdmin() = hak akses penuh (kelola user, backup, audit log, kelola
 * kendaraan/personil). Sejak role Super Admin ditambahkan, hak ini HANYA
 * milik Super Admin — Team Leader (role DB 'Admin') tidak lagi otomatis
 * mendapatkannya (lihat isTeamLeader() & isSupervisor() di bawah).
 */
function isAdmin(): bool
{
    return isSuperAdmin();
}

/** Role DB 'Admin', label tampilan "Team Leader". */
function isTeamLeader(): bool
{
    $user = currentUser();
    return isset($user['role']) && $user['role'] === 'Admin';
}

function isMonitoring(): bool
{
    $user = currentUser();
    return isset($user['role']) && $user['role'] === 'Monitoring';
}

function isViewer(): bool
{
    $user = currentUser();
    return isset($user['role']) && $user['role'] === 'Viewer';
}

function isKoordinator(): bool
{
    $user = currentUser();
    return isset($user['role']) && $user['role'] === 'Koordinator';
}

// Alias yang lebih jelas sesuai peran bisnis (nilai mentah di database TETAP
// 'SuperAdmin' / 'Admin' / 'Monitoring' / 'Viewer' / 'Koordinator' — hanya
// nama & labelnya yang berubah):
//   SuperAdmin  -> Super Admin  (akses penuh ke semua fitur, termasuk kelola user)
//   Admin       -> Team Leader  (sekarang PERSIS seperti Manager UL: hanya melihat laporan)
//   Monitoring  -> Manager UL   (hanya boleh melihat laporan)
//   Viewer      -> Admin        (petugas, hanya boleh menginput data)
//   Koordinator -> Koordinator  (peran sama seperti Viewer di atas, hanya boleh menginput data)
// Team Leader digabung ke isSupervisor() supaya seluruh pembatasan yang
// berlaku untuk Manager UL otomatis berlaku juga untuk Team Leader.
function isSupervisor(): bool { return isMonitoring() || isTeamLeader(); }
function isPetugas(): bool { return isViewer() || isKoordinator(); }

/** Label tampilan untuk role. Nilai mentah di DB tidak berubah. */
function roleLabel(?string $role): string
{
    switch ($role) {
        case 'SuperAdmin':  return 'Super Admin';
        case 'Admin':       return 'Team Leader';
        case 'Monitoring':  return 'Manager UL';
        case 'Viewer':      return 'Admin';
        case 'Koordinator': return 'Koordinator';
        default:            return $role ?? '-';
    }
}

function requireAdmin(): void
{
    requireLogin();
    if (!isAdmin()) {
        setFlash('danger', 'Akses ditolak. Halaman ini hanya untuk Super Admin.');
        header('Location: index.php');
        exit;
    }
}

/**
 * Halaman DATA KENDARAAN & DATA PERSONIL.
 * Super Admin boleh kelola penuh (tambah/edit/hapus).
 * Team Leader (Admin) dan Manager UL (Monitoring) hanya boleh melihat
 * (read-only), tidak boleh ubah data — perilaku Team Leader sekarang
 * disamakan dengan Manager UL.
 * Role lain tidak boleh akses.
 */
function canManageKendaraanPersonil(): bool
{
    return isSuperAdmin();
}

function requireKendaraanPersonilAccess(): void
{
    requireLogin();
    if (!isSuperAdmin() && !isSupervisor()) {
        setFlash('danger', 'Akses ditolak. Halaman ini hanya untuk Super Admin, Team Leader, dan Manager UL.');
        header('Location: index.php');
        exit;
    }
}

/**
 * Halaman DATA ULP (Unit Layanan Pelanggan).
 * Super Admin dan Petugas (Viewer/Koordinator) boleh kelola penuh
 * (tambah/edit/hapus ULP, input SLA per ULP).
 * Team Leader (Admin) dan Manager UL (Monitoring) hanya boleh melihat
 * (read-only) — perilaku Team Leader sekarang disamakan dengan Manager UL.
 */
function canManageUlp(): bool
{
    return !isSupervisor();
}

function requireUlpAccess(): void
{
    // Semua role yang sudah login boleh melihat data ULP.
    // Pembatasan tambah/ubah/hapus dilakukan di halaman masing-masing lewat canManageUlp().
    requireLogin();
}

/**
 * Halaman INPUT DATA (Data Kontrak, Input Monitoring Harian, Data ULP).
 * Supervisor (Team Leader & Manager UL) hanya boleh melihat laporan,
 * tidak boleh menginput data.
 */
function requireInputAccess(): void
{
    requireLogin();
    if (isSupervisor()) {
        setFlash('danger', 'Akses ditolak. Role Team Leader/Manager UL hanya dapat melihat laporan, tidak dapat menginput/mengubah data.');
        header('Location: index.php');
        exit;
    }
}


/**
 * Halaman LAPORAN (Rekap SLA, Rata-Rata SLA, Cetak Laporan).
 * User/Petugas (Viewer) hanya boleh menginput data, tidak boleh melihat laporan.
 */
function requireReportAccess(): void
{
    requireLogin();
    if (isPetugas()) {
        setFlash('danger', 'Akses ditolak. Role Admin/Koordinator hanya dapat menginput data, tidak dapat melihat laporan.');
        header('Location: index.php');
        exit;
    }
}

// ------------------------------------------------------------
//  FORMAT TANGGAL LENGKAP (gaya Indonesia, dipakai di topbar)
// ------------------------------------------------------------
const BULAN_PANJANG_ID_AUTH = [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
const HARI_ID_AUTH = [0=>'Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];

if (!function_exists('formatTanggalLengkap')) {
    function formatTanggalLengkap(?int $timestamp = null): string
    {
        $ts = $timestamp ?? time();
        $hari  = HARI_ID_AUTH[(int)date('w', $ts)];
        $bulan = BULAN_PANJANG_ID_AUTH[(int)date('n', $ts)];
        return $hari . ', ' . date('d', $ts) . ' ' . $bulan . ' ' . date('Y', $ts);
    }
}
