<?php
/**
 * includes/kontrak_selector.php
 *
 * Cara mencari kontrak yang SAMA di semua halaman (mengikuti halaman Input SLA):
 *   Pilih Bidang -> Pilih Project -> SEMUA kontrak di Project itu langsung
 *   muncul sebagai daftar. Filter Bulan & Tahun hanyalah filter biasa di atas
 *   daftar tersebut (langsung menyaring tanpa memuat ulang halaman), dipakai
 *   kalau perlu mencari kontrak tertentu. Klik tombol di baris untuk membukanya.
 *
 * Dipakai oleh: rekap_sla, detail_perhitungan, rata_rata, cetak, input_ulp,
 * kendaraan, personil. (Halaman Data Kontrak sengaja tidak memakai ini.)
 *
 * Pemakaian di halaman:
 *   require_once 'includes/kontrak_selector.php';
 *   $sel = kontrakSelectorInit($db, $kontrak_id);          // sebelum include header
 *   ...
 *   renderKontrakSelectorFields($sel, 'halaman.php', [...]); // di dalam card filter
 *   renderKontrakListCard($sel, 'halaman.php', [...]);       // setelah card filter
 *
 * Opsi umum ($o):
 *   extra         array  parameter tambahan yang ikut terbawa di semua link (mis. ['tipe'=>'bulanan'])
 *   bidangAll     string label opsi "belum pilih bidang"
 *   btnLabel      string teks tombol di daftar kontrak
 */

const KS_BULAN = ['JANUARI','FEBRUARI','MARET','APRIL','MEI','JUNI','JULI','AGUSTUS','SEPTEMBER','OKTOBER','NOVEMBER','DESEMBER'];

/** Potongan WHERE untuk "kontrak milik Project terpilih" (unit_id angka, atau 'none' = tanpa Project). */
function ksUnitWhere(string $jenis, string $unit, array &$params): string {
    if ($unit === 'none') {
        $w = "unit_id IS NULL";
        if ($jenis === 'DISTRIBUSI') {
            $w .= " AND (jenis_kontrak = 'DISTRIBUSI' OR jenis_kontrak IS NULL OR jenis_kontrak = '')";
        } elseif ($jenis !== 'ALL') {
            $w .= " AND jenis_kontrak = ?";
            $params[] = $jenis;
        }
        return $w;
    }
    $params[] = (int)$unit;
    return "unit_id = ?";
}

function kontrakSelectorInit(PDO $db, int $kontrak_id = 0, array $o = []): array {
    $jenis = strtoupper(trim($_GET['jenis'] ?? 'ALL'));
    if (!in_array($jenis, ['ALL', 'DISTRIBUSI', 'TRANSMISI', 'PEMBANGKIT'], true)) $jenis = 'ALL';
    $unit  = trim($_GET['unit_id'] ?? '');

    // Kalau halaman dibuka dengan kontrak_id (mis. dari link di halaman lain),
    // Bidang/Project otomatis disesuaikan dengan kontrak itu.
    $kontrak = null;
    if ($kontrak_id) {
        $kontrak = dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$kontrak_id]);
        if ($kontrak) {
            $uid = $kontrak['unit_id'] ?? null;
            $jenisUnit = $uid ? dbVal($db, "SELECT jenis_kontrak FROM unit_kerja WHERE id=?", [(int)$uid]) : null;
            $jenis = strtoupper(trim((string)($jenisUnit ?: ($kontrak['jenis_kontrak'] ?: 'DISTRIBUSI'))));
            if (!in_array($jenis, ['DISTRIBUSI', 'TRANSMISI', 'PEMBANGKIT'], true)) $jenis = 'DISTRIBUSI';
            $unit  = $uid ? (string)(int)$uid : 'none';
        }
    }

    if ($jenis === 'ALL') $unit = '';
    $unitOptions = ($jenis !== 'ALL') ? getUnitKerjaList($db, $jenis) : [];

    // Opsi "Tanpa Project" hanya muncul kalau memang ada kontrak yang belum punya Project di bidang ini.
    $adaTanpaUnit = false;
    if ($jenis !== 'ALL') {
        $p = [];
        $w = ksUnitWhere($jenis, 'none', $p);
        $adaTanpaUnit = (int)dbVal($db, "SELECT COUNT(*) FROM kontrak WHERE $w", $p) > 0;
    }
    if ($unit !== '' && $unit !== 'none') {
        $valid = array_map('strval', array_column($unitOptions, 'id'));
        if (!in_array($unit, $valid, true)) $unit = '';
    }
    if ($unit === 'none' && !$adaTanpaUnit) $unit = '';

    $unitTerpilih = null;
    foreach ($unitOptions as $u) { if ((string)$u['id'] === $unit) { $unitTerpilih = $u; break; } }

    // Semua kontrak di Project terpilih (tanpa disaring; Bulan/Tahun disaring di sisi tampilan).
    $list = [];
    if ($unit !== '' && !$kontrak) {
        $p = [];
        $w = ksUnitWhere($jenis, $unit, $p);
        $list = dbAll($db, "SELECT * FROM kontrak WHERE $w
            ORDER BY tahun DESC, FIELD(UPPER(periode_bulan),'" . implode("','", KS_BULAN) . "') DESC, tahap, id", $p);
        foreach ($list as $i => $kk) {
            $list[$i]['_ringkasan'] = getRingkasanKontrak($db, (int)$kk['id']);
        }
    }

    return [
        'jenis' => $jenis, 'unit' => $unit,
        'unitOptions' => $unitOptions, 'unitTerpilih' => $unitTerpilih, 'adaTanpaUnit' => $adaTanpaUnit,
        'kontrak' => $kontrak, 'kontrak_id' => $kontrak ? (int)$kontrak['id'] : 0,
        'list' => $list,
    ];
}

/** URL "halaman?param=..&key=" (diakhiri key= supaya nilai dropdown tinggal ditempel di JS). */
function ksUrl(string $page, array $extra, array $params, string $lastKey): string {
    $params = array_filter($params, fn($v) => $v !== '' && $v !== 0 && $v !== null && $v !== 'ALL');
    $q = http_build_query(array_merge($extra, $params));
    return $page . '?' . $q . ($q !== '' ? '&' : '') . $lastKey . '=';
}

/** URL lengkap tanpa key penutup, mis. "halaman?jenis=X&unit_id=1". */
function ksUrlPlain(string $page, array $extra, array $params): string {
    $params = array_filter($params, fn($v) => $v !== '' && $v !== 0 && $v !== null && $v !== 'ALL');
    $q = http_build_query(array_merge($extra, $params));
    return $page . ($q !== '' ? '?' . $q : '');
}

function ksOnchange(string $url): string {
    return 'location.href=' . htmlspecialchars(json_encode($url), ENT_QUOTES) . '+encodeURIComponent(this.value)';
}

function renderKontrakSelectorFields(array $sel, string $page, array $o = []): void {
    $extra = $o['extra'] ?? [];
    $bidangAll = $o['bidangAll'] ?? '-- Pilih Bidang --';
    $jenis = $sel['jenis']; $unit = $sel['unit'];
    $h = fn($s) => htmlspecialchars((string)$s);
    ?>
    <div class="form-grid" style="grid-template-columns:repeat(auto-fit,minmax(170px,1fr));">
        <div class="form-group">
            <label>Pilih Bidang</label>
            <select class="form-control" onchange="<?= ksOnchange(ksUrl($page, $extra, [], 'jenis')) ?>">
                <option value="ALL" <?= $jenis === 'ALL' ? 'selected' : '' ?>><?= $h($bidangAll) ?></option>
                <option value="DISTRIBUSI" <?= $jenis === 'DISTRIBUSI' ? 'selected' : '' ?>>Distribusi</option>
                <option value="TRANSMISI" <?= $jenis === 'TRANSMISI' ? 'selected' : '' ?>>Transmisi</option>
                <option value="PEMBANGKIT" <?= $jenis === 'PEMBANGKIT' ? 'selected' : '' ?>>Pembangkit</option>
            </select>
        </div>
        <div class="form-group">
            <label>Pilih Project</label>
            <?php if ($jenis === 'ALL'): ?>
            <select class="form-control" disabled style="background:#f1f5f9;cursor:not-allowed;color:#94a3b8;">
                <option>-- Pilih Bidang terlebih dahulu --</option>
            </select>
            <?php else: ?>
            <select class="form-control" onchange="<?= ksOnchange(ksUrl($page, $extra, ['jenis' => $jenis], 'unit_id')) ?>">
                <option value="">-- Pilih Project --</option>
                <?php foreach ($sel['unitOptions'] as $u): ?>
                <option value="<?= (int)$u['id'] ?>" <?= $unit === (string)$u['id'] ? 'selected' : '' ?>><?= $h($u['nama']) ?></option>
                <?php endforeach; ?>
                <?php if ($sel['adaTanpaUnit']): ?>
                <option value="none" <?= $unit === 'none' ? 'selected' : '' ?>>Belum Ditentukan / Tanpa Project</option>
                <?php endif; ?>
                <?php if (empty($sel['unitOptions']) && !$sel['adaTanpaUnit']): ?>
                <option value="" disabled>Belum ada Project untuk bidang ini</option>
                <?php endif; ?>
            </select>
            <div style="font-size:11px;color:var(--text-light);margin-top:4px;">Kelola daftar Project di menu <a href="unit_kerja.php" target="_blank">Kelola Project</a>.</div>
            <?php endif; ?>
        </div>
    </div>
    <?php if ($sel['kontrak']): ?>
    <div style="font-size:12px;color:var(--text-light);margin-top:8px;">
        Kontrak: <b><?= $h($sel['kontrak']['nama_kontrak'] ?: '-') ?></b>
        — <a href="<?= $h(ksUrlPlain($page, $extra, ['jenis' => $jenis, 'unit_id' => $unit])) ?>">← Semua kontrak Project ini</a>
    </div>
    <?php endif;
}

function renderKontrakListCard(array $sel, string $page, array $o = []): void {
    if ($sel['unit'] === '' || $sel['kontrak']) return;
    $extra = $o['extra'] ?? [];
    $btn = $o['btnLabel'] ?? 'Pilih';
    $list = $sel['list'];
    $badge = ['good' => 'badge-success', 'warn' => 'badge-warning', 'bad' => 'badge-danger'];
    $h = fn($s) => htmlspecialchars((string)$s);

    // Pilihan filter diambil dari kontrak yang benar-benar ada di Project ini.
    $bulanAda = []; $tahunAda = [];
    foreach ($list as $kk) {
        $b = strtoupper((string)($kk['periode_bulan'] ?? ''));
        if (in_array($b, KS_BULAN, true)) $bulanAda[$b] = true;
        if (!empty($kk['tahun'])) $tahunAda[(int)$kk['tahun']] = true;
    }
    $bulanOpts = array_values(array_filter(KS_BULAN, fn($b) => isset($bulanAda[$b])));
    $tahunOpts = array_keys($tahunAda); rsort($tahunOpts);
    ?>
<div class="card no-print" id="ksListCard">
    <div class="card-header">
        <div>
            <div class="card-title">📄 Daftar Kontrak<?= $sel['unitTerpilih'] ? ' — ' . $h($sel['unitTerpilih']['nama']) : '' ?></div>
            <div class="card-subtitle">
                <span id="ksCount"><?= count($list) ?></span> kontrak<span id="ksCountNote"></span>.
                Klik <b><?= $h($btn) ?></b> pada kontrak yang ingin dibuka.
            </div>
        </div>
    </div>
    <?php if (empty($list)): ?>
    <div class="card-body">
        <div class="alert alert-warning" style="margin:0;">
            Belum ada kontrak di Project ini. <?= isSuperAdmin() ? 'Buat kontraknya di <a href="kontrak.php" target="_blank">Data Kontrak</a>.' : 'Hubungi Super Admin untuk menambahkan kontrak.' ?>
        </div>
    </div>
    <?php else: ?>
    <div class="card-body" style="padding-bottom:0;">
        <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
            <span style="font-size:12px;color:var(--text-light);align-self:center;">🔎 Cari kontrak:</span>
            <div class="form-group" style="margin:0;min-width:150px;">
                <select class="form-control" id="ksFilterBulan" aria-label="Filter Bulan">
                    <option value="">Semua Bulan</option>
                    <?php foreach ($bulanOpts as $b): ?><option value="<?= $b ?>"><?= $h(ucfirst(strtolower($b))) ?></option><?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="margin:0;min-width:120px;">
                <select class="form-control" id="ksFilterTahun" aria-label="Filter Tahun">
                    <option value="">Semua Tahun</option>
                    <?php foreach ($tahunOpts as $t): ?><option value="<?= (int)$t ?>"><?= (int)$t ?></option><?php endforeach; ?>
                </select>
            </div>
            <button type="button" class="btn btn-outline btn-sm" id="ksFilterReset" style="display:none;">Reset filter</button>
        </div>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr><th>Periode</th><th>Nama Kontrak</th><th>Tahap</th><th>Vendor</th><th>Progress SLA</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($list as $kk): $rk = $kk['_ringkasan'] ?? null; ?>
                <tr class="ks-row" data-bulan="<?= $h(strtoupper((string)($kk['periode_bulan'] ?? ''))) ?>" data-tahun="<?= (int)($kk['tahun'] ?? 0) ?>">
                    <td style="white-space:nowrap;"><b><?= $h(ucfirst(strtolower((string)($kk['periode_bulan'] ?? '-')))) ?> <?= $h($kk['tahun'] ?? '') ?></b></td>
                    <td style="font-size:12px;max-width:380px;">
                        <?= $h($kk['nama_kontrak'] ?: '-') ?>
                        <?php if (!empty($kk['no_kontrak_1'])): ?><br><span style="color:var(--text-light);font-size:11px;"><?= $h($kk['no_kontrak_1']) ?></span><?php endif; ?>
                    </td>
                    <td style="white-space:nowrap;"><?= $h($kk['tahap'] ?: '-') ?></td>
                    <td style="font-size:12px;"><?= $h($kk['vendor'] ?: '-') ?></td>
                    <td style="white-space:nowrap;"><?= $rk ? number_format($rk['progress_sla'], 2) . '%' : '—' ?></td>
                    <td><?php if ($rk): ?><span class="badge <?= $badge[$rk['status_class']] ?? 'badge-info' ?>"><?= $h($rk['status_label']) ?></span><?php else: ?>—<?php endif; ?></td>
                    <td style="text-align:right;white-space:nowrap;">
                        <a href="<?= $h(ksUrl($page, $extra, ['jenis' => $sel['jenis'], 'unit_id' => $sel['unit']], 'kontrak_id') . (int)$kk['id']) ?>" class="btn btn-primary btn-sm"><?= $h($btn) ?></a>
                    </td>
                </tr>
            <?php endforeach; ?>
                <tr id="ksEmptyRow" style="display:none;">
                    <td colspan="7" style="text-align:center;color:var(--text-light);padding:18px;">Tidak ada kontrak yang cocok dengan filter. Ubah atau reset filter Bulan/Tahun.</td>
                </tr>
            </tbody>
        </table>
    </div>
    <script>
    (function () {
        var fb = document.getElementById('ksFilterBulan'), ft = document.getElementById('ksFilterTahun');
        var rs = document.getElementById('ksFilterReset'), cnt = document.getElementById('ksCount');
        var note = document.getElementById('ksCountNote'), empty = document.getElementById('ksEmptyRow');
        var rows = document.querySelectorAll('#ksListCard .ks-row');
        function apply() {
            var b = fb.value, t = ft.value, n = 0;
            rows.forEach(function (r) {
                var ok = (!b || r.dataset.bulan === b) && (!t || r.dataset.tahun === t);
                r.style.display = ok ? '' : 'none';
                if (ok) n++;
            });
            cnt.textContent = n;
            note.textContent = (b || t) ? ' ditemukan (sesuai filter)' : ' ditemukan';
            empty.style.display = n ? 'none' : '';
            rs.style.display = (b || t) ? '' : 'none';
        }
        fb.addEventListener('change', apply);
        ft.addEventListener('change', apply);
        rs.addEventListener('click', function () { fb.value = ''; ft.value = ''; apply(); });
        apply();
    })();
    </script>
    <?php endif; ?>
</div>
    <?php
}
