<?php
/**
 * includes/header.php
 *
 * Variabel yang harus disiapkan SEBELUM include file ini:
 *   $title   (string) judul halaman, tampil di topbar & <title>
 *             (dipakai oleh halaman-halaman modul SLA yang sudah ada)
 */
require_once __DIR__ . '/auth.php';
requireLogin();

$pageTitle  = $title ?? 'Dashboard';
$flash      = getFlash();
$activePage = basename($_SERVER['PHP_SELF']);

$loggedUser  = currentUser();
$userFoto    = $loggedUser['foto'] ?? null;
// Foto profil hanya dipakai kalau filenya benar-benar ada di server; kalau
// tidak (folder avatars kosong / file terhapus) tampilkan inisial, bukan gambar pecah.
if ($userFoto) {
    $__fotoFile = __DIR__ . '/../' . ltrim($userFoto, '/');
    if (!is_file($__fotoFile)) $userFoto = null;
}
$userInisial = mb_strtoupper(mb_substr($loggedUser['nama'] ?? 'U', 0, 1));
$roleBadgeClass = match($loggedUser['role'] ?? '') {
    'SuperAdmin' => 'role-superadmin',
    'Admin'      => 'role-admin',
    'Monitoring' => 'role-monitoring',
    default      => 'role-viewer',
};

// Menu utama — mengikuti modul-modul yang sudah ada di aplikasi ini
$menu = [
    'index.php'      => ['label' => 'Dashboard',                 'icon' => 'bi-speedometer2',         ],
    'kontrak.php'     => ['label' => 'Data Kontrak & Target SLA',  'icon' => 'bi-file-earmark-text',    ],
    'input_harian.php'=> ['label' => 'Input SLA',   'icon' => 'bi-calendar2-check',      ],
];
// Halaman yang sifatnya INPUT data (Supervisor tidak boleh akses, hanya lihat laporan)
$menuInputPages = ['kontrak.php', 'input_harian.php'];
if (isSupervisor()) {
    foreach ($menuInputPages as $mp) unset($menu[$mp]);
}

// Grup "Laporan & Analisis" — digabung jadi satu submenu supaya sidebar tidak
// penuh dengan banyak halaman laporan yang terpisah-pisah.
$menuLaporan = !isPetugas() ? [
    'rekap_sla.php'          => ['label' => 'Rekap SLA',            'icon' => 'bi-bar-chart-line'   ],
    'detail_perhitungan.php' => ['label' => 'Detail Perhitungan',   'icon' => 'bi-calculator'       ],
    'rata_rata.php'          => ['label' => 'Rata-Rata SLA',        'icon' => 'bi-graph-up-arrow'   ],
    'laporan_grafik.php'     => ['label' => 'Laporan Grafik',       'icon' => 'bi-bar-chart-fill'   ],
    'laporan.php'            => ['label' => 'Laporan SLA',          'icon' => 'bi-funnel'           ],
    'cetak.php'              => ['label' => 'Cetak Laporan',        'icon' => 'bi-printer'          ],
] : [];
$menuLaporanActive = array_key_exists($activePage, $menuLaporan);
// Grup "Konfigurasi": Kelola Project (dulu "Unit Kerja") + Kelola User, Audit Log, Backup Database.
// Kelola Project pakai requireInputAccess() (sama seperti Data Kontrak) — Supervisor (Team Leader & Manager UL) tidak bisa akses sama sekali.
// Kelola User, Audit Log, Backup Database — hanya untuk Super Admin.
// (Grup "Data Pendukung" sudah dihapus; Data ULP, Master ULP, Data Kendaraan & Data Personil juga tidak ada di sidebar.)
$menuAdmin = [];
if (!isSupervisor()) {
    $menuAdmin['unit_kerja.php'] = ['label' => 'Kelola Project', 'icon' => 'bi-diagram-3'];
}
if (isAdmin()) {
    $menuAdmin['users.php']     = ['label' => 'Kelola User',      'icon' => 'bi-people'];
    $menuAdmin['audit-log.php'] = ['label' => 'Audit Log',        'icon' => 'bi-clock-history'];
    $menuAdmin['backup.php']    = ['label' => 'Backup Database',  'icon' => 'bi-hdd-network'];
}
?>
<!DOCTYPE html>
<html lang="id"<?= (($loggedUser['theme_preference'] ?? 'light') === 'dark') ? ' data-theme="dark"' : '' ?>>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title><?= h($pageTitle) ?> — SLA Monitoring</title>
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16.png">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicon-180.png">
    <link rel="shortcut icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="assets/css/style.css">
    <script>
    // Terapkan status sidebar (kecil/besar) sebelum halaman tampil, supaya tidak berkedip.
    (function () {
        var d = document.documentElement;
        try { if (localStorage.getItem('sidebarCollapsed') === '1') d.classList.add('sidebar-collapsed'); } catch (e) {}
        d.classList.add('sidebar-init'); // matikan animasi untuk render pertama
        window.addEventListener('load', function () {
            requestAnimationFrame(function () { requestAnimationFrame(function () { d.classList.remove('sidebar-init'); }); });
        });
    })();
    </script>
</head>
<body>

<!-- CUSTOM CONFIRM MODAL -->
<div class="modal-overlay" id="confirmModal">
    <div class="modal" style="max-width:400px;">
        <div class="modal-header">
            <span class="modal-title" id="confirmModalTitle">Konfirmasi</span>
            <button class="modal-close" onclick="closeConfirmModal()">×</button>
        </div>
        <div class="modal-body">
            <div style="display:flex;align-items:flex-start;gap:14px;">
                <div id="confirmModalIcon" style="font-size:28px;line-height:1;flex-shrink:0;">⚠️</div>
                <div id="confirmModalMessage" style="font-size:14px;color:var(--gray-700);line-height:1.6;"></div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeConfirmModal()">Batal</button>
            <button class="btn btn-danger" id="confirmModalOkBtn" onclick="confirmModalProceed()">Ya, Lanjutkan</button>
        </div>
    </div>
</div>

<script>
// ------------------------------------------------------------
//  MODAL HELPER GLOBAL — dipakai oleh SEMUA modal di aplikasi ini
//  (confirmModal, profileModal, keteranganModal, ringkasanInputModal,
//  dan modal lain yang dibuat di masa depan).
//
//  Sebelum ini tiap modal mengatur show/hide sendiri-sendiri lewat
//  classList.add('show')/remove('show') secara terpisah, TANPA
//  mengunci scroll halaman di belakangnya — akibatnya halaman di
//  balik modal masih bisa di-scroll (mouse wheel / swipe), yang bikin
//  modal terasa "lepas kendali". openAppModal()/closeAppModal() di
//  bawah ini menambahkan penguncian scroll + hitung modal yang lagi
//  aktif (supaya scroll tetap terkunci selama MASIH ADA modal lain
//  yang terbuka, walau modal ini sendiri baru ditutup).
// ------------------------------------------------------------
var _openModalCount = 0;
function openAppModal(id) {
    var el = document.getElementById(id);
    if (!el || el.classList.contains('show')) return;
    el.classList.add('show');
    _openModalCount++;
    document.documentElement.classList.add('modal-open');
}
function closeAppModal(id) {
    var el = document.getElementById(id);
    if (!el || !el.classList.contains('show')) return;
    el.classList.remove('show');
    _openModalCount = Math.max(0, _openModalCount - 1);
    if (_openModalCount === 0) document.documentElement.classList.remove('modal-open');
}

var _confirmCallback = null;

function showConfirm(opts, callback) {
    document.getElementById('confirmModalTitle').textContent  = opts.title   || 'Konfirmasi';
    document.getElementById('confirmModalMessage').innerHTML  = opts.message || 'Lanjutkan?';
    document.getElementById('confirmModalIcon').textContent   = opts.icon    || '⚠️';
    var okBtn = document.getElementById('confirmModalOkBtn');
    okBtn.textContent = opts.btnLabel || 'Ya, Lanjutkan';
    okBtn.className   = 'btn ' + (opts.btnClass || 'btn-danger');
    _confirmCallback  = callback;
    openAppModal('confirmModal');
}

function closeConfirmModal() {
    closeAppModal('confirmModal');
    _confirmCallback = null;
}

function confirmModalProceed() {
    var cb = _confirmCallback;
    closeConfirmModal();
    if (typeof cb === 'function') cb();
}

document.addEventListener('click', function(e) {
    var modal = document.getElementById('confirmModal');
    if (e.target === modal) closeConfirmModal();
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeConfirmModal();
});

// Buka/tutup grup submenu sidebar (mis. "Laporan & Analisis")
function toggleNavGroup(btn) {
    var group   = btn.closest('.nav-group');
    var submenu = group.querySelector('.nav-submenu');
    var isOpen  = group.classList.toggle('open');
    submenu.style.display = isOpen ? 'flex' : 'none';
}

// confirmDelete() dipanggil dari halaman-halaman modul SLA (kontrak, ULP,
// indikator) — dialihkan agar memakai modal konfirmasi yang sama seperti
// tombol Logout, alih-alih confirm() bawaan browser.
function confirmDelete(url, name) {
    showConfirm({
        title: 'Konfirmasi Hapus',
        message: 'Hapus ' + name + '? Data tidak bisa dikembalikan.',
        icon: '🗑️',
        btnLabel: 'Ya, Hapus',
        btnClass: 'btn-danger'
    }, function() {
        window.location.href = url;
    });
    return false;
}

document.addEventListener('DOMContentLoaded', function() {
    var btnLogout = document.getElementById('btnLogout');
    if (btnLogout) {
        btnLogout.addEventListener('click', function(e) {
            e.preventDefault();
            showConfirm({
                title: 'Logout',
                message: 'Yakin ingin keluar dari aplikasi?',
                icon: '!',
                btnLabel: 'Ya, Logout',
                btnClass: 'btn-danger'
            }, function() {
                window.location = 'logout.php';
            });
        });
    }
});
</script>

<!-- Overlay sidebar mobile -->
<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>

<div class="layout">
<aside class="sidebar" id="sidebar">

    <div class="sidebar-brand">
        <img class="brand-full" src="assets/img/logo-light.png" alt="PLN Nusa Daya">
        <img class="brand-mini" src="assets/img/logo-icon.png" alt="PLN">
    </div>

    <nav class="sidebar-nav">
        <?php $i = 0; foreach ($menu as $href => $item): $i++; ?>
            <a class="nav-link<?= $activePage === $href ? ' active' : '' ?>"
               href="<?= h($href) ?>"
               style="animation-delay:<?= min($i * 30, 300) ?>ms">
                <span class="nav-icon"><i class="bi <?= h($item['icon']) ?>"></i></span>
                <span class="nav-label"><?= h($item['label']) ?></span>
                <?php if (!empty($item['badge'])): ?>
                    <span class="badge badge-warning" style="margin-left:auto;"><?= (int)$item['badge'] ?></span>
                <?php endif; ?>
            </a>
        <?php endforeach; ?>

        <?php if (!empty($menuLaporan)): $i++; ?>
        <div class="nav-group<?= $menuLaporanActive ? ' open' : '' ?>">
            <button type="button" class="nav-link nav-group-toggle" onclick="toggleNavGroup(this)" style="animation-delay:<?= min($i * 30, 300) ?>ms">
                <span class="nav-icon"><i class="bi bi-graph-up"></i></span>
                <span class="nav-label">Laporan &amp; Analisis</span>
                <i class="bi bi-chevron-down nav-group-chevron"></i>
            </button>
            <div class="nav-submenu" style="<?= $menuLaporanActive ? '' : 'display:none;' ?>">
                <?php foreach ($menuLaporan as $href => $item): $i++; ?>
                <a class="nav-link<?= $activePage === $href ? ' active' : '' ?>"
                   href="<?= h($href) ?>"
                   style="animation-delay:<?= min($i * 30, 300) ?>ms">
                    <span class="nav-icon"><i class="bi <?= h($item['icon']) ?>"></i></span>
                    <span class="nav-label"><?= h($item['label']) ?></span>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($menuAdmin)): ?>
        <div class="nav-divider"><span class="nav-label">Konfigurasi</span></div>
        <?php foreach ($menuAdmin as $href => $item): $i++; ?>
            <a class="nav-link<?= $activePage === $href ? ' active' : '' ?>"
               href="<?= h($href) ?>"
               style="animation-delay:<?= min($i * 30, 300) ?>ms">
                <span class="nav-icon"><i class="bi <?= h($item['icon']) ?>"></i></span>
                <span class="nav-label"><?= h($item['label']) ?></span>
            </a>
        <?php endforeach; ?>
        <?php endif; ?>
    </nav>

    <div class="sidebar-footer">
        <button type="button" class="user-info user-info-btn" id="btnOpenProfile" title="Lihat Profil">
            <div class="user-avatar" id="sidebarAvatar">
                <?php if ($userFoto): ?>
                    <img src="<?= h($userFoto) ?>?v=<?= time() ?>" alt="foto profil" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" data-inisial="<?= h($userInisial) ?>" onerror="this.replaceWith(document.createTextNode(this.dataset.inisial))">
                <?php else: ?>
                    <?= $userInisial ?>
                <?php endif; ?>
            </div>
            <div class="user-text" style="min-width:0;">
                <div class="user-name"><?= h($loggedUser['nama'] ?? 'User') ?></div>
                <div class="user-role"><?= h(roleLabel($loggedUser['role'] ?? null)) ?></div>
            </div>
        </button>
        <a href="#" id="btnLogout" title="Keluar">
            <i class="bi bi-box-arrow-right"></i>
        </a>
    </div>

</aside>

<!-- ======================================================
     MODAL PROFIL
     ====================================================== -->
<div class="modal-overlay" id="profileModal">
    <div class="modal profile-modal">

        <button class="profile-back-btn" id="btnCloseProfile" title="Tutup">
            <i class="bi bi-chevron-left"></i>
        </button>

        <div class="profile-top">
            <div class="profile-avatar-wrap">
                <div class="profile-avatar" id="profileAvatarDisplay">
                    <?php if ($userFoto): ?>
                        <img src="<?= h($userFoto) ?>?v=<?= time() ?>" alt="foto profil" id="profileAvatarImg" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">
                    <?php else: ?>
                        <span id="profileAvatarInitial"><?= $userInisial ?></span>
                        <img src="" alt="" id="profileAvatarImg" style="display:none;width:100%;height:100%;object-fit:cover;border-radius:50%;">
                    <?php endif; ?>
                </div>
                <label class="profile-edit-btn" for="inputFoto" title="Ganti foto profil">
                    <i class="bi bi-pencil-fill"></i>
                </label>
            </div>
            <div class="role-popup <?= $roleBadgeClass ?>" style="position:relative;top:auto;left:auto;transform:none;margin-left:8px;align-self:flex-start;margin-top:8px;">
                <i class="bi bi-shield-fill"></i>
                <?= h(roleLabel($loggedUser['role'] ?? null)) ?>
            </div>
        </div>

        <div class="profile-username-box">
            <?= h($loggedUser['username'] ?? '-') ?>
        </div>

        <div class="profile-modal-body">
            <div class="profile-info-label">Nama</div>
            <div class="profile-info-btn">
                <?= h($loggedUser['nama'] ?? '-') ?>
            </div>

            <div class="profile-info-label">Email</div>
            <div class="profile-info-btn">
                <?= h($loggedUser['email'] ?? '-') ?>
            </div>

            <p class="profile-readonly-note"><i class="bi bi-lock-fill"></i> Data hanya dapat diubah oleh Administrator.</p>
        </div>

        <form id="formFoto" method="post" action="profile-save.php" enctype="multipart/form-data" style="display:none;">
            <?= csrfField() ?>
            <input type="file" id="inputFoto" name="foto" accept="image/jpeg,image/png,image/gif,image/webp">
        </form>
    </div>
</div>

<script>
(function () {
    var btnOpen  = document.getElementById('btnOpenProfile');
    var btnClose = document.getElementById('btnCloseProfile');
    var modal    = document.getElementById('profileModal');

    if (btnOpen) btnOpen.addEventListener('click', function () {
        openAppModal('profileModal');
    });
    if (btnClose) btnClose.addEventListener('click', function () {
        closeAppModal('profileModal');
    });
    modal.addEventListener('click', function (e) {
        if (e.target === modal) closeAppModal('profileModal');
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && modal.classList.contains('show')) closeAppModal('profileModal');
    });

    var inputFoto = document.getElementById('inputFoto');
    var avatarImg = document.getElementById('profileAvatarImg');
    var avatarIni = document.getElementById('profileAvatarInitial');
    var sidebarAv = document.getElementById('sidebarAvatar');

    if (inputFoto) {
        inputFoto.addEventListener('change', function () {
            var file = this.files[0];
            if (!file) return;

            if (file.size > 2 * 1024 * 1024) {
                alert('Ukuran foto maksimal 2MB.');
                this.value = '';
                return;
            }

            var reader = new FileReader();
            reader.onload = function (e) {
                if (avatarImg) {
                    avatarImg.src = e.target.result;
                    avatarImg.style.display = 'block';
                }
                if (avatarIni) avatarIni.style.display = 'none';

                if (sidebarAv) {
                    sidebarAv.innerHTML = '<img src="' + e.target.result + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">';
                }
            };
            reader.readAsDataURL(file);

            document.getElementById('formFoto').submit();
        });
    }
})();
</script>

    <!-- MAIN CONTENT -->
    <main class="main-content">
        <div class="topbar">
            <div class="topbar-left">
                <button type="button" class="btn-hamburger" id="btnSidebarToggle" onclick="toggleSidebar()" title="Perbesar / perkecil menu" aria-label="Perbesar atau perkecil menu"><i class="bi bi-list"></i></button>
                <div class="topbar-title"><?= h($pageTitle) ?></div>
            </div>
            <div style="display:flex;align-items:center;gap:10px;">
                <button type="button" id="themeToggle" class="btn-theme-toggle" title="Ganti mode terang/gelap" data-csrf="<?= h(csrfToken()) ?>">
                    <i class="bi <?= (($loggedUser['theme_preference'] ?? 'light') === 'dark') ? 'bi-sun-fill' : 'bi-moon-stars-fill' ?>"></i>
                </button>
                <span class="badge-clock" id="liveClock">--:--:--</span>
                <span class="badge-month"><?= h(formatTanggalLengkap()) ?></span>
            </div>
        </div>

        <script>
        (function () {
            var btn = document.getElementById('themeToggle');
            if (!btn) return;
            var current = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
            btn.addEventListener('click', function () {
                var next = current === 'dark' ? 'light' : 'dark';
                btn.disabled = true;
                fetch('theme_save.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'theme=' + next + '&csrf_token=' + encodeURIComponent(btn.dataset.csrf)
                }).finally(function () {
                    // Reload penuh (bukan cuma ganti atribut) supaya grafik Chart.js di
                    // halaman Dashboard/Laporan Grafik/Rekap SLA/Rata-rata ikut render
                    // ulang dengan warna sesuai tema baru, dan tema baru sudah tersimpan
                    // ke akun (bukan cuma browser ini).
                    location.reload();
                });
            });
        })();
        </script>

        <script>
        (function () {
            var el = document.getElementById('liveClock');
            if (!el) return;
            function pad(n) { return String(n).padStart(2, '0'); }
            function tick() {
                var d = new Date();
                el.textContent = pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
            }
            tick();
            setInterval(tick, 1000);
        })();
        </script>

        <!-- WATERMARK LOGO -->
        <div style="position:absolute;left:0;right:0;top:var(--topbar-h);bottom:0;pointer-events:none;z-index:1;display:flex;align-items:center;justify-content:center;overflow:hidden;">
            <img src="assets/img/logo.png" alt="" class="bg-watermark-logo" style="width:500px;max-width:55%;opacity:0.045;filter:grayscale(100%);user-select:none;pointer-events:none;">
        </div>

        <div class="page-content" style="position:relative;z-index:2;background:transparent;">
            <?php
            // Tombol "← Kembali" konsisten di semua halaman (kecuali Dashboard). Halaman form
            // (tambah/ubah) yang sudah punya tombol Kembali sendiri di kartunya dilewati.
            $__act = $_GET['act'] ?? 'list';
            $__kid = (int)($_GET['kontrak_id'] ?? 0);
            $__backUrl = null; $__backHint = 'Dashboard';
            if ($activePage !== 'index.php') {
                $__backUrl = 'index.php';
                $__ownBack = ['kontrak.php','kendaraan.php','personil.php','ulp_master.php','unit_kerja.php'];
                if (in_array($activePage, $__ownBack, true)) {
                    if ($__act !== 'list') $__backUrl = null; // form: sudah ada Kembali di kartu
                } elseif ($activePage === 'user-form.php') {
                    $__backUrl = null;
                } elseif ($activePage === 'cetak.php' && !empty($_GET['kontrak_id'])) {
                    $__backUrl = null;
                } elseif ($activePage === 'input_ulp.php') {
                    if ($__act !== 'list') { $__backUrl = 'input_ulp.php?kontrak_id=' . $__kid; $__backHint = 'Daftar ULP'; }
                    elseif ($__kid) { $__backUrl = 'kontrak.php?act=edit&id=' . $__kid; $__backHint = 'Data Kontrak'; }
                }
            }
            if ($__backUrl): ?>
                <div class="back-bar no-print"><a href="<?= h($__backUrl) ?>" class="btn btn-outline btn-sm" title="Kembali ke <?= h($__backHint) ?>">← Kembali</a></div>
            <?php endif; ?>
            <?php if (!empty(currentUser()['must_change_password'])): ?>
                <div class="alert alert-danger">
                    <i class="bi bi-shield-exclamation"></i>
                    <div>⚠️ Akun Anda masih menggunakan <b>password default</b>. Segera ganti password Anda di
                        <a href="user-form.php?id=<?= (int)currentUser()['id'] ?>"><b>Kelola User &rarr; Edit Profil Anda</b></a> untuk keamanan sistem.</div>
                </div>
            <?php endif; ?>
            <?= renderFlash($flash) ?>
