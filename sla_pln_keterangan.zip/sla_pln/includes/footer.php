        </div><!-- end page-content -->

        <!-- FOOTER -->
        <footer class="site-footer">
            <div class="footer-brand">
                <i class="bi bi-lightning-charge-fill" style="color:var(--pln-yellow);font-size:14px;"></i>
                <span>PLN Nusa Daya</span> &nbsp;— SLA Monitoring System
            </div>
            <div class="footer-ver">&copy; <?= date('Y') ?> &nbsp;v1.0</div>
        </footer>
        <div class="footer-bar"></div>
    </main>
</div>

<script>
// Desktop (> 768px): perbesar/perkecil sidebar jadi rel ikon (dianimasikan lewat CSS).
// Mobile (<= 768px): sidebar tetap berupa laci geser + overlay seperti sebelumnya.
function sidebarTitles() {
    var kecil = document.documentElement.classList.contains('sidebar-collapsed') && window.matchMedia('(min-width:769px)').matches;
    document.querySelectorAll('#sidebar .nav-link').forEach(function (a) {
        var lb = a.querySelector('.nav-label');
        if (kecil && lb) a.setAttribute('title', lb.textContent.trim());
        else a.removeAttribute('title');
    });
}
// Pasang kelas animasi sementara (footer memudar-masuk; saat diperbesar, item menu masuk berurutan).
// Dilepas lagi setelah selesai; klik beruntun dihandle dengan me-restart animasinya.
var sidebarAnimTimer = null;
function animasiSidebar(diperbesar) {
    var d = document.documentElement;
    clearTimeout(sidebarAnimTimer);
    d.classList.remove('sidebar-anim', 'sidebar-expanding');
    void d.offsetWidth; // paksa reflow supaya animasi mulai ulang
    d.classList.add('sidebar-anim');
    if (diperbesar) d.classList.add('sidebar-expanding');
    sidebarAnimTimer = setTimeout(function () {
        d.classList.remove('sidebar-anim', 'sidebar-expanding');
    }, 900);
}
function toggleSidebar() {
    if (window.matchMedia('(min-width:769px)').matches) {
        var d = document.documentElement;
        var kecil = d.classList.toggle('sidebar-collapsed');
        animasiSidebar(!kecil);
        try { localStorage.setItem('sidebarCollapsed', kecil ? '1' : '0'); } catch (e) {}
        sidebarTitles();
        return;
    }
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebarOverlay').classList.toggle('show');
}
sidebarTitles();
window.addEventListener('resize', sidebarTitles);
function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebarOverlay').classList.remove('show');
}

// Tab functionality (dipakai di Rekap SLA — tab per kategori / per ULP)
function showTab(tabId, btn) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById(tabId).classList.add('active');
    btn.classList.add('active');
}

// Number format
function formatRupiah(num) {
    return 'Rp ' + Math.abs(num).toLocaleString('id-ID', {minimumFractionDigits: 0});
}

// Auto-calculate SLA pencapaian (dipakai di Input Target & Realisasi SLA)
document.addEventListener('change', function(e) {
    if (e.target.classList.contains('input-realisasi') || e.target.classList.contains('input-target')) {
        var row = e.target.closest('tr');
        if (!row) return;
        var polaritas = row.dataset.polaritas;
        var target = parseFloat(row.querySelector('.input-target')?.value) || 0;
        var realisasi = parseFloat(row.querySelector('.input-realisasi')?.value) || 0;
        var pctEl = row.querySelector('.calc-pct');
        if (!pctEl) return;

        // Setara rumus Excel: =IF(AND(I=0;J=0);1;IF(negatif;2-(J/I);J/I))
        var pct;
        if (target === 0) pct = realisasi === 0 ? 100 : (polaritas === 'Negatif' ? 0 : 100);
        else if (polaritas === 'Negatif') pct = (2 - realisasi / target) * 100; // tidak dibatasi 0%
        else pct = (realisasi / target) * 100;

        pctEl.textContent = pct.toFixed(2) + '%';
        var cls = pct >= 90 ? 'good' : pct >= 70 ? 'warn' : 'bad';
        pctEl.className = 'calc-pct progress-label ' + cls;
    }
});
</script>
<script src="assets/js/kontrak-picker.js"></script>
<script>
document.querySelectorAll('.alert[data-autohide]').forEach(function (el) {
    setTimeout(function () {
        el.classList.add('alert-hide');
        setTimeout(function () { el.remove(); }, 320);
    }, parseInt(el.getAttribute('data-autohide'), 10) || 6000);
});
window.showToast = function (msg, type) {
    var t = document.createElement('div');
    t.className = 'app-toast' + (type === 'error' ? ' error' : '');
    t.textContent = msg;
    document.body.appendChild(t);
    requestAnimationFrame(function () { t.classList.add('show'); });
    setTimeout(function () { t.classList.remove('show'); setTimeout(function () { t.remove(); }, 250); }, 3500);
};
</script>
</body>
</html>
