<?php
require_once 'includes/database.php';
$db = getDB();
requireInputAccess();
$title = 'Data Kontrak';
$msg = '';
$act = $_GET['act'] ?? 'list';
$id = (int)($_GET['id'] ?? 0);

// TAMBAH KONTRAK hanya boleh dilakukan Super Admin. Role lain (Koordinator, Admin,
// Team Leader, Manager UL) tidak boleh membuka form tambah maupun menyimpan kontrak baru.
$bukanTambahKontrak = !isSuperAdmin();
if ($bukanTambahKontrak) {
    $mencobaTambah = ($act === 'tambah')
        || ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form_type'] ?? '') === 'kontrak' && !$id);
    if ($mencobaTambah) {
        setFlash('danger', '⚠️ Akses ditolak. Hanya Super Admin yang dapat menambah kontrak baru.');
        header('Location: kontrak.php'); exit;
    }
}

// DELETE
if ($act == 'hapus' && $id) {
    csrfVerify();
    $oldRow = dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$id]);
    if ($oldRow) {
        // Catatan: sla_entries punya 2 jalur FK cascade menuju kontrak
        // (langsung via kontrak_id, dan tidak langsung via ulp_id -> ulp -> kontrak).
        // Jalur "diamond" seperti ini rawan membuat MySQL/InnoDB gagal
        // menuntaskan ON DELETE CASCADE berantai (error 1451) walau constraint-nya
        // sudah benar. Supaya hapus kontrak SELALU berhasil apa pun kombinasi
        // relasinya, foreign key check dimatikan sementara selama proses hapus
        // manual (dari tabel paling "anak" ke paling "induk") di dalam satu
        // transaction, lalu dinyalakan kembali di akhir (baik sukses maupun gagal).
        try {
            $db->beginTransaction();
            dbExec($db, "SET FOREIGN_KEY_CHECKS=0");

            // monitoring_harian milik sla_entries kontrak ini (langsung via
            // kontrak_id maupun tidak langsung via ulp_id -> ulp.kontrak_id)
            dbExec($db,
                "DELETE mh FROM monitoring_harian mh
                 INNER JOIN sla_entries se ON se.id = mh.sla_entry_id
                 LEFT JOIN ulp u ON u.id = se.ulp_id
                 WHERE se.kontrak_id = ? OR u.kontrak_id = ?",
                [$id, $id]);

            // sla_entries -> kontrak & sla_entries -> ulp (kedua jalur sekaligus)
            dbExec($db,
                "DELETE se FROM sla_entries se
                 LEFT JOIN ulp u ON u.id = se.ulp_id
                 WHERE se.kontrak_id = ? OR u.kontrak_id = ?",
                [$id, $id]);

            // tabel-tabel lain yang langsung anak dari kontrak
            dbExec($db, "DELETE FROM rekap_sla WHERE kontrak_id=?", [$id]);
            dbExec($db, "DELETE FROM personil WHERE kontrak_id=?", [$id]);
            dbExec($db, "DELETE FROM kendaraan WHERE kontrak_id=?", [$id]);
            dbExec($db, "DELETE FROM ulp WHERE kontrak_id=?", [$id]);

            // terakhir, baris kontrak itu sendiri
            dbExec($db, "DELETE FROM kontrak WHERE id=?", [$id]);

            dbExec($db, "SET FOREIGN_KEY_CHECKS=1");
            $db->commit();
        } catch (Throwable $e) {
            if ($db->inTransaction()) $db->rollBack();
            try { dbExec($db, "SET FOREIGN_KEY_CHECKS=1"); } catch (Throwable $e2) {}
            setFlash('danger', '⚠️ Gagal menghapus kontrak: ' . $e->getMessage());
            header('Location: kontrak.php'); exit;
        }
        logAudit($db, 'delete', 'kontrak', "Hapus kontrak id=$id", $oldRow, null);
    }
    setFlash('success', '🗑️ Kontrak berhasil dihapus.');
    header('Location: kontrak.php'); exit;
}

// SAVE — Detail Kontrak
if ($_SERVER['REQUEST_METHOD'] == 'POST' && ($_POST['form_type'] ?? '') === 'kontrak') {
    csrfVerify();
    $vendor_nama = trim($_POST['vendor'] ?? '') ?: 'PT PELAYANAN LISTRIK NASIONAL NUSA DAYA';
    $fields = [
        'nama_kontrak'        => $_POST['nama_kontrak'] ?? '',
        'tgl_kontrak'         => $_POST['tgl_kontrak'] ?? '',
        'vendor'              => $vendor_nama,
        'periode_bulan'       => $_POST['periode_bulan'] ?? '',
        'tahun'               => (int)($_POST['tahun'] ?? date('Y')),
        'tahap'               => $_POST['tahap'] ?? 'TAHAP-2',
        'jenis_kontrak'       => $_POST['jenis_kontrak'] ?? 'DISTRIBUSI',
        'unit_id'             => (int)($_POST['unit_id'] ?? 0) ?: null,
        'nilai_tagihan_tahap1'=> (float)str_replace(['.','Rp',' '], '', $_POST['nilai_tagihan_tahap1'] ?? '0'),
        'nilai_tagihan_tahap2'=> (float)str_replace(['.','Rp',' '], '', $_POST['nilai_tagihan_tahap2'] ?? '0'),
    ];

    // Cek data double: kombinasi Project + periode + tahun + tahap + Unit yang sama.
    // Unit ikut dicek (pakai <=> supaya NULL unit_id juga cocok dengan NULL).
    $dupPeriode = (bool)dbVal($db,
        "SELECT COUNT(*) FROM kontrak WHERE nama_kontrak=? AND periode_bulan=? AND tahun=? AND tahap=? AND unit_id <=> ? AND id<>?",
        [$fields['nama_kontrak'], $fields['periode_bulan'], $fields['tahun'], $fields['tahap'], $fields['unit_id'], $id]);

    if ($dupPeriode) {
        $unitDup = $fields['unit_id'] ? dbVal($db, "SELECT nama FROM unit_kerja WHERE id=?", [$fields['unit_id']]) : null;
        $pesan = "Data gagal disimpan: Kontrak \"{$fields['nama_kontrak']}\" periode {$fields['periode_bulan']} {$fields['tahun']} ({$fields['tahap']})" . ($unitDup ? " Unit \"$unitDup\"" : '') . " sudah ada. Silakan periksa daftar kontrak.";
        setFlash('danger', '⚠️ ' . $pesan);
        header('Location: kontrak.php?act=' . ($id ? "edit&id=$id" : 'tambah')); exit;
    }

    if ($id) {
        $oldRow = dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$id]);
        $sets = implode(',', array_map(fn($k) => "$k=?", array_keys($fields)));
        $vals = array_values($fields);
        $vals[] = $id;
        dbExec($db, "UPDATE kontrak SET $sets WHERE id=?", $vals);
        [$lamaChanged, $baruChanged] = diffFields($oldRow ?: [], $fields);
        logAudit($db, 'update', 'kontrak', "Update kontrak id=$id", $lamaChanged ?: null, $baruChanged ?: null, $_POST['alasan_perubahan'] ?? null);
        setFlash('success', '✅ Data kontrak berhasil diperbarui.');
        header("Location: kontrak.php?act=edit&id=$id#detail-kontrak"); exit;
    } else {
        $cols = implode(',', array_keys($fields));
        $phs  = implode(',', array_fill(0, count($fields), '?'));
        dbExec($db, "INSERT INTO kontrak ($cols) VALUES ($phs)", array_values($fields));
        $new_id = (int)$db->lastInsertId();
        $unitKodeBaru = $fields['unit_id'] ? dbVal($db, "SELECT kode FROM unit_kerja WHERE id=?", [$fields['unit_id']]) : null;
        insertDefaultSLA($db, $new_id, $fields['jenis_kontrak'], $unitKodeBaru ?: null);
        logAudit($db, 'create', 'kontrak', "Tambah kontrak id=$new_id");
        // Kontrak baru: langsung ke halaman yang sama, lengkap dengan tabel Target & Realisasi di bawahnya
        setFlash('success', '✅ Kontrak berhasil ditambahkan.');
        header("Location: kontrak.php?act=edit&id=$new_id&msg=created#target-realisasi"); exit;
    }
}

// SAVE — Target & Realisasi SLA (digabung di halaman yang sama)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && ($_POST['form_type'] ?? '') === 'sla' && $id) {
    csrfVerify();
    $canEditTarget = isSuperAdmin(); // Kolom Target hanya boleh diubah oleh Super Admin
    $ulp_id_post = (int)($_POST['ulp_id'] ?? 0);
    $entries = $_POST['entries'] ?? [];
    $auditLama = [];
    $auditBaru = [];
    $touchedGabungan = []; // pasangan kategori+no_urut yang perlu disinkron ke baris Gabungan
    // Indikator level Gabungan (ulp_id IS NULL) yang realisasinya sudah dikelola
    // otomatis oleh Input SLA harian (input_harian.php) TIDAK BOLEH ditimpa lewat
    // form manual ini — kalau tetap ditimpa di sini, nilainya akan diam-diam
    // "hilang" lagi begitu ada input harian berikutnya (recalcRealisasiHarian
    // menang terakhir). Lihat getEntriesWithHarianData().
    // Aturan: Realisasi level kontrak (Gabungan) HANYA bersumber dari Input SLA —
    // di sini selalu dikunci, apa pun yang dikirim dari form diabaikan. Satu-satunya
    // cara mengubahnya adalah merevisi Input SLA. Realisasi per-ULP tetap boleh manual.
    foreach ($entries as $entry_id => $vals) {
        $row = dbRow($db, "SELECT kriteria, polaritas, bobot, target, realisasi, kategori, no_urut FROM sla_entries WHERE id=?", [(int)$entry_id]);
        if (!$row) continue;
        $dikelolaHarian = ($ulp_id_post === 0);
        // Non-Super Admin: nilai Target diabaikan, tetap pakai nilai lama di
        // database (apa pun yang dikirim dari form/browser tidak dipakai).
        $target = $canEditTarget ? (float)($vals['target'] ?? 0) : (float)$row['target'];
        // Realisasi yang sudah dikelola Input SLA harian: abaikan nilai dari form
        // ini, tetap pakai realisasi hasil agregasi harian yang sudah tersimpan.
        // Kalau field Realisasi dikosongkan (bukan diisi angka 0), simpan sebagai
        // NULL = "belum dinilai" — supaya tidak otomatis dihitung gagal (0%).
        if ($dikelolaHarian) {
            $realisasi = $row['realisasi'] !== null ? (float)$row['realisasi'] : null;
        } else {
            $rawRealisasi = trim((string)($vals['realisasi'] ?? ''));
            $realisasi = ($rawRealisasi === '') ? null : (float)$rawRealisasi;
        }
        if ((float)$row['target'] != $target || (float)$row['realisasi'] != $realisasi) {
            $label = mb_strimwidth($row['kriteria'] ?? "Indikator #$entry_id", 0, 40, '…');
            $auditLama[$label] = "target={$row['target']}, realisasi=" . ($row['realisasi'] ?? 'belum diisi');
            $auditBaru[$label] = "target=$target, realisasi=" . ($realisasi ?? 'belum diisi');
        }
        $pct   = ($realisasi === null) ? null : hitungPencapaian($row['polaritas'], $target, $realisasi);
        $nilai = ($pct === null) ? null : hitungNilaiBobot((float)$row['bobot'], $pct);
        // target_waktu_input harus ditulis SEBELUM target=? — MySQL mengevaluasi SET dari kiri ke kanan,
        // jadi perbandingan memakai nilai target yang masih lama.
        dbExec($db, "UPDATE sla_entries SET target_waktu_input = IF(target <=> ?, target_waktu_input, NOW()),
                target=?, realisasi=?, persen_pencapaian=?, nilai_bobot=? WHERE id=?",
            [$target, $target, $realisasi, $pct, $nilai, (int)$entry_id]);
        if ($ulp_id_post !== 0) {
            $touchedGabungan[$row['kategori'] . '|' . $row['no_urut']] = [$row['kategori'], $row['no_urut']];
        }
    }
    // Input per-ULP -> otomatis jumlahkan (rata-rata) ke baris "Gabungan" supaya
    // Rekap SLA (yang membaca baris Gabungan) selalu ikut ter-update.
    foreach ($touchedGabungan as [$catTouched, $noUrutTouched]) {
        syncGabunganFromULP($id, $catTouched, $noUrutTouched);
    }
    logAudit($db, 'update', 'input_sla', "Update target/realisasi manual kontrak_id=$id", $auditLama ?: null, $auditBaru ?: null, $_POST['alasan_perubahan'] ?? null);
    updateRekapSLA($id);
    $waktuSimpanSla = date('Y-m-d H:i:s'); // waktu persis (sampai detik) saat Target & Realisasi disimpan
    setFlash('success', '✅ Data Target & Realisasi SLA berhasil disimpan dan rekap diperbarui pada ' . date('d/m/Y H:i:s', strtotime($waktuSimpanSla)) . '.');
    header("Location: kontrak.php?act=edit&id=$id&ulp_id=$ulp_id_post#target-realisasi"); exit;
}

// Edit mode
$editData = null;
$canEditTarget = isSuperAdmin(); // Kolom Target hanya boleh diubah oleh Super Admin
$ulpList = [];
$entries = [];
$byKat = [];
$harianEntryIds = []; // id sla_entries (Gabungan) yang realisasinya sudah dikelola Input SLA harian
$ulp_id = (int)($_GET['ulp_id'] ?? 0);
// Prefill form Tambah Kontrak dari query string (dipakai link "buat kontrak dulu"
// dari halaman Input SLA, supaya Bidang/Project/Bulan/Tahun tidak perlu dipilih ulang).
$prefill = ($act === 'tambah') ? [
    'jenis_kontrak' => strtoupper(trim($_GET['jenis_kontrak'] ?? '')),
    'unit_id'       => (int)($_GET['unit_id'] ?? 0),
    'periode_bulan' => strtoupper(trim($_GET['periode_bulan'] ?? '')),
    'tahun'         => (int)($_GET['tahun'] ?? 0),
] : [];
if ($act == 'edit' && $id) {
    $editData = dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$id]);
    if ($editData) {
        $ulpList = dbAll($db, "SELECT * FROM ulp WHERE kontrak_id=? ORDER BY id", [$id]);
        $entries = $ulp_id
            ? dbAll($db, "SELECT * FROM sla_entries WHERE kontrak_id=? AND ulp_id=? ORDER BY kategori, no_urut", [$id, $ulp_id])
            : dbAll($db, "SELECT * FROM sla_entries WHERE kontrak_id=? AND ulp_id IS NULL ORDER BY kategori, no_urut", [$id]);
        foreach ($entries as $e) $byKat[$e['kategori']][] = $e;
        // Hanya baris Gabungan (ulp_id IS NULL) yang bisa bentrok dengan Input
        // SLA harian — entries per-ULP tidak pernah disentuh input_harian.php.
        if (!$ulp_id) {
            $harianEntryIds = getEntriesWithHarianData($db, array_column($entries, 'id'));
        }
    }
}
$ulpSel = $ulp_id ? dbRow($db, "SELECT * FROM ulp WHERE id=?", [$ulp_id]) : null;

// ── Ringkasan Input SLA (dipakai di popup "Ringkasan") ─────────
// Merangkum entries yang sedang ditampilkan (Gabungan atau per ULP)
// supaya pengguna bisa cek cepat tanpa scroll seluruh tabel.
$ringkasanInput = null;
if (!empty($entries)) {
    $rTotal = count($entries);
    $rTercapai = 0; $rTidakTercapai = 0; $rBelumDinilai = 0; $rSumPct = 0; $rSumBobot = 0; $rSumNilaiBobot = 0;
    $rPol = ['Positif' => ['jumlah'=>0,'dinilai'=>0,'sumPct'=>0], 'Negatif' => ['jumlah'=>0,'dinilai'=>0,'sumPct'=>0]];
    $rKat = [];
    foreach ($entries as $e) {
        $pct = $e['persen_pencapaian'] !== null ? (float)$e['persen_pencapaian'] : null;
        $rSumBobot += (float)($e['bobot'] ?? 0);
        $rSumNilaiBobot += (float)($e['nilai_bobot'] ?? 0);
        if ($pct === null) {
            $rBelumDinilai++;
        } else {
            $rSumPct += $pct;
            if ($pct >= 100) $rTercapai++; else $rTidakTercapai++;
        }

        $pol = ($e['polaritas'] ?? '') === 'Negatif' ? 'Negatif' : 'Positif';
        $rPol[$pol]['jumlah']++;
        if ($pct !== null) { $rPol[$pol]['dinilai']++; $rPol[$pol]['sumPct'] += $pct; }

        $kat = $e['kategori'] ?? '-';
        if (!isset($rKat[$kat])) $rKat[$kat] = ['jumlah'=>0,'dinilai'=>0,'sumPct'=>0,'tercapai'=>0];
        $rKat[$kat]['jumlah']++;
        if ($pct !== null) {
            $rKat[$kat]['dinilai']++;
            $rKat[$kat]['sumPct'] += $pct;
            if ($pct >= 100) $rKat[$kat]['tercapai']++;
        }
    }
    $rDinilai = $rTercapai + $rTidakTercapai;
    $ringkasanInput = [
        'total' => $rTotal,
        'tercapai' => $rTercapai,
        'tidak_tercapai' => $rTidakTercapai,
        'belum_dinilai' => $rBelumDinilai,
        // Rata-rata pencapaian hanya dari indikator yang SUDAH dinilai (realisasi
        // terisi) — indikator "Belum Dinilai" tidak ikut menyeret turun rata-rata.
        'avg_pct' => $rDinilai ? $rSumPct / $rDinilai : 0,
        'total_bobot' => $rSumBobot,
        'total_nilai_bobot' => $rSumNilaiBobot,
        'polaritas' => $rPol,
        'per_kategori' => $rKat,
    ];
}
function pctColor($pct) {
    if ($pct >= 90) return 'good';
    if ($pct >= 70) return 'warn';
    return 'bad';
}

// List — dengan filter (Jenis Kontrak, kata kunci pencarian, Bulan, Tahun)
// supaya tidak bingung saat mencari kontrak di antara banyak data.
$bulanValidFilter = ['JANUARI','FEBRUARI','MARET','APRIL','MEI','JUNI','JULI','AGUSTUS','SEPTEMBER','OKTOBER','NOVEMBER','DESEMBER'];
$filterJenis = strtoupper(trim($_GET['jenis'] ?? 'ALL'));
if (!in_array($filterJenis, ['ALL','DISTRIBUSI','TRANSMISI','PEMBANGKIT'], true)) $filterJenis = 'ALL';
$filterQ     = trim($_GET['q'] ?? '');
$filterBulan = strtoupper(trim($_GET['bulan'] ?? ''));
if (!in_array($filterBulan, $bulanValidFilter, true)) $filterBulan = '';
$filterTahun = trim($_GET['tahun'] ?? '');

$whereParts = [];
$whereVals  = [];
if ($filterJenis === 'DISTRIBUSI') {
    // Data lama tanpa jenis_kontrak dianggap DISTRIBUSI (default aplikasi)
    $whereParts[] = "(kontrak.jenis_kontrak = 'DISTRIBUSI' OR kontrak.jenis_kontrak IS NULL OR kontrak.jenis_kontrak = '')";
} elseif ($filterJenis !== 'ALL') {
    $whereParts[] = "kontrak.jenis_kontrak = ?";
    $whereVals[]  = $filterJenis;
}
if ($filterQ !== '') {
    $like = '%' . $filterQ . '%';
    $whereParts[] = "(kontrak.nama_kontrak LIKE ? OR kontrak.vendor LIKE ?)";
    array_push($whereVals, $like, $like);
}
if ($filterBulan !== '') {
    $whereParts[] = "kontrak.periode_bulan = ?";
    $whereVals[]  = $filterBulan;
}
if ($filterTahun !== '') {
    $whereParts[] = "kontrak.tahun = ?";
    $whereVals[]  = (int)$filterTahun;
}
$whereSql = $whereParts ? ('WHERE ' . implode(' AND ', $whereParts)) : '';

$kontrakList = dbAll($db, "SELECT kontrak.*, u.nama AS unit_nama FROM kontrak LEFT JOIN unit_kerja u ON u.id = kontrak.unit_id $whereSql
    ORDER BY kontrak.tahun DESC, FIELD(kontrak.periode_bulan,'JANUARI','FEBRUARI','MARET','APRIL','MEI','JUNI','JULI','AGUSTUS','SEPTEMBER','OKTOBER','NOVEMBER','DESEMBER') DESC, kontrak.id DESC", $whereVals);

// Jumlah per Jenis Kontrak (total keseluruhan, tidak terpengaruh filter aktif) — untuk badge di tab filter
$countJenis = [
    'ALL'        => (int)dbVal($db, "SELECT COUNT(*) FROM kontrak"),
    'DISTRIBUSI' => (int)dbVal($db, "SELECT COUNT(*) FROM kontrak WHERE jenis_kontrak='DISTRIBUSI' OR jenis_kontrak IS NULL OR jenis_kontrak=''"),
    'TRANSMISI'  => (int)dbVal($db, "SELECT COUNT(*) FROM kontrak WHERE jenis_kontrak='TRANSMISI'"),
    'PEMBANGKIT' => (int)dbVal($db, "SELECT COUNT(*) FROM kontrak WHERE jenis_kontrak='PEMBANGKIT'"),
];
// Daftar tahun yang tersedia (untuk dropdown filter tahun)
$tahunList = array_map(fn($r) => $r['tahun'], dbAll($db, "SELECT DISTINCT tahun FROM kontrak ORDER BY tahun DESC"));

$bulanList = $bulanValidFilter;
$unitListAll = getUnitKerjaList($db); // semua unit aktif, difilter di sisi JS mengikuti Jenis Kontrak yang dipilih

include 'includes/header.php';
?>

<?php if ($act != 'list'): ?>
<?php if ($editData): $kontrak_id = (int)$editData['id']; $kontrak = $editData; $kontrakTabActive = 'kontrak'; include 'includes/kontrak_tabs.php'; endif; ?>
<!-- FORM -->
<div class="card" id="detail-kontrak">
    <div class="card-header">
        <div>
            <div class="card-title"><?= $editData ? '✏️ Edit Kontrak' : '➕ Tambah Kontrak Baru' ?></div>
            <div class="card-subtitle">Isi data kontrak SLA secara lengkap</div>
        </div>
        <a href="kontrak.php" class="btn btn-outline btn-sm">← Kembali</a>
    </div>
    <div class="card-body">
    <form method="POST">
        <?= csrfField() ?>
        <input type="hidden" name="form_type" value="kontrak">
        <div class="form-grid">
            <div class="form-group">
                <label>Nama Project</label>
                <input class="form-control" name="nama_kontrak" required maxlength="80" placeholder="Mis. O&amp;M Distribusi"
                    value="<?= htmlspecialchars($editData['nama_kontrak'] ?? 'O&M Distribusi') ?>">
            </div>
            <div class="form-group">
                <label>Tanggal Kontrak</label>
                <input class="form-control" name="tgl_kontrak" value="<?= htmlspecialchars($editData['tgl_kontrak'] ?? '') ?>" placeholder="01 September 2025">
            </div>
            <div class="form-group">
                <label>Vendor / Pelaksana</label>
                <input class="form-control" name="vendor" required
                    value="<?= htmlspecialchars($editData['vendor'] ?? 'PT PELAYANAN LISTRIK NASIONAL NUSA DAYA') ?>">
            </div>
            <div class="form-group">
                <label>Bidang</label>
                <select class="form-control" name="jenis_kontrak" id="jenis_kontrak" onchange="updateNamaKontrak(this.value); filterUnitOptions(this.value);">
                    <option value="DISTRIBUSI" <?= ($editData['jenis_kontrak'] ?? $prefill['jenis_kontrak'] ?? 'DISTRIBUSI')=='DISTRIBUSI'?'selected':'' ?>>Distribusi</option>
                    <option value="TRANSMISI" <?= ($editData['jenis_kontrak'] ?? $prefill['jenis_kontrak'] ?? '')=='TRANSMISI'?'selected':'' ?>>Transmisi</option>
                    <option value="PEMBANGKIT" <?= ($editData['jenis_kontrak'] ?? $prefill['jenis_kontrak'] ?? '')=='PEMBANGKIT'?'selected':'' ?>>Pembangkit</option>
                </select>
                <div style="font-size:11px;color:var(--text-light);margin-top:4px;">Pembangkit: target SLA dikosongkan otomatis, wajib diisi manual sesuai kesepakatan kontrak.</div>
            </div>
            <div class="form-group">
                <label>Unit</label>
                <select class="form-control" name="unit_id" id="unit_id" >
                    <option value="">-- Belum ditentukan --</option>
                    <?php foreach ($unitListAll as $u): ?>
                    <option value="<?= $u['id'] ?>" data-jenis="<?= h($u['jenis_kontrak']) ?>" data-nama="<?= h($u['nama']) ?>"
                        <?= (($editData['unit_id'] ?? $prefill['unit_id'] ?? 0)) == $u['id'] ? 'selected' : '' ?>>
                        <?= h($u['nama']) ?><?= $u['kode'] !== $u['nama'] ? ' (' . h($u['kode']) . ')' : '' ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <div style="font-size:11px;color:var(--text-light);margin-top:4px;">Daftar unit menyesuaikan Bidang di atas. Kelola daftar project di menu <a href="unit_kerja.php" target="_blank">Kelola Project</a>.</div>
            </div>
            <div class="form-group">
                <label>Tahap Tagihan</label>
                <select class="form-control" name="tahap">
                    <?php foreach(['TAHAP-1','TAHAP-2','TAHAP-1 & TAHAP-2'] as $t): ?>
                    <option value="<?= $t ?>" <?= ($editData['tahap']??'TAHAP-2')==$t?'selected':'' ?>><?= $t ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Periode Bulan</label>
                <select class="form-control" name="periode_bulan">
                    <?php foreach($bulanList as $b): ?>
                    <option value="<?= $b ?>" <?= ($editData['periode_bulan'] ?? $prefill['periode_bulan'] ?? '')==$b?'selected':'' ?>><?= $b ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Tahun</label>
                <?php
                    $tahunDipilih = (int)($editData['tahun'] ?? (($prefill['tahun'] ?? 0) ?: date('Y')));
                    $tahunAwal = min(2020, $tahunDipilih); $tahunAkhir = max(2035, $tahunDipilih);
                ?>
                <select class="form-control" name="tahun">
                    <?php for ($ty = $tahunAkhir; $ty >= $tahunAwal; $ty--): ?>
                    <option value="<?= $ty ?>" <?= $ty === $tahunDipilih ? 'selected' : '' ?>><?= $ty ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Nilai Tagihan Tahap 1 (Rp)</label>
                <input class="form-control" name="nilai_tagihan_tahap1" type="number" step="1"
                    value="<?= $editData['nilai_tagihan_tahap1'] ?? 0 ?>" placeholder="0">
            </div>
            <div class="form-group">
                <label>Nilai Tagihan Tahap 2 (Rp)</label>
                <input class="form-control" name="nilai_tagihan_tahap2" type="number" step="1"
                    value="<?= $editData['nilai_tagihan_tahap2'] ?? 0 ?>" placeholder="0">
            </div>
        </div>
        <?php if ($editData): ?>
        <div class="form-group" style="margin-top:6px;">
            <label>Alasan Perubahan <span style="font-weight:400;color:var(--text-light);">(opsional)</span></label>
            <input class="form-control" name="alasan_perubahan" placeholder="Contoh: koreksi nilai tagihan sesuai adendum kontrak">
        </div>
        <?php endif; ?>
        <hr class="divider">
        <div style="display:flex;gap:10px;justify-content:flex-end;">
            <a href="kontrak.php" class="btn btn-outline">Batal</a>
            <button type="submit" class="btn btn-primary">💾 Simpan Kontrak</button>
        </div>
    </form>
    </div>
</div>
<script>
function updateNamaKontrak(jenis) {
    const namaInput = document.querySelector('input[name="nama_kontrak"]');
    if (!namaInput || namaInput.value.trim() !== '') return; // jangan timpa kalau sudah diisi
    if (jenis === 'TRANSMISI') {
        namaInput.value = 'O&M Transmisi';
    } else if (jenis === 'PEMBANGKIT') {
        namaInput.value = 'O&M Pembangkit';
    } else {
        namaInput.value = 'O&M Distribusi';
    }
}

// Dropdown "Unit" hanya menampilkan unit yang sesuai Jenis Kontrak yang sedang dipilih
// (mis. Distribusi -> OPGI, Transmisi -> GP). Kalau unit yang sebelumnya terpilih tidak
// cocok lagi dengan jenis baru, pilihan direset ke "Belum ditentukan".
function filterUnitOptions(jenis) {
    const unitSelect = document.getElementById('unit_id');
    if (!unitSelect) return;
    const prevValue = unitSelect.value;
    let stillValid = false;
    Array.prototype.forEach.call(unitSelect.options, function (opt) {
        if (!opt.value) { opt.hidden = false; return; }
        const cocok = opt.getAttribute('data-jenis') === jenis;
        opt.hidden = !cocok;
        if (cocok && opt.value === prevValue) stillValid = true;
    });
    if (!stillValid) unitSelect.value = '';
}
document.addEventListener('DOMContentLoaded', function () {
    const jenisSelect = document.getElementById('jenis_kontrak');
    if (jenisSelect) filterUnitOptions(jenisSelect.value);
});

</script>
<?php if ($editData): ?>
<script>localStorage.setItem('lastKontrakId', '<?= (int)$editData['id'] ?>');</script>
<?php endif; ?>


<?php if ($editData && !empty($entries)): ?>
<div id="target-realisasi"></div>
<?php if (!$ulp_id): ?>
<div class="alert alert-info" style="margin-bottom:16px;">
    <i class="bi bi-lock-fill"></i>
    Realisasi level kontrak dikunci (🔒) dan hanya bersumber dari
    <a href="input_harian.php?kontrak_id=<?= $id ?>"><b>Input SLA</b></a> (Periode 1 &amp; 2) — Rekap SLA mengikuti data tersebut.
    Untuk mengubahnya, revisi lewat menu Input SLA. Realisasi per-ULP tetap bisa diisi di sini (pilih ULP).
</div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title">✏️ Target & Realisasi SLA</div>
            <div class="card-subtitle">Isi pencapaian SLA untuk kontrak ini — langsung di bawah data kontrak, tanpa pindah halaman</div>
        </div>
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
            <?php if ($ringkasanInput): ?>
            <button type="button" class="btn btn-outline btn-sm" onclick="openRingkasanInputModal()">
                <i class="bi bi-clipboard-data"></i> Ringkasan
            </button>
            <?php endif; ?>
            <?php if(!empty($ulpList)): ?>
            <select class="form-control" style="max-width:240px;" onchange="window.location='kontrak.php?act=edit&id=<?= $id ?>&ulp_id='+this.value+'#target-realisasi'">
                <option value="0" <?= $ulp_id==0?'selected':'' ?>>-- Rekap Gabungan --</option>
                <?php foreach($ulpList as $u): ?>
                <option value="<?= $u['id'] ?>" <?= $ulp_id==$u['id']?'selected':'' ?>><?= htmlspecialchars((string)($u['nama_ulp'] ?? '')) ?></option>
                <?php endforeach; ?>
            </select>
            <?php endif; ?>
        </div>
    </div>
</div>

<form method="POST" id="formSla">
<?= csrfField() ?>
<input type="hidden" name="form_type" value="sla">
<input type="hidden" name="ulp_id" value="<?= $ulp_id ?>">
<?php
$katLabels = [
    'TEKNIS' => ['label'=>'A. SLA TEKNIS','icon'=>'⚡','color'=>'#003087'],
    'K3' => ['label'=>'B. SLA K3 (Keselamatan & Kesehatan Kerja)','icon'=>'🦺','color'=>'#27ae60'],
    'KECELAKAAN' => ['label'=>'C. Kecelakaan Kerja','icon'=>'⚠️','color'=>'#e67e22'],
    'ILP' => ['label'=>'D. Integritas Layanan Publik (ILP)','icon'=>'🏛️','color'=>'#8e44ad'],
];
?>
<?php $katIndex = 0; foreach($katLabels as $kat=>$katInfo):
    if(empty($byKat[$kat])) continue;
    $katEntries = $byKat[$kat];
    $katDinilai = array_values(array_filter($katEntries, fn($e) => $e['persen_pencapaian'] !== null));
    $avgPct = count($katDinilai) > 0 ? array_sum(array_column($katDinilai,'persen_pencapaian'))/count($katDinilai) : 0;
    // Accordion: kategori pertama yang punya data terbuka secara default,
    // sisanya tertutup — diklik untuk buka/tutup (tidak mengubah form input-nya).
    $katOpen = ($katIndex === 0);
    $katIndex++;
?>
<div class="card kat-accordion<?= $katOpen ? ' open' : '' ?>">
    <div class="card-header kat-accordion-header" onclick="toggleKatAccordion(this)">
        <div>
            <div class="card-title" style="color:<?= $katInfo['color'] ?>;"><?= $katInfo['icon'] ?> <?= $katInfo['label'] ?></div>
            <div class="card-subtitle"><?= count($katEntries) ?> indikator &bull; Rata-rata pencapaian: <b><?= number_format($avgPct,2) ?>%</b></div>
        </div>
        <div style="display:flex;align-items:center;gap:14px;">
            <div class="sla-gauge">
                <div class="sla-pct <?= pctColor($avgPct) ?>"><?= number_format($avgPct,1) ?>%</div>
            </div>
            <i class="bi bi-chevron-down kat-accordion-chevron"></i>
        </div>
    </div>
    <div class="table-wrap kat-accordion-body" style="<?= $katOpen ? '' : 'display:none;' ?>">
    <table>
        <thead>
            <tr>
                <th style="width:30px;">#</th>
                <th>Ruang Lingkup</th>
                <th>Kriteria / Kinerja</th>
                <th>Satuan</th>
                <th>Polaritas<?= helpTip(HELP_POLARITAS) ?></th>
                <th style="width:110px;">Target<?= $canEditTarget ? '' : ' <i class="bi bi-lock-fill" style="font-size:10px;color:var(--text-light);" title="Hanya Super Admin"></i>' ?></th>
                <th style="width:110px;">Realisasi <i class="bi bi-info-circle" style="font-size:10px;color:var(--text-light);" title="Realisasi level kontrak dikunci dan hanya berasal dari Input SLA"></i></th>
                <th style="width:120px;">% Pencapaian</th>
                <th style="width:160px;">Keterangan</th>
            </tr>
        </thead>
        <tbody>
        <?php $no=1; foreach($katEntries as $e):
            $pct = $e['persen_pencapaian'] !== null ? (float)$e['persen_pencapaian'] : null;
            $dikelolaHarian = !$ulp_id; // level kontrak: selalu dikunci, sumber = Input SLA
        ?>
        <tr data-polaritas="<?= $e['polaritas'] ?>" data-bobot="<?= $e['bobot'] ?>">
            <td><?= $no++ ?></td>
            <td>
                <div style="font-size:12px;font-weight:700;"><?= htmlspecialchars((string)($e['ruang_lingkup'] ?? '')) ?></div>
                <div style="font-size:11px;color:var(--text-light);">No. <?= htmlspecialchars((string)($e['no_urut'] ?? '')) ?></div>
            </td>
            <td style="font-size:12px;max-width:280px;"><?= htmlspecialchars((string)($e['kriteria'] ?? '')) ?></td>
            <td><?= htmlspecialchars((string)($e['satuan'] ?? '')) ?></td>
            <td>
                <span class="badge <?= $e['polaritas']=='Positif'?'badge-positif':'badge-negatif' ?>">
                    <?= $e['polaritas'] ?>
                </span>
            </td>
            <td>
                <input type="number" step="any" class="form-control input-target"
                    name="entries[<?= $e['id'] ?>][target]"
                    value="<?= $e['target'] ?>"
                    <?= $canEditTarget ? '' : 'readonly title="Hanya Super Admin yang dapat mengubah Target"' ?>
                    style="width:100%;padding:6px 8px;<?= $canEditTarget ? '' : 'background:#f1f5f9;cursor:not-allowed;color:#94a3b8;' ?>">
            </td>
            <td>
                <input type="number" step="any" class="form-control input-realisasi"
                    name="entries[<?= $e['id'] ?>][realisasi]"
                    value="<?= $e['realisasi'] !== null ? $e['realisasi'] : '' ?>"
                    placeholder="Belum diisi"
                    <?= $dikelolaHarian ? 'readonly title="Realisasi level kontrak hanya berasal dari Input SLA Periode 1 & 2 — revisi lewat menu Input SLA"' : '' ?>
                    style="width:100%;padding:6px 8px;<?= $dikelolaHarian ? 'background:#f1f5f9;cursor:not-allowed;color:#94a3b8;' : '' ?>">
                <?php if ($dikelolaHarian): ?>
                <div style="font-size:10px;color:var(--text-light);margin-top:2px;">
                    <i class="bi bi-lock-fill"></i> Dari <a href="input_harian.php?kontrak_id=<?= $id ?>" style="color:inherit;text-decoration:underline;">Input SLA harian</a>
                </div>
                <?php endif; ?>
            </td>
            <td class="pct-cell">
                <?php if ($pct === null): ?>
                <span class="badge belum-dinilai-badge" style="background:#f1f5f9;color:#94a3b8;border:1px solid #e2e8f0;white-space:nowrap;">
                    <i class="bi bi-hourglass-split"></i> Belum Dinilai
                </span>
                <?php else: ?>
                <div class="progress-bar"><div class="progress-fill calc-pct-bar <?= pctColor($pct) ?>" style="width:<?= min(100,max(0,$pct)) ?>%"></div></div>
                <div class="progress-label calc-pct <?= pctColor($pct) ?>"><?= number_format($pct,2) ?>%</div>
                <?php endif; ?>
            </td>
            <?php
                // Keterangan hanya untuk indikator yang belum mencapai target (< 100%, sesuai angka yang tampil 2 desimal).
                // Pencapaian >= 100% atau belum dinilai: keterangan tertutup, tidak bisa diisi.
                $ketTerbuka = ($pct !== null && round($pct, 2) < 100);
            ?>
            <td class="ket-td" data-saved-open="<?= $ketTerbuka ? '1' : '0' ?>">
                <span class="keterangan-cell" style="cursor:pointer;color:var(--blue);font-size:11px;font-weight:600;display:<?= $ketTerbuka ? 'inline-flex' : 'none' ?>;align-items:center;gap:4px;"
                    data-keterangan="<?= htmlspecialchars((string)($e['keterangan'] ?? '')) ?>"
                    onclick="openKeteranganModal(<?= (int)$e['id'] ?>, this, '<?= htmlspecialchars(addslashes((string)($e['ruang_lingkup'] ?? ''))) ?>')">
                    <i class="bi bi-pencil-square"></i>
                    <span class="keterangan-preview"><?= $e['keterangan'] ? htmlspecialchars(mb_strimwidth((string)$e['keterangan'],0,28,'…')) : '+ Isi Keterangan' ?></span>
                </span>
                <span class="ket-tutup" style="display:<?= $ketTerbuka ? 'none' : 'inline' ?>;color:#cbd5e1;" title="Keterangan hanya untuk indikator yang belum mencapai target (&lt; 100%)">–</span>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</div>
<?php endforeach; ?>

<div class="form-group" style="max-width:520px;margin-left:auto;margin-bottom:14px;">
    <label>Alasan Perubahan <span style="font-weight:400;color:var(--text-light);">(opsional)</span></label>
    <input class="form-control" name="alasan_perubahan" placeholder="Contoh: revisi realisasi berdasarkan verifikasi lapangan">
</div>
<div style="display:flex;gap:10px;justify-content:flex-end;margin-bottom:20px;flex-wrap:wrap;">
    <button type="submit" class="btn btn-success">💾 Simpan Target & Realisasi</button>
    <a href="rekap_sla.php?kontrak_id=<?= $id ?>" class="btn btn-primary">📊 Lihat Rekap SLA</a>
</div>
</form>
<script>
function toggleKatAccordion(header) {
    var card = header.closest('.kat-accordion');
    var body = card.querySelector('.kat-accordion-body');
    var isOpen = card.classList.toggle('open');
    body.style.display = isOpen ? '' : 'none';
}
(function(){
    var inputs = Array.from(document.querySelectorAll('#formSla .input-target, #formSla .input-realisasi'));
    inputs.forEach(function(el, idx){
        el.addEventListener('keydown', function(e){
            if (e.key === 'Enter') {
                e.preventDefault();
                var next = inputs[idx+1];
                if (next) {
                    // Kalau field berikutnya ada di kategori accordion yang masih
                    // tertutup, buka dulu supaya fokus tidak "hilang" ke input yang disembunyikan.
                    var nextCard = next.closest('.kat-accordion');
                    if (nextCard && !nextCard.classList.contains('open')) {
                        toggleKatAccordion(nextCard.querySelector('.kat-accordion-header'));
                    }
                    next.focus();
                }
            }
        });
    });

    // ── Live update "% Pencapaian" & "Nilai Bobot" mengikuti Realisasi/Target
    // yang sedang diinput — mencerminkan persis rumus hitungPencapaian() di PHP
    // (includes/database.php), supaya pengguna langsung lihat hasilnya tanpa
    // harus simpan dulu.
    function hitungPencapaianJS(polaritas, target, realisasi) {
        target = parseFloat(target); if (isNaN(target)) target = 0;
        realisasi = parseFloat(realisasi); if (isNaN(realisasi)) realisasi = 0;
        // Setara rumus Excel: =IF(AND(I=0;J=0);1;IF(negatif;2-(J/I);J/I))
        if (target === 0) {
            if (realisasi === 0) return 100;
            return polaritas === 'Negatif' ? 0 : 100;
        }
        if (polaritas === 'Negatif') return (2 - realisasi / target) * 100; // tidak dibatasi 0%
        return (realisasi / target) * 100;
    }
    // Keterangan terbuka hanya saat pencapaian (yang tampil, 2 desimal) < 100%, dinilai dari angka
    // yang SEDANG diketik (belum perlu disimpan). >= 100% atau belum dinilai: langsung tertutup.
    function updateKeteranganCell(row, pct) {
        var td = row.querySelector('.ket-td');
        if (!td) return;
        var btn = td.querySelector('.keterangan-cell');
        var tutup = td.querySelector('.ket-tutup');
        var terbuka = (pct !== null && Math.round(pct * 100) / 100 < 100);
        btn.style.display   = terbuka ? 'inline-flex' : 'none';
        tutup.style.display = terbuka ? 'none' : 'inline';
    }
    function pctColorJS(pct) {
        if (pct >= 90) return 'good';
        if (pct >= 70) return 'warn';
        return 'bad';
    }
    function recalcRow(row) {
        var tEl = row.querySelector('.input-target');
        var rEl = row.querySelector('.input-realisasi');
        if (!tEl || !rEl) return;
        var pctCell = row.querySelector('.pct-cell');
        if (!pctCell) return;

        // Realisasi kosong = "Belum Dinilai" — jangan dihitung sebagai gagal (0%)
        if (String(rEl.value).trim() === '') {
            updateKeteranganCell(row, null);
            pctCell.innerHTML = '<span class="badge belum-dinilai-badge" style="background:#f1f5f9;color:#94a3b8;border:1px solid #e2e8f0;white-space:nowrap;"><i class="bi bi-hourglass-split"></i> Belum Dinilai</span>';
            return;
        }

        var polaritas = row.getAttribute('data-polaritas') || 'Positif';
        var pct = hitungPencapaianJS(polaritas, tEl.value, rEl.value);
        updateKeteranganCell(row, pct);
        var cls = pctColorJS(pct);
        pctCell.innerHTML =
            '<div class="progress-bar"><div class="progress-fill calc-pct-bar ' + cls + '" style="width:' + Math.min(100, Math.max(0, pct)) + '%"></div></div>' +
            '<div class="progress-label calc-pct ' + cls + '">' + pct.toFixed(2) + '%</div>';
    }
    document.querySelectorAll('#formSla .input-target, #formSla .input-realisasi').forEach(function(el){
        el.addEventListener('input', function(){
            var row = el.closest('tr[data-polaritas]');
            if (row) recalcRow(row);
        });
    });
})();
<?php if (str_contains($_SERVER['REQUEST_URI'] ?? '', 'target-realisasi') || (isset($_GET['msg']) && $_GET['msg']==='created')): ?>
document.getElementById('target-realisasi').scrollIntoView({behavior:'smooth', block:'start'});
<?php endif; ?>
</script>

<!-- ── MODAL: ISI KETERANGAN INDIKATOR SLA (muncul kalau belum capai target) ── -->
<div class="modal-overlay" id="keteranganModal">
    <div class="modal" style="max-width:520px;">
        <div class="modal-header">
            <span class="modal-title">📝 Keterangan Indikator SLA</span>
            <button class="modal-close" onclick="closeKeteranganModal()">×</button>
        </div>
        <div class="modal-body">
            <div id="keteranganEntryInfo" style="font-size:12px;font-weight:700;color:var(--g700);margin-bottom:10px;"></div>
            <div class="form-group" style="margin-bottom:4px;">
                <label>Keterangan <span style="color:var(--red);">*wajib diisi</span> <span style="font-weight:400;color:var(--text-light);">(alasan indikator ini belum mencapai target)</span></label>
                <textarea id="keteranganText" class="form-control" rows="4" placeholder="Contoh: Keterlambatan material dari vendor, cuaca ekstrem, dsb."></textarea>
                <div id="keteranganError" style="display:none;color:var(--red);font-size:11.5px;margin-top:6px;">⚠️ Gagal: Keterangan tidak boleh kosong, harus diisi terlebih dahulu.</div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-outline btn-sm" onclick="closeKeteranganModal()">Batal</button>
            <button class="btn btn-primary btn-sm" onclick="saveKeterangan()">💾 Simpan Keterangan</button>
        </div>
    </div>
</div>
<script>
var CSRF_TOKEN = "<?= htmlspecialchars(csrfToken()) ?>";
var currentKeteranganEntryId = null;
var currentKeteranganCellEl  = null;

function openKeteranganModal(entryId, cellEl, ruangLingkup) {
    currentKeteranganEntryId = entryId;
    currentKeteranganCellEl  = cellEl;
    document.getElementById('keteranganEntryInfo').textContent = ruangLingkup || '';
    document.getElementById('keteranganText').value = cellEl.getAttribute('data-keterangan') || '';
    document.getElementById('keteranganError').style.display = 'none';
    document.getElementById('keteranganText').style.borderColor = '';
    openAppModal('keteranganModal');
    setTimeout(function () { document.getElementById('keteranganText').focus(); }, 100);
}
function closeKeteranganModal() {
    closeAppModal('keteranganModal');
}
function saveKeterangan() {
    if (!currentKeteranganEntryId) return;
    var textEl = document.getElementById('keteranganText');
    var errEl  = document.getElementById('keteranganError');
    var teks   = textEl.value.trim();

    if (teks === '') {
        // Gagal: keterangan wajib diisi, tidak dikirim ke server.
        errEl.style.display = 'block';
        textEl.style.borderColor = 'var(--red)';
        textEl.focus();
        return;
    }
    errEl.style.display = 'none';
    textEl.style.borderColor = '';

    var fd = new FormData();
    fd.append('action', 'save_keterangan');
    fd.append('entry_id', currentKeteranganEntryId);
    fd.append('keterangan', teks);
    // Kirim nilai yang sedang diketik di baris ini, supaya server menilai < 100% berdasarkan angka live
    var rowEl = currentKeteranganCellEl ? currentKeteranganCellEl.closest('tr') : null;
    if (rowEl) {
        var tEl = rowEl.querySelector('.input-target'), rEl = rowEl.querySelector('.input-realisasi');
        if (tEl) fd.append('target', tEl.value);
        if (rEl) fd.append('realisasi', rEl.value);
    }
    fd.append('csrf_token', CSRF_TOKEN);
    fetch('api.php', { method: 'POST', body: fd })
        .then(function (res) { return res.json(); })
        .then(function (data) {
            if (!data.ok) {
                errEl.textContent = '⚠️ Gagal: ' + (data.error || 'terjadi kesalahan, keterangan tidak tersimpan.');
                errEl.style.display = 'block';
                textEl.style.borderColor = 'var(--red)';
                return;
            }
            if (currentKeteranganCellEl) {
                currentKeteranganCellEl.setAttribute('data-keterangan', teks);
                var preview = currentKeteranganCellEl.querySelector('.keterangan-preview');
                if (preview) preview.textContent = teks.slice(0, 28) + (teks.length > 28 ? '…' : '');
            }
            closeKeteranganModal();
            window.showToast('✅ Keterangan berhasil disimpan.');
        })
        .catch(function () {
            errEl.textContent = '⚠️ Gagal menyimpan keterangan. Silakan coba lagi.';
            errEl.style.display = 'block';
        });
}
document.getElementById('keteranganModal').addEventListener('click', function (e) {
    if (e.target === this) closeKeteranganModal();
});
</script>

<?php if ($ringkasanInput): $ri = $ringkasanInput; ?>
<!-- ── POPUP: RINGKASAN INPUT SLA ──────────────────────────── -->
<div class="modal-overlay" id="ringkasanInputModal">
    <div class="modal" style="max-width:640px;">
        <div class="modal-header">
            <span class="modal-title">
                <i class="bi bi-clipboard-data"></i> Ringkasan Input SLA
                <div style="font-size:11px;font-weight:400;color:var(--g500);margin-top:2px;">
                    <?= $ulpSel ? htmlspecialchars((string)$ulpSel['nama_ulp']) : 'Rekap Gabungan' ?>
                </div>
            </span>
            <button class="modal-close" onclick="closeRingkasanInputModal()">×</button>
        </div>
        <div class="modal-body">
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-bottom:16px;">
                <div class="kpi-card kpi-blue" style="margin:0;">
                    <div class="kpi-icon"><i class="bi bi-list-check"></i></div>
                    <div class="kpi-body">
                        <div class="kpi-label">Total Indikator</div>
                        <div class="kpi-value"><?= $ri['total'] ?></div>
                    </div>
                </div>
                <div class="kpi-card kpi-green" style="margin:0;">
                    <div class="kpi-icon"><i class="bi bi-check-circle"></i></div>
                    <div class="kpi-body">
                        <div class="kpi-label">Tercapai</div>
                        <div class="kpi-value"><?= $ri['tercapai'] ?></div>
                    </div>
                </div>
                <div class="kpi-card <?= $ri['tidak_tercapai']>0 ? 'kpi-red' : 'kpi-green' ?>" style="margin:0;">
                    <div class="kpi-icon"><i class="bi bi-x-circle"></i></div>
                    <div class="kpi-body">
                        <div class="kpi-label">Tidak Tercapai</div>
                        <div class="kpi-value"><?= $ri['tidak_tercapai'] ?></div>
                    </div>
                </div>
                <?php if ($ri['belum_dinilai'] > 0): ?>
                <div class="kpi-card kpi-amber" style="margin:0;">
                    <div class="kpi-icon"><i class="bi bi-hourglass-split"></i></div>
                    <div class="kpi-body">
                        <div class="kpi-label">Belum Dinilai</div>
                        <div class="kpi-value"><?= $ri['belum_dinilai'] ?></div>
                    </div>
                </div>
                <?php endif; ?>
                <div class="kpi-card kpi-<?= progressClass($ri['avg_pct'])==='good'?'green':($ri['avg_pct']>=70?'amber':'red') ?>" style="margin:0;">
                    <div class="kpi-icon"><i class="bi bi-speedometer2"></i></div>
                    <div class="kpi-body">
                        <div class="kpi-label">Rata-rata Pencapaian</div>
                        <div class="kpi-value"><?= number_format($ri['avg_pct'],1) ?>%</div>
                        <?php if ($ri['belum_dinilai'] > 0): ?><div class="kpi-sub">dari indikator yang sudah dinilai</div><?php endif; ?>
                    </div>
                </div>
            </div>

            <div style="font-size:12px;font-weight:700;color:var(--g700);margin-bottom:6px;">Per Kategori</div>
            <div class="table-wrap" style="margin-bottom:16px;">
                <table>
                    <thead><tr><th>Kategori</th><th>Jml.</th><th>Tercapai</th><th>Rata² %</th></tr></thead>
                    <tbody>
                    <?php foreach($katLabels as $kat=>$katInfo): $kr = $ri['per_kategori'][$kat] ?? null; if(!$kr) continue; ?>
                        <tr>
                            <td style="font-size:12px;"><?= $katInfo['icon'] ?> <?= htmlspecialchars($katInfo['label']) ?></td>
                            <td><?= $kr['jumlah'] ?></td>
                            <td><?= $kr['tercapai'] ?>/<?= $kr['dinilai'] ?><?= $kr['dinilai'] < $kr['jumlah'] ? ' <span style="color:#b8970a;">('.($kr['jumlah']-$kr['dinilai']).' belum dinilai)</span>' : '' ?></td>
                            <td><b><?= $kr['dinilai'] ? number_format($kr['sumPct']/$kr['dinilai'],1).'%' : '-' ?></b></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div style="font-size:12px;font-weight:700;color:var(--g700);margin-bottom:6px;">Berdasarkan Polaritas<?= helpTip(HELP_POLARITAS) ?></div>
            <div class="table-wrap" style="margin-bottom:16px;">
                <table>
                    <thead><tr><th>Polaritas</th><th>Jml. Indikator</th><th>Rata² % Pencapaian</th></tr></thead>
                    <tbody>
                    <?php foreach(['Positif','Negatif'] as $pol): $pr = $ri['polaritas'][$pol]; ?>
                        <tr>
                            <td><span class="badge <?= $pol==='Positif'?'badge-positif':'badge-negatif' ?>"><?= $pol ?></span></td>
                            <td><?= $pr['jumlah'] ?></td>
                            <td><b><?= $pr['dinilai'] ? number_format($pr['sumPct']/$pr['dinilai'],1).'%' : '-' ?></b></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-outline" onclick="closeRingkasanInputModal()">Tutup</button>
        </div>
    </div>
</div>
<script>
function openRingkasanInputModal() {
    openAppModal('ringkasanInputModal');
}
function closeRingkasanInputModal() {
    closeAppModal('ringkasanInputModal');
}
document.getElementById('ringkasanInputModal').addEventListener('click', function (e) {
    if (e.target === this) closeRingkasanInputModal();
});
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeRingkasanInputModal();
});
</script>
<?php endif; ?>

<?php elseif ($editData && empty($entries)): ?>
<div class="alert alert-info" style="margin-top:0;">Belum ada entry SLA untuk kontrak ini.</div>
<?php endif; ?>

<?php else:
    $tabUrl = function(string $jenis) use ($filterQ, $filterBulan, $filterTahun): string {
        $params = ['jenis' => $jenis];
        if ($filterQ !== '') $params['q'] = $filterQ;
        if ($filterBulan !== '') $params['bulan'] = $filterBulan;
        if ($filterTahun !== '') $params['tahun'] = $filterTahun;
        return 'kontrak.php?' . http_build_query($params);
    };
    $jenisTabs = [
        'ALL'        => 'Semua',
        'DISTRIBUSI' => 'Distribusi',
        'TRANSMISI'  => 'Transmisi',
        'PEMBANGKIT' => 'Pembangkit',
    ];
?>
<!-- ── FILTER: cari & saring kontrak ──────────────────────── -->
<div class="tabs">
    <?php foreach($jenisTabs as $jv=>$jl): ?>
    <a class="tab-btn<?= $filterJenis===$jv?' active':'' ?>" href="<?= htmlspecialchars($tabUrl($jv)) ?>">
        <?= $jl ?> <span class="tab-count"><?= $countJenis[$jv] ?></span>
    </a>
    <?php endforeach; ?>
</div>
<form method="GET" action="kontrak.php" class="filter-bar">
    <input type="hidden" name="jenis" value="<?= htmlspecialchars($filterJenis) ?>">
    <div class="form-group" style="margin:0;flex:1;min-width:220px;">
        <label>Cari Kontrak</label>
        <input class="form-control" type="text" name="q" value="<?= htmlspecialchars($filterQ) ?>"
            placeholder="Nama kontrak atau vendor…">
    </div>
    <div class="form-group" style="margin:0;min-width:150px;">
        <label>Bulan</label>
        <select class="form-control" name="bulan">
            <option value="">Semua Bulan</option>
            <?php foreach($bulanList as $bl): ?>
            <option value="<?= $bl ?>" <?= $filterBulan===$bl?'selected':'' ?>><?= ucwords(strtolower($bl)) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group" style="margin:0;min-width:140px;">
        <label>Tahun</label>
        <select class="form-control" name="tahun">
            <option value="">Semua Tahun</option>
            <?php foreach($tahunList as $ty): ?>
            <option value="<?= $ty ?>" <?= (string)$filterTahun===(string)$ty?'selected':'' ?>><?= $ty ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-search"></i> Cari</button>
    <?php if ($filterQ !== '' || $filterBulan !== '' || $filterTahun !== '' || $filterJenis !== 'ALL'): ?>
    <a href="kontrak.php" class="btn btn-outline btn-sm">Reset</a>
    <?php endif; ?>
</form>

<!-- LIST -->
<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title">📋 Daftar Kontrak SLA</div>
            <div class="card-subtitle">
                Menampilkan <?= count($kontrakList) ?> dari <?= $countJenis['ALL'] ?> kontrak
                <?= $filterJenis!=='ALL' ? '· Bidang: '.htmlspecialchars($jenisTabs[$filterJenis]) : '' ?>
                <?= $filterQ!=='' ? '· Kata kunci: "'.htmlspecialchars($filterQ).'"' : '' ?>
                <?= $filterBulan!=='' ? '· Bulan: '.htmlspecialchars(ucwords(strtolower($filterBulan))) : '' ?>
                <?= $filterTahun!=='' ? '· Tahun: '.htmlspecialchars($filterTahun) : '' ?>
            </div>
        </div>
        <?php if (isSuperAdmin()): ?>
        <a href="kontrak.php?act=tambah" class="btn btn-primary">+ Tambah Kontrak</a>
        <?php endif; ?>
    </div>
    <?php if(empty($kontrakList)): ?>
    <div class="alert alert-info">
        <?= ($filterQ!=='' || $filterBulan!=='' || $filterTahun!=='' || $filterJenis!=='ALL')
            ? 'Tidak ada kontrak yang cocok dengan filter/pencarian ini. <a href="kontrak.php">Reset filter</a>.'
            : (isSuperAdmin() ? 'Belum ada kontrak. Klik "Tambah Kontrak" untuk memulai.' : 'Belum ada kontrak. Hubungi Super Admin untuk menambahkan kontrak.') ?>
    </div>
    <?php else: ?>
    <div class="table-wrap">
    <table>
        <thead>
            <tr><th>#</th><th>Project</th><th>Bidang</th><th>Periode</th><th>Tahap</th><th>Vendor</th><th>Tagihan</th><th>Aksi</th></tr>
        </thead>
        <tbody>
        <?php foreach($kontrakList as $i=>$k): ?>
        <tr>
            <td><?= $i+1 ?></td>
            <td><b style="font-size:12px;"><?= htmlspecialchars(mb_strimwidth((string)($k['nama_kontrak'] ?? ''),0,60,'...')) ?></b></td>
            <td>
                <?= badgeJenisKontrak($k['jenis_kontrak'] ?? 'DISTRIBUSI') ?>
                <?php if (!empty($k['unit_nama'])): ?><br><span style="margin-top:3px;display:inline-block;"><?= badgeUnitKerja($k['unit_nama']) ?></span><?php endif; ?>
            </td>
            <td><?= htmlspecialchars((string)($k['periode_bulan'] ?? '')) ?> <?= $k['tahun'] ?></td>
            <td><span class="badge badge-teknis"><?= htmlspecialchars((string)($k['tahap'] ?? '')) ?></span></td>
            <td style="font-size:12px;"><?= htmlspecialchars(mb_strimwidth((string)($k['vendor'] ?? ''),0,35,'...')) ?></td>
            <td style="font-size:12px;">
                Rp <?= number_format(($k['nilai_tagihan_tahap1']??0)+($k['nilai_tagihan_tahap2']??0),0,',','.') ?>
            </td>
            <td>
                <div class="aksi-btn-group">
                    <a href="kontrak.php?act=edit&id=<?= $k['id'] ?>#target-realisasi" class="btn btn-primary btn-sm">Target & Realisasi</a>
                    <a href="kontrak.php?act=edit&id=<?= $k['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="rekap_sla.php?kontrak_id=<?= $k['id'] ?>" class="btn btn-outline btn-sm">Rekap</a>
                    <a href="#" onclick="confirmDelete('<?= csrfUrl('kontrak.php?act=hapus&id=' . $k['id']) ?>','kontrak ini')" class="btn btn-danger btn-sm">Hapus</a>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>