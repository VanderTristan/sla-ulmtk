<?php
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/auth.php';

// Hapus data login dari session, lalu regenerasi ID session demi keamanan
unset($_SESSION['user']);
session_regenerate_id(true);

setFlash('success', 'Anda berhasil logout.');
header('Location: login.php');
exit;
