<?php
/**
 * input_sla.php
 *
 * Halaman "Input Target & Realisasi" sekarang sudah digabung menjadi satu
 * dengan halaman Data Kontrak (lihat kontrak.php). File ini dipertahankan
 * sebagai pengalih (redirect) supaya tautan/menu lama tetap berfungsi:
 *  - kalau kontrak_id dikirim -> langsung ke kontrak.php?act=edit&id=...
 *  - kalau belum ada -> ke kontrak terakhir yang dipakai (localStorage), atau ke daftar kontrak
 */
require_once 'includes/database.php';
$db = getDB();
requireLogin();

$kontrak_id = (int)($_GET['kontrak_id'] ?? 0);
if ($kontrak_id) {
    $ulp_id = (int)($_GET['ulp_id'] ?? 0);
    $extra = $ulp_id ? "&ulp_id=$ulp_id" : '';
    header("Location: kontrak.php?act=edit&id={$kontrak_id}{$extra}#target-realisasi");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Mengalihkan…</title>
</head>
<body>
<script>
// Coba arahkan ke kontrak terakhir yang dipakai, kalau tidak ada -> daftar kontrak
var last = localStorage.getItem('lastKontrakId');
window.location = last ? ('kontrak.php?act=edit&id=' + last + '#target-realisasi') : 'kontrak.php';
</script>
<noscript><meta http-equiv="refresh" content="0;url=kontrak.php"></noscript>
</body>
</html>
