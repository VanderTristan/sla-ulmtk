<?php
require_once 'includes/database.php';
$db = getDB();
requireReportAccess();
$title = 'Cetak Laporan SLA';
$kontrak_id = (int)($_GET['kontrak_id'] ?? 0);
$tipe = $_GET['tipe'] ?? 'bulanan'; // bulanan | tahunan
$tahun_filter = (int)($_GET['tahun'] ?? date('Y'));

require_once 'includes/kontrak_selector.php';
$selOpt = [];
$sel = kontrakSelectorInit($db, $kontrak_id);
$filterJenis = $sel['jenis']; $filterUnit = $sel['unit'];
$selExtra = ['tipe' => $tipe] + ($tipe === 'tahunan' ? ['tahun' => $tahun_filter] : []);
$kontrak = $kontrak_id ? dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$kontrak_id]) : null;
$rekap = $kontrak_id ? dbRow($db, "SELECT * FROM rekap_sla WHERE kontrak_id=?", [$kontrak_id]) : null;
// Mode cetak: halaman bersih (tanpa sidebar/topbar/layout flex) khusus untuk dicetak / disimpan PDF.
$printMode = (($_GET['print'] ?? '') === '1') && $kontrak_id;

function getCatEntries2($db, $cid, $kat) {
    $r = dbAll($db, "SELECT * FROM sla_entries WHERE kontrak_id=? AND ulp_id IS NULL AND kategori=? ORDER BY no_urut", [$cid, $kat]); return $r;
}
function pctColorCetak($pct) {
    if ($pct >= 90) return 'good';
    if ($pct >= 70) return 'warn';
    return 'bad';
}

if ($printMode) {
    echo '<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><title>Laporan SLA</title>'
       . '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">'
       . '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600;700&display=swap">'
       . '<link rel="stylesheet" href="assets/css/style.css"></head><body class="print-mode">';
} else {
    include 'includes/header.php';
}
?>
<style>
/* Info kontrak: label + isi, rapi di layar lebar maupun sempit */
.info-list { margin:0; padding:6px 20px 12px; }
.info-row { display:grid; grid-template-columns:170px 1fr; gap:4px 14px; padding:9px 0; border-bottom:1px solid var(--border); font-size:13px; line-height:1.5; }
.info-row:last-child { border-bottom:none; }
.info-row dt { font-weight:700; color:var(--g700); }
.info-row dd { margin:0; color:var(--g900); overflow-wrap:anywhere; }
@media (max-width:640px) {
    .info-list { padding:4px 16px 10px; }
    .info-row { grid-template-columns:1fr; gap:1px; padding:8px 0; }
    .info-row dt { font-size:10.5px; text-transform:uppercase; letter-spacing:.04em; color:var(--g500); }
}
.print-mode .info-list { padding:2px 8px 4px; }
.print-mode .info-row { grid-template-columns:120px 1fr; padding:1px 0; border-bottom:none; font-size:9.5px; line-height:1.25; }
/* ===== Mode cetak (cetak.php?print=1): halaman bersih, tidak bergantung layout aplikasi ===== */
@page { size: A4 landscape; margin: 6mm; }
body.print-mode { background:#fff!important; padding:0; font-size:9.5px; line-height:1.25; }
.print-mode .print-header { display:block!important; margin-bottom:4px!important; }
.print-mode .print-header > div { font-size:11px!important; margin-bottom:0!important; line-height:1.3; }
.print-mode .print-header hr { margin:4px 0!important; }
.print-mode .card { overflow:visible!important; box-shadow:none!important; border:1px solid #bbb!important; margin-bottom:6px!important; break-inside:auto; page-break-inside:auto; animation:none!important; }
.print-mode .card-header { padding:4px 8px!important; gap:4px!important; }
.print-mode .card-title { font-size:11px!important; }
.print-mode .card-subtitle { font-size:9px!important; margin-top:0!important; }
.print-mode .card-header > div:last-child { font-size:12px!important; }
.print-mode .table-wrap { overflow:visible!important; }
.print-mode table { width:100%; font-size:9px!important; }
.print-mode th, .print-mode td { padding:2px 4px!important; white-space:normal!important; word-break:break-word; line-height:1.25; }
.print-mode thead th { font-size:8.5px!important; letter-spacing:0!important; }
.print-mode thead { display:table-header-group; }
.print-mode tr { break-inside:avoid; page-break-inside:avoid; }
.print-mode td > div { display:inline!important; font-size:9px!important; }
.print-mode td > div + div { margin-left:4px; }
.print-mode .progress-bar { display:none!important; }
.print-mode .progress-label { margin-top:0!important; font-size:9px!important; }
.print-mode .badge { padding:1px 5px!important; font-size:8.5px!important; }
.print-mode td div[style*="height:60px"] { height:26px!important; display:block!important; }
.print-mode td[style*="padding:16px"] { padding:2px 6px!important; }
.print-mode td[style*="padding:16px"] > div { display:block!important; font-size:10px!important; }
.print-mode .card:has(td[style*="padding:16px"]) { break-inside:avoid; page-break-inside:avoid; }
.print-mode * { -webkit-print-color-adjust:exact; print-color-adjust:exact; }

@media print {
    .sidebar, .topbar, .no-print, .tabs, .tab-btn { display:none!important; }
    .main { margin-left:0!important; }
    .content { padding:0!important; }
    .card { box-shadow:none!important; border:1px solid #ccc!important; page-break-inside:avoid; }
    body { font-size:11px; }
    table { font-size:10px; }
    .print-header { display:block!important; }

    /* Kertas landscape supaya semua kolom (sampai Realisasi, % Pencapaian,
       Nilai Bobot, Keterangan) muat dan tidak terpotong di sisi kanan. */
    @page { size: A4 landscape; margin: 8mm; }
    html, body { overflow:visible!important; width:auto!important; height:auto!important; }
    .layout, .main-content, .page-content { display:block!important; overflow:visible!important; max-width:none!important; width:auto!important; margin:0!important; padding:0!important; animation:none!important; }
    /* Jangan dipotong: overflow tabel/kartu dibuka saat cetak */
    .card { overflow:visible!important; page-break-inside:auto!important; break-inside:auto!important; }
    .table-wrap { overflow:visible!important; }
    table { width:100%!important; table-layout:auto; }
    th, td { padding:4px 5px!important; white-space:normal!important; word-break:break-word; }
    thead { display:table-header-group; }
    tr { page-break-inside:avoid; break-inside:avoid; }
    * { -webkit-print-color-adjust:exact; print-color-adjust:exact; }
}
.print-header { display:none; text-align:center; margin-bottom:20px; }
</style>

<?php if (!$printMode): ?>
<div class="card no-print">
    <div class="card-header">
        <div class="card-title">🖨️ Cetak Laporan SLA</div>
    </div>
    <div class="card-body">
    <?php $qTahun = ($tipe === 'tahunan') ? '&tahun=' . $tahun_filter : ''; ?>
    <?php renderKontrakSelectorFields($sel, 'cetak.php', $selOpt + ['extra' => $selExtra, 'btnLabel' => 'Pilih']); ?>
    <?php if($kontrak_id): ?>
    <div style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap;margin-top:14px;">
        <div class="form-group" style="min-width:160px;margin:0;">
            <label>Jenis Laporan</label>
            <select class="form-control" onchange="location.href='cetak.php?jenis=<?= $filterJenis ?>&unit_id=<?= $filterUnit ?>&kontrak_id=<?= $kontrak_id ?>&tipe='+this.value">
                <?php foreach(['bulanan'=>'📆 Bulanan','tahunan'=>'📊 Tahunan'] as $jv=>$jl): ?>
                <option value="<?= $jv ?>" <?= $tipe==$jv?'selected':'' ?>><?= $jl ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php if($tipe=='tahunan'):
            // Daftar tahun dari data kontrak yang ada + tahun berjalan, biar tidak perlu ketik angka.
            $tahunList = dbAll($db, "SELECT DISTINCT tahun FROM kontrak WHERE tahun IS NOT NULL ORDER BY tahun DESC");
            $tahunOptions = array_column($tahunList, 'tahun');
            if (!in_array((int)date('Y'), $tahunOptions, true)) array_unshift($tahunOptions, (int)date('Y'));
        ?>
        <div class="form-group" style="min-width:110px;margin:0;">
            <label>Tahun</label>
            <select class="form-control" onchange="location.href='cetak.php?jenis=<?= $filterJenis ?>&unit_id=<?= $filterUnit ?>&kontrak_id=<?= $kontrak_id ?>&tipe=tahunan&tahun='+this.value">
                <?php foreach($tahunOptions as $ty): ?>
                <option value="<?= $ty ?>" <?= $tahun_filter==$ty?'selected':'' ?>><?= $ty ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        <a href="cetak.php?tipe=<?= $tipe ?>&jenis=<?= $filterJenis ?>&unit_id=<?= $filterUnit ?>&kontrak_id=<?= $kontrak_id ?><?= $qTahun ?>&print=1" target="_blank" class="btn btn-primary">🖨️ Cetak / Simpan PDF</a>
        <?php $excelUrl = ($tipe === 'tahunan')
            ? 'export_laporan_tahunan.php?kontrak_id=' . $kontrak_id . '&tahun=' . $tahun_filter
            : 'export_excel.php?kontrak_id=' . $kontrak_id; ?>
        <a href="<?= $excelUrl ?>" class="btn btn-outline" style="border-color:#1D6F42;color:#1D6F42;"><i class="bi bi-file-earmark-excel"></i> Export Excel</a>
        <a href="cetak.php?tipe=<?= $tipe ?>&jenis=<?= $filterJenis ?>&unit_id=<?= $filterUnit ?><?= $qTahun ?>" class="btn btn-outline">☰ Ganti Kontrak</a>
        <a href="rekap_sla.php?kontrak_id=<?= $kontrak_id ?>" class="btn btn-outline">← Kembali</a>
    </div>
    <?php endif; ?>
    </div>
</div>

<?php endif; ?>

<?php if (!$kontrak): ?>
<?php if ($filterUnit !== ''): ?>
<?php renderKontrakListCard($sel, 'cetak.php', $selOpt + ['extra' => $selExtra, 'btnLabel' => 'Pilih']); ?>
<?php else: ?>
<div class="card">
    <div style="text-align:center;padding:40px;">
        <div style="font-size:48px;">🖨️</div>
        <div style="font-size:16px;font-weight:700;color:var(--pln-blue);margin-top:12px;">Pilih Bidang dan Project untuk mencetak laporan SLA</div>
    </div>
</div>
<?php endif; ?>

<?php elseif ($tipe == 'tahunan'): ?>
<!-- ============== LAPORAN TAHUNAN ============== -->
<?php
$tahunRows = dbAll($db, "SELECT k.*, r.sla_teknis, r.sla_k3, r.sla_kecelakaan, r.sla_ilp, r.sla_overall
    FROM kontrak k LEFT JOIN rekap_sla r ON r.kontrak_id=k.id
    WHERE k.nama_kontrak=? AND k.tahun=? ORDER BY k.id ASC", [$kontrak['nama_kontrak'], $tahun_filter]);
$bulanUrut = ['JANUARI','FEBRUARI','MARET','APRIL','MEI','JUNI','JULI','AGUSTUS','SEPTEMBER','OKTOBER','NOVEMBER','DESEMBER'];
usort($tahunRows, fn($a,$b) => array_search($a['periode_bulan'],$bulanUrut) <=> array_search($b['periode_bulan'],$bulanUrut));
?>
<div class="print-header">
    <div style="font-size:16px;font-weight:900;margin-bottom:4px;">PT PLN NUSA DAYA</div>
    <div style="font-size:13px;font-weight:700;">LAPORAN TAHUNAN SLA</div>
    <div style="font-size:13px;"><?= htmlspecialchars((string)($kontrak['nama_kontrak'] ?? '')) ?> — TAHUN <?= $tahun_filter ?></div>
    <hr style="margin:10px 0;">
</div>
<div class="card">
    <div class="card-header"><div class="card-title">Tren SLA Bulanan — <?= htmlspecialchars((string)($kontrak['nama_kontrak'] ?? '')) ?> Tahun <?= $tahun_filter ?></div></div>
    <?php if (empty($tahunRows)): ?>
    <div class="alert alert-info">Belum ada data kontrak/rekap untuk project dan tahun ini.</div>
    <?php else: ?>
    <div class="table-wrap">
    <table>
        <thead><tr><th>Periode Bulan</th><th>Tahap</th><th>SLA Teknis</th><th>SLA K3</th><th>SLA Kecelakaan</th><th>SLA ILP</th></tr></thead>
        <tbody>
        <?php foreach($tahunRows as $r): ?>
        <tr>
            <td><?= htmlspecialchars((string)($r['periode_bulan'] ?? '')) ?></td>
            <td><?= htmlspecialchars((string)($r['tahap'] ?? '')) ?></td>
            <td><?= number_format($r['sla_teknis']??0,2) ?>%</td>
            <td><?= number_format($r['sla_k3']??0,2) ?>%</td>
            <td><?= number_format($r['sla_kecelakaan']??0,2) ?>%</td>
            <td><?= number_format($r['sla_ilp']??0,2) ?>%</td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
</div>

<?php else: // tipe == 'bulanan' (laporan asli, default) ?>
<!-- ============== LAPORAN BULANAN ============== -->
<?php if($kontrak && $rekap):
    $teknis_entries = getCatEntries2($db, $kontrak_id, 'TEKNIS');
    $k3_entries = getCatEntries2($db, $kontrak_id, 'K3');
    $kel_entries = getCatEntries2($db, $kontrak_id, 'KECELAKAAN');
    $ilp_entries = getCatEntries2($db, $kontrak_id, 'ILP');
    $tagihan_total = ($kontrak['nilai_tagihan_tahap1']??0)+($kontrak['nilai_tagihan_tahap2']??0);
?>

<!-- Print Header -->
<div class="print-header">
    <div style="font-size:16px;font-weight:900;margin-bottom:4px;">PT PLN NUSA DAYA</div>
    <div style="font-size:13px;font-weight:700;">SERVICE LEVEL AGREEMENT (SLA)</div>
    <div style="font-size:13px;"><?= htmlspecialchars((string)($kontrak['nama_kontrak'] ?? '')) ?></div>
    <div style="font-size:12px;">PERIODE BULAN <?= strtoupper($kontrak['periode_bulan']) ?> <?= $kontrak['tahun'] ?> - <?= $kontrak['tahap'] ?></div>
    <hr style="margin:10px 0;">
</div>

<!-- Info Kontrak -->
<div class="card">
    <div class="card-header">
        <div class="card-title">📋 SERVICE LEVEL AGREEMENT (SLA)</div>
    </div>
    <dl class="info-list">
        <div class="info-row"><dt>Nama Pekerjaan</dt><dd><?= htmlspecialchars((string)($kontrak['nama_kontrak'] ?? '')) ?></dd></div>
        <div class="info-row"><dt>Pelaksana</dt><dd><?= htmlspecialchars((string)($kontrak['vendor'] ?? '')) ?></dd></div>
        <div class="info-row"><dt>Periode</dt><dd><?= htmlspecialchars(strtoupper((string)($kontrak['periode_bulan'] ?? '')) . ' ' . ($kontrak['tahun'] ?? '') . ' - ' . ($kontrak['tahap'] ?? '')) ?></dd></div>
    </dl>
</div>

<!-- Ringkasan SLA -->
<div class="card">
    <div class="card-header"><div class="card-title">Ringkasan Nilai SLA</div></div>
    <div class="table-wrap">
    <table>
        <thead>
            <tr><th>No</th><th>SLA</th><th>Jumlah SLA (%)</th><th>Jumlah Nilai Bobot</th></tr>
        </thead>
        <tbody>
            <tr><td>1</td><td>Teknis</td><td><?= number_format($rekap['sla_teknis']??0,2) ?>%</td><td><?= number_format(($rekap['sla_teknis']??0)/100*2200,2) ?></td></tr>
            <tr><td>2</td><td>K3 (Keselamatan dan Kesehatan Kerja)</td><td><?= number_format($rekap['sla_k3']??0,2) ?>%</td><td><?= number_format(($rekap['sla_k3']??0)/100*1200,2) ?></td></tr>
            <tr><td>3</td><td>Kecelakaan Kerja</td><td><?= number_format($rekap['sla_kecelakaan']??0,2) ?>%</td><td><?= number_format(($rekap['sla_kecelakaan']??0)/100*200,2) ?></td></tr>
            <tr><td>4</td><td>ILP (Integritas Layanan Publik)</td><td><?= number_format($rekap['sla_ilp']??0,2) ?>%</td><td><?= number_format(($rekap['sla_ilp']??0)/100*300,2) ?></td></tr>
            <tr style="font-weight:800;background:#f0f4ff;"><td colspan="2">TOTAL</td>
                <td><?= number_format(rekapOverallPct($rekap),2) ?>%</td>
                <td><?= number_format($rekap['total_bobot']??0,2) ?></td>
            </tr>
        </tbody>
    </table>
    </div>
</div>

<?php 
$katGroups = [
    ['TEKNIS','A. SLA TEKNIS',$teknis_entries],
    ['K3','B. SLA K3 (Keselamatan dan Kesehatan Kerja)',$k3_entries],
    ['KECELAKAAN','C. Kecelakaan Kerja',$kel_entries],
    ['ILP','D. Integritas Layanan Publik (ILP)',$ilp_entries],
];
$pct_fields = ['TEKNIS'=>'sla_teknis','K3'=>'sla_k3','KECELAKAAN'=>'sla_kecelakaan','ILP'=>'sla_ilp'];
foreach($katGroups as [$kat,$lbl,$entries]):
    if(empty($entries)) {
        echo '<div class="card"><div class="card-header"><div class="card-title">' . $lbl . '</div></div>'
           . '<div style="padding:12px 18px;font-size:12px;color:var(--text-light);">Belum ada indikator pada kategori ini (level Rekap Gabungan).</div></div>';
        continue;
    }
    $entriesDinilai = array_values(array_filter($entries, fn($e) => $e['persen_pencapaian'] !== null));
    $totalBobot = array_sum(array_column($entriesDinilai,'nilai_bobot'));
    $avgPct = (float)($rekap[$pct_fields[$kat]]??0);
?>
<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title"><?= $lbl ?></div>
            <div class="card-subtitle"><?= count($entries) ?> indikator &bull; Rata-rata pencapaian: <b><?= number_format($avgPct,2) ?>%</b></div>
        </div>
        <div style="font-size:22px;font-weight:900;color:<?= $avgPct>=90?'var(--pln-green)':($avgPct>=70?'#b8970a':'var(--pln-red)') ?>">
            <?= number_format($avgPct,2) ?>%
        </div>
    </div>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th style="width:28px;">#</th>
                <th>Ruang Lingkup</th>
                <th>Kriteria / Kinerja</th>
                <th>Satuan</th>
                <th>Polaritas</th>
                <th>Target</th>
                <th>Realisasi</th>
                <th>% Pencapaian</th>
            </tr>
        </thead>
        <tbody>
        <?php $no=1; foreach($entries as $e):
            $pct = $e['persen_pencapaian'] !== null ? (float)$e['persen_pencapaian'] : null;
        ?>
        <tr>
            <td><?= $no++ ?></td>
            <td>
                <div style="font-size:12px;font-weight:700;"><?= htmlspecialchars((string)($e['ruang_lingkup'] ?? '')) ?></div>
                <div style="font-size:10px;color:var(--text-light);">No. <?= htmlspecialchars((string)($e['no_urut'] ?? '')) ?></div>
            </td>
            <td style="font-size:12px;"><?= htmlspecialchars((string)($e['kriteria'] ?? '')) ?></td>
            <td><?= htmlspecialchars((string)($e['satuan'] ?? '')) ?></td>
            <td>
                <span class="badge <?= $e['polaritas']=='Positif'?'badge-positif':'badge-negatif' ?>"><?= htmlspecialchars((string)($e['polaritas'] ?? '')) ?></span>
            </td>
            <td><?= number_format($e['target'],2) ?></td>
            <td><?= $e['realisasi'] !== null ? number_format($e['realisasi'],2) : '-' ?></td>
            <td>
                <?php if ($pct === null): ?>
                <span class="badge belum-dinilai-badge" style="background:#f1f5f9;color:#94a3b8;border:1px solid #e2e8f0;white-space:nowrap;">Belum Dinilai</span>
                <?php else: ?>
                <div class="progress-bar"><div class="progress-fill calc-pct-bar <?= pctColorCetak($pct) ?>" style="width:<?= min(100,max(0,$pct)) ?>%"></div></div>
                <div class="progress-label calc-pct <?= pctColorCetak($pct) ?>"><?= number_format($pct,2) ?>%</div>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</div>
<?php endforeach; ?>

<!-- TTD -->
<div class="card">
    <table style="width:100%;border:none;">
        <tr>
            <td style="width:50%;padding:16px;text-align:center;vertical-align:top;">
                <div style="font-size:12px;">Pelaksana Pekerjaan</div>
                <div style="font-size:12px;font-weight:700;">PT PLN NUSA DAYA</div>
                <div style="font-size:12px;">Manager Unit Layanan</div>
                <div style="height:60px;"></div>
                <div style="border-top:1px solid #333;padding-top:6px;font-size:12px;">___________________</div>
            </td>
            <td style="width:50%;padding:16px;text-align:center;vertical-align:top;">
                <div style="font-size:12px;">Pengawas Pekerjaan</div>
                <div style="font-size:12px;">Manager</div>
                <div style="height:60px;"></div>
                <div style="border-top:1px solid #333;padding-top:6px;font-size:12px;">___________________</div>
            </td>
        </tr>
    </table>
</div>

<div style="margin-top:16px;text-align:right;font-size:11px;color:var(--text-light);" class="no-print">
    Dicetak: <?= date('d/m/Y H:i:s') ?> | Sistem Monitoring SLA PT PLN Nusa Daya
</div>

<?php else: ?>
<div class="alert alert-info">Kontrak ini belum punya data rekap SLA. Silakan input realisasi SLA terlebih dahulu.</div>
<?php endif; ?>

<?php endif; ?>

<?php if ($printMode): ?>
<script>window.addEventListener('load', function () { setTimeout(function () { window.print(); }, 500); });</script>
</body></html>
<?php else: include 'includes/footer.php'; endif; ?>