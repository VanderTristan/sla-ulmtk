<?php
/**
 * export_detail_perhitungan.php — Export halaman "Detail Perhitungan SLA" ke .xlsx.
 * Parameter: kontrak_id (wajib), ulp_id (opsional: '' semua, 'gabungan', atau id ULP).
 * Berisi rumus yang dipakai untuk tiap indikator, sama dengan yang tampil di layar.
 */
require_once 'includes/database.php';
require_once 'includes/xlsx_writer.php';

$db = getDB();
requireReportAccess();

$kontrak_id = (int)($_GET['kontrak_id'] ?? 0);
$ulp_filter = (string)($_GET['ulp_id'] ?? '');
if (!$kontrak_id) { http_response_code(400); die('Parameter kontrak_id wajib diisi.'); }
$kontrak = dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$kontrak_id]);
if (!$kontrak) { http_response_code(404); die('Kontrak tidak ditemukan.'); }

$sql  = "SELECT e.*, u.nama_ulp FROM sla_entries e LEFT JOIN ulp u ON e.ulp_id = u.id WHERE e.kontrak_id=?";
$bind = [$kontrak_id];
if ($ulp_filter === 'gabungan') {
    $sql .= " AND e.ulp_id IS NULL";
} elseif ($ulp_filter !== '' && ctype_digit($ulp_filter)) {
    $sql .= " AND e.ulp_id=?"; $bind[] = (int)$ulp_filter;
}
$sql .= " ORDER BY e.kategori, e.no_urut, e.ulp_id";
$entries = dbAll($db, $sql, $bind);

$data = [['No', 'Kategori', 'No. Urut', 'ULP', 'Ruang Lingkup', 'Indikator', 'Polaritas', 'Satuan', 'Target', 'Realisasi', 'Bobot', '% Pencapaian', 'Nilai Bobot', 'Rumus % Pencapaian', 'Rumus Nilai Bobot']];
$no = 1;
foreach ($entries as $e) {
    $belum = $e['realisasi'] === null || $e['persen_pencapaian'] === null;
    $pol = (string)($e['polaritas'] ?? '');
    $target = (float)($e['target'] ?? 0);
    $bobot = (float)($e['bobot'] ?? 0);
    $data[] = [
        $no++,
        (string)($e['kategori'] ?? ''),
        (string)($e['no_urut'] ?? ''),
        $e['ulp_id'] ? (string)($e['nama_ulp'] ?? '') : 'Gabungan',
        (string)($e['ruang_lingkup'] ?? ''),
        (string)($e['kriteria'] ?? ''),
        $pol,
        (string)($e['satuan'] ?? ''),
        $target,
        $e['realisasi'] === null ? 'Belum diisi' : (float)$e['realisasi'],
        $bobot,
        $belum ? 'Belum dinilai' : round((float)$e['persen_pencapaian'], 2),
        $belum ? 'Belum dinilai' : round((float)$e['nilai_bobot'], 2),
        $belum ? '' : formulaPencapaian($pol, $target, (float)$e['realisasi'], (float)$e['persen_pencapaian']),
        $belum ? '' : formulaNilaiBobot((float)$e['persen_pencapaian'], $bobot, (float)$e['nilai_bobot']),
    ];
}
if (count($data) === 1) $data[] = ['', 'Tidak ada data indikator', '', '', '', '', '', '', '', '', '', '', '', '', ''];

$ulpLabel = 'Semua';
if ($ulp_filter === 'gabungan') $ulpLabel = 'Gabungan';
elseif ($ulp_filter !== '' && ctype_digit($ulp_filter)) {
    $ulpLabel = (string)(dbVal($db, "SELECT nama_ulp FROM ulp WHERE id=? AND kontrak_id=?", [(int)$ulp_filter, $kontrak_id]) ?: $ulp_filter);
}

$xlsx = new SimpleXlsxWriter();
$xlsx->addSheet('Detail Perhitungan', $data, true, [5, 14, 9, 22, 30, 44, 10, 10, 10, 12, 8, 13, 12, 60, 28]);
$xlsx->addSheet('Info', [['Keterangan', 'Nilai'],
    ['Kontrak', (string)($kontrak['nama_kontrak'] ?? '')],
    ['Periode', ucwords(strtolower((string)$kontrak['periode_bulan'])) . ' ' . $kontrak['tahun']],
    ['Tahap', (string)($kontrak['tahap'] ?? '')],
    ['ULP', $ulpLabel],
    ['Diekspor', date('d-m-Y H:i')]], true, [16, 44]);

logAudit($db, 'export', 'detail_perhitungan', "Export Excel Detail Perhitungan kontrak_id=$kontrak_id, ulp=$ulpLabel");
$xlsx->download('Detail_Perhitungan_SLA_' . date('Ymd_His') . '.xlsx');
