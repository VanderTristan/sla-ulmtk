<?php
require_once 'includes/database.php';
require_once 'includes/auth.php';

// Team Leader (Admin): kelola penuh. Manager UL (Monitoring): hanya lihat.
requireKendaraanPersonilAccess();
$canManage = canManageKendaraanPersonil();

$db = getDB();
$title = 'Data Kendaraan';

$act = $_GET['act'] ?? 'list';
$id  = (int)($_GET['id'] ?? 0);

// Manager UL tidak boleh akses form tambah/edit/hapus
if (!$canManage && $act !== 'list') {
    setFlash('danger', 'Akses ditolak. Role Manager UL hanya dapat melihat data kendaraan.');
    header('Location: kendaraan.php'); exit;
}

$kontrakList = dbAll($db, "SELECT id, nama_kontrak, periode_bulan, tahun, tahap, jenis_kontrak FROM kontrak ORDER BY FIELD(jenis_kontrak,'DISTRIBUSI','TRANSMISI','PEMBANGKIT'), nama_kontrak ASC, tahun DESC, FIELD(periode_bulan,'JANUARI','FEBRUARI','MARET','APRIL','MEI','JUNI','JULI','AGUSTUS','SEPTEMBER','OKTOBER','NOVEMBER','DESEMBER') DESC, id DESC");

// Daftar ULP per kontrak (tabel `ulp` — sama persis dengan yang dipakai Input SLA
// di menu Data Kontrak), dikelompokkan per kontrak_id supaya dropdown ULP di form
// tambah/edit bisa langsung menyesuaikan begitu operator memilih Kontrak,
// tanpa perlu reload halaman. Ini yang membuat Data Kendaraan "nyambung" ke ULP
// yang sama dengan Input SLA, bukan sekadar ketikan bebas.
$ulpByKontrak = [];
foreach (dbAll($db, "SELECT id, kontrak_id, nama_ulp FROM ulp ORDER BY nama_ulp") as $u) {
    $ulpByKontrak[(int)$u['kontrak_id']][] = ['id' => (int)$u['id'], 'nama_ulp' => $u['nama_ulp']];
}

// ── DELETE ──────────────────────────────────────────────
if ($act === 'hapus' && $id) {
    if (!$canManage) { http_response_code(403); die('Akses ditolak.'); }
    csrfVerify();
    $old = dbRow($db, "SELECT * FROM kendaraan WHERE id=?", [$id]);
    dbExec($db, "DELETE FROM kendaraan WHERE id=?", [$id]);
    logAudit($db, 'delete', 'kendaraan', "Hapus kendaraan id=$id", $old ?: null, null);
    setFlash('success', '🗑️ Data kendaraan berhasil dihapus.');
    header('Location: kendaraan.php'); exit;
}

// ── SAVE (tambah / update) ─────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$canManage) { http_response_code(403); die('Akses ditolak.'); }
    csrfVerify();
    $fields = [
        'kontrak_id'        => (int)($_POST['kontrak_id'] ?? 0),
        'ulp_id'            => (int)($_POST['ulp_id'] ?? 0) ?: null,
        'jenis_kendaraan'   => trim($_POST['jenis_kendaraan'] ?? '') ?: null,
        'fungsi_kendaraan'  => trim($_POST['fungsi_kendaraan'] ?? ''),
        'merk_type'         => trim($_POST['merk_type'] ?? ''),
        'tahun'             => trim($_POST['tahun'] ?? ''),
        'nomor_polisi'      => trim($_POST['nomor_polisi'] ?? '') ?: null,
        'warna'             => trim($_POST['warna'] ?? ''),
        'lokasi'            => trim($_POST['lokasi'] ?? ''),
        'nama_ulp'          => trim($_POST['nama_ulp'] ?? ''),
        'nama_koordinator'  => trim($_POST['nama_koordinator'] ?? ''),
        'no_hp_koordinator' => trim($_POST['no_hp_koordinator'] ?? ''),
    ];
    // Kalau operator pilih ULP dari dropdown tapi ulp_id ternyata bukan milik
    // kontrak yang dipilih (mis. sempat ganti Kontrak setelah pilih ULP), lepas
    // saja link-nya — nama_ulp yang sudah keisi otomatis tetap dipakai.
    if ($fields['ulp_id'] && !dbVal($db, "SELECT COUNT(*) FROM ulp WHERE id=? AND kontrak_id=?", [$fields['ulp_id'], $fields['kontrak_id']])) {
        $fields['ulp_id'] = null;
    }
    if (!$fields['kontrak_id']) {
        setFlash('danger', 'Kontrak wajib dipilih.');
        header('Location: kendaraan.php?act=' . ($id ? 'edit&id=' . $id : 'tambah')); exit;
    }

    // Cek data double: nomor polisi yang sama (nomor polisi seharusnya unik)
    if ($fields['nomor_polisi'] !== null) {
        $dupKendaraan = (bool)dbVal($db,
            "SELECT COUNT(*) FROM kendaraan WHERE LOWER(TRIM(nomor_polisi))=LOWER(TRIM(?)) AND id<>?",
            [$fields['nomor_polisi'], $id]);
        if ($dupKendaraan) {
            setFlash('danger', "⚠️ Data gagal disimpan: Kendaraan dengan nomor polisi \"{$fields['nomor_polisi']}\" sudah terdaftar.");
            header('Location: kendaraan.php?act=' . ($id ? 'edit&id=' . $id : 'tambah')); exit;
        }
    }

    if ($id) {
        $old = dbRow($db, "SELECT * FROM kendaraan WHERE id=?", [$id]);
        $sets = implode(',', array_map(fn($k) => "$k=?", array_keys($fields)));
        $vals = array_values($fields);
        $vals[] = $id;
        dbExec($db, "UPDATE kendaraan SET $sets WHERE id=?", $vals);
        [$lama, $baru] = diffFields($old ?: [], $fields);
        logAudit($db, 'update', 'kendaraan', "Update kendaraan id=$id", $lama ?: null, $baru ?: null);
        $msg = 'success_update';
    } else {
        $cols = implode(',', array_keys($fields));
        $phs  = implode(',', array_fill(0, count($fields), '?'));
        dbExec($db, "INSERT INTO kendaraan ($cols) VALUES ($phs)", array_values($fields));
        logAudit($db, 'create', 'kendaraan', "Tambah kendaraan: " . $fields['nomor_polisi'], null, $fields);
        $msg = 'success_create';
    }
    setFlash('success', $msg === 'success_create' ? '✅ Data kendaraan berhasil ditambahkan.' : '✅ Data kendaraan berhasil diperbarui.');
    header("Location: kendaraan.php"); exit;
}

$editData = null;
if ($act === 'edit' && $id) {
    $editData = dbRow($db, "SELECT * FROM kendaraan WHERE id=?", [$id]);
}

// ── LIST + FILTER ───────────────────────────────────────
$kontrak_id = (int)($_GET['kontrak_id'] ?? 0);
$q          = trim($_GET['q'] ?? '');

require_once 'includes/kontrak_selector.php';
$sel = kontrakSelectorInit($db, $kontrak_id);

$where  = [];
$params = [];
if ($kontrak_id) {
    $where[] = "k.kontrak_id = ?";
    $params[] = $kontrak_id;
} elseif ($sel['unit'] !== '') {
    // Project dipilih tapi belum memilih kontrak tertentu -> tampilkan data semua kontrak di Project itu
    $pUnit = [];
    $wUnit = ksUnitWhere($sel['jenis'], $sel['unit'], $pUnit);
    $where[] = "k.kontrak_id IN (SELECT id FROM kontrak WHERE $wUnit)";
    $params = array_merge($params, $pUnit);
}
if ($q !== '') {
    $where[] = "(k.merk_type LIKE ? OR k.nomor_polisi LIKE ? OR k.nama_ulp LIKE ? OR u.nama_ulp LIKE ? OR k.nama_koordinator LIKE ? OR k.fungsi_kendaraan LIKE ?)";
    $like = "%$q%";
    array_push($params, $like, $like, $like, $like, $like, $like);
}
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

// COALESCE(u.nama_ulp, k.nama_ulp): kalau kendaraan sudah terhubung ke Data ULP
// (ulp_id terisi), tampilkan nama ULP yang sedang berlaku di sana (ikut ter-update
// otomatis kalau nama ULP-nya diedit) — kalau belum terhubung, tetap pakai teks
// bebas lama supaya data historis tidak "hilang" tampilannya.
$kendaraanList = dbAll($db, "
    SELECT k.*, c.nama_kontrak AS kontrak_nama, c.periode_bulan, c.tahun,
           u.nama_ulp AS ulp_terhubung,
           COALESCE(u.nama_ulp, k.nama_ulp) AS ulp_tampil
    FROM kendaraan k
    JOIN kontrak c ON c.id = k.kontrak_id
    LEFT JOIN ulp u ON u.id = k.ulp_id
    $whereSql
    ORDER BY c.id DESC, ulp_tampil, k.id
", $params);

$totalMobil = 0; $totalMotor = 0;
foreach ($kendaraanList as $row) {
    if (strtoupper((string)$row['jenis_kendaraan']) === 'MOBIL') $totalMobil++;
    elseif (strtoupper((string)$row['jenis_kendaraan']) === 'MOTOR') $totalMotor++;
}

require 'includes/header.php';
?>

<?php if ($act !== 'list'): ?>
<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title"><?= $editData ? '✏️ Edit Kendaraan' : '➕ Tambah Kendaraan' ?></div>
            <div class="card-subtitle">Data unit kendaraan operasional per kontrak</div>
        </div>
        <a href="kendaraan.php" class="btn btn-outline btn-sm">← Kembali</a>
    </div>
    <div class="card-body">
    <form method="POST">
        <?= csrfField() ?>
        <input type="hidden" name="ulp_id" id="ulp_id" value="<?= h((string)($editData['ulp_id'] ?? '')) ?>">
        <div class="form-grid">
            <div class="form-group" style="grid-column:1/-1">
                <label>Kontrak <span style="color:var(--pln-red);">*</span></label>
                <select class="form-control" name="kontrak_id" id="kontrak_id_field" required data-kontrak-picker data-placeholder="-- Pilih Project --">
                    <option value="">-- Pilih Project --</option>
                    <?php foreach ($kontrakList as $k): ?>
                    <option value="<?= $k['id'] ?>" <?= ($editData['kontrak_id'] ?? 0) == $k['id'] ? 'selected' : '' ?> <?= kontrakOptionAttrs($k) ?>>
                        <?= h(kontrakSelectLabel($k)) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="grid-column:1/-1">
                <label>Pilih dari Data ULP kontrak ini (opsional)</label>
                <select class="form-control" id="ulp_picker">
                    <option value="">-- Isi manual / Gabungan --</option>
                </select>
                <div style="font-size:11px;color:var(--text-light);margin-top:4px;">Menyesuaikan otomatis dengan daftar ULP yang dipakai di menu Input SLA untuk kontrak ini. Pilih untuk isi otomatis field "Nama ULP" di bawah (tetap bisa diubah manual). Kelola daftarnya di menu <a href="input_ulp.php" target="_blank">Data ULP</a>.</div>
            </div>
            <div class="form-group">
                <label>Jenis Kendaraan</label>
                <select class="form-control" name="jenis_kendaraan">
                    <?php foreach (['', 'MOBIL', 'MOTOR'] as $opt): ?>
                    <option value="<?= $opt ?>" <?= ($editData['jenis_kendaraan'] ?? '') == $opt ? 'selected' : '' ?>><?= $opt ?: '-- Pilih --' ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Fungsi / Peruntukan</label>
                <input class="form-control" name="fungsi_kendaraan" placeholder="Mis. ROW / Operasional" value="<?= h($editData['fungsi_kendaraan'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Merk / Type</label>
                <input class="form-control" name="merk_type" value="<?= h($editData['merk_type'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Tahun</label>
                <?php
                    $thnKend = (string)($editData['tahun'] ?? '');
                    $thnMax = (int)date('Y') + 1;
                    $thnMin = 1990;
                    if ($thnKend !== '' && ctype_digit($thnKend)) { $thnMin = min($thnMin, (int)$thnKend); $thnMax = max($thnMax, (int)$thnKend); }
                ?>
                <select class="form-control" name="tahun">
                    <option value="">-- Pilih --</option>
                    <?php if ($thnKend !== '' && !ctype_digit($thnKend)): ?>
                    <option value="<?= h($thnKend) ?>" selected><?= h($thnKend) ?></option>
                    <?php endif; ?>
                    <?php for ($ty = $thnMax; $ty >= $thnMin; $ty--): ?>
                    <option value="<?= $ty ?>" <?= (string)$ty === $thnKend ? 'selected' : '' ?>><?= $ty ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="form-group">
                <label>No. Polisi</label>
                <input class="form-control" name="nomor_polisi" placeholder="Mis. B 1809 RZH" value="<?= h($editData['nomor_polisi'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Warna</label>
                <input class="form-control" name="warna" value="<?= h($editData['warna'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Lokasi</label>
                <input class="form-control" name="lokasi" value="<?= h($editData['lokasi'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Nama ULP</label>
                <input class="form-control" name="nama_ulp" id="nama_ulp_field" value="<?= h($editData['nama_ulp'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Koordinator</label>
                <input class="form-control" name="nama_koordinator" value="<?= h($editData['nama_koordinator'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>No. HP Koordinator</label>
                <input class="form-control" name="no_hp_koordinator" value="<?= h($editData['no_hp_koordinator'] ?? '') ?>">
            </div>
        </div>
        <hr class="divider">
        <div style="display:flex;gap:10px;justify-content:flex-end;">
            <a href="kendaraan.php" class="btn btn-outline">Batal</a>
            <button type="submit" class="btn btn-primary">💾 Simpan Kendaraan</button>
        </div>
    </form>
    <script>
    // Data ULP per kontrak (sama dengan sumber Input SLA) untuk mengisi dropdown
    // "Pilih dari Data ULP kontrak ini" secara dinamis begitu Kontrak dipilih,
    // tanpa reload halaman.
    var ulpByKontrak = <?= json_encode($ulpByKontrak, JSON_UNESCAPED_UNICODE) ?>;
    var editUlpId = <?= json_encode((int)($editData['ulp_id'] ?? 0)) ?>;

    function isiPilihanUlp(kontrakId, selectedUlpId) {
        var picker = document.getElementById('ulp_picker');
        picker.innerHTML = '<option value="">-- Isi manual / Gabungan --</option>';
        var list = ulpByKontrak[String(kontrakId)] || [];
        list.forEach(function (u) {
            var opt = document.createElement('option');
            opt.value = u.id;
            opt.textContent = u.nama_ulp;
            if (selectedUlpId && parseInt(selectedUlpId, 10) === u.id) opt.selected = true;
            picker.appendChild(opt);
        });
    }

    document.getElementById('ulp_picker').addEventListener('change', function () {
        var opt = this.options[this.selectedIndex];
        document.getElementById('ulp_id').value = opt.value || '';
        var f = document.getElementById('nama_ulp_field');
        if (opt.value) f.value = opt.textContent;
        f.readOnly = !!opt.value;   // dipilih dari dropdown -> nama dikunci, tidak bisa salah ketik
    });

    document.getElementById('kontrak_id_field').addEventListener('change', function () {
        // Ganti kontrak -> daftar ULP pilihan berubah, link ULP lama dilepas
        // (nama_ulp yang sudah keisi manual tidak dihapus).
        document.getElementById('ulp_id').value = '';
        isiPilihanUlp(this.value, null);
        document.getElementById('nama_ulp_field').readOnly = false;
    });

    // Render awal (mode edit: tampilkan daftar ULP kontrak yang sedang dipakai,
    // dengan ULP yang sudah terhubung otomatis terpilih).
    isiPilihanUlp(document.getElementById('kontrak_id_field').value, editUlpId);
    if (editUlpId) document.getElementById('nama_ulp_field').readOnly = true;
    </script>
    </div>
</div>

<?php else: ?>

<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title"><i class="bi bi-truck"></i> Data Kendaraan</div>
            <div class="card-subtitle">
                Total <?= count($kendaraanList) ?> unit
                (<span class="badge badge-info"><?= $totalMobil ?> Mobil</span>
                 <span class="badge badge-purple"><?= $totalMotor ?> Motor</span>)
            </div>
        </div>
        <?php if ($canManage): ?>
        <a href="kendaraan.php?act=tambah" class="btn btn-primary">+ Tambah Kendaraan</a>
        <?php else: ?>
        <span class="badge badge-info" style="padding:6px 12px;font-size:12px;"><i class="bi bi-eye"></i> Mode Lihat Saja</span>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <?php renderKontrakSelectorFields($sel, 'kendaraan.php', ['btnLabel' => 'Lihat Kendaraan']); ?>
        <div style="height:14px;"></div>
        <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
            <?php foreach (["jenis" => $sel["jenis"] !== "ALL" ? $sel["jenis"] : "", "unit_id" => $sel["unit"], "kontrak_id" => $kontrak_id ?: ""] as $hn => $hv): if ($hv === "") continue; ?>
            <input type="hidden" name="<?= $hn ?>" value="<?= h((string)$hv) ?>">
            <?php endforeach; ?>
            <div class="form-group" style="flex:1;min-width:220px;">
                <label>Cari (merk, no. polisi, ULP, koordinator, fungsi)</label>
                <input class="form-control" type="text" name="q" value="<?= h($q) ?>" placeholder="Mis. TONDANO / B 1809 RZH / ROW">
            </div>
            <div class="form-group">
                <button class="btn btn-primary" type="submit"><i class="bi bi-search"></i> Cari</button>
                <a href="kendaraan.php" class="btn btn-outline">Reset</a>
            </div>
        </form>
    </div>
</div>

<?php renderKontrakListCard($sel, 'kendaraan.php', ['btnLabel' => 'Lihat Kendaraan']); ?>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Kontrak</th>
                    <th>Jenis</th>
                    <th>Fungsi / Peruntukan</th>
                    <th>Merk / Type</th>
                    <th>Tahun</th>
                    <th>No. Polisi</th>
                    <th>Warna</th>
                    <th>Lokasi</th>
                    <th>Nama ULP</th>
                    <th>Koordinator</th>
                    <th>No. HP</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($kendaraanList as $i => $r):
                    $jenis = strtoupper((string)$r['jenis_kendaraan']);
                    $jenisClass = $jenis === 'MOBIL' ? 'badge-info' : ($jenis === 'MOTOR' ? 'badge-purple' : 'badge-warning');
                ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td style="font-size:11px;"><?= h($r['kontrak_nama'] ?? '-') ?><br><span style="color:var(--gray-400);"><?= h($r['periode_bulan']) ?> <?= $r['tahun'] ?></span></td>
                    <td><span class="badge <?= $jenisClass ?>"><?= h($r['jenis_kendaraan'] ?? '-') ?></span></td>
                    <td><?= h($r['fungsi_kendaraan'] ?? $r['peruntukan'] ?? '-') ?></td>
                    <td><?= h($r['merk_type'] ?? '-') ?></td>
                    <td><?= h($r['tahun'] ?? '-') ?></td>
                    <td><b><?= h($r['nomor_polisi'] ?? '-') ?></b></td>
                    <td><?= h($r['warna'] ?? '-') ?></td>
                    <td><?= h($r['lokasi'] ?? '-') ?></td>
                    <td>
                        <?= h($r['ulp_tampil'] ?? '-') ?>
                        <?php if ($r['ulp_terhubung']): ?>
                        <br><span class="badge badge-success" style="font-size:9px;">🔗 Data ULP</span>
                        <?php endif; ?>
                    </td>
                    <td><?= h($r['nama_koordinator'] ?? '-') ?></td>
                    <td><?= h((string)($r['no_hp_koordinator'] ?? '-')) ?></td>
                    <td>
                        <?php if ($canManage): ?>
                        <div class="aksi-btn-group">
                            <a href="kendaraan.php?act=edit&id=<?= $r['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="#" onclick="confirmDelete('<?= csrfUrl('kendaraan.php?act=hapus&id=' . $r['id']) ?>','kendaraan ini')" class="btn btn-danger btn-sm">Hapus</a>
                        </div>
                        <?php else: ?>
                        <span style="color:var(--gray-400);font-size:12px;">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($kendaraanList)): ?>
                <tr><td colspan="13" style="text-align:center;color:var(--gray-400);padding:24px;">Tidak ada data kendaraan yang cocok.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php require 'includes/footer.php'; ?>