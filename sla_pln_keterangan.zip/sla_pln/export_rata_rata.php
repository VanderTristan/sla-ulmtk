<?php
/**
 * export_rata_rata.php — Export halaman "Rata-Rata SLA" (rata_rata.php) ke .xlsx.
 *   - Sheet "Trend Bulanan"     : rekap SLA semua kontrak (selalu ada)
 *   - Sheet "Per ULP"           : bila kontrak_id dipilih
 *   - Sheet "Rata-Rata Indikator": bila kontrak_id dipilih
 * Contoh URL: export_rata_rata.php?kontrak_id=6
 */
require_once 'includes/database.php';
require_once 'includes/xlsx_writer.php';

$db = getDB();
requireReportAccess();

$kontrak_id = (int)($_GET['kontrak_id'] ?? 0);
$kontrak = $kontrak_id ? dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$kontrak_id]) : null;
if ($kontrak_id && !$kontrak) { http_response_code(404); die('Kontrak tidak ditemukan.'); }

$r2 = fn($v) => $v === null ? '' : round((float)$v, 2);
$xlsx = new SimpleXlsxWriter();

// Ringkasan filter
$info = [['Keterangan', 'Nilai'],
    ['Laporan', 'Rata-Rata SLA'],
    ['Kontrak', $kontrak ? (string)($kontrak['nama_kontrak'] ?? '') : 'Semua (trend)'],
    ['Periode', $kontrak ? ucwords(strtolower((string)$kontrak['periode_bulan'])) . ' ' . $kontrak['tahun'] : '-'],
    ['Diekspor', date('d-m-Y H:i')]];
$xlsx->addSheet('Info', $info, true, [18, 44]);

// Trend bulanan (semua kontrak)
$monthlyRows = dbAll($db, "
    SELECT k.periode_bulan, k.tahun, k.nama_kontrak,
           r.sla_teknis, r.sla_k3, r.sla_kecelakaan, r.sla_ilp, r.sla_overall AS avg_sla
    FROM rekap_sla r JOIN kontrak k ON r.kontrak_id=k.id
    ORDER BY k.tahun, k.id");
$trend = [['No', 'Kontrak', 'Periode', 'SLA Teknis (%)', 'SLA K3 (%)', 'SLA Kecelakaan (%)', 'SLA ILP (%)', 'Rata-Rata SLA (%)']];
$no = 1;
foreach ($monthlyRows as $m) {
    $trend[] = [$no++, (string)($m['nama_kontrak'] ?? ''), ucwords(strtolower((string)$m['periode_bulan'])) . ' ' . $m['tahun'],
        $r2($m['sla_teknis']), $r2($m['sla_k3']), $r2($m['sla_kecelakaan']), $r2($m['sla_ilp']), $r2($m['avg_sla'])];
}
if (count($trend) === 1) $trend[] = ['', 'Belum ada data rekap SLA', '', '', '', '', '', ''];
$xlsx->addSheet('Trend Bulanan', $trend, true, [5, 36, 16, 15, 12, 18, 12, 17]);

if ($kontrak_id) {
    $cats = ['TEKNIS', 'K3', 'KECELAKAAN', 'ILP'];

    // Per ULP (total berbobot, sama dengan halaman)
    $perUlp = [['No', 'ULP', 'Teknis (%)', 'K3 (%)', 'Kecelakaan (%)', 'ILP (%)', 'Total SLA Berbobot (%)']];
    $no = 1;
    foreach (dbAll($db, "SELECT * FROM ulp WHERE kontrak_id=? ORDER BY nama_ulp", [$kontrak_id]) as $u) {
        $row = [$no++, (string)$u['nama_ulp']];
        $bobotTot = 0.0; $nilaiTot = 0.0;
        foreach ($cats as $cat) {
            $r = dbRow($db, "SELECT SUM(bobot) AS bobot_asli, SUM(nilai_bobot) AS total_bobot FROM sla_entries WHERE kontrak_id=? AND ulp_id=? AND kategori=?", [$kontrak_id, (int)$u['id'], $cat]);
            $b = (float)($r['bobot_asli'] ?? 0); $n = (float)($r['total_bobot'] ?? 0);
            $row[] = $b > 0 ? round($n / $b, 2) : 0;
            $bobotTot += $b; $nilaiTot += $n;
        }
        $row[] = $bobotTot > 0 ? round($nilaiTot / $bobotTot, 2) : 0;
        $perUlp[] = $row;
    }
    if (count($perUlp) === 1) $perUlp[] = ['', 'Kontrak ini belum punya Data ULP', '', '', '', '', ''];
    $xlsx->addSheet('Per ULP', $perUlp, true, [5, 30, 12, 10, 15, 10, 22]);

    // Rata-rata per indikator
    $ind = [['No', 'Kategori', 'Ruang Lingkup', 'Indikator', 'Rata-Rata (%)', 'Min (%)', 'Maks (%)']];
    $no = 1;
    foreach ($cats as $cat) {
        foreach (dbAll($db, "SELECT ruang_lingkup, kriteria, AVG(persen_pencapaian) AS avg_pct, MIN(persen_pencapaian) AS min_pct, MAX(persen_pencapaian) AS max_pct FROM sla_entries WHERE kontrak_id=? AND kategori=? GROUP BY ruang_lingkup, kriteria ORDER BY avg_pct ASC", [$kontrak_id, $cat]) as $r) {
            $ind[] = [$no++, $cat, (string)($r['ruang_lingkup'] ?? ''), (string)($r['kriteria'] ?? ''), $r2($r['avg_pct']), $r2($r['min_pct']), $r2($r['max_pct'])];
        }
    }
    if (count($ind) === 1) $ind[] = ['', '', 'Belum ada data indikator', '', '', '', ''];
    $xlsx->addSheet('Rata-Rata Indikator', $ind, true, [5, 14, 30, 44, 14, 10, 10]);
}

logAudit($db, 'export', 'rata_rata_sla', 'Export Excel Rata-Rata SLA' . ($kontrak_id ? " kontrak_id=$kontrak_id" : ' (trend semua kontrak)'));
$xlsx->download('Rata_Rata_SLA_' . date('Ymd_His') . '.xlsx');
