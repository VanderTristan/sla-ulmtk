<?php
require_once 'includes/database.php';
header('Content-Type: application/json');

// Wajib login untuk semua aksi di endpoint ini (sebelumnya tidak ada pengecekan sama sekali).
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$db = getDB();

switch ($action) {
    case 'hitung_pct':
        $polaritas = $_POST['polaritas'] ?? 'Positif';
        $target = (float)($_POST['target'] ?? 0);
        $realisasi = (float)($_POST['realisasi'] ?? 0);
        $pct = hitungPencapaian($polaritas, $target, $realisasi);
        echo json_encode(['pct' => round($pct, 4), 'nilai_bobot' => round(hitungNilaiBobot(2, $pct), 4)]);
        break;

    case 'get_rekap':
        $kid = (int)($_GET['kontrak_id'] ?? 0);
        $r = dbRow($db, "SELECT * FROM rekap_sla WHERE kontrak_id=?", [$kid]);
        echo json_encode($r ?: ['error' => 'not found']);
        break;

    case 'update_rekap':
        // Aksi ini mengubah data (recalculate rekap) -> Manager UL (Monitoring) tidak boleh, sama seperti halaman input lainnya.
        if (isSupervisor()) {
            http_response_code(403);
            echo json_encode(['error' => 'forbidden']);
            break;
        }
        $kid = (int)($_POST['kontrak_id'] ?? 0);
        if ($kid) {
            updateRekapSLA($kid);
            $r = dbRow($db, "SELECT * FROM rekap_sla WHERE kontrak_id=?", [$kid]);
            echo json_encode(['ok' => true, 'rekap' => $r]);
        } else {
            echo json_encode(['error' => 'invalid kontrak_id']);
        }
        break;

    case 'dashboard_stats':
        $stats = [
            'total_kontrak' => dbVal($db, "SELECT COUNT(*) FROM kontrak"),
            'total_ulp' => dbVal($db, "SELECT COUNT(*) FROM ulp"),
            'avg_sla_teknis' => dbVal($db, "SELECT AVG(sla_teknis) FROM rekap_sla"),
        ];
        echo json_encode($stats);
        break;

    case 'sla_detail':
        // Detail lengkap 1 kontrak SLA (dipakai oleh modal "Detail SLA" di Dashboard).
        $kid = (int)($_GET['kontrak_id'] ?? 0);
        $kontrak = $kid ? dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$kid]) : null;
        if (!$kontrak) {
            http_response_code(404);
            echo json_encode(['error' => 'Kontrak tidak ditemukan']);
            break;
        }
        $rekap = dbRow($db, "SELECT * FROM rekap_sla WHERE kontrak_id=?", [$kid]);
        $entriesAll = dbAll($db, "SELECT * FROM sla_entries WHERE kontrak_id=? AND ulp_id IS NULL ORDER BY kategori, no_urut", [$kid]);
        $byKat = [];
        foreach ($entriesAll as $e) {
            $belumDinilai = $e['persen_pencapaian'] === null;
            $byKat[$e['kategori']][] = [
                'ruang_lingkup' => $e['ruang_lingkup'],
                'kriteria' => $e['kriteria'],
                'target_kinerja' => $e['target_kinerja'],
                'satuan' => $e['satuan'],
                'polaritas' => $e['polaritas'],
                'bobot' => (float)$e['bobot'],
                'target' => (float)$e['target'],
                'realisasi' => $belumDinilai ? null : (float)$e['realisasi'],
                'persen_pencapaian' => $belumDinilai ? null : round((float)$e['persen_pencapaian'], 2),
                'nilai_bobot' => $belumDinilai ? null : round((float)$e['nilai_bobot'], 2),
                'keterangan' => $e['keterangan'] ?? '',
            ];
        }
        $ulpRows = dbAll($db, "SELECT * FROM ulp WHERE kontrak_id=?", [$kid]);
        $ulpSummary = [];
        foreach ($ulpRows as $u) {
            $row = ['nama_ulp' => $u['nama_ulp'], 'manager_pln' => $u['manager_pln'] ?? ''];
            foreach (['TEKNIS','K3','KECELAKAAN','ILP'] as $cat) {
                $r = dbRow($db, "SELECT SUM(bobot) as bobot_asli, SUM(nilai_bobot) as bobot FROM sla_entries WHERE kontrak_id=? AND ulp_id=? AND kategori=? AND realisasi IS NOT NULL", [$kid, $u['id'], $cat]);
                $bobotAsli = (float)($r['bobot_asli'] ?? 0);
                $row[$cat] = $bobotAsli > 0 ? round(((float)($r['bobot'] ?? 0) / $bobotAsli), 2) : 0;
            }
            $ulpSummary[] = $row;
        }
        echo json_encode([
            'ok' => true,
            'kontrak' => [
                'id' => (int)$kontrak['id'],
                'nama_kontrak' => $kontrak['nama_kontrak'],
                'vendor' => $kontrak['vendor'],
                'periode_bulan' => $kontrak['periode_bulan'],
                'tahun' => $kontrak['tahun'],
                'tahap' => $kontrak['tahap'],
                'jenis_kontrak' => $kontrak['jenis_kontrak'] ?? 'DISTRIBUSI',
                'jenis_kontrak_badge' => badgeJenisKontrak($kontrak['jenis_kontrak'] ?? 'DISTRIBUSI'),
            ],
            'rekap' => [
                'sla_teknis' => round((float)($rekap['sla_teknis'] ?? 0), 2),
                'sla_k3' => round((float)($rekap['sla_k3'] ?? 0), 2),
                'sla_kecelakaan' => round((float)($rekap['sla_kecelakaan'] ?? 0), 2),
                'sla_ilp' => round((float)($rekap['sla_ilp'] ?? 0), 2),
                'total_bobot' => round((float)($rekap['total_bobot'] ?? 0), 2),
                'total_pencapaian' => round(rekapOverallPct($rekap), 2),
            ],
            'entries' => $byKat,
            'ulp' => $ulpSummary,
        ]);
        break;

    case 'save_keterangan':
        // Simpan keterangan (alasan belum capai target) untuk satu indikator SLA.
        // Manager UL (Monitoring) hanya boleh melihat laporan, tidak boleh input/ubah data.
        if (isSupervisor()) {
            http_response_code(403);
            echo json_encode(['error' => 'Akses ditolak: role ini hanya boleh melihat laporan.']);
            break;
        }
        $csrfOk = !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '');
        if (!$csrfOk) {
            http_response_code(403);
            echo json_encode(['error' => 'Token keamanan tidak valid. Muat ulang halaman dan coba lagi.']);
            break;
        }
        $entryId = (int)($_POST['entry_id'] ?? 0);
        $keterangan = trim($_POST['keterangan'] ?? '');
        if ($keterangan === '') {
            http_response_code(422);
            echo json_encode(['error' => 'Keterangan wajib diisi, tidak boleh kosong.']);
            break;
        }
        $row = dbRow($db, "SELECT id, kriteria, kontrak_id, persen_pencapaian, polaritas, target FROM sla_entries WHERE id=?", [$entryId]);
        if (!$row) {
            http_response_code(404);
            echo json_encode(['error' => 'Indikator SLA tidak ditemukan']);
            break;
        }
        // Nilai pencapaian yang dipakai untuk menilai: kalau form mengirim realisasi yang sedang diketik
        // (belum disimpan), hitung dari angka itu; kalau tidak, pakai nilai tersimpan.
        // Target live hanya dipercaya untuk Super Admin (satu-satunya yang boleh mengubah Target).
        $pctCek = $row['persen_pencapaian'] !== null ? (float)$row['persen_pencapaian'] : null;
        $rawReal = trim((string)($_POST['realisasi'] ?? ''));
        if ($rawReal !== '' && is_numeric($rawReal)) {
            $targetCek = (float)$row['target'];
            if (isSuperAdmin() && isset($_POST['target']) && is_numeric($_POST['target'])) {
                $targetCek = (float)$_POST['target'];
            }
            $pctCek = hitungPencapaian((string)$row['polaritas'], $targetCek, (float)$rawReal);
        } elseif (array_key_exists('realisasi', $_POST) && $rawReal === '') {
            $pctCek = null; // realisasi dikosongkan = belum dinilai
        }
        if ($pctCek === null || round($pctCek, 2) >= 100) {
            http_response_code(422);
            echo json_encode(['error' => 'Keterangan hanya untuk indikator yang belum mencapai target (< 100%). Indikator ini sudah ≥ 100% atau belum dinilai, jadi keterangan dikunci.']);
            break;
        }
        dbExec($db, "UPDATE sla_entries SET keterangan=? WHERE id=?", [$keterangan, $entryId]);
        logAudit($db, 'update', 'sla_entries',
            'Isi keterangan indikator SLA: ' . mb_strimwidth((string)($row['kriteria'] ?? "#$entryId"), 0, 40, '…') . ' (kontrak_id=' . $row['kontrak_id'] . ')');
        echo json_encode(['ok' => true, 'keterangan' => $keterangan]);
        break;

    default:
        echo json_encode(['error' => 'unknown action']);
}
?>
