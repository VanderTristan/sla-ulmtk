<?php
/**
 * laporan_grafik.php
 *
 * "Laporan Grafik" — kumpulan grafik siap presentasi untuk manajemen:
 *   1. SLA per Bulan
 *   2. SLA per ULP
 *   3. SLA per Vendor
 *   4. Pencapaian tiap Indikator
 *
 * Bisa difilter berdasarkan Tahun dan Jenis Kontrak supaya presentasi
 * bisa difokuskan ke lingkup tertentu. Akses sama seperti halaman Laporan lain
 * (requireReportAccess) — Petugas/Koordinator tidak bisa akses, hanya input data.
 */
require_once 'includes/database.php';
requireReportAccess();
$db = getDB();
$title = 'Laporan Grafik';

$tahun = trim($_GET['tahun'] ?? '');
$jenis = trim($_GET['jenis'] ?? '');

// Pilih Unit — muncul setelah Bidang dipilih, SAMA seperti cara mencari
// project di halaman Input SLA, supaya cara filternya konsisten.
$unitId = trim($_GET['unit_id'] ?? '');
if ($jenis === '') $unitId = ''; // unit tidak relevan kalau Bidang belum dipilih
$unitOptions = ($jenis !== '') ? getUnitKerjaList($db, $jenis) : [];
if ($unitId !== '' && $unitId !== 'none') {
    $validUnitIds = array_column($unitOptions, 'id');
    if (!in_array((int)$unitId, $validUnitIds, true)) $unitId = '';
}

$daftarTahun = dbAll($db, "SELECT DISTINCT tahun FROM kontrak WHERE tahun IS NOT NULL ORDER BY tahun DESC");

// ------------------------------------------------------------
//  Filter dinamis (dipakai bersama oleh beberapa query di bawah)
// ------------------------------------------------------------
$whereParts = [];
$params = [];
if ($tahun !== '') { $whereParts[] = "k.tahun = ?"; $params[] = $tahun; }
if ($jenis !== '') { $whereParts[] = "k.jenis_kontrak = ?"; $params[] = $jenis; }
if ($unitId === 'none') {
    $whereParts[] = "k.unit_id IS NULL";
} elseif ($unitId !== '') {
    $whereParts[] = "k.unit_id = ?"; $params[] = (int)$unitId;
}
$whereSql = $whereParts ? (' AND ' . implode(' AND ', $whereParts)) : '';

// 1) SLA per Bulan
$trendBulanan = dbAll($db, "
    SELECT k.periode_bulan, k.tahun, k.nama_kontrak,
           r.sla_overall AS avg_sla
    FROM rekap_sla r
    JOIN kontrak k ON r.kontrak_id = k.id
    WHERE 1=1 $whereSql
    ORDER BY k.tahun ASC, FIELD(k.periode_bulan,'JANUARI','FEBRUARI','MARET','APRIL','MEI','JUNI','JULI','AGUSTUS','SEPTEMBER','OKTOBER','NOVEMBER','DESEMBER') ASC, k.id ASC
", $params);

// 2) SLA per ULP (rata-rata pencapaian semua indikator per ULP)
$slaPerUlp = dbAll($db, "
    SELECT u.nama_ulp,
           AVG(e.persen_pencapaian) AS avg_pencapaian,
           COUNT(e.id) AS jml_indikator
    FROM sla_entries e
    JOIN ulp u ON e.ulp_id = u.id
    JOIN kontrak k ON u.kontrak_id = k.id
    WHERE 1=1 $whereSql
    GROUP BY u.id, u.nama_ulp
    ORDER BY avg_pencapaian DESC
", $params);

// 3) SLA per Vendor (rata-rata SLA per vendor)
$slaPerVendor = dbAll($db, "
    SELECT k.vendor,
           AVG(r.sla_overall) AS avg_sla,
           COUNT(DISTINCT k.id) AS jml_kontrak
    FROM rekap_sla r
    JOIN kontrak k ON r.kontrak_id = k.id
    WHERE k.vendor IS NOT NULL AND k.vendor != '' $whereSql
    GROUP BY k.vendor
    ORDER BY avg_sla DESC
", $params);

// 5) Pencapaian tiap Indikator (rata-rata persen pencapaian per kriteria, level kontrak)
$pencapaianIndikator = dbAll($db, "
    SELECT e.kategori, e.ruang_lingkup, e.kriteria,
           AVG(e.persen_pencapaian) AS avg_pct
    FROM sla_entries e
    JOIN kontrak k ON e.kontrak_id = k.id
    WHERE e.ulp_id IS NULL $whereSql
    GROUP BY e.kategori, e.ruang_lingkup, e.kriteria
    ORDER BY avg_pct ASC
", $params);

$adaData = !empty($trendBulanan) || !empty($slaPerUlp) || !empty($slaPerVendor) || !empty($pencapaianIndikator);
$kategoriWarna = ['TEKNIS'=>'#0066AE','K3'=>'#F5A623','KECELAKAAN'=>'#e11d48','ILP'=>'#7c3aed'];

include 'includes/header.php';
?>

<div class="card no-print">
    <div class="card-header">
        <div>
            <div class="card-title">📊 Laporan Grafik</div>
            <div class="card-subtitle">Kumpulan grafik siap presentasi untuk manajemen — SLA per bulan, per ULP, per vendor, dan pencapaian tiap indikator</div>
        </div>
        <?php if ($adaData): ?>
        <a href="export_laporan_grafik.php?<?= htmlspecialchars(http_build_query(array_filter(['tahun' => $tahun, 'jenis' => $jenis, 'unit_id' => $unitId], fn($v) => $v !== ''))) ?>" class="btn btn-outline" style="border-color:#1D6F42;color:#1D6F42;white-space:nowrap;"><i class="bi bi-file-earmark-excel"></i> Export Excel</a>
        <?php endif; ?>
    </div>
    <div class="card-body">
    <form method="GET">
    <div class="form-grid">
        <div class="form-group">
            <label>Pilih Bidang</label>
            <select class="form-control" name="jenis" onchange="this.form.submit()">
                <option value="">-- Semua Bidang --</option>
                <option value="DISTRIBUSI" <?= $jenis==='DISTRIBUSI'?'selected':'' ?>>Distribusi</option>
                <option value="TRANSMISI" <?= $jenis==='TRANSMISI'?'selected':'' ?>>Transmisi</option>
                <option value="PEMBANGKIT" <?= $jenis==='PEMBANGKIT'?'selected':'' ?>>Pembangkit</option>
            </select>
        </div>
        <div class="form-group">
            <label>Pilih Unit</label>
            <?php if ($jenis === ''): ?>
            <select class="form-control" disabled style="background:#f1f5f9;cursor:not-allowed;color:#94a3b8;">
                <option>-- Pilih Bidang terlebih dahulu --</option>
            </select>
            <?php else: ?>
            <select class="form-control" name="unit_id" onchange="this.form.submit()">
                <option value="">-- Semua Unit --</option>
                <?php foreach ($unitOptions as $u): ?>
                <option value="<?= $u['id'] ?>" <?= ((string)$unitId === (string)$u['id']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($u['nama']) ?><?= $u['kode'] !== $u['nama'] ? ' (' . htmlspecialchars($u['kode']) . ')' : '' ?>
                </option>
                <?php endforeach; ?>
                <option value="none" <?= $unitId==='none'?'selected':'' ?>>Belum Ditentukan / Tanpa Unit</option>
            </select>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label>Tahun</label>
            <select class="form-control" name="tahun" onchange="this.form.submit()">
                <option value="">-- Semua Tahun --</option>
                <?php foreach ($daftarTahun as $t): ?>
                <option value="<?= $t['tahun'] ?>" <?= $tahun == $t['tahun'] ? 'selected' : '' ?>><?= $t['tahun'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
    </form>
    <div style="display:flex;justify-content:flex-end;margin-top:8px;">
        <button type="button" class="btn btn-outline" onclick="window.print()">🖨️ Cetak / Simpan PDF</button>
    </div>
    </div>
</div>

<?php if (!$adaData): ?>
<div class="card">
    <div style="text-align:center;padding:40px;">
        <div style="font-size:48px;">📊</div>
        <div style="font-size:16px;font-weight:700;color:var(--pln-blue);margin-top:12px;">Belum ada data untuk filter ini</div>
        <div style="color:var(--text-light);margin-top:8px;">Coba ubah filter Tahun/Jenis Kontrak di atas.</div>
    </div>
</div>
<?php else: ?>

<!-- 1. SLA per Bulan -->
<?php if (!empty($trendBulanan)): ?>
<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title"><i class="bi bi-graph-up-arrow" style="color:var(--blue);"></i> 1. SLA per Bulan</div>
            <div class="card-subtitle">Tren rata-rata pencapaian SLA (4 kategori) tiap periode kontrak</div>
        </div>
    </div>
    <div class="card-body"><div class="chart-wrap" style="--chart-h:280px;"><canvas id="chartSlaBulan"></canvas></div></div>
</div>
<?php endif; ?>

<!-- 2. SLA per ULP -->
<?php if (!empty($slaPerUlp)): ?>
<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title"><i class="bi bi-building" style="color:var(--blue);"></i> 2. SLA per ULP</div>
            <div class="card-subtitle">Rata-rata pencapaian seluruh indikator per ULP</div>
        </div>
    </div>
    <div class="card-body"><div class="chart-wrap" style="--chart-h:<?= max(160, min(720, count($slaPerUlp) * 40 + 50)) ?>px;"><canvas id="chartSlaUlp"></canvas></div></div>
</div>
<?php endif; ?>

<!-- 3. SLA per Vendor -->
<?php if (!empty($slaPerVendor)): ?>
<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title"><i class="bi bi-building-gear" style="color:var(--blue);"></i> 3. SLA per Vendor</div>
            <div class="card-subtitle">Rata-rata pencapaian SLA per vendor pelaksana</div>
        </div>
    </div>
    <div class="card-body"><div class="chart-wrap" style="--chart-h:<?= max(160, min(720, count($slaPerVendor) * 40 + 50)) ?>px;"><canvas id="chartSlaVendor"></canvas></div></div>
</div>
<?php endif; ?>

<!-- 4. Pencapaian tiap Indikator -->
<?php if (!empty($pencapaianIndikator)): ?>
<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title"><i class="bi bi-list-check" style="color:var(--blue);"></i> 4. Pencapaian tiap Indikator</div>
            <div class="card-subtitle">Rata-rata pencapaian semua indikator SLA — diurutkan dari yang terendah</div>
        </div>
    </div>
    <div class="card-body"><div class="chart-wrap" style="--chart-h:<?= max(220, min(1600, count($pencapaianIndikator) * 44 + 50)) ?>px;"><canvas id="chartIndikator"></canvas></div></div>
</div>
<?php endif; ?>

<?php
// ── Siapkan data JSON untuk semua chart ──────────────────────
$labelsBulan = []; $avgSlaBulan = [];
foreach ($trendBulanan as $row) {
    $labelsBulan[]  = trim(($row['nama_kontrak'] ?? '') . ' ' . ($row['periode_bulan'] ?? '') . ' ' . ($row['tahun'] ?? ''));
    $avgSlaBulan[]  = round((float)$row['avg_sla'], 2);
}

$labelsUlp = []; $avgUlp = [];
foreach ($slaPerUlp as $row) {
    $labelsUlp[] = $row['nama_ulp'];
    $avgUlp[]    = round((float)$row['avg_pencapaian'], 2);
}

$labelsVendor = []; $avgVendor = [];
foreach ($slaPerVendor as $row) {
    $labelsVendor[] = $row['vendor'];
    $avgVendor[]    = round((float)$row['avg_sla'], 2);
}

$labelsIndikator = []; $avgIndikator = []; $colorIndikator = [];
foreach ($pencapaianIndikator as $row) {
    $labelsIndikator[]  = (string)($row['kriteria'] ?? '');
    $avgIndikator[]     = round((float)$row['avg_pct'], 2);
    $colorIndikator[]   = $kategoriWarna[$row['kategori']] ?? '#64748b';
}

function warnaBar(float $v): string {
    return $v >= 90 ? 'rgba(16,185,129,0.8)' : ($v >= 70 ? 'rgba(245,166,35,0.8)' : 'rgba(220,38,38,0.8)');
}
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script src="assets/js/chart-helpers.js"></script>
<script>
(function(){
    SLAChart.init();

    <?php if (!empty($trendBulanan)): ?>
    // 1. SLA per Bulan
    SLAChart.line(document.getElementById('chartSlaBulan'), {
        labels: <?= json_encode($labelsBulan) ?>,
        datasets: [{ label: 'Rata-rata SLA', data: <?= json_encode($avgSlaBulan) ?>, borderColor: '#0066AE', backgroundColor: 'rgba(0,102,174,0.08)', fill: true }],
        ref: 100
    });
    <?php endif; ?>

    <?php if (!empty($slaPerUlp)): ?>
    // 2. SLA per ULP
    SLAChart.bar(document.getElementById('chartSlaUlp'), {
        labels: <?= json_encode($labelsUlp) ?>,
        datasets: [{ label: 'Rata-rata Pencapaian', data: <?= json_encode($avgUlp) ?>, backgroundColor: <?= json_encode(array_map('warnaBar', $avgUlp)) ?> }],
        horizontal: true, ref: 100
    });
    <?php endif; ?>

    <?php if (!empty($slaPerVendor)): ?>
    // 3. SLA per Vendor
    SLAChart.bar(document.getElementById('chartSlaVendor'), {
        labels: <?= json_encode($labelsVendor) ?>,
        datasets: [{ label: 'Rata-rata SLA', data: <?= json_encode($avgVendor) ?>, backgroundColor: <?= json_encode(array_map('warnaBar', $avgVendor)) ?> }],
        horizontal: true, ref: 100, tickLen: 34
    });
    <?php endif; ?>

    <?php if (!empty($pencapaianIndikator)): ?>
    // 4. Pencapaian tiap Indikator (warna = kategori)
    SLAChart.bar(document.getElementById('chartIndikator'), {
        labels: <?= json_encode($labelsIndikator) ?>,
        datasets: [{ label: 'Rata-rata Pencapaian', data: <?= json_encode($avgIndikator) ?>, backgroundColor: <?= json_encode($colorIndikator) ?>, maxBarThickness: 16 }],
        horizontal: true, ref: 100, tickLen: 40
    });
    <?php endif; ?>
})();
</script>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
