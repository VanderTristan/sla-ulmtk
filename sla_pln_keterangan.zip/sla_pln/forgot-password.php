<?php
/**
 * forgot-password.php
 *
 * Halaman "Lupa Password" — user memasukkan email akunnya, sistem mengirim
 * link reset password (berlaku 60 menit) lewat email kalau email tersebut
 * terdaftar. Pesan yang ditampilkan SELALU sama baik email ditemukan atau
 * tidak, supaya halaman ini tidak bisa dipakai untuk menebak-nebak email
 * mana saja yang terdaftar di sistem (user enumeration).
 */
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/mailer.php';
$db = getDB();

if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$flash = getFlash();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfVerify();
    $email = trim($_POST['email'] ?? '');

    if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) && mailAktif()) {
        $user = dbRow($db, "SELECT id, nama, email FROM app_users WHERE email = ? AND status = 'Aktif' LIMIT 1", [$email]);
        if ($user) {
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+60 minutes'));
            dbExec($db, "UPDATE app_users SET reset_token = ?, reset_token_expires = ? WHERE id = ?", [$token, $expires, $user['id']]);
            kirimEmailResetPassword($user['email'], $user['nama'], $token);
            logAudit($db, 'forgot_password', 'auth', 'Permintaan reset password untuk email ' . $email);
        }
    }

    // Pesan generik — tidak membocorkan apakah email terdaftar atau tidak, dan tidak
    // membocorkan apakah fitur email sedang nonaktif (biar tidak jadi info bocor ke luar).
    setFlash('success', 'Kalau email tersebut terdaftar, link reset password sudah kami kirim. Silakan periksa kotak masuk (dan folder spam) Anda.');
    header('Location: forgot-password.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lupa Password — SLA Monitoring</title>
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16.png">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicon-180.png">
    <link rel="shortcut icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page">
    <div class="login-wrap">
        <div class="login-card">
            <div class="login-brand">
                <img src="assets/img/logo.png" alt="PLN Nusa Daya" style="height:64px;width:auto;object-fit:contain;display:block;margin:0 auto 12px;">
                <div class="login-sub">Lupa Password</div>
            </div>

            <?= renderFlash($flash, 'margin-bottom:16px;') ?>

            <p style="font-size:13px;color:var(--text-light);margin-bottom:16px;">
                Masukkan alamat email akun Anda. Kami akan mengirimkan link untuk mengatur ulang password.
            </p>

            <form method="post" action="forgot-password.php">
                <?= csrfField() ?>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" placeholder="nama@plnnusadaya.co.id" required autofocus>
                </div>
                <button type="submit" class="btn btn-primary">Kirim Link Reset Password</button>
            </form>

            <div class="login-hint"><a href="login.php">&larr; Kembali ke halaman login</a></div>
        </div>
    </div>
</body>
</html>
