<?php
/**
 * backup_database.php
 *
 * ENTRY POINT — BACKUP DATABASE OTOMATIS (dijalankan terjadwal lewat cron)
 * ============================================================================
 * Skrip ini TIDAK perlu dibuka manual sehari-hari — jadwalkan salah satu cara
 * di bawah supaya backup berjalan otomatis. (Tombol "Backup Sekarang" untuk
 * backup manual ada di halaman admin backup.php.)
 *
 * A) VPS / hosting dengan akses SSH (disarankan):
 *      crontab -e
 *    lalu tambahkan baris ini (contoh: backup tiap hari jam 01:00):
 *      0 1 * * * php /path/ke/aplikasi/backup_database.php >> /path/ke/aplikasi/storage/backup/cron.log 2>&1
 *
 * B) Shared hosting / cPanel (fitur "Cron Jobs"), tanpa perlu masuk SSH:
 *      Command   : php -q /home/USERNAME/public_html/backup_database.php
 *      Jadwal    : sesuai kebutuhan, mis. setiap hari jam 01:00
 *
 * C) Hosting yang HANYA punya "Cron via URL" (tidak bisa jalankan file .php lewat CLI):
 *      1. Isi BACKUP_CRON_TOKEN di file .env dengan token rahasia (string acak, panjang).
 *      2. Jadwalkan URL berikut untuk diakses (mis. tiap hari jam 01:00):
 *           https://domain-anda/backup_database.php?token=TOKEN_RAHASIA_ANDA
 *      Tanpa token yang cocok, skrip ini menolak akses lewat browser/URL.
 *
 * Backup lama otomatis dihapus sesuai BACKUP_RETENTION_DAYS di .env (default 30 hari).
 */

require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/backup.php';

$isCli = (php_sapi_name() === 'cli');

if (!$isCli) {
    // Diakses lewat web/URL (opsi C di atas) — WAJIB token rahasia yang cocok dengan .env
    $token    = $_GET['token'] ?? '';
    $expected = getenv('BACKUP_CRON_TOKEN') ?: '';
    if ($expected === '' || !hash_equals($expected, (string)$token)) {
        http_response_code(403);
        header('Content-Type: text/plain; charset=utf-8');
        die("Akses ditolak. Skrip ini hanya bisa dijalankan lewat CLI/cron, atau lewat URL dengan token rahasia yang valid (lihat komentar di awal file ini).\n");
    }
    header('Content-Type: text/plain; charset=utf-8');
}

echo "=== Backup Database Otomatis — SLA PLN Nusa Daya ===\n";
echo 'Waktu mulai : ' . date('Y-m-d H:i:s') . "\n";

try {
    getDB(); // pastikan koneksi & skema tabel siap sebelum backup dijalankan
    $result = createDatabaseBackup();

    if ($result['success']) {
        echo "Status      : BERHASIL\n";
        echo "File        : {$result['file']}\n";
        echo 'Ukuran      : ' . formatUkuranBackup($result['size']) . "\n";
        echo "Metode      : {$result['method']}\n";
    } else {
        echo "Status      : GAGAL\n";
        echo "Pesan       : {$result['message']}\n";
        if (!$isCli) http_response_code(500);
        echo 'Waktu selesai: ' . date('Y-m-d H:i:s') . "\n";
        exit(1);
    }
} catch (Throwable $e) {
    backupLog('GAGAL (exception): ' . $e->getMessage());
    echo "Status      : GAGAL (exception)\n";
    echo 'Pesan       : ' . $e->getMessage() . "\n";
    if (!$isCli) http_response_code(500);
    exit(1);
}

echo 'Waktu selesai: ' . date('Y-m-d H:i:s') . "\n";
exit(0);
