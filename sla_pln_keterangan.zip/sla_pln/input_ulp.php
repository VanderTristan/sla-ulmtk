<?php
require_once 'includes/database.php';
$db = getDB();

// Team Leader (Admin) & Petugas (Viewer/Koordinator): kelola penuh.
// Manager UL (Monitoring): hanya lihat.
requireUlpAccess();
$canManage = canManageUlp();

$title = 'Data ULP';
$kontrak_id = (int)($_GET['kontrak_id'] ?? 0);
require_once 'includes/kontrak_selector.php';
$sel = kontrakSelectorInit($db, $kontrak_id);
$act = $_GET['act'] ?? 'list';
$id  = (int)($_GET['id'] ?? 0);

// Manager UL tidak boleh akses form tambah/edit/hapus
if (!$canManage && $act !== 'list') {
    setFlash('danger', 'Akses ditolak. Role Manager UL hanya dapat melihat data ULP.');
    header("Location: input_ulp.php?kontrak_id=$kontrak_id"); exit;
}

$kontrakList = dbAll($db, "SELECT id, nama_kontrak, periode_bulan, tahun, tahap, jenis_kontrak FROM kontrak ORDER BY FIELD(jenis_kontrak,'DISTRIBUSI','TRANSMISI','PEMBANGKIT'), nama_kontrak ASC, tahun DESC, FIELD(periode_bulan,'JANUARI','FEBRUARI','MARET','APRIL','MEI','JUNI','JULI','AGUSTUS','SEPTEMBER','OKTOBER','NOVEMBER','DESEMBER') DESC, id DESC");

// DELETE
if ($act == 'hapus' && $id) {
    if (!$canManage) { http_response_code(403); die('Akses ditolak.'); }
    csrfVerify();
    dbExec($db, "DELETE FROM ulp WHERE id=?", [$id]);
    logAudit($db, 'delete', 'ulp', "Hapus ULP id=$id");
    setFlash('success', '🗑️ ULP berhasil dihapus.');
    header("Location: input_ulp.php?kontrak_id=$kontrak_id"); exit;
}

// SAVE
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!$canManage) { http_response_code(403); die('Akses ditolak.'); }
    csrfVerify();
    $nama = $_POST['nama_ulp'] ?? '';
    $mgr  = $_POST['manager_pln'] ?? '';
    $kor  = $_POST['koordinator_nd'] ?? '';
    $kid  = (int)($_POST['kontrak_id'] ?? $kontrak_id);
    $ulpMasterId = (int)($_POST['ulp_master_id'] ?? 0) ?: null; // opsional — link ke Master ULP kalau dipilih

    // Cek data double: nama ULP yang sama di kontrak yang sama
    $dupUlp = (bool)dbVal($db,
        "SELECT COUNT(*) FROM ulp WHERE kontrak_id=? AND LOWER(TRIM(nama_ulp))=LOWER(TRIM(?)) AND id<>?",
        [$kid, $nama, $id]);
    if ($dupUlp) {
        setFlash('danger', "⚠️ Data gagal disimpan: ULP dengan nama \"$nama\" sudah ada untuk kontrak ini.");
        header("Location: input_ulp.php?kontrak_id=$kid" . ($id ? "&act=edit&id=$id" : '')); exit;
    }

    if ($id) {
        dbExec($db, "UPDATE ulp SET nama_ulp=?, manager_pln=?, koordinator_nd=?, ulp_master_id=? WHERE id=?",
            [$nama, $mgr, $kor, $ulpMasterId, $id]);
    } else {
        dbExec($db, "INSERT INTO ulp (kontrak_id, nama_ulp, manager_pln, koordinator_nd, ulp_master_id) VALUES (?,?,?,?,?)",
            [$kid, $nama, $mgr, $kor, $ulpMasterId]);
        $new_ulp = (int)$db->lastInsertId();
        // Copy SLA template entries for this ULP
        $templates = dbAll($db, "SELECT * FROM sla_entries WHERE kontrak_id=? AND ulp_id IS NULL", [$kid]);
        $st = $db->prepare("INSERT INTO sla_entries
            (kontrak_id, ulp_id, kategori, no_urut, ruang_lingkup, kriteria,
             target_kinerja, polaritas, satuan, bobot, jenis_bobot,
             target, realisasi, persen_pencapaian, nilai_bobot)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NULL,NULL,NULL)");
        foreach ($templates as $t) {
            $st->execute([$kid, $new_ulp, $t['kategori'], $t['no_urut'],
                $t['ruang_lingkup'], $t['kriteria'], $t['target_kinerja'],
                $t['polaritas'], $t['satuan'], $t['bobot'], $t['jenis_bobot'], $t['target']]);
        }
    }
    setFlash('success', '✅ Data ULP berhasil disimpan.');
    header("Location: input_ulp.php?kontrak_id=$kid"); exit;
}

// List
$ulpList = $kontrak_id
    ? dbAll($db, "SELECT * FROM ulp WHERE kontrak_id=? ORDER BY id", [$kontrak_id])
    : [];

$editData = ($act=='edit' && $id) ? dbRow($db, "SELECT * FROM ulp WHERE id=?", [$id]) : null;
$kontrak  = $kontrak_id ? dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$kontrak_id]) : null;
$ulpMasterList = getUlpMasterList($db);

include 'includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div class="card-title">🏢 Data ULP (Unit Layanan Pelanggan)</div>
    </div>
    <div class="card-body">
    <?php renderKontrakSelectorFields($sel, 'input_ulp.php', ['btnLabel' => 'Kelola ULP']); ?>
    </div>
</div>

<?php renderKontrakListCard($sel, 'input_ulp.php', ['btnLabel' => 'Kelola ULP']); ?>

<?php if($kontrak_id): ?>
<?php if($kontrak): ?>
<div style="background:#e8f0ff;border:1px solid #c5d5ff;border-radius:8px;padding:14px 18px;margin-bottom:20px;font-size:13px;">
    📋 <b><?= htmlspecialchars(mb_strimwidth((string)($kontrak['nama_kontrak'] ?? ''),0,60,'...')) ?></b> &bull;
    <?= $kontrak['periode_bulan'] ?> <?= $kontrak['tahun'] ?>
</div>
<?php endif; ?>

<?php if ($canManage): ?>
<div class="card">
    <div class="card-header">
        <div class="card-title"><?= $editData?'✏️ Edit ULP':'➕ Tambah ULP' ?></div>
    </div>
    <div class="card-body">
    <form method="POST">
        <?= csrfField() ?>
        <input type="hidden" name="kontrak_id" value="<?= $kontrak_id ?>">
        <input type="hidden" name="ulp_master_id" id="ulp_master_id" value="<?= h((string)($editData['ulp_master_id'] ?? '')) ?>">
        <?php if (!empty($ulpMasterList)): ?>
        <div class="form-group" style="margin-bottom:14px;">
            <label>Pilih dari Master ULP (opsional)</label>
            <select class="form-control" id="ulp_master_picker" onchange="isiDariMasterUlp(this)">
                <option value="">-- Isi manual --</option>
                <?php foreach ($ulpMasterList as $m): ?>
                <option value="<?= $m['id'] ?>"
                    data-nama="<?= h($m['nama_ulp']) ?>"
                    data-manager="<?= h($m['manager_pln'] ?? '') ?>"
                    data-koordinator="<?= h($m['koordinator_nd'] ?? '') ?>"
                    <?= (int)($editData['ulp_master_id'] ?? 0) === (int)$m['id'] ? 'selected' : '' ?>>
                    <?= h($m['nama_ulp']) ?>
                </option>
                <?php endforeach; ?>
            </select>
            <div style="font-size:11px;color:var(--text-light);margin-top:4px;">Pilih untuk isi otomatis 3 field di bawah (tetap bisa diubah manual sesudahnya). Kelola daftarnya di menu <a href="ulp_master.php" target="_blank">Master ULP</a>.</div>
        </div>
        <?php endif; ?>
        <div class="form-grid form-grid-3">
            <div class="form-group">
                <label>Nama ULP</label>
                <input class="form-control" name="nama_ulp" id="nama_ulp" required placeholder="ULP TOMOHON"
                    value="<?= htmlspecialchars($editData['nama_ulp'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Manager PLN (Pengawas Lapangan)</label>
                <input class="form-control" name="manager_pln" id="manager_pln" placeholder="Nama Manager"
                    value="<?= htmlspecialchars($editData['manager_pln'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Koordinator PLN ND (Pelaksana)</label>
                <input class="form-control" name="koordinator_nd" id="koordinator_nd" placeholder="Nama Koordinator"
                    value="<?= htmlspecialchars($editData['koordinator_nd'] ?? '') ?>">
            </div>
        </div>
        <div style="margin-top:14px;display:flex;gap:10px;justify-content:flex-end;">
            <?php if($editData): ?><a href="input_ulp.php?kontrak_id=<?= $kontrak_id ?>" class="btn btn-outline">Batal</a><?php endif; ?>
            <button type="submit" class="btn btn-primary">💾 <?= $editData?'Update':'Tambah' ?> ULP</button>
        </div>
    </form>
    <script>
    // Isi 3 field manual dari Master ULP yang dipilih — tetap bisa diedit sesudahnya
    // (bukan field terkunci), dan kalau operator ganti lagi jadi "-- Isi manual --"
    // link ke master-nya dilepas (ulp_master_id dikosongkan) tapi isian field tidak dihapus.
    function isiDariMasterUlp(sel) {
        const opt = sel.options[sel.selectedIndex];
        const hidden = document.getElementById('ulp_master_id');
        const namaField = document.getElementById('nama_ulp');
        if (!opt.value) { hidden.value = ''; namaField.readOnly = false; return; }
        namaField.readOnly = true;   // nama diambil dari Master ULP -> dikunci, tidak bisa salah ketik
        namaField.value = opt.getAttribute('data-nama') || '';
        document.getElementById('manager_pln').value = opt.getAttribute('data-manager') || '';
        document.getElementById('koordinator_nd').value = opt.getAttribute('data-koordinator') || '';
        hidden.value = opt.value;
    }
    // Mode edit: kalau ULP ini sudah terhubung ke Master ULP, namanya langsung terkunci.
    (function () { var p = document.getElementById('ulp_master_picker'); if (p && p.value) document.getElementById('nama_ulp').readOnly = true; })();
    </script>
    </div>
</div>
<?php endif; ?>

<?php if(!empty($ulpList)): ?>
<div class="card">
    <div class="card-header">
        <div class="card-title">Daftar ULP (<?= count($ulpList) ?> ULP)</div>
    </div>
    <div class="table-wrap">
    <table>
        <thead>
            <tr><th>#</th><th>Nama ULP</th><th>Manager PLN</th><th>Koordinator PLN ND</th><th>Aksi</th></tr>
        </thead>
        <tbody>
        <?php foreach($ulpList as $i=>$u): ?>
        <tr>
            <td><?= $i+1 ?></td>
            <td><b><?= htmlspecialchars((string)($u['nama_ulp'] ?? '')) ?></b></td>
            <td><?= htmlspecialchars((string)($u['manager_pln'] ?? '')) ?></td>
            <td><?= htmlspecialchars((string)($u['koordinator_nd'] ?? '')) ?></td>
            <td>
                <?php if ($canManage): ?>
                <div class="aksi-btn-group">
                    <a href="input_sla.php?kontrak_id=<?= $kontrak_id ?>&ulp_id=<?= $u['id'] ?>" class="btn btn-primary btn-sm">Target & Realisasi</a>
                    <a href="input_ulp.php?act=edit&id=<?= $u['id'] ?>&kontrak_id=<?= $kontrak_id ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="#" onclick="confirmDelete('<?= csrfUrl('input_ulp.php?act=hapus&id=' . $u['id'] . '&kontrak_id=' . $kontrak_id) ?>','<?= htmlspecialchars((string)($u['nama_ulp'] ?? '')) ?>')" class="btn btn-danger btn-sm">Hapus</a>
                </div>
                <?php else: ?>
                <span class="text-muted" style="font-size:12px;">Hanya lihat</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</div>
<?php endif; ?>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>