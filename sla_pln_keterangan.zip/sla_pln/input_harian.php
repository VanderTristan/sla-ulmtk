<?php
require_once 'includes/database.php';
requireInputAccess();
$db = getDB();
$title = 'Input SLA';

$bulanValid = ['JANUARI','FEBRUARI','MARET','APRIL','MEI','JUNI','JULI','AGUSTUS','SEPTEMBER','OKTOBER','NOVEMBER','DESEMBER'];

// ------------------------------------------------------------------
// ALUR PILIH DATA: Bidang -> Project (dulu namanya "Unit").
// Setelah Project dipilih, SEMUA kontrak di Project itu langsung tampil sebagai
// daftar; filter Bulan & Tahun di atas daftar hanyalah filter biasa untuk
// mencari kontrak tertentu. Kalau operator perlu mengedit atau mengisi kontrak
// baru, itu dilakukan lewat menu Data Kontrak, bukan di sini.
// Tanggal input SLA yang sebenarnya tetap otomatis tercatat sebagai tanggal
// hari ini saat data disimpan (lihat bagian SAVE di bawah).
// ------------------------------------------------------------------
$kontrak_id = (int)($_GET['kontrak_id'] ?? 0);
// Pemilihan Bidang -> Project -> daftar kontrak memakai komponen bersama
// (sama dengan halaman Rekap SLA, Detail Perhitungan, dst).
require_once 'includes/kontrak_selector.php';
$sel = kontrakSelectorInit($db, $kontrak_id);
$filterJenis  = $sel['jenis'];
$filterUnit   = $sel['unit'];
$unitOptions  = $sel['unitOptions'];
$unitTerpilih = $sel['unitTerpilih'];

// Dipakai hanya untuk tombol "Tahap" (kontrak lain di bulan & tahun yang sama) setelah kontrak dibuka.
$filterBulan = '';
$filterTahun = 0;

$kontrak = null;

if ($kontrak_id) {
    $kontrak = $sel['kontrak'];
    if (!$kontrak) {
        $kontrak_id = 0; // kontrak_id tidak valid / bukan milik Project ini
    } else {
        // Sinkronkan dropdown Bulan/Tahun dengan kontrak yang sedang dibuka
        if (in_array(strtoupper((string)$kontrak['periode_bulan']), $bulanValid, true)) {
            $filterBulan = strtoupper((string)$kontrak['periode_bulan']);
        }
        if (!empty($kontrak['tahun'])) $filterTahun = (int)$kontrak['tahun'];
    }
}

// Tombol Tahap: kontrak lain di bulan & tahun yang sama dengan kontrak yang sedang dibuka.
$kontrakTahapList = [];
if ($kontrak && $filterUnit !== '' && $filterUnit !== 'none') {
    $kontrakTahapList = dbAll($db,
        "SELECT id, tahap FROM kontrak WHERE unit_id=? AND periode_bulan=? AND tahun=? ORDER BY tahap, id",
        [(int)$filterUnit, $filterBulan, $filterTahun]);
}
// Dipakai untuk catatan "kontrak ini punya Data ULP" di bawah — supaya operator yang
// masuk lewat menu Input SLA tahu kalau realisasi per-ULP diisi di tempat lain
// (Data Kontrak > Target & Realisasi), bukan di halaman ini.
$jumlahUlpKontrak = $kontrak_id ? (int)dbVal($db, "SELECT COUNT(*) FROM ulp WHERE kontrak_id=?", [$kontrak_id]) : 0;


// Query string filter aktif, dipakai untuk menjaga pilihan Bidang/Project/Tanggal
// tetap terbawa saat pindah periode atau menyimpan data.
$filterParamsArr = [];
if ($filterJenis !== 'ALL') $filterParamsArr['jenis'] = $filterJenis;
if ($filterUnit !== '') $filterParamsArr['unit_id'] = $filterUnit;
$filterQueryString = $filterParamsArr ? ('&' . http_build_query($filterParamsArr)) : '';

// ------------------------------------------------------------------
// Input SLA HANYA boleh 2 kali sebulan, dibagi 2 PERIODE:
//   Periode 1 = 2 minggu pertama (tgl 1 - 15)
//   Periode 2 = 2 minggu akhir   (tgl 16 - akhir bulan)
// Periode ini murni dipakai sebagai SLOT/kategori akumulasi SLA bulanan.
// Tanggal SESUNGGUHNYA saat data itu diinput/disimpan (hari ini) tetap
// disimpan apa adanya di kolom `tanggal` — bukan lagi dipaksa jadi tgl 15/25.
// ------------------------------------------------------------------
$statusPeriode = $kontrak ? getStatusPeriodeInput($db, $kontrak_id) : [];

if (isset($_GET['periode']) && in_array((int)$_GET['periode'], [1, 2], true)) {
    // Pengguna sudah eksplisit memilih Periode 1 atau Periode 2
    $periode = (int)$_GET['periode'];
} elseif ($kontrak) {
    // Default cerdas: periode yang paling akhir diisi, kalau belum ada data
    // sama sekali pilih berdasarkan posisi tanggal hari ini (<=15 -> Periode 1).
    if (!empty($statusPeriode[2]['terakhir_input'])) {
        $periode = 2;
    } elseif (!empty($statusPeriode[1]['terakhir_input'])) {
        $periode = 1;
    } else {
        $periode = ((int)date('d') <= 15) ? 1 : 2;
    }
} else {
    $periode = 1;
}

// Input SLA hanya boleh Periode 1 atau Periode 2 (tidak ada nilai lain)
$rangeError = $kontrak && !in_array($periode, [1, 2], true);

// SAVE
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $kontrak_id && !$rangeError) {
    csrfVerify();
    $entries = $_POST['entries'] ?? [];
    $user = currentUser();
    $createdBy = $user['nama'] ?? ($user['username'] ?? 'system');
    $createdByEmail = $user['email'] ?? null;
    $tanggalInput = date('Y-m-d'); // tanggal SESUNGGUHNYA saat disimpan (bukan tgl 15/25)
    $waktuInputLengkap = date('Y-m-d H:i:s'); // waktu persis (sampai detik) saat data ini disimpan — untuk log & notifikasi
    $jmlTersimpan = 0;
    foreach ($entries as $entry_id => $vals) {
        $rawNilai = trim((string)($vals['nilai'] ?? ''));
        $catatan = trim($vals['catatan'] ?? '');
        // Realisasi dikosongkan = "belum dinilai" (sama seperti di Target & Realisasi):
        // tidak disimpan sebagai 0, supaya tidak ikut menurunkan akumulasi/rata-rata periode.
        if ($rawNilai !== '') {
            $nilai = (float)$rawNilai;
            $db->prepare("INSERT INTO monitoring_harian (sla_entry_id, tanggal, periode, nilai_harian, catatan, created_by, created_by_email)
                VALUES (?,?,?,?,?,?,?)
                ON DUPLICATE KEY UPDATE tanggal=VALUES(tanggal), nilai_harian=VALUES(nilai_harian), catatan=VALUES(catatan),
                created_by=VALUES(created_by), created_by_email=VALUES(created_by_email), updated_at=NOW()")
                ->execute([(int)$entry_id, $tanggalInput, $periode, $nilai, $catatan ?: null, $createdBy, $createdByEmail]);
            $jmlTersimpan++;
        }

        // Perubahan target SLA bulanan (opsional) — hanya Super Admin.
        // Waktu input dicatat per KONTRAK (bukan per indikator) — lihat "Waktu Input" di atas tabel.
        if (isSuperAdmin() && isset($vals['target']) && $vals['target'] !== '') {
            $targetBaru = (float)$vals['target'];
            $entryRow = dbRow($db, "SELECT target, realisasi, polaritas, bobot FROM sla_entries WHERE id=?", [(int)$entry_id]);
            if ($entryRow && (float)$entryRow['target'] != $targetBaru) {
                $realisasiLama = $entryRow['realisasi'] !== null ? (float)$entryRow['realisasi'] : null;
                $pct = hitungPencapaian($entryRow['polaritas'], $targetBaru, $realisasiLama);
                $nb  = hitungNilaiBobot((float)$entryRow['bobot'], $pct);
                dbExec($db, "UPDATE sla_entries SET target=?, persen_pencapaian=?, nilai_bobot=? WHERE id=?",
                    [$targetBaru, $pct, $nb, (int)$entry_id]);
                logAudit($db, 'update', 'sla_entries', "Ubah target bulanan sla_entry_id=$entry_id",
                    ['target' => $entryRow['target']], ['target' => $targetBaru]);
            }
        }
    }
    recalcRealisasiHarian($db, $kontrak_id);
    logAudit($db, 'create', 'monitoring_harian', "Input harian kontrak_id=$kontrak_id periode=$periode waktu_input=$waktuInputLengkap");

    setFlash('success', '✅ Data SLA Periode ' . $periode . ' berhasil disimpan (waktu input: ' . date('d/m/Y H:i:s', strtotime($waktuInputLengkap)) . ').');
    header("Location: input_harian.php?kontrak_id=$kontrak_id&periode=$periode$filterQueryString"); exit;
}

$entriesList = [];
if ($kontrak_id) {
    $rows = dbAll($db, "SELECT * FROM sla_entries WHERE kontrak_id=? AND ulp_id IS NULL ORDER BY kategori, no_urut", [$kontrak_id]);
    // Total & jumlah isian dari periode LAIN — untuk hitung % Pencapaian langsung (live) di browser.
    $periodeLain = [];
    if ($rows) {
        $ids = array_map('intval', array_column($rows, 'id'));
        $ph = implode(',', array_fill(0, count($ids), '?'));
        foreach (dbAll($db,
            "SELECT sla_entry_id, SUM(nilai_harian) AS s, COUNT(*) AS c FROM monitoring_harian
             WHERE sla_entry_id IN ($ph) AND periode IS NOT NULL AND periode <> ? GROUP BY sla_entry_id",
            array_merge($ids, [$periode])) as $pl) {
            $periodeLain[(int)$pl['sla_entry_id']] = ['s' => (float)$pl['s'], 'c' => (int)$pl['c']];
        }
    }
    foreach ($rows as $r) {
        $existing = dbRow($db, "SELECT * FROM monitoring_harian WHERE sla_entry_id=? AND periode=?", [$r['id'], $periode]);
        $r['harian_nilai'] = $existing['nilai_harian'] ?? '';
        $r['harian_catatan'] = $existing['catatan'] ?? '';
        $r['harian_tanggal_input'] = $existing['tanggal'] ?? null;
        $r['lain_sum'] = $periodeLain[(int)$r['id']]['s'] ?? 0;
        $r['lain_cnt'] = $periodeLain[(int)$r['id']]['c'] ?? 0;
        $r['metode']   = metodeAgregasiHarian((string)($r['satuan'] ?? ''));
        $entriesList[] = $r;
    }
}

if (!function_exists('pctColor')) {
    function pctColor($pct) {
        if ($pct >= 90) return 'good';
        if ($pct >= 70) return 'warn';
        return 'bad';
    }
}

// Role petugas (Admin/Koordinator): % Pencapaian cukup ditampilkan sebagai angka, tanpa bar progres.
$tampilBarPencapaian = !isPetugas();

$katLabels = [
    'TEKNIS' => ['label'=>'A. SLA TEKNIS','icon'=>'⚡','color'=>'#003087'],
    'K3' => ['label'=>'B. SLA K3 (Keselamatan & Kesehatan Kerja)','icon'=>'🦺','color'=>'#27ae60'],
    'KECELAKAAN' => ['label'=>'C. Kecelakaan Kerja','icon'=>'⚠️','color'=>'#e67e22'],
    'ILP' => ['label'=>'D. Integritas Layanan Publik (ILP)','icon'=>'🏛️','color'=>'#8e44ad'],
];
$byKat = [];
foreach ($entriesList as $e) $byKat[$e['kategori']][] = $e;

// Label rentang tanggal tiap periode, untuk ditampilkan sebagai keterangan (bukan pembatas input)
$labelRentang = [
    1 => '2 minggu pertama (tgl 1–15)',
    2 => '2 minggu akhir (tgl 16–akhir bulan)',
];

include 'includes/header.php';
?>

<?php if ($kontrak_id): $kontrakTabActive = 'harian'; $kontrakTabHideRingkasan = true; include 'includes/kontrak_tabs.php'; endif; ?>

<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title">🎯 Input SLA</div>
            <div class="card-subtitle">Catat realisasi SLA & ubah target bulanan per indikator — input dilakukan 2 kali sebulan (Periode 1 & Periode 2), diakumulasi otomatis menjadi realisasi bulanan. Tanggal saat kamu menyimpan akan tetap tercatat sebagai tanggal input.</div>
        </div>
        <?php if ($kontrak && !$rangeError): ?>
        <a href="export_input_sla.php?kontrak_id=<?= (int)$kontrak_id ?>" class="btn btn-outline no-print" style="border-color:#1D6F42;color:#1D6F42;white-space:nowrap;align-self:flex-start;"
           title="Unduh data yang sudah tersimpan (Periode 1 &amp; 2) beserta waktu input kontrak"><i class="bi bi-file-earmark-excel"></i> Export Excel</a>
        <?php endif; ?>
    </div>
    <div class="card-body">
    <div class="form-grid" style="grid-template-columns:repeat(auto-fit,minmax(170px,1fr));">
        <div class="form-group">
            <label>Pilih Bidang</label>
            <select class="form-control" onchange="location.href='input_harian.php?jenis='+this.value">
                <option value="ALL" <?= $filterJenis==='ALL'?'selected':'' ?>>-- Pilih Bidang --</option>
                <option value="DISTRIBUSI" <?= $filterJenis==='DISTRIBUSI'?'selected':'' ?>>Distribusi</option>
                <option value="TRANSMISI" <?= $filterJenis==='TRANSMISI'?'selected':'' ?>>Transmisi</option>
                <option value="PEMBANGKIT" <?= $filterJenis==='PEMBANGKIT'?'selected':'' ?>>Pembangkit</option>
            </select>
        </div>
        <div class="form-group">
            <label>Pilih Project</label>
            <?php if ($filterJenis === 'ALL'): ?>
            <select class="form-control" disabled style="background:#f1f5f9;cursor:not-allowed;color:#94a3b8;">
                <option>-- Pilih Bidang terlebih dahulu --</option>
            </select>
            <?php else: ?>
            <select class="form-control" onchange="location.href='input_harian.php?jenis=<?= $filterJenis ?>&unit_id='+this.value">
                <option value="">-- Pilih Project --</option>
                <?php foreach($unitOptions as $u): ?>
                <option value="<?= $u['id'] ?>" <?= ((string)$filterUnit === (string)$u['id']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($u['nama']) ?>
                </option>
                <?php endforeach; ?>
                <?php if (empty($unitOptions)): ?>
                <option value="" disabled>Belum ada Project untuk bidang ini</option>
                <?php endif; ?>
            </select>
            <div style="font-size:11px;color:var(--text-light);margin-top:4px;">Kelola daftar Project di menu <a href="unit_kerja.php" target="_blank">Kelola Project</a>.</div>
            <?php endif; ?>
        </div>
        <?php if ($kontrak): ?>
        <div class="form-group">
            <label>Periode Input SLA</label>
            <div style="display:flex;gap:6px;">
                <?php foreach ([1, 2] as $p):
                    $info = $statusPeriode[$p] ?? ['status' => 'kosong', 'terisi' => 0, 'total' => 0, 'terakhir_input' => null, 'tanggal_terakhir' => null];
                    $isActive = $p === $periode;
                    $tooltip = $info['total'] > 0 ? "{$info['terisi']}/{$info['total']} indikator terisi" : 'Belum ada data';
                    if (!empty($info['terakhir_input'])) {
                        $tooltip .= ' — waktu input terakhir: ' . date('d/m/Y H:i:s', strtotime($info['terakhir_input']));
                    }
                ?>
                <a href="input_harian.php?kontrak_id=<?= $kontrak_id ?>&periode=<?= $p ?><?= $filterQueryString ?>"
                   class="btn <?= $isActive ? 'btn-primary' : 'btn-outline' ?>" style="flex:1;text-align:center;position:relative;">
                    Periode <?= $p ?>
                    <span class="cal-dot <?= $info['status'] ?>" style="display:inline-block;margin-left:6px;" title="<?= htmlspecialchars($tooltip) ?>"></span>
                </a>
                <?php endforeach; ?>
            </div>
            <div style="font-size:11px;color:var(--text-light);margin-top:4px;">
                Kontrak: <b><?= htmlspecialchars((string)($kontrak['nama_kontrak'] ?: '-')) ?></b>
                — <a href="input_harian.php?jenis=<?= urlencode($filterJenis) ?>&unit_id=<?= urlencode($filterUnit) ?>">← Semua kontrak Project ini</a>
                · kelola di <a href="kontrak.php?act=edit&id=<?= $kontrak_id ?>" target="_blank">Data Kontrak</a>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php if ($kontrak && count($kontrakTahapList) > 1): ?>
    <div style="display:flex;gap:6px;align-items:center;margin-top:8px;flex-wrap:wrap;">
        <span style="font-size:12px;color:var(--text-light);">Tahap kontrak bulan ini:</span>
        <?php foreach ($kontrakTahapList as $kt): ?>
        <a href="input_harian.php?kontrak_id=<?= (int)$kt['id'] ?>&periode=<?= $periode ?><?= $filterQueryString ?>"
           class="btn btn-sm <?= (int)$kt['id'] === $kontrak_id ? 'btn-primary' : 'btn-outline' ?>">
            Tahap <?= htmlspecialchars((string)($kt['tahap'] ?: '-')) ?>
        </a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <?php if($kontrak): ?>
    <div class="alert alert-info" style="margin-top:8px;">
        Periode kontrak: <b><?= htmlspecialchars((string)($kontrak['periode_bulan'] ?? '')) ?> <?= $kontrak['tahun'] ?></b> —
        Input SLA dilakukan 2 kali sebulan: <b>Periode 1</b> (<?= $labelRentang[1] ?>) dan <b>Periode 2</b> (<?= $labelRentang[2] ?>).
    </div>
    <div class="alert alert-info" style="margin-top:8px;">
        🕒 <b>Waktu Input Kontrak</b> (terakhir disimpan):
        <?php foreach ([1, 2] as $p):
            $ti = $statusPeriode[$p]['terakhir_input'] ?? null; ?>
        <span style="margin-left:10px;white-space:nowrap;<?= $p === $periode ? 'font-weight:700;' : '' ?>">
            Periode <?= $p ?>: <?= $ti ? htmlspecialchars(date('d/m/Y H:i:s', strtotime($ti))) : '<span style="color:var(--text-light);">belum diinput</span>' ?>
        </span>
        <?php endforeach; ?>
    </div>
    <?php if ($jumlahUlpKontrak > 0): ?>
    <div class="alert alert-warning" style="margin-top:8px;">
        <i class="bi bi-info-circle"></i> Kontrak ini punya <b><?= $jumlahUlpKontrak ?> Data ULP</b>. Halaman ini cuma untuk realisasi <b>level kontrak (gabungan)</b> —
        kalau butuh isi realisasi per-ULP, gunakan tombol <b>"Target & Realisasi"</b> di
        <a href="kontrak.php?act=edit&id=<?= $kontrak_id ?>#target-realisasi">Data Kontrak</a> lalu pilih ULP-nya dari dropdown di sana.
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php if($rangeError): ?>
    <div class="alert alert-danger">⚠️ Input SLA hanya bisa dilakukan untuk Periode 1 atau Periode 2. Silakan pilih salah satu periode di atas.</div>
    <?php endif; ?>
    </div>
</div>

<?php renderKontrakListCard($sel, 'input_harian.php', ['btnLabel' => 'Input SLA']); ?>

<?php if ($kontrak && !$rangeError): ?>
<form method="POST" id="formSla">
<?= csrfField() ?>
<?php $katIndex = 0; foreach ($katLabels as $kat => $katInfo):
    if (empty($byKat[$kat])) continue;
    $katEntries = $byKat[$kat];
    $katDinilai = array_values(array_filter($katEntries, fn($e) => $e['persen_pencapaian'] !== null));
    $avgPct = count($katDinilai) > 0 ? array_sum(array_column($katDinilai, 'persen_pencapaian')) / count($katDinilai) : 0;
    $katOpen = ($katIndex === 0); // kategori pertama terbuka, sisanya diklik untuk buka (sama seperti Target & Realisasi)
    $katIndex++;
?>
<div class="card kat-accordion<?= $katOpen ? ' open' : '' ?>">
    <div class="card-header kat-accordion-header" onclick="toggleKatAccordion(this)">
        <div>
            <div class="card-title" style="color:<?= $katInfo['color'] ?>;"><?= $katInfo['icon'] ?> <?= $katInfo['label'] ?></div>
            <div class="card-subtitle"><?= count($katEntries) ?> indikator &bull; Rata-rata pencapaian: <b><?= number_format($avgPct, 2) ?>%</b></div>
        </div>
        <div style="display:flex;align-items:center;gap:14px;">
            <div class="sla-gauge">
                <div class="sla-pct <?= pctColor($avgPct) ?>"><?= number_format($avgPct, 1) ?>%</div>
            </div>
            <i class="bi bi-chevron-down kat-accordion-chevron"></i>
        </div>
    </div>
    <div class="table-wrap kat-accordion-body" style="<?= $katOpen ? '' : 'display:none;' ?>">
    <table>
        <thead>
            <tr>
                <th style="width:30px;">#</th>
                <th>Ruang Lingkup</th>
                <th>Kriteria / Kinerja</th>
                <th>Satuan</th>
                <th>Polaritas<?= helpTip(HELP_POLARITAS) ?></th>
                <th style="width:110px;">Target<?= isSuperAdmin() ? '' : ' <i class="bi bi-lock-fill" style="font-size:10px;color:var(--text-light);" title="Hanya Super Admin"></i>' ?></th>
                <th style="width:120px;">Realisasi (Periode <?= $periode ?>)</th>
                <th style="width:120px;">% Pencapaian</th>
                <th style="width:160px;">Keterangan</th>
            </tr>
        </thead>
        <tbody>
        <?php $no = 1; foreach ($katEntries as $e):
            $pct = $e['persen_pencapaian'] !== null ? (float)$e['persen_pencapaian'] : null;
        ?>
        <tr data-polaritas="<?= htmlspecialchars((string)$e['polaritas']) ?>" data-metode="<?= $e['metode'] ?>"
            data-ruang="<?= htmlspecialchars((string)($e['ruang_lingkup'] ?? '')) ?>" data-kriteria="<?= htmlspecialchars((string)($e['kriteria'] ?? '')) ?>"
            data-satuan="<?= htmlspecialchars((string)($e['satuan'] ?? '')) ?>" data-kat="<?= htmlspecialchars((string)$kat) ?>"
            data-katlabel="<?= htmlspecialchars((string)$katInfo['label']) ?>" data-awal-r="<?= htmlspecialchars((string)($e['harian_nilai'] ?? '')) ?>"
            data-awal-t="<?= htmlspecialchars((string)($e['target'] ?? '')) ?>"
            data-lain-sum="<?= $e['lain_sum'] ?>" data-lain-cnt="<?= (int)$e['lain_cnt'] ?>">
            <td><?= $no++ ?></td>
            <td>
                <div style="font-size:12px;font-weight:700;"><?= htmlspecialchars((string)($e['ruang_lingkup'] ?? '')) ?></div>
                <div style="font-size:11px;color:var(--text-light);">No. <?= htmlspecialchars((string)($e['no_urut'] ?? '')) ?></div>
            </td>
            <td style="font-size:12px;max-width:280px;">
                <?= htmlspecialchars((string)($e['kriteria'] ?? '')) ?>
                <?php if (!empty($e['eviden'])): ?>
                <div style="font-size:11px;color:var(--text-light);margin-top:4px;"><b>Eviden:</b> <?= nl2br(htmlspecialchars((string)$e['eviden'])) ?></div>
                <?php endif; ?>
            </td>
            <td><?= htmlspecialchars((string)($e['satuan'] ?? '')) ?></td>
            <td>
                <span class="badge <?= $e['polaritas'] == 'Positif' ? 'badge-positif' : 'badge-negatif' ?>"><?= htmlspecialchars((string)$e['polaritas']) ?></span>
            </td>
            <td>
                <input type="number" step="any" min="0" class="form-control input-target js-validate-num"
                    name="entries[<?= $e['id'] ?>][target]" value="<?= htmlspecialchars((string)($e['target'] ?? '0')) ?>"
                    <?= isSuperAdmin() ? '' : 'readonly title="Hanya Super Admin yang dapat mengubah Target"' ?>
                    style="width:100%;padding:6px 8px;<?= isSuperAdmin() ? '' : 'background:#f1f5f9;cursor:not-allowed;color:#94a3b8;' ?>">
                <?php if (isSuperAdmin()): ?><div class="field-error"><i class="bi bi-exclamation-circle"></i> <span></span></div><?php endif; ?>
            </td>
            <td>
                <input type="number" step="any" min="0" class="form-control input-realisasi js-validate-num"
                    name="entries[<?= $e['id'] ?>][nilai]" value="<?= htmlspecialchars((string)($e['harian_nilai'] ?? '')) ?>"
                    placeholder="Belum diisi" style="width:100%;padding:6px 8px;">
                <div class="field-error"><i class="bi bi-exclamation-circle"></i> <span></span></div>
            </td>
            <td class="pct-cell">
                <?php if ($pct === null): ?>
                <span class="badge belum-dinilai-badge" style="background:#f1f5f9;color:#94a3b8;border:1px solid #e2e8f0;white-space:nowrap;">
                    <i class="bi bi-hourglass-split"></i> Belum Dinilai
                </span>
                <?php else: ?>
                <?php if ($tampilBarPencapaian): ?>
                <div class="progress-bar"><div class="progress-fill calc-pct-bar <?= pctColor($pct) ?>" style="width:<?= min(100, max(0, $pct)) ?>%"></div></div>
                <?php endif; ?>
                <div class="progress-label calc-pct <?= pctColor($pct) ?>"><?= number_format($pct, 2) ?>%</div>
                <?php endif; ?>
            </td>
            <?php
                // Keterangan (sama seperti di Target & Realisasi): hanya untuk indikator yang belum mencapai target
                // (< 100%, sesuai angka yang tampil 2 desimal). Pencapaian >= 100% atau belum dinilai: tertutup.
                $ketTerbuka = ($pct !== null && round($pct, 2) < 100);
            ?>
            <td class="ket-td">
                <input type="hidden" name="entries[<?= $e['id'] ?>][catatan]" value="<?= htmlspecialchars((string)($e['harian_catatan'] ?? '')) ?>">
                <span class="keterangan-cell" style="cursor:pointer;color:var(--blue);font-size:11px;font-weight:600;display:<?= $ketTerbuka ? 'inline-flex' : 'none' ?>;align-items:center;gap:4px;"
                    data-keterangan="<?= htmlspecialchars((string)($e['keterangan'] ?? '')) ?>"
                    onclick="openKeteranganModal(<?= (int)$e['id'] ?>, this, '<?= htmlspecialchars(addslashes((string)($e['ruang_lingkup'] ?? ''))) ?>')">
                    <i class="bi bi-pencil-square"></i>
                    <span class="keterangan-preview"><?= !empty($e['keterangan']) ? htmlspecialchars(mb_strimwidth((string)$e['keterangan'],0,28,'…')) : '+ Isi Keterangan' ?></span>
                </span>
                <span class="ket-tutup" style="display:<?= $ketTerbuka ? 'none' : 'inline' ?>;color:#cbd5e1;" title="Keterangan hanya untuk indikator yang belum mencapai target (&lt; 100%)">–</span>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</div>
<?php endforeach; ?>

<?php if (!empty($entriesList)): ?>
<div style="display:flex;gap:10px;justify-content:flex-end;margin-bottom:24px;flex-wrap:wrap;">
    <button type="submit" class="btn btn-success">💾 Simpan Data SLA</button>
    <a href="rekap_sla.php?kontrak_id=<?= $kontrak_id ?>" class="btn btn-primary">📊 Lihat Rekap SLA</a>
</div>
<?php else: ?>
<div class="alert alert-info">Kontrak ini belum punya indikator SLA. Tambahkan indikator lewat menu <a href="input_sla.php?kontrak_id=<?= $kontrak_id ?>">Input Target &amp; Realisasi</a>.</div>
<?php endif; ?>
</form>
<?php if (!empty($entriesList)): ?>
<!-- ── POPUP: PREVIEW REALISASI SLA (muncul setelah input, sebelum disimpan) ── -->
<div class="modal-overlay" id="previewSlaModal">
    <div class="modal" style="max-width:860px;">
        <div class="modal-header">
            <span class="modal-title">
                <i class="bi bi-eye"></i> Preview Realisasi SLA — Periode <?= (int)$periode ?>
                <div style="font-size:11px;font-weight:400;color:var(--g500);margin-top:2px;">Periksa kembali data di bawah sebelum disimpan.</div>
            </span>
            <button type="button" class="modal-close" onclick="closePreviewSla()">×</button>
        </div>
        <div class="modal-body">
            <div class="alert alert-info" style="margin:0 0 12px;font-size:12px;">
                <i class="bi bi-info-circle"></i> Ini data yang akan disimpan. Pastikan <b>Realisasi</b> sudah benar. Jika ada yang salah, klik <b>Kembali Edit</b>.
            </div>
            <div id="previewSlaInfo" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;font-size:12px;"></div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th style="width:30px;">#</th>
                            <th>Indikator</th>
                            <th>Target</th>
                            <th>Realisasi (Periode <?= (int)$periode ?>)</th>
                            <th>% Pencapaian</th>
                            <th>Status</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody id="previewSlaBody"></tbody>
                </table>
            </div>
            <div id="previewSlaEmpty" class="alert alert-warning" style="display:none;margin-top:10px;">
                <i class="bi bi-info-circle"></i> Belum ada Realisasi yang diisi pada periode ini.
            </div>
            <div id="previewSlaKosong" class="alert alert-warning" style="display:none;margin-top:10px;font-size:12px;"></div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-outline" onclick="closePreviewSla()"><i class="bi bi-pencil"></i> Kembali Edit</button>
            <button type="button" class="btn btn-success" id="previewSlaConfirmBtn" onclick="konfirmasiSimpanSla()">💾 Konfirmasi &amp; Simpan</button>
        </div>
    </div>
</div>

<!-- ── MODAL: ISI KETERANGAN INDIKATOR SLA (muncul kalau belum capai target) ── -->
<div class="modal-overlay" id="keteranganModal">
    <div class="modal" style="max-width:520px;">
        <div class="modal-header">
            <span class="modal-title">📝 Keterangan Indikator SLA</span>
            <button type="button" class="modal-close" onclick="closeKeteranganModal()">×</button>
        </div>
        <div class="modal-body">
            <div id="keteranganEntryInfo" style="font-size:12px;font-weight:700;color:var(--g700);margin-bottom:10px;"></div>
            <div class="form-group" style="margin-bottom:4px;">
                <label>Keterangan <span style="color:var(--red);">*wajib diisi</span> <span style="font-weight:400;color:var(--text-light);">(alasan indikator ini belum mencapai target)</span></label>
                <textarea id="keteranganText" class="form-control" rows="4" placeholder="Contoh: Keterlambatan material dari vendor, cuaca ekstrem, dsb."></textarea>
                <div id="keteranganError" style="display:none;color:var(--red);font-size:11.5px;margin-top:6px;">⚠️ Gagal: Keterangan tidak boleh kosong, harus diisi terlebih dahulu.</div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-outline btn-sm" onclick="closeKeteranganModal()">Batal</button>
            <button type="button" class="btn btn-primary btn-sm" onclick="saveKeterangan()">💾 Simpan Keterangan</button>
        </div>
    </div>
</div>
<script>
var CSRF_TOKEN = "<?= htmlspecialchars(csrfToken()) ?>";
var currentKeteranganEntryId = null;
var currentKeteranganCellEl  = null;

function openKeteranganModal(entryId, cellEl, ruangLingkup) {
    currentKeteranganEntryId = entryId;
    currentKeteranganCellEl  = cellEl;
    document.getElementById('keteranganEntryInfo').textContent = ruangLingkup || '';
    document.getElementById('keteranganText').value = cellEl.getAttribute('data-keterangan') || '';
    document.getElementById('keteranganError').style.display = 'none';
    document.getElementById('keteranganText').style.borderColor = '';
    openAppModal('keteranganModal');
    setTimeout(function () { document.getElementById('keteranganText').focus(); }, 100);
}
function closeKeteranganModal() {
    closeAppModal('keteranganModal');
}
function saveKeterangan() {
    if (!currentKeteranganEntryId) return;
    var textEl = document.getElementById('keteranganText');
    var errEl  = document.getElementById('keteranganError');
    var teks   = textEl.value.trim();

    if (teks === '') {
        errEl.style.display = 'block';
        textEl.style.borderColor = 'var(--red)';
        textEl.focus();
        return;
    }
    errEl.style.display = 'none';
    textEl.style.borderColor = '';

    var fd = new FormData();
    fd.append('action', 'save_keterangan');
    fd.append('entry_id', currentKeteranganEntryId);
    fd.append('keterangan', teks);
    // Kirim target & realisasi bulanan (akumulasi) yang sedang tampil di baris ini,
    // supaya server menilai < 100% berdasarkan angka live yang sama dengan kolom % Pencapaian.
    var rowEl = currentKeteranganCellEl ? currentKeteranganCellEl.closest('tr') : null;
    if (rowEl) {
        var tEl = rowEl.querySelector('.input-target');
        if (tEl) fd.append('target', tEl.value);
        var rEf = rowEl.getAttribute('data-real-efektif');
        if (rEf !== null && rEf !== '') fd.append('realisasi', rEf);
    }
    fd.append('csrf_token', CSRF_TOKEN);
    fetch('api.php', { method: 'POST', body: fd })
        .then(function (res) { return res.json(); })
        .then(function (data) {
            if (!data.ok) {
                errEl.textContent = '⚠️ Gagal: ' + (data.error || 'terjadi kesalahan, keterangan tidak tersimpan.');
                errEl.style.display = 'block';
                textEl.style.borderColor = 'var(--red)';
                return;
            }
            if (currentKeteranganCellEl) {
                currentKeteranganCellEl.setAttribute('data-keterangan', teks);
                var preview = currentKeteranganCellEl.querySelector('.keterangan-preview');
                if (preview) preview.textContent = teks.slice(0, 28) + (teks.length > 28 ? '…' : '');
            }
            closeKeteranganModal();
            window.showToast('✅ Keterangan berhasil disimpan.');
        })
        .catch(function () {
            errEl.textContent = '⚠️ Gagal menyimpan keterangan. Silakan coba lagi.';
            errEl.style.display = 'block';
        });
}
document.getElementById('keteranganModal').addEventListener('click', function (e) {
    if (e.target === this) closeKeteranganModal();
});
</script>
<script>
function toggleKatAccordion(header) {
    var card = header.closest('.kat-accordion');
    var body = card.querySelector('.kat-accordion-body');
    var isOpen = card.classList.toggle('open');
    body.style.display = isOpen ? '' : 'none';
}
(function () {
    var TAMPIL_BAR = <?= $tampilBarPencapaian ? 'true' : 'false' ?>; // false untuk role petugas: hanya angka
    var form = document.getElementById('formSla');
    if (!form) return;
    var inputs = Array.from(form.querySelectorAll('.input-target, .input-realisasi'));

    function bukaAccordion(el) {
        var card = el.closest('.kat-accordion');
        if (card && !card.classList.contains('open')) toggleKatAccordion(card.querySelector('.kat-accordion-header'));
    }

    // ── Validasi real-time: cegah nilai negatif / bukan angka. Kosong tetap boleh (= belum dinilai).
    function pesanUntuk(input) {
        if (input.value === '') return '';
        if (isNaN(input.value)) return 'Harus berupa angka.';
        if (parseFloat(input.value) < 0) return 'Tidak boleh bernilai negatif.';
        return '';
    }
    function validate(input) {
        var errBox = input.parentElement.querySelector('.field-error');
        var msg = pesanUntuk(input);
        if (msg) {
            input.classList.add('is-invalid');
            if (errBox) { errBox.querySelector('span').textContent = msg; errBox.classList.add('show'); }
            return false;
        }
        input.classList.remove('is-invalid');
        if (errBox) errBox.classList.remove('show');
        return true;
    }

    // ── Live "% Pencapaian": mencerminkan hitungPencapaian() di PHP. Realisasi bulanan = akumulasi
    // periode lain + isian periode ini (SUM, atau rata-rata untuk satuan Menit/Rasio).
    function hitungPencapaianJS(polaritas, target, realisasi) {
        target = parseFloat(target); if (isNaN(target)) target = 0;
        realisasi = parseFloat(realisasi); if (isNaN(realisasi)) realisasi = 0;
        if (target === 0) {
            if (realisasi === 0) return 100;
            return polaritas === 'Negatif' ? 0 : 100;
        }
        if (polaritas === 'Negatif') return (2 - realisasi / target) * 100;
        return (realisasi / target) * 100;
    }
    function pctColorJS(pct) { return pct >= 90 ? 'good' : (pct >= 70 ? 'warn' : 'bad'); }
    // Keterangan terbuka hanya saat pencapaian (yang tampil, 2 desimal) < 100%. >= 100% atau belum dinilai: tertutup.
    function updateKeteranganCell(row, pct) {
        var td = row.querySelector('.ket-td');
        if (!td) return;
        var btn = td.querySelector('.keterangan-cell');
        var tutup = td.querySelector('.ket-tutup');
        var terbuka = (pct !== null && Math.round(pct * 100) / 100 < 100);
        btn.style.display   = terbuka ? 'inline-flex' : 'none';
        tutup.style.display = terbuka ? 'none' : 'inline';
    }
    function recalcRow(row) {
        var tEl = row.querySelector('.input-target'), rEl = row.querySelector('.input-realisasi');
        var pctCell = row.querySelector('.pct-cell');
        if (!tEl || !rEl || !pctCell) return;
        var sum = parseFloat(row.getAttribute('data-lain-sum')) || 0;
        var cnt = parseInt(row.getAttribute('data-lain-cnt'), 10) || 0;
        var v = String(rEl.value).trim();
        if (v !== '' && !isNaN(v)) { sum += parseFloat(v); cnt += 1; }
        if (cnt === 0) {
            row.setAttribute('data-real-efektif', '');
            updateKeteranganCell(row, null);
            pctCell.innerHTML = '<span class="badge belum-dinilai-badge" style="background:#f1f5f9;color:#94a3b8;border:1px solid #e2e8f0;white-space:nowrap;"><i class="bi bi-hourglass-split"></i> Belum Dinilai</span>';
            return;
        }
        var realisasi = row.getAttribute('data-metode') === 'AVG' ? sum / cnt : sum;
        var pct = hitungPencapaianJS(row.getAttribute('data-polaritas') || 'Positif', tEl.value, realisasi);
        row.setAttribute('data-real-efektif', String(realisasi));
        updateKeteranganCell(row, pct);
        var cls = pctColorJS(pct);
        pctCell.innerHTML =
            (TAMPIL_BAR ? '<div class="progress-bar"><div class="progress-fill calc-pct-bar ' + cls + '" style="width:' + Math.min(100, Math.max(0, pct)) + '%"></div></div>' : '') +
            '<div class="progress-label calc-pct ' + cls + '">' + pct.toFixed(2) + '%</div>';
    }

    inputs.forEach(function (el, idx) {
        el.addEventListener('input', function () {
            validate(el);
            var row = el.closest('tr[data-polaritas]');
            if (row) recalcRow(row);
        });
        el.addEventListener('blur', function () { validate(el); });
        // Enter = pindah ke kolom berikutnya (sama seperti di Target & Realisasi)
        el.addEventListener('keydown', function (e) {
            if (e.key !== 'Enter') return;
            e.preventDefault();
            var next = inputs[idx + 1];
            if (next) { bukaAccordion(next); next.focus(); }
        });
    });

    // ── Preview: setelah Realisasi diisi dan tombol Simpan diklik, tampilkan pop up preview dulu.
    // Data baru benar-benar dikirim setelah pengguna menekan "Konfirmasi & Simpan".
    var sudahDikonfirmasi = false;
    function esc(t) {
        return String(t).replace(/[&<>"']/g, function (c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }
    function sama(a, b) {
        if (String(a).trim() === '' || String(b).trim() === '') return String(a).trim() === String(b).trim();
        return parseFloat(a) === parseFloat(b);
    }
    function bangunPreview() {
        var body = document.getElementById('previewSlaBody');
        var rows = Array.from(form.querySelectorAll('tr[data-polaritas]'));
        var html = '', terisi = 0, baru = 0, diubah = 0, no = 0, lastKat = '';
        var kosongList = [];
        rows.forEach(function (row) {
            var rEl = row.querySelector('.input-realisasi');
            var tEl = row.querySelector('.input-target');
            var kCell = row.querySelector('.keterangan-cell');
            var ketTxt = (kCell && kCell.style.display !== 'none') ? (kCell.getAttribute('data-keterangan') || '').trim() : '';
            if (!rEl) return;
            var nama = (row.getAttribute('data-ruang') || '') + ' — ' + (row.getAttribute('data-kriteria') || '');
            var rVal = String(rEl.value).trim();
            if (rVal === '') { kosongList.push(nama); return; }
            terisi++; no++;
            var katLabel = row.getAttribute('data-katlabel') || '';
            if (katLabel !== lastKat) {
                html += '<tr><td colspan="7" style="background:var(--g100,#f1f5f9);font-weight:700;font-size:12px;">' + esc(katLabel) + '</td></tr>';
                lastKat = katLabel;
            }
            var pctLabel = row.querySelector('.pct-cell .calc-pct');
            var pctText = pctLabel ? pctLabel.textContent : '—';
            var cls = pctLabel ? (pctLabel.className.match(/\b(good|warn|bad)\b/) || [''])[0] : '';
            var sat = row.getAttribute('data-satuan') || '';
            var awalR = row.getAttribute('data-awal-r') || '';
            var awalT = row.getAttribute('data-awal-t') || '';

            var status;
            if (awalR === '') { status = '<span class="badge badge-positif">Baru</span>'; baru++; }
            else if (!sama(awalR, rVal)) {
                status = '<span class="badge" style="background:#fff7e0;color:#8a5800;border:1px solid #ecd095;">Diubah</span>' +
                         '<div style="font-size:11px;color:var(--text-light);">sebelumnya ' + esc(awalR) + ' ' + esc(sat) + '</div>';
                diubah++;
            } else { status = '<span class="badge" style="background:#f1f5f9;color:#64748b;border:1px solid #e2e8f0;">Tidak berubah</span>'; }

            var targetTxt = esc(tEl ? tEl.value : '') + ' ' + esc(sat);
            if (tEl && !tEl.readOnly && awalT !== '' && !sama(awalT, tEl.value)) {
                targetTxt += '<div style="font-size:11px;color:#8a5800;">Target diubah dari ' + esc(awalT) + '</div>';
            }
            html += '<tr>' +
                '<td>' + no + '</td>' +
                '<td style="font-size:12px;"><div style="font-weight:700;">' + esc(row.getAttribute('data-ruang') || '') + '</div>' +
                    '<div style="color:var(--text-light);">' + esc(row.getAttribute('data-kriteria') || '') + '</div></td>' +
                '<td style="white-space:nowrap;">' + targetTxt + '</td>' +
                '<td style="white-space:nowrap;"><b>' + esc(rVal) + '</b> ' + esc(sat) + '</td>' +
                '<td><span class="progress-label ' + cls + '">' + esc(pctText) + '</span></td>' +
                '<td>' + status + '</td>' +
                '<td style="font-size:12px;">' + (ketTxt ? esc(ketTxt) : '—') + '</td>' +
                '</tr>';
        });
        body.innerHTML = html;
        document.getElementById('previewSlaEmpty').style.display = terisi === 0 ? '' : 'none';
        document.getElementById('previewSlaInfo').innerHTML =
            '<span class="badge badge-positif">' + terisi + ' indikator terisi</span>' +
            (baru ? '<span class="badge badge-positif">' + baru + ' baru</span>' : '') +
            (diubah ? '<span class="badge" style="background:#fff7e0;color:#8a5800;border:1px solid #ecd095;">' + diubah + ' diubah</span>' : '') +
            (kosongList.length ? '<span class="badge" style="background:#f1f5f9;color:#64748b;border:1px solid #e2e8f0;">' + kosongList.length + ' belum diisi</span>' : '');
        var kBox = document.getElementById('previewSlaKosong');
        if (kosongList.length) {
            kBox.style.display = '';
            kBox.innerHTML = '<b>Belum diisi (tidak ikut disimpan):</b><ul style="margin:6px 0 0 18px;padding:0;">' +
                kosongList.map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('') + '</ul>';
        } else { kBox.style.display = 'none'; kBox.innerHTML = ''; }
    }
    window.closePreviewSla = function () { closeAppModal('previewSlaModal'); };
    window.konfirmasiSimpanSla = function () {
        sudahDikonfirmasi = true;
        var btn = document.getElementById('previewSlaConfirmBtn');
        btn.disabled = true; btn.textContent = 'Menyimpan…';
        form.submit();
    };
    document.getElementById('previewSlaModal').addEventListener('click', function (e) {
        if (e.target === this) closePreviewSla();
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closePreviewSla();
    });

    form.addEventListener('submit', function (e) {
        if (sudahDikonfirmasi) return;
        e.preventDefault();
        var firstInvalid = null;
        inputs.forEach(function (input) {
            if (!validate(input) && !firstInvalid) firstInvalid = input;
        });
        if (firstInvalid) {
            bukaAccordion(firstInvalid);
            firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
            firstInvalid.focus();
            return;
        }
        bangunPreview();
        openAppModal('previewSlaModal');
    });
})();
</script>
<?php endif; ?>
<?php elseif (!$kontrak && $filterUnit === ''): ?>
<div class="card">
    <div style="text-align:center;padding:40px;">
        <div style="font-size:48px;">📅</div>
        <div style="font-size:16px;font-weight:700;color:var(--pln-blue);margin-top:12px;">Pilih Bidang dan Project untuk mulai input SLA</div>
    </div>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
