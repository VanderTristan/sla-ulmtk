<?php
/**
 * laporan_export.php — Export hasil filter Laporan SLA (laporan.php) ke .xlsx.
 * Filter yang dipakai identik dengan yang tampil di layar.
 */
require_once 'includes/database.php';
require_once 'includes/xlsx_writer.php';
require_once 'includes/laporan_helper.php';

$db = getDB();
requireReportAccess();

$f    = laporanFilter();
$rows = laporanRows($db, $f);

$data = [['No', 'Project', 'Periode', 'ULP', 'Kategori', 'Ruang Lingkup', 'Indikator', 'Satuan', 'Target', 'Realisasi', '% Pencapaian', 'Status']];
$no = 1;
foreach ($rows as $r) {
    $pct  = $r['persen_pencapaian'] !== null ? (float)$r['persen_pencapaian'] : null;
    $data[] = [
        $no++,
        (string)($r['nama_kontrak'] ?? ''),
        ucwords(strtolower((string)$r['periode_bulan'])) . ' ' . $r['tahun'],
        (string)($r['nama_ulp'] ?? ''),
        (string)($r['kategori'] ?? ''),
        (string)($r['ruang_lingkup'] ?? ''),
        (string)($r['kriteria'] ?? ''),
        (string)($r['satuan'] ?? ''),
        (float)($r['target'] ?? 0),
        $r['realisasi'] === null ? 'Belum diisi' : (float)$r['realisasi'],
        $pct === null ? 'Belum diisi' : round($pct, 2),
        laporanStatus($pct),
    ];
}
if (count($data) === 1) {
    $data[] = ['', 'Tidak ada data untuk filter ini', '', '', '', '', '', '', '', '', '', ''];
}

$xlsx = new SimpleXlsxWriter();
$xlsx->addSheet('Laporan SLA', $data, true, [5, 34, 16, 22, 14, 26, 34, 10, 10, 12, 13, 15]);
$xlsx->addSheet('Filter', [['Filter', 'Nilai'], ['Tahun', $f['tahun'] ?: 'Semua'], ['Bulan', $f['bulan'] ? ucwords(strtolower($f['bulan'])) : 'Semua'],
    ['ULP', $f['ulp'] !== '' ? $f['ulp'] : 'Semua'], ['Indikator', $f['indikator'] !== '' ? $f['indikator'] : 'Semua'],
    ['Diekspor', date('d-m-Y H:i')]], true, [16, 40]);

logAudit($db, 'export', 'laporan_sla', 'Export Excel Laporan SLA: ' . laporanFilterLabel($f));
$xlsx->download('Laporan_SLA_' . date('Ymd_His') . '.xlsx');
