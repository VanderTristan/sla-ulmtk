<?php
require_once 'includes/database.php';
requireInputAccess();
$db = getDB();
$title = 'Kelola Project';

$act = $_GET['act'] ?? 'list';
$id  = (int)($_GET['id'] ?? 0);

// ── DELETE ──────────────────────────────────────────────
if ($act === 'hapus' && $id) {
    csrfVerify();
    $old = dbRow($db, "SELECT * FROM unit_kerja WHERE id=?", [$id]);
    // Kontrak yang sudah terlanjur pakai unit ini otomatis dilepas (unit_id jadi kosong), bukan ikut terhapus
    dbExec($db, "UPDATE kontrak SET unit_id=NULL WHERE unit_id=?", [$id]);
    dbExec($db, "DELETE FROM unit_kerja WHERE id=?", [$id]);
    logAudit($db, 'delete', 'unit_kerja', "Hapus unit kerja id=$id", $old ?: null, null);
    setFlash('success', '🗑️ Unit kerja berhasil dihapus.');
    header('Location: unit_kerja.php'); exit;
}

// ── SAVE (tambah / update) ─────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfVerify();
    $fields = [
        'jenis_kontrak' => $_POST['jenis_kontrak'] ?? 'DISTRIBUSI',
        'kode'          => trim($_POST['kode'] ?? ''),
        'nama'          => trim($_POST['nama'] ?? ''),
        'keterangan'    => trim($_POST['keterangan'] ?? '') ?: null,
        'urutan'        => (int)($_POST['urutan'] ?? 0),
        'is_active'     => isset($_POST['is_active']) ? 1 : 0,
    ];
    if ($fields['kode'] === '' || $fields['nama'] === '') {
        setFlash('danger', 'Kode dan Nama Unit wajib diisi.');
        header('Location: unit_kerja.php?act=' . ($id ? 'edit&id=' . $id : 'tambah')); exit;
    }

    $dup = (bool)dbVal($db,
        "SELECT COUNT(*) FROM unit_kerja WHERE jenis_kontrak=? AND LOWER(TRIM(kode))=LOWER(TRIM(?)) AND id<>?",
        [$fields['jenis_kontrak'], $fields['kode'], $id]);
    if ($dup) {
        setFlash('danger', "⚠️ Unit dengan kode \"{$fields['kode']}\" sudah ada untuk jenis kontrak {$fields['jenis_kontrak']}.");
        header('Location: unit_kerja.php?act=' . ($id ? 'edit&id=' . $id : 'tambah')); exit;
    }

    if ($id) {
        $old = dbRow($db, "SELECT * FROM unit_kerja WHERE id=?", [$id]);
        $sets = implode(',', array_map(fn($k) => "$k=?", array_keys($fields)));
        $vals = array_values($fields);
        $vals[] = $id;
        dbExec($db, "UPDATE unit_kerja SET $sets WHERE id=?", $vals);
        [$lama, $baru] = diffFields($old ?: [], $fields);
        logAudit($db, 'update', 'unit_kerja', "Update unit kerja id=$id", $lama ?: null, $baru ?: null);
        $msg = 'success_update';
    } else {
        $cols = implode(',', array_keys($fields));
        $phs  = implode(',', array_fill(0, count($fields), '?'));
        dbExec($db, "INSERT INTO unit_kerja ($cols) VALUES ($phs)", array_values($fields));
        logAudit($db, 'create', 'unit_kerja', "Tambah unit kerja: {$fields['jenis_kontrak']} - {$fields['nama']}", null, $fields);
        $msg = 'success_create';
    }
    setFlash('success', $msg === 'success_create' ? '✅ Unit kerja berhasil ditambahkan.' : '✅ Unit kerja berhasil diperbarui.');
    header("Location: unit_kerja.php"); exit;
}

$editData = null;
if ($act === 'edit' && $id) {
    $editData = dbRow($db, "SELECT * FROM unit_kerja WHERE id=?", [$id]);
}

// ── LIST + FILTER PER JENIS KONTRAK ─────────────────────
$filterJenis = strtoupper($_GET['jenis'] ?? 'SEMUA');
$where = [];
$params = [];
if (in_array($filterJenis, ['DISTRIBUSI', 'TRANSMISI', 'PEMBANGKIT'], true)) {
    $where[] = "jenis_kontrak=?";
    $params[] = $filterJenis;
}
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
$unitList = dbAll($db, "SELECT u.*, (SELECT COUNT(*) FROM kontrak k WHERE k.unit_id=u.id) AS jml_kontrak
                         FROM unit_kerja u $whereSql ORDER BY jenis_kontrak, urutan, nama", $params);

$countJenis = [
    'SEMUA'      => (int)dbVal($db, "SELECT COUNT(*) FROM unit_kerja"),
    'DISTRIBUSI' => (int)dbVal($db, "SELECT COUNT(*) FROM unit_kerja WHERE jenis_kontrak='DISTRIBUSI'"),
    'TRANSMISI'  => (int)dbVal($db, "SELECT COUNT(*) FROM unit_kerja WHERE jenis_kontrak='TRANSMISI'"),
    'PEMBANGKIT' => (int)dbVal($db, "SELECT COUNT(*) FROM unit_kerja WHERE jenis_kontrak='PEMBANGKIT'"),
];
$jenisTabs = ['SEMUA' => 'Semua', 'DISTRIBUSI' => 'Distribusi', 'TRANSMISI' => 'Transmisi', 'PEMBANGKIT' => 'Pembangkit'];

require 'includes/header.php';
?>

<?php if ($act !== 'list'): ?>
<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title"><?= $editData ? '✏️ Edit Project' : '➕ Tambah Project' ?></div>
            <div class="card-subtitle">Unit kerja per jenis kontrak — mis. Transmisi: OPGI, GP. Nanti tiap unit bisa punya cara input SLA sendiri-sendiri.</div>
        </div>
        <a href="unit_kerja.php" class="btn btn-outline btn-sm">← Kembali</a>
    </div>
    <div class="card-body">
    <form method="POST">
        <?= csrfField() ?>
        <div class="form-grid">
            <div class="form-group">
                <label>Bidang</label>
                <select class="form-control" name="jenis_kontrak">
                    <option value="DISTRIBUSI" <?= ($editData['jenis_kontrak'] ?? 'DISTRIBUSI') == 'DISTRIBUSI' ? 'selected' : '' ?>>Distribusi</option>
                    <option value="TRANSMISI" <?= ($editData['jenis_kontrak'] ?? '') == 'TRANSMISI' ? 'selected' : '' ?>>Transmisi</option>
                    <option value="PEMBANGKIT" <?= ($editData['jenis_kontrak'] ?? '') == 'PEMBANGKIT' ? 'selected' : '' ?>>Pembangkit</option>
                </select>
            </div>
            <div class="form-group">
                <label>Kode Unit</label>
                <input class="form-control" name="kode" required placeholder="Mis. OPGI, GP" value="<?= h($editData['kode'] ?? '') ?>">
            </div>
            <div class="form-group" style="grid-column:1/-1">
                <label>Nama Unit</label>
                <input class="form-control" name="nama" required placeholder="Mis. OPGI" value="<?= h($editData['nama'] ?? '') ?>">
            </div>
            <div class="form-group" style="grid-column:1/-1">
                <label>Keterangan (opsional)</label>
                <input class="form-control" name="keterangan" placeholder="Deskripsi singkat unit ini" value="<?= h($editData['keterangan'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Urutan Tampil</label>
                <input class="form-control" type="number" name="urutan" value="<?= h((string)($editData['urutan'] ?? 0)) ?>">
            </div>
            <div class="form-group" style="display:flex;align-items:end;">
                <label style="display:flex;align-items:center;gap:8px;margin:0;">
                    <input type="checkbox" name="is_active" value="1" <?= ($editData['is_active'] ?? 1) ? 'checked' : '' ?>>
                    Aktif (tampil di pilihan Unit pada Data Kontrak)
                </label>
            </div>
        </div>
        <hr class="divider">
        <div style="display:flex;gap:10px;justify-content:flex-end;">
            <a href="unit_kerja.php" class="btn btn-outline">Batal</a>
            <button type="submit" class="btn btn-primary">💾 Simpan Project</button>
        </div>
    </form>
    </div>
</div>

<?php else: ?>

<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title"><i class="bi bi-diagram-3"></i> Kelola Project</div>
            <div class="card-subtitle">Master data unit per jenis kontrak (mis. Transmisi → OPGI, GP). Tambahkan unit sesuai kebutuhan — tiap unit nanti bisa punya cara input SLA yang berbeda.</div>
        </div>
        <a href="unit_kerja.php?act=tambah" class="btn btn-primary">+ Tambah Project</a>
    </div>
    <div class="card-body">
        <div class="tabs">
            <?php foreach ($jenisTabs as $jv => $jl): ?>
            <a class="tab-btn<?= $filterJenis === $jv ? ' active' : '' ?>" href="unit_kerja.php?jenis=<?= $jv ?>">
                <?= $jl ?> <span class="tab-count"><?= $countJenis[$jv] ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Bidang</th>
                    <th>Kode</th>
                    <th>Nama Unit</th>
                    <th>Keterangan</th>
                    <th>Dipakai di Kontrak</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($unitList as $i => $r): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= badgeJenisKontrak($r['jenis_kontrak']) ?></td>
                    <td><b><?= h($r['kode']) ?></b></td>
                    <td><?= h($r['nama']) ?></td>
                    <td style="color:var(--text-light);font-size:12px;"><?= h($r['keterangan'] ?? '-') ?></td>
                    <td><?= (int)$r['jml_kontrak'] ?> kontrak</td>
                    <td>
                        <?php if ($r['is_active']): ?>
                        <span class="badge badge-success">Aktif</span>
                        <?php else: ?>
                        <span class="badge badge-danger">Nonaktif</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="aksi-btn-group">
                            <a href="unit_kerja.php?act=edit&id=<?= $r['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="#" onclick="confirmDelete('<?= csrfUrl('unit_kerja.php?act=hapus&id=' . $r['id']) ?>','unit kerja ini')" class="btn btn-danger btn-sm">Hapus</a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($unitList)): ?>
                <tr><td colspan="8" style="text-align:center;color:var(--gray-400);padding:24px;">Belum ada project untuk kategori ini. Klik "+ Tambah Project" untuk menambahkan.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php require 'includes/footer.php'; ?>
