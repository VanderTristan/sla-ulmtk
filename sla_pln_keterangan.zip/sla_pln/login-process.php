<?php
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit;
}

csrfVerify();

$pdo = getDB();

$username = trim($_POST['username'] ?? '');
$password = (string)($_POST['password'] ?? '');
$ip = clientIp();

if ($username === '' || $password === '') {
    setFlash('danger', 'Username dan password wajib diisi.');
    header('Location: login.php');
    exit;
}

if (isLoginLocked($pdo, $username, $ip)) {
    setFlash('danger', 'Terlalu banyak percobaan login gagal. Akun terkunci sementara, coba lagi dalam 3 menit.');
    header('Location: login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM app_users WHERE username = ? LIMIT 1");
$stmt->execute([$username]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password'])) {
    recordLoginAttempt($pdo, $username, false);
    $_SESSION['old_username'] = $username;
    setFlash('danger', 'Username atau password salah.');
    header('Location: login.php');
    exit;
}

if ($user['status'] !== 'Aktif') {
    recordLoginAttempt($pdo, $username, false);
    setFlash('danger', 'Akun "' . $user['username'] . '" tidak aktif. Hubungi administrator.');
    header('Location: login.php');
    exit;
}

recordLoginAttempt($pdo, $username, true);

// Cegah session fixation
session_regenerate_id(true);

$_SESSION['user'] = [
    'id'       => (int)$user['id'],
    'nama'     => $user['nama'],
    'username' => $user['username'],
    'email'    => $user['email'],
    'role'     => $user['role'],
    'foto'     => $user['foto'] ?? null,
    'must_change_password' => (bool)($user['must_change_password'] ?? false),
    'theme_preference' => $user['theme_preference'] ?? 'light',
];

logAudit($pdo, 'login', 'auth', 'Login berhasil');

$redirect = $_SESSION['redirect_after_login'] ?? 'index.php';
unset($_SESSION['redirect_after_login']);

// Jangan sampai redirect balik ke halaman login/logout/proses (cegah redirect loop)
if ($redirect === '' || str_contains($redirect, 'login') || str_contains($redirect, 'logout')) {
    $redirect = 'index.php';
}

setFlash('success', 'Selamat datang, ' . $user['nama'] . '!');
header('Location: ' . $redirect);
exit;
