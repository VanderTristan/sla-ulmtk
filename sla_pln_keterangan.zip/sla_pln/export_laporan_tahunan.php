<?php
/**
 * export_laporan_tahunan.php — Export Laporan Tahunan SLA satu project ke .xlsx.
 * Isinya sama dengan tabel "Tren SLA Bulanan" di cetak.php?tipe=tahunan,
 * ditambah kolom SLA keseluruhan dan baris rata-rata setahun.
 *
 * Dipanggil dari: cetak.php (tombol "Export Excel" saat Jenis Laporan = Tahunan)
 * Contoh URL: export_laporan_tahunan.php?kontrak_id=6&tahun=2026
 */
require_once 'includes/database.php';
require_once 'includes/xlsx_writer.php';

$db = getDB();
requireReportAccess();

$kontrak_id = (int)($_GET['kontrak_id'] ?? 0);
$tahun      = (int)($_GET['tahun'] ?? date('Y'));
if (!$kontrak_id) { http_response_code(400); die('Parameter kontrak_id wajib diisi.'); }

$kontrak = dbRow($db, "SELECT * FROM kontrak WHERE id=?", [$kontrak_id]);
if (!$kontrak) { http_response_code(404); die('Kontrak tidak ditemukan.'); }

$rows = dbAll($db, "SELECT k.periode_bulan, k.tahap, r.sla_teknis, r.sla_k3, r.sla_kecelakaan, r.sla_ilp, r.sla_overall, r.total_bobot
    FROM kontrak k LEFT JOIN rekap_sla r ON r.kontrak_id = k.id
    WHERE k.nama_kontrak = ? AND k.tahun = ? ORDER BY k.id ASC", [$kontrak['nama_kontrak'], $tahun]);
$bulanUrut = ['JANUARI','FEBRUARI','MARET','APRIL','MEI','JUNI','JULI','AGUSTUS','SEPTEMBER','OKTOBER','NOVEMBER','DESEMBER'];
usort($rows, fn($a, $b) => array_search($a['periode_bulan'], $bulanUrut) <=> array_search($b['periode_bulan'], $bulanUrut));

$xlsx = new SimpleXlsxWriter();

$info = [
    ['Nama Kontrak', (string)($kontrak['nama_kontrak'] ?? '')],
    ['Vendor', (string)($kontrak['vendor'] ?? '')],
    ['Jenis Kontrak', (string)($kontrak['jenis_kontrak'] ?? '')],
    ['Tahun', $tahun],
];
$xlsx->addSheet('Info', $info, false, [18, 70]);
$header = ['Periode Bulan', 'Tahap', 'SLA Teknis (%)', 'SLA K3 (%)', 'SLA Kecelakaan (%)', 'SLA ILP (%)', 'SLA Keseluruhan (%)'];
$data = [$header];

$sum = ['t' => 0, 'k3' => 0, 'kc' => 0, 'ilp' => 0, 'all' => 0];
$n = 0;
foreach ($rows as $r) {
    $adaRekap = $r['sla_teknis'] !== null;
    $t   = round((float)($r['sla_teknis'] ?? 0), 2);
    $k3  = round((float)($r['sla_k3'] ?? 0), 2);
    $kc  = round((float)($r['sla_kecelakaan'] ?? 0), 2);
    $ilp = round((float)($r['sla_ilp'] ?? 0), 2);
    $all = $adaRekap ? round(rekapOverallPct($r), 2) : 0;
    $data[] = [
        ucwords(strtolower((string)($r['periode_bulan'] ?? ''))),
        (string)($r['tahap'] ?? ''),
        $adaRekap ? $t : '-', $adaRekap ? $k3 : '-', $adaRekap ? $kc : '-', $adaRekap ? $ilp : '-', $adaRekap ? $all : '-',
    ];
    if ($adaRekap) { $sum['t'] += $t; $sum['k3'] += $k3; $sum['kc'] += $kc; $sum['ilp'] += $ilp; $sum['all'] += $all; $n++; }
}
if (empty($rows)) {
    $data[] = ['Belum ada data kontrak/rekap untuk project dan tahun ini', '', '', '', '', '', ''];
} elseif ($n > 0) {
    $data[] = ['RATA-RATA', '', round($sum['t']/$n, 2), round($sum['k3']/$n, 2), round($sum['kc']/$n, 2), round($sum['ilp']/$n, 2), round($sum['all']/$n, 2)];
}
$xlsx->addSheet('Laporan Tahunan', $data, true, [24, 14, 16, 14, 18, 14, 20]);

logAudit($db, 'export', 'rekap_sla', "Export Excel laporan tahunan kontrak_id=$kontrak_id tahun=$tahun");

$safe = preg_replace('/[^A-Za-z0-9_-]+/', '_', (string)($kontrak['nama_kontrak'] ?? 'kontrak'));
$xlsx->download('Laporan_Tahunan_SLA_' . substr($safe, 0, 50) . '_' . $tahun . '_' . date('Ymd') . '.xlsx');
