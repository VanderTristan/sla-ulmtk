<?php
/**
 * audit-log.php
 *
 * Jejak audit: siapa mengubah data, kapan, data lama, data baru.
 * Hanya bisa diakses Admin.
 */
require_once 'includes/database.php';
$db = getDB();
requireAdmin();
$title = 'Audit Log';

// ── Filter ──────────────────────────────────────────────────
$f_modul    = $_GET['modul'] ?? '';
$f_aksi     = $_GET['aksi'] ?? '';
$f_user     = trim($_GET['user'] ?? '');
$f_dari     = $_GET['dari'] ?? '';
$f_sampai   = $_GET['sampai'] ?? '';
$page       = max(1, (int)($_GET['page'] ?? 1));
$perPage    = 30;

$where  = [];
$params = [];
if ($f_modul !== '') { $where[] = "modul = ?"; $params[] = $f_modul; }
if ($f_aksi  !== '') { $where[] = "aksi = ?";   $params[] = $f_aksi; }
if ($f_user  !== '') { $where[] = "username LIKE ?"; $params[] = "%$f_user%"; }
if ($f_dari  !== '') { $where[] = "created_at >= ?"; $params[] = $f_dari . ' 00:00:00'; }
if ($f_sampai!== '') { $where[] = "created_at <= ?"; $params[] = $f_sampai . ' 23:59:59'; }
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$total = (int)dbVal($db, "SELECT COUNT(*) FROM audit_log $whereSql", $params);
$totalPages = max(1, (int)ceil($total / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

$logs = dbAll($db, "SELECT * FROM audit_log $whereSql ORDER BY created_at DESC, id DESC LIMIT $perPage OFFSET $offset", $params);

$modulList = dbAll($db, "SELECT DISTINCT modul FROM audit_log ORDER BY modul");
$aksiList  = dbAll($db, "SELECT DISTINCT aksi FROM audit_log ORDER BY aksi");

function auditAksiBadge($aksi) {
    switch ($aksi) {
        case 'create': return 'badge-success';
        case 'update': return 'badge-warning';
        case 'delete': return 'badge-danger';
        case 'login':  return 'badge-info';
        case 'recalc': return 'badge-purple';
        default:       return 'badge-info';
    }
}
function auditFormatVal($v) {
    if ($v === null) return '<span style="color:#9ca3af;">-</span>';
    if (is_array($v) || is_object($v)) $v = json_encode($v, JSON_UNESCAPED_UNICODE);
    $v = (string)$v;
    if (strlen($v) > 60) $v = substr($v, 0, 60) . '…';
    return htmlspecialchars($v);
}

include 'includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title">🕵️ Audit Log</div>
            <div class="card-subtitle">Jejak siapa mengubah data, kapan, data lama & data baru — total <?= $total ?> aktivitas</div>
        </div>
    </div>
    <div class="card-body">
        <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
            <div class="form-group" style="margin-bottom:0;min-width:150px;">
                <label style="font-size:11.5px;">Modul</label>
                <select name="modul" class="form-control">
                    <option value="">-- Semua --</option>
                    <?php foreach($modulList as $m): ?>
                    <option value="<?= h($m['modul']) ?>" <?= $f_modul===$m['modul']?'selected':'' ?>><?= h($m['modul']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="margin-bottom:0;min-width:140px;">
                <label style="font-size:11.5px;">Aksi</label>
                <select name="aksi" class="form-control">
                    <option value="">-- Semua --</option>
                    <?php foreach($aksiList as $a): ?>
                    <option value="<?= h($a['aksi']) ?>" <?= $f_aksi===$a['aksi']?'selected':'' ?>><?= h(ucfirst($a['aksi'])) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="margin-bottom:0;min-width:150px;">
                <label style="font-size:11.5px;">User</label>
                <input type="text" name="user" class="form-control" placeholder="username..." value="<?= h($f_user) ?>">
            </div>
            <div class="form-group" style="margin-bottom:0;">
                <label style="font-size:11.5px;">Dari Tanggal</label>
                <input type="date" name="dari" class="form-control" value="<?= h($f_dari) ?>">
            </div>
            <div class="form-group" style="margin-bottom:0;">
                <label style="font-size:11.5px;">Sampai Tanggal</label>
                <input type="date" name="sampai" class="form-control" value="<?= h($f_sampai) ?>">
            </div>
            <button type="submit" class="btn btn-primary">🔍 Filter</button>
            <a href="audit-log.php" class="btn btn-outline">Reset</a>
        </form>
    </div>
</div>

<div class="card">
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th style="width:140px;">Waktu</th>
                <th>User</th>
                <th>Aksi</th>
                <th>Modul</th>
                <th>Keterangan</th>
                <th>Data Lama</th>
                <th>Data Baru</th>
                <th>Alasan</th>
            </tr>
        </thead>
        <tbody>
        <?php if (empty($logs)): ?>
        <tr><td colspan="8" style="text-align:center;padding:30px;color:var(--text-light);">Tidak ada data audit log untuk filter ini.</td></tr>
        <?php endif; ?>
        <?php foreach ($logs as $log):
            $dataLama = $log['data_lama'] ? json_decode($log['data_lama'], true) : null;
            $dataBaru = $log['data_baru'] ? json_decode($log['data_baru'], true) : null;
        ?>
        <tr>
            <td style="font-size:11.5px;white-space:nowrap;"><?= date('d/m/Y H:i:s', strtotime($log['created_at'])) ?></td>
            <td><b><?= h($log['username'] ?? 'system') ?></b><div style="font-size:10.5px;color:var(--text-light);"><?= h($log['ip_address'] ?? '') ?></div></td>
            <td><span class="badge <?= auditAksiBadge($log['aksi']) ?>"><?= h(ucfirst($log['aksi'])) ?></span></td>
            <td><?= h($log['modul']) ?></td>
            <td style="font-size:12px;max-width:220px;"><?= h($log['detail']) ?></td>
            <td style="font-size:11px;max-width:220px;">
                <?php if ($dataLama): foreach ($dataLama as $k=>$v): ?>
                    <div><b><?= h($k) ?>:</b> <?= auditFormatVal($v) ?></div>
                <?php endforeach; else: ?>
                    <span style="color:#9ca3af;">-</span>
                <?php endif; ?>
            </td>
            <td style="font-size:11px;max-width:220px;">
                <?php if ($dataBaru): foreach ($dataBaru as $k=>$v): ?>
                    <div><b><?= h($k) ?>:</b> <?= auditFormatVal($v) ?></div>
                <?php endforeach; else: ?>
                    <span style="color:#9ca3af;">-</span>
                <?php endif; ?>
            </td>
            <td style="font-size:11.5px;max-width:180px;">
                <?= $log['alasan'] ? nl2br(h($log['alasan'])) : '<span style="color:#9ca3af;">-</span>' ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php if ($totalPages > 1): ?>
    <div style="display:flex;gap:6px;justify-content:center;padding:14px;flex-wrap:wrap;">
        <?php
        $qs = $_GET; 
        for ($p = 1; $p <= $totalPages; $p++):
            $qs['page'] = $p;
            $active = $p === $page;
        ?>
        <a href="?<?= http_build_query($qs) ?>" class="btn btn-sm <?= $active ? 'btn-primary' : 'btn-outline' ?>"><?= $p ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
