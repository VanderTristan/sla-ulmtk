<?php
require_once 'includes/database.php';
require_once 'includes/auth.php';

requireAdmin();
csrfVerify();

$db = getDB();
$id = (int)($_GET['id'] ?? 0);
$me = currentUser();

if ($id === (int)($me['id'] ?? 0)) {
    setFlash('danger', 'Anda tidak dapat menghapus akun Anda sendiri.');
    header('Location: users.php');
    exit;
}

if ($id > 0) {
    $oldUser = dbRow($db, "SELECT nama, username, email, role, status FROM app_users WHERE id = ?", [$id]);
    if ($oldUser) {
        dbExec($db, "DELETE FROM app_users WHERE id = ?", [$id]);
        logAudit($db, 'delete', 'user', "Hapus user id=$id ({$oldUser['nama']})", $oldUser, null);
        setFlash('success', 'User "' . $oldUser['nama'] . '" berhasil dihapus.');
    } else {
        setFlash('danger', 'User tidak ditemukan.');
    }
} else {
    setFlash('danger', 'ID tidak valid.');
}

header('Location: users.php');
exit;
