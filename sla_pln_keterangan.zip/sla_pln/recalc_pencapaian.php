<?php
/**
 * recalc_pencapaian.php
 *
 * Alat sekali-pakai (Super Admin): hitung ulang % pencapaian & nilai berbobot
 * SEMUA indikator yang sudah tersimpan, lalu perbarui rekap SLA tiap kontrak.
 * Perlu dijalankan sekali setelah batas 100% dihapus, supaya data lama (yang
 * sebelumnya terpotong di 100%) ikut menjadi > 100% tanpa harus disimpan ulang
 * satu per satu.
 */
require_once 'includes/database.php';
requireLogin();
if (!isSuperAdmin()) { http_response_code(403); exit('Hanya Super Admin.'); }
$db = getDB();
$title = 'Hitung Ulang Pencapaian';

$hasil = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfVerify();
    $rows = dbAll($db, "SELECT id, kontrak_id, polaritas, target, realisasi, bobot FROM sla_entries WHERE realisasi IS NOT NULL");
    $diubah = 0; $kontrakIds = [];
    foreach ($rows as $r) {
        $pct = hitungPencapaian((string)$r['polaritas'], (float)$r['target'], (float)$r['realisasi']);
        $nb  = hitungNilaiBobot((float)$r['bobot'], $pct);
        dbExec($db, "UPDATE sla_entries SET persen_pencapaian=?, nilai_bobot=? WHERE id=?", [$pct, $nb, (int)$r['id']]);
        $kontrakIds[(int)$r['kontrak_id']] = true;
        $diubah++;
    }
    foreach (array_keys($kontrakIds) as $kid) updateRekapSLA($kid);
    logAudit($db, 'update', 'sla_entries', "Hitung ulang pencapaian: $diubah indikator, " . count($kontrakIds) . " kontrak");
    $hasil = [$diubah, count($kontrakIds)];
}
include 'includes/header.php';
?>
<div class="card">
    <div class="card-header"><div class="card-title">🔄 Hitung Ulang Pencapaian SLA</div></div>
    <div class="card-body">
        <?php if ($hasil): ?>
        <div class="alert alert-success">✅ Selesai: <?= $hasil[0] ?> indikator di <?= $hasil[1] ?> kontrak dihitung ulang.</div>
        <?php endif; ?>
        <p>Menghitung ulang % pencapaian, nilai berbobot, dan rekap SLA semua kontrak memakai rumus terbaru (pencapaian boleh lebih dari 100%).</p>
        <form method="POST"><?= csrfField() ?>
            <button type="submit" class="btn btn-primary" onclick="return confirm('Hitung ulang semua indikator?')">Hitung Ulang Sekarang</button>
        </form>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
