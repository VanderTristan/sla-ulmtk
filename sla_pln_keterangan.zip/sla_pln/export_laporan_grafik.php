<?php
/**
 * export_laporan_grafik.php — Export data di balik "Laporan Grafik" (laporan_grafik.php) ke .xlsx.
 * Filter (tahun, jenis, unit_id) identik dengan halaman. Satu sheet per grafik.
 */
require_once 'includes/database.php';
require_once 'includes/xlsx_writer.php';

$db = getDB();
requireReportAccess();

$tahun  = trim($_GET['tahun'] ?? '');
$jenis  = trim($_GET['jenis'] ?? '');
$unitId = trim($_GET['unit_id'] ?? '');
if ($jenis === '') $unitId = '';
if ($unitId !== '' && $unitId !== 'none') {
    $unitOptions = getUnitKerjaList($db, $jenis);
    if (!in_array((int)$unitId, array_map('intval', array_column($unitOptions, 'id')), true)) $unitId = '';
}

$whereParts = []; $params = [];
if ($tahun !== '') { $whereParts[] = "k.tahun = ?"; $params[] = $tahun; }
if ($jenis !== '') { $whereParts[] = "k.jenis_kontrak = ?"; $params[] = $jenis; }
if ($unitId === 'none') {
    $whereParts[] = "k.unit_id IS NULL";
} elseif ($unitId !== '') {
    $whereParts[] = "k.unit_id = ?"; $params[] = (int)$unitId;
}
$whereSql = $whereParts ? (' AND ' . implode(' AND ', $whereParts)) : '';
$r2 = fn($v) => $v === null ? '' : round((float)$v, 2);

$trend = dbAll($db, "
    SELECT k.periode_bulan, k.tahun, k.nama_kontrak, r.sla_overall AS avg_sla
    FROM rekap_sla r JOIN kontrak k ON r.kontrak_id = k.id
    WHERE 1=1 $whereSql
    ORDER BY k.tahun ASC, FIELD(k.periode_bulan,'JANUARI','FEBRUARI','MARET','APRIL','MEI','JUNI','JULI','AGUSTUS','SEPTEMBER','OKTOBER','NOVEMBER','DESEMBER') ASC, k.id ASC", $params);
$perUlp = dbAll($db, "
    SELECT u.nama_ulp, AVG(e.persen_pencapaian) AS avg_pencapaian, COUNT(e.id) AS jml_indikator
    FROM sla_entries e JOIN ulp u ON e.ulp_id = u.id JOIN kontrak k ON u.kontrak_id = k.id
    WHERE 1=1 $whereSql GROUP BY u.id, u.nama_ulp ORDER BY avg_pencapaian DESC", $params);
$perVendor = dbAll($db, "
    SELECT k.vendor, AVG(r.sla_overall) AS avg_sla, COUNT(DISTINCT k.id) AS jml_kontrak
    FROM rekap_sla r JOIN kontrak k ON r.kontrak_id = k.id
    WHERE k.vendor IS NOT NULL AND k.vendor != '' $whereSql GROUP BY k.vendor ORDER BY avg_sla DESC", $params);
$indikator = dbAll($db, "
    SELECT e.kategori, e.ruang_lingkup, e.kriteria, AVG(e.persen_pencapaian) AS avg_pct
    FROM sla_entries e JOIN kontrak k ON e.kontrak_id = k.id
    WHERE e.ulp_id IS NULL $whereSql GROUP BY e.kategori, e.ruang_lingkup, e.kriteria ORDER BY avg_pct ASC", $params);

$sheet = function (array $header, array $rows, array $kosong) { array_unshift($rows, $header); if (count($rows) === 1) $rows[] = $kosong; return $rows; };

$a = []; $no = 1;
foreach ($trend as $t) $a[] = [$no++, (string)($t['nama_kontrak'] ?? ''), ucwords(strtolower((string)$t['periode_bulan'])) . ' ' . $t['tahun'], $r2($t['avg_sla'])];
$b = []; $no = 1;
foreach ($perUlp as $u) $b[] = [$no++, (string)$u['nama_ulp'], $r2($u['avg_pencapaian']), (int)$u['jml_indikator']];
$c = []; $no = 1;
foreach ($perVendor as $v) $c[] = [$no++, (string)$v['vendor'], $r2($v['avg_sla']), (int)$v['jml_kontrak']];
$d = []; $no = 1;
foreach ($indikator as $i) $d[] = [$no++, (string)$i['kategori'], (string)($i['ruang_lingkup'] ?? ''), (string)($i['kriteria'] ?? ''), $r2($i['avg_pct'])];

$unitLabel = 'Semua';
if ($unitId === 'none') $unitLabel = 'Belum Ditentukan / Tanpa Unit';
elseif ($unitId !== '') $unitLabel = (string)(dbVal($db, "SELECT nama FROM unit_kerja WHERE id=?", [(int)$unitId]) ?: $unitId);

$xlsx = new SimpleXlsxWriter();
$xlsx->addSheet('Info', [['Filter', 'Nilai'],
    ['Laporan', 'Laporan Grafik'],
    ['Bidang', $jenis !== '' ? ucfirst(strtolower($jenis)) : 'Semua'],
    ['Unit', $unitLabel],
    ['Tahun', $tahun !== '' ? $tahun : 'Semua'],
    ['Diekspor', date('d-m-Y H:i')]], true, [16, 40]);
$xlsx->addSheet('SLA per Bulan',  $sheet(['No', 'Kontrak', 'Periode', 'SLA (%)'], $a, ['', 'Tidak ada data', '', '']), true, [5, 36, 16, 12]);
$xlsx->addSheet('SLA per ULP',    $sheet(['No', 'ULP', 'Rata-Rata Pencapaian (%)', 'Jumlah Indikator'], $b, ['', 'Tidak ada data', '', '']), true, [5, 30, 24, 16]);
$xlsx->addSheet('SLA per Vendor', $sheet(['No', 'Vendor', 'Rata-Rata SLA (%)', 'Jumlah Kontrak'], $c, ['', 'Tidak ada data', '', '']), true, [5, 34, 18, 15]);
$xlsx->addSheet('Pencapaian Indikator', $sheet(['No', 'Kategori', 'Ruang Lingkup', 'Indikator', 'Rata-Rata Pencapaian (%)'], $d, ['', '', 'Tidak ada data', '', '']), true, [5, 14, 30, 44, 24]);

logAudit($db, 'export', 'laporan_grafik', "Export Excel Laporan Grafik (bidang=" . ($jenis ?: 'semua') . ", unit=$unitLabel, tahun=" . ($tahun ?: 'semua') . ")");
$xlsx->download('Laporan_Grafik_' . date('Ymd_His') . '.xlsx');
