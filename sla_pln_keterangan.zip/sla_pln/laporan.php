<?php
require_once 'includes/database.php';
require_once 'includes/laporan_helper.php';
$db = getDB();
requireReportAccess();
$title = 'Laporan SLA';

$f     = laporanFilter();
$opsi  = laporanOpsi($db);
$tampil = isset($_GET['tampil']);              // data baru dimuat setelah tombol [Tampilkan] ditekan
$rows  = $tampil ? laporanRows($db, $f) : [];
$terpotong = count($rows) >= LAPORAN_MAX_BARIS;

// Query string filter untuk tombol Export Excel (tanpa parameter 'tampil')
$qs = http_build_query(array_filter($f, fn($v) => $v !== '' && $v !== 0));

include 'includes/header.php';
?>
<style>
@media print {
    .sidebar, .topbar, .no-print { display:none!important; }
    .main { margin-left:0!important; }
    .content { padding:0!important; }
    .card { box-shadow:none!important; border:1px solid #ccc!important; overflow:visible!important; }
    .table-wrap { overflow:visible!important; }
    table { width:100%!important; font-size:9px!important; }
    th, td { padding:2px 4px!important; white-space:normal!important; word-break:break-word; }
    thead { display:table-header-group; }
    tr { page-break-inside:avoid; }
    .print-title { display:block!important; }
    * { -webkit-print-color-adjust:exact; print-color-adjust:exact; }
    @page { size: A4 landscape; margin: 8mm; }
}
.print-title { display:none; margin-bottom:8px; }
</style>

<div class="card no-print">
    <div class="card-header"><div class="card-title"><i class="bi bi-funnel" style="color:var(--blue);"></i> Laporan SLA per ULP</div></div>
    <div class="card-body">
        <form method="get" action="laporan.php">
            <input type="hidden" name="tampil" value="1">
            <div class="form-grid" style="grid-template-columns:repeat(4,1fr);">
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                        <option value="">Semua</option>
                        <?php foreach ($opsi['tahun'] as $t): ?>
                        <option value="<?= (int)$t ?>" <?= $f['tahun']===(int)$t?'selected':'' ?>><?= (int)$t ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Bulan</label>
                    <select name="bulan" class="form-control">
                        <option value="">Semua</option>
                        <?php foreach (LAPORAN_BULAN as $b): ?>
                        <option value="<?= $b ?>" <?= $f['bulan']===$b?'selected':'' ?>><?= ucwords(strtolower($b)) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>ULP</label>
                    <select name="ulp" class="form-control">
                        <option value="">Semua</option>
                        <?php foreach ($opsi['ulp'] as $u): ?>
                        <option value="<?= htmlspecialchars($u) ?>" <?= $f['ulp']===$u?'selected':'' ?>><?= htmlspecialchars($u) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Indikator</label>
                    <select name="indikator" class="form-control">
                        <option value="">Semua</option>
                        <?php foreach ($opsi['indikator'] as $i): ?>
                        <option value="<?= htmlspecialchars($i) ?>" <?= $f['indikator']===$i?'selected':'' ?>><?= htmlspecialchars(mb_strimwidth($i, 0, 60, '…')) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;">
                <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i> Tampilkan</button>
                <a href="laporan_export.php<?= $qs ? '?'.$qs : '' ?>" class="btn btn-outline"><i class="bi bi-file-earmark-excel"></i> Export Excel</a>
                <button type="button" class="btn btn-outline" onclick="window.print()" <?= $tampil ? '' : 'disabled title="Tampilkan data dulu"' ?>><i class="bi bi-printer"></i> Cetak PDF</button>
            </div>
        </form>
    </div>
</div>

<?php if (!$tampil): ?>
<div class="alert alert-info no-print">Pilih filter lalu tekan <b>Tampilkan</b>. Kosongkan filter untuk melihat semua data.</div>
<?php else: ?>
<div class="print-title">
    <div style="font-size:14px;font-weight:800;">Laporan SLA per ULP</div>
    <div style="font-size:11px;"><?= htmlspecialchars(laporanFilterLabel($f)) ?> &bull; Dicetak <?= date('d-m-Y H:i') ?></div>
</div>
<div class="card">
    <div class="card-header" style="padding:10px 14px;">
        <div>
            <div class="card-title">Hasil</div>
            <div class="card-subtitle"><?= count($rows) ?> baris &mdash; <?= htmlspecialchars(laporanFilterLabel($f)) ?></div>
        </div>
    </div>
    <?php if ($terpotong): ?>
    <div class="alert alert-info no-print" style="margin:0 14px 8px;">Hanya <?= LAPORAN_MAX_BARIS ?> baris pertama yang ditampilkan. Persempit filter agar hasilnya lengkap.</div>
    <?php endif; ?>
    <div class="table-wrap">
        <table style="font-size:12px;">
            <thead>
                <tr>
                    <th>#</th><th>Project</th><th>Periode</th><th>ULP</th><th>Kategori</th><th>Indikator</th>
                    <th style="text-align:center;">Target</th><th style="text-align:center;">Realisasi</th>
                    <th style="text-align:center;">Pencapaian</th><th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$rows): ?>
                <tr><td colspan="10" style="text-align:center;color:#94a3b8;padding:20px;">Tidak ada data untuk filter ini.</td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $i => $r):
                $pct = $r['persen_pencapaian'] !== null ? (float)$r['persen_pencapaian'] : null;
                $fmt = fn($v) => rtrim(rtrim(number_format((float)$v, 2), '0'), '.');
            ?>
                <tr>
                    <td style="color:#94a3b8;"><?= $i+1 ?></td>
                    <td><?= htmlspecialchars(mb_strimwidth((string)($r['nama_kontrak'] ?? ''), 0, 40, '…')) ?></td>
                    <td style="white-space:nowrap;"><?= htmlspecialchars(ucwords(strtolower((string)$r['periode_bulan']))) ?> <?= (int)$r['tahun'] ?></td>
                    <td style="font-weight:600;"><?= htmlspecialchars((string)($r['nama_ulp'] ?? '')) ?></td>
                    <td><span class="badge badge-teknis" style="font-size:10px;"><?= htmlspecialchars((string)($r['kategori'] ?? '')) ?></span></td>
                    <td><?= htmlspecialchars((string)($r['kriteria'] ?? '')) ?></td>
                    <td style="text-align:center;"><?= $fmt($r['target']) ?> <?= htmlspecialchars((string)($r['satuan'] ?? '')) ?></td>
                    <td style="text-align:center;"><?= $r['realisasi'] === null ? '–' : $fmt($r['realisasi']).' '.htmlspecialchars((string)($r['satuan'] ?? '')) ?></td>
                    <td style="text-align:center;"><?= $pct === null ? '–' : '<span style="'.pctBadgeStyle($pct).'font-size:11px;font-weight:700;padding:2px 8px;border-radius:6px;">'.number_format($pct,1).'%</span>' ?></td>
                    <td><?= laporanStatus($pct) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
