<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/auth.php';
$db = getDB(); // memastikan tabel app_users sudah dibuat (initDB)

if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$flash = getFlash();
$oldUsername = $_SESSION['old_username'] ?? '';
unset($_SESSION['old_username']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — SLA Monitoring</title>
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16.png">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicon-180.png">
    <link rel="shortcut icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page">
    <div class="login-wrap">
        <div class="login-card">
            <div class="login-brand">
                <img src="assets/img/logo.png" alt="PLN Nusa Daya" style="height:64px;width:auto;object-fit:contain;display:block;margin:0 auto 12px;">
                <div class="login-sub">Masuk untuk mengakses dashboard</div>
            </div>

            <?= renderFlash($flash, 'margin-bottom:16px;') ?>

            <form method="post" action="login-process.php">
                <?= csrfField() ?>
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" placeholder="Masukkan username" value="<?= h($oldUsername) ?>" required autofocus>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <div class="input-password-wrap">
                        <input type="password" id="password" name="password" placeholder="Masukkan password" required>
                        <button type="button" class="toggle-password" id="togglePassword" aria-label="Tampilkan/sembunyikan password" tabindex="-1">
                            <i class="bi bi-eye" id="eyeIcon"></i>
                        </button>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Masuk</button>
            </form>

            <div class="login-hint"><a href="forgot-password.php">Lupa password?</a></div>
        </div>
    </div>

    <!-- FAB Customer Service — pojok kanan bawah -->
    <div class="cs-fab" id="csFab">
        <!-- Panel pilihan muncul ke atas -->
        <div class="cs-panel" id="csPanel">
            <div class="cs-panel-header">
                <div class="cs-panel-avatar">
                    <i class="bi bi-headset"></i>
                    <span class="cs-online-dot"></span>
                </div>
                <div class="cs-panel-info">
                    <span class="cs-panel-title">Customer Service</span>
                    <span class="cs-panel-status"><span class="cs-blink"></span> Online &amp; Siap Membantu</span>
                </div>
            </div>
            <p class="cs-panel-greeting">Halo! 👋 Pilih saluran komunikasi yang ingin Anda gunakan.</p>
            <div class="cs-opts">
                <a href="mailto:support@plnnusadaya.co.id" class="cs-opt">
                    <div class="cs-opt-ico" style="background:#dbeafe;color:#1d4ed8"><i class="bi bi-envelope-fill"></i></div>
                    <div class="cs-opt-info">
                        <span class="cs-opt-name">Email</span>
                        <span class="cs-opt-detail">support@plnnusadaya.co.id</span>
                    </div>
                    <i class="bi bi-chevron-right cs-opt-arr"></i>
                </a>
                <a href="https://wa.me/6281919731321" class="cs-opt" target="_blank" rel="noopener">
                    <div class="cs-opt-ico" style="background:#d1fae5;color:#065f46"><i class="bi bi-whatsapp"></i></div>
                    <div class="cs-opt-info">
                        <span class="cs-opt-name">WhatsApp</span>
                        <span class="cs-opt-detail">+62 819-1973-1321</span>
                    </div>
                    <i class="bi bi-chevron-right cs-opt-arr"></i>
                </a>
                <a href="#" class="cs-opt" onclick="return false;">
                    <div class="cs-opt-ico" style="background:#fff7ed;color:#c2410c"><i class="bi bi-chat-dots-fill"></i></div>
                    <div class="cs-opt-info">
                        <span class="cs-opt-name">Live Chat</span>
                        <span class="cs-opt-detail">Senin–Jumat, 08.00–17.00 WIB</span>
                    </div>
                    <i class="bi bi-chevron-right cs-opt-arr"></i>
                </a>
            </div>
        </div>

        <!-- Tombol FAB utama -->
        <button class="cs-fab-btn" id="csTrigger" type="button" aria-label="Hubungi Customer Service">
            <span class="cs-fab-ring"></span>
            <i class="bi bi-headset cs-fab-icon-open"></i>
            <i class="bi bi-x-lg cs-fab-icon-close"></i>
        </button>
        <span class="cs-fab-label">Customer Service</span>
    </div>

<script>
    // Toggle password
    document.getElementById('togglePassword').addEventListener('click', function () {
        const p = document.getElementById('password');
        const i = document.getElementById('eyeIcon');
        const hidden = p.type === 'password';
        p.type = hidden ? 'text' : 'password';
        i.className = hidden ? 'bi bi-eye-slash' : 'bi bi-eye';
    });

    // Pindahkan .cs-fab langsung ke <body> agar position:fixed
    // tidak terjebak di dalam stacking context apapun
    const fab = document.getElementById('csFab');
    document.body.appendChild(fab);

    const trigger = document.getElementById('csTrigger');
    const panel   = document.getElementById('csPanel');
    let isOpen = false;

    function openCS() {
        isOpen = true;
        trigger.classList.add('cs-fab-open');
        panel.classList.add('cs-panel-show');
    }
    function closeCS() {
        isOpen = false;
        trigger.classList.remove('cs-fab-open');
        panel.classList.remove('cs-panel-show');
    }

    trigger.addEventListener('click', function (e) {
        e.stopPropagation();
        isOpen ? closeCS() : openCS();
    });

    document.addEventListener('click', function (e) {
        if (isOpen && !fab.contains(e.target)) closeCS();
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && isOpen) closeCS();
    });
</script>
</body>
</html>
