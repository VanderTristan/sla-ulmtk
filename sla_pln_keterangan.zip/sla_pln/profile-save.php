<?php
require __DIR__ . '/includes/database.php';
require __DIR__ . '/includes/auth.php';
getDB();
requireLogin();

$user = currentUser();
$userId = $user['id'];
$redirectBack = $_SERVER['HTTP_REFERER'] ?? 'index.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . $redirectBack);
    exit;
}

csrfVerify();

// Handle foto upload
if (!empty($_FILES['foto']['name'])) {
    $file     = $_FILES['foto'];
    $maxSize  = 2 * 1024 * 1024; // 2MB
    $allowed  = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        setFlash('danger', 'Gagal upload foto.');
        header('Location: ' . $redirectBack);
        exit;
    }
    if ($file['size'] > $maxSize) {
        setFlash('danger', 'Ukuran foto maksimal 2MB.');
        header('Location: ' . $redirectBack);
        exit;
    }

    $finfo    = finfo_open(FILEINFO_MIME_TYPE);
    $mime     = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime, $allowed)) {
        setFlash('danger', 'Format foto harus JPG, PNG, GIF, atau WEBP.');
        header('Location: ' . $redirectBack);
        exit;
    }

    $ext      = match($mime) {
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/gif'  => 'gif',
        'image/webp' => 'webp',
        default      => 'jpg',
    };

    $uploadDir = __DIR__ . '/assets/img/avatars/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    // Hapus foto lama kalau ada
    if (!empty($user['foto'])) {
        $oldFile = __DIR__ . '/' . ltrim($user['foto'], '/');
        if (file_exists($oldFile)) {
            @unlink($oldFile);
        }
    }

    $filename = 'user_' . $userId . '_' . time() . '.' . $ext;
    $dest     = $uploadDir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        setFlash('danger', 'Gagal menyimpan foto.');
        header('Location: ' . $redirectBack);
        exit;
    }

    $fotoPath = 'assets/img/avatars/' . $filename;

    // Simpan ke DB
    $pdo = getDB();
    $stmt = $pdo->prepare("UPDATE app_users SET foto = ? WHERE id = ?");
    $stmt->execute([$fotoPath, $userId]);

    if ($stmt->rowCount() === 0) {
        setFlash('warning', 'Profil tidak berubah. Pastikan user ID valid.');
    } else {
        $_SESSION['user']['foto'] = $fotoPath;
        setFlash('success', 'Foto profil berhasil diperbarui.');
    }
} else {
    setFlash('warning', 'Tidak ada foto yang dipilih.');
}

header('Location: ' . $redirectBack);
exit;
