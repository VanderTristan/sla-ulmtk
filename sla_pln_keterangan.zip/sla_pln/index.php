<?php
require_once 'includes/database.php';
$title = 'Dashboard';
$db = getDB();

// ── Stats ringkasan ─────────────────────────────────────────
$total_kontrak      = (int)dbVal($db, "SELECT COUNT(*) FROM kontrak");
$total_ulp          = (int)dbVal($db, "SELECT COUNT(*) FROM ulp");
$total_entries      = (int)dbVal($db, "SELECT COUNT(*) FROM sla_entries");
$total_users        = (int)dbVal($db, "SELECT COUNT(*) FROM app_users");
$avg_sla_teknis     = (float)(dbVal($db, "SELECT AVG(sla_teknis) FROM rekap_sla") ?? 0);
$avg_sla_k3         = (float)(dbVal($db, "SELECT AVG(sla_k3) FROM rekap_sla") ?? 0);
$avg_kecelakaan     = (float)(dbVal($db, "SELECT AVG(sla_kecelakaan) FROM rekap_sla") ?? 0);
$avg_ilp            = (float)(dbVal($db, "SELECT AVG(sla_ilp) FROM rekap_sla") ?? 0);
// Rata-rata SLA keseluruhan (lintas semua kontrak) — pakai AVG(sla_overall), bukan
// mengambil rata-rata dari 4 rata-rata kategori di atas (itu tetap salah walau
// masing-masing kategorinya sendiri sudah benar, karena porsi tiap kategori beda-beda).
$avg_sla_overall    = (float)(dbVal($db, "SELECT AVG(sla_overall) FROM rekap_sla") ?? 0);
$kontrak_distribusi = (int)dbVal($db, "SELECT COUNT(*) FROM kontrak WHERE jenis_kontrak='DISTRIBUSI' OR jenis_kontrak IS NULL");
$kontrak_transmisi  = (int)dbVal($db, "SELECT COUNT(*) FROM kontrak WHERE jenis_kontrak='TRANSMISI'");
$kontrak_pembangkit = (int)dbVal($db, "SELECT COUNT(*) FROM kontrak WHERE jenis_kontrak='PEMBANGKIT'");
$kontrakNoRekap     = (int)dbVal($db, "SELECT COUNT(*) FROM kontrak k LEFT JOIN rekap_sla r ON r.kontrak_id=k.id WHERE r.id IS NULL");

// Kontrak Aktif = kontrak dengan periode tagihan bulan & tahun berjalan (masih dalam siklus aktif)
$BULAN_ID = [1=>'JANUARI',2=>'FEBRUARI',3=>'MARET',4=>'APRIL',5=>'MEI',6=>'JUNI',7=>'JULI',8=>'AGUSTUS',9=>'SEPTEMBER',10=>'OKTOBER',11=>'NOVEMBER',12=>'DESEMBER'];
$bulanIni = $BULAN_ID[(int)date('n')];
$tahunIni = (int)date('Y');
$kontrak_aktif = (int)dbVal($db, "SELECT COUNT(*) FROM kontrak WHERE UPPER(periode_bulan)=? AND tahun=?", [$bulanIni, $tahunIni]);

// Kontrak Terlambat/Berisiko = avg SLA di bawah ambang target (90%) pada rekap terakhirnya
$kontrak_terlambat = (int)dbVal($db, "
    SELECT COUNT(*) FROM rekap_sla
    WHERE sla_overall < 90
");

// ── Ringkasan Bulan Berjalan (periode berjalan) ────────────
$sla_bulan_berjalan = dbVal($db, "
    SELECT AVG(r.sla_overall)
    FROM rekap_sla r JOIN kontrak k ON r.kontrak_id = k.id
    WHERE UPPER(k.periode_bulan)=? AND k.tahun=?
", [$bulanIni, $tahunIni]);
$sla_bulan_berjalan = $sla_bulan_berjalan !== null ? (float)$sla_bulan_berjalan : null;

// Indikator tercapai / tidak tercapai (level kontrak, bulan berjalan)
$indikator_tercapai = (int)dbVal($db, "
    SELECT COUNT(*) FROM sla_entries e JOIN kontrak k ON e.kontrak_id = k.id
    WHERE e.ulp_id IS NULL AND e.persen_pencapaian >= 100
      AND UPPER(k.periode_bulan)=? AND k.tahun=?
", [$bulanIni, $tahunIni]);
$indikator_tidak_tercapai = (int)dbVal($db, "
    SELECT COUNT(*) FROM sla_entries e JOIN kontrak k ON e.kontrak_id = k.id
    WHERE e.ulp_id IS NULL AND e.persen_pencapaian < 100
      AND UPPER(k.periode_bulan)=? AND k.tahun=?
", [$bulanIni, $tahunIni]);

// ── Pencapaian tiap ULP (rata-rata persen pencapaian semua indikator per ULP) ──
$ulpPerforma = dbAll($db, "
    SELECT u.nama_ulp,
           AVG(e.persen_pencapaian) AS avg_pencapaian,
           COUNT(*) AS jml_indikator
    FROM sla_entries e
    JOIN ulp u ON e.ulp_id = u.id
    GROUP BY u.id, u.nama_ulp
    HAVING avg_pencapaian IS NOT NULL
    ORDER BY avg_pencapaian ASC
");

// ── Top 5 indikator dengan nilai/pencapaian terendah (level kontrak) ──
// Indikator yang belum dinilai (realisasi belum diisi) sengaja dikecualikan —
// bukan berarti "terendah", tapi memang belum ada datanya.
$top5Rendah = dbAll($db, "
    SELECT e.ruang_lingkup, e.kriteria, e.kategori, e.persen_pencapaian,
           e.target, e.realisasi, e.satuan,
           k.nama_kontrak, k.periode_bulan, k.tahun
    FROM sla_entries e
    JOIN kontrak k ON e.kontrak_id = k.id
    WHERE e.ulp_id IS NULL AND e.persen_pencapaian IS NOT NULL
    ORDER BY e.persen_pencapaian ASC
    LIMIT 5
");

// ── Performa Vendor (rata-rata avg SLA per vendor) ──
$vendorPerforma = dbAll($db, "
    SELECT k.vendor,
           AVG(r.sla_overall) AS avg_sla,
           COUNT(DISTINCT k.id) AS jml_kontrak
    FROM rekap_sla r
    JOIN kontrak k ON r.kontrak_id = k.id
    WHERE k.vendor IS NOT NULL AND k.vendor != ''
    GROUP BY k.vendor
    ORDER BY avg_sla DESC
");

// ── Ringkasan per kontrak (semua, terbaru dulu) ────────────
$rekapAll = dbAll($db, "
    SELECT r.*, k.id as kid, k.nama_kontrak, k.periode_bulan, k.tahun, k.tahap,
           k.vendor, k.jenis_kontrak, k.nilai_tagihan_tahap1, k.nilai_tagihan_tahap2,
           r.sla_overall AS avg_sla
    FROM rekap_sla r
    JOIN kontrak k ON r.kontrak_id = k.id
    ORDER BY r.updated_at DESC
");

// ── Tren untuk chart (urut lama ke baru) ──────────────────
$trendRows = dbAll($db, "
    SELECT k.periode_bulan, k.tahun, k.nama_kontrak, k.tahap, k.jenis_kontrak,
           r.sla_teknis, r.sla_k3, r.sla_kecelakaan, r.sla_ilp,
           r.sla_overall AS avg_sla
    FROM rekap_sla r
    JOIN kontrak k ON r.kontrak_id = k.id
    ORDER BY k.tahun ASC, k.id ASC
");

// ── Ringkasan per Bidang (Distribusi/Transmisi/Pembangkit) ─
$bidangSummaryRaw = dbAll($db, "
    SELECT COALESCE(NULLIF(k.jenis_kontrak,''), 'DISTRIBUSI') AS jenis_kontrak,
           COUNT(DISTINCT k.id) AS jml_kontrak,
           COUNT(DISTINCT r.id) AS jml_rekap,
           AVG(r.sla_overall) AS avg_sla
    FROM kontrak k
    LEFT JOIN rekap_sla r ON r.kontrak_id = k.id
    GROUP BY COALESCE(NULLIF(k.jenis_kontrak,''), 'DISTRIBUSI')
");
$bidangSummary = ['DISTRIBUSI'=>null, 'TRANSMISI'=>null, 'PEMBANGKIT'=>null];
foreach ($bidangSummaryRaw as $b) { $bidangSummary[$b['jenis_kontrak']] = $b; }

// ── Performa per Unit Kerja (rata-rata SLA gabungan tiap unit) ──
$unitPerforma = dbAll($db, "
    SELECT u.nama AS nama_unit, u.kode AS kode_unit, u.jenis_kontrak,
           COUNT(DISTINCT k.id) AS jml_kontrak,
           AVG(r.sla_overall) AS avg_sla
    FROM unit_kerja u
    JOIN kontrak k ON k.unit_id = u.id
    LEFT JOIN rekap_sla r ON r.kontrak_id = k.id
    WHERE u.is_active = 1
    GROUP BY u.id, u.nama, u.kode, u.jenis_kontrak
    HAVING COUNT(DISTINCT k.id) > 0
    ORDER BY FIELD(u.jenis_kontrak,'DISTRIBUSI','TRANSMISI','PEMBANGKIT'), avg_sla ASC
");

// ── Kontrak periode berjalan yang belum lengkap input SLA (Periode 1/2) ──
$kontrakBelumInput = dbAll($db, "
    SELECT k.id, k.nama_kontrak, k.jenis_kontrak,
           COUNT(DISTINCT se.id) AS total_indikator,
           COUNT(DISTINCT CASE WHEN mh.periode=1 THEN mh.sla_entry_id END) AS terisi_p1,
           COUNT(DISTINCT CASE WHEN mh.periode=2 THEN mh.sla_entry_id END) AS terisi_p2
    FROM kontrak k
    JOIN sla_entries se ON se.kontrak_id = k.id AND se.ulp_id IS NULL
    LEFT JOIN monitoring_harian mh ON mh.sla_entry_id = se.id
    WHERE UPPER(k.periode_bulan) = ? AND k.tahun = ?
    GROUP BY k.id, k.nama_kontrak, k.jenis_kontrak
    HAVING total_indikator > 0 AND (terisi_p1 < total_indikator OR terisi_p2 < total_indikator)
    ORDER BY k.nama_kontrak
", [$bulanIni, $tahunIni]);

// ── Status kelengkapan data per ULP (periode berjalan) ──────
// Lengkap = semua indikator ULP sudah ada realisasinya; Belum lengkap = sebagian;
// Belum input = belum ada satupun (realisasi NULL = "belum dinilai").
$ulpStatusRows = dbAll($db, "
    SELECT u.id, u.nama_ulp, k.nama_kontrak, k.id AS kid,
           COUNT(e.id) AS total_ind,
           COALESCE(SUM(CASE WHEN e.realisasi IS NOT NULL THEN 1 ELSE 0 END),0) AS terisi
    FROM ulp u
    JOIN kontrak k ON u.kontrak_id = k.id
    LEFT JOIN sla_entries e ON e.ulp_id = u.id
    WHERE UPPER(k.periode_bulan) = ? AND k.tahun = ?
    GROUP BY u.id, u.nama_ulp, k.nama_kontrak, k.id
    ORDER BY k.nama_kontrak, u.nama_ulp
", [$bulanIni, $tahunIni]);
$ulpStatus = ['lengkap'=>0, 'sebagian'=>0, 'kosong'=>0];
$ulpBelumLengkap = [];
foreach ($ulpStatusRows as $ur) {
    $tot = (int)$ur['total_ind']; $ter = (int)$ur['terisi'];
    if ($tot > 0 && $ter >= $tot)  { $ulpStatus['lengkap']++; continue; }
    if ($ter > 0)                  { $ulpStatus['sebagian']++; $ur['status'] = 'sebagian'; }
    else                           { $ulpStatus['kosong']++;   $ur['status'] = 'kosong'; }
    $ulpBelumLengkap[] = $ur;
}

// ── Info ringkas untuk kartu pintasan Laporan (Rekap, Rata-Rata, Grafik, Laporan SLA) ──
$rekapTerekap   = (int)dbVal($db, "SELECT COUNT(*) FROM rekap_sla");
$rekapUpdateTs  = dbVal($db, "SELECT MAX(updated_at) FROM rekap_sla");
$rekapUpdate    = $rekapUpdateTs ? date('d/m/Y H:i', strtotime($rekapUpdateTs)) : null;
$katAvg         = ['Teknis'=>$avg_sla_teknis, 'K3'=>$avg_sla_k3, 'Kecelakaan'=>$avg_kecelakaan, 'ILP'=>$avg_ilp];
$katTertinggi   = $katTerendah = null;
if ($rekapTerekap > 0) {
    $katTertinggi = array_search(max($katAvg), $katAvg);
    $katTerendah  = array_search(min($katAvg), $katAvg);
}
$grafikPeriode  = (int)dbVal($db, "SELECT COUNT(DISTINCT CONCAT(k.tahun,'-',UPPER(k.periode_bulan))) FROM rekap_sla r JOIN kontrak k ON r.kontrak_id=k.id");
$lapTotalBaris  = (int)dbVal($db, "SELECT COUNT(*) FROM sla_entries WHERE ulp_id IS NOT NULL");
$lapTercapai    = (int)dbVal($db, "SELECT COUNT(*) FROM sla_entries WHERE ulp_id IS NOT NULL AND persen_pencapaian >= 100");
$lapBelumTcp    = (int)dbVal($db, "SELECT COUNT(*) FROM sla_entries WHERE ulp_id IS NOT NULL AND persen_pencapaian < 100");
$lapBelumIsi    = (int)dbVal($db, "SELECT COUNT(*) FROM sla_entries WHERE ulp_id IS NOT NULL AND persen_pencapaian IS NULL");

// progressClass() dan pctBadgeStyle() sekarang didefinisikan di includes/database.php
// supaya bisa dipakai bersama oleh halaman lain (mis. detail_perhitungan.php).

include 'includes/header.php';
$canInput = !isSupervisor();   // Team Leader & Manager UL hanya melihat laporan, tidak menginput
?>

<?php
// ── Ringkasan sederhana untuk info banner ──────────────────
// Pakai CSS variable (var(--red-lt) dkk), bukan hex mentah — supaya
// banner status ini otomatis ikut berubah warna saat mode gelap aktif,
// sama seperti perbaikan pctBadgeStyle()/pctColorSla(). Hex mentah
// sebelumnya (#fef2f2, #f0fdf4) tidak cocok dengan pola tambalan mode
// gelap yang ada, jadi banner ini tetap terang menyala di dashboard.
$overallAvg = $avg_sla_overall;
if ($total_kontrak === 0) {
    $statusInfo = ['icon'=>'🆕','color'=>'var(--blue,#0066AE)','bg'=>'var(--blue-lt,#eaf3ff)','title'=>'Belum ada data kontrak',
        'desc'=>'Tambahkan kontrak baru di menu "Kontrak" untuk mulai memantau SLA.'];
} elseif ($kontrak_terlambat > 0) {
    $statusInfo = ['icon'=>'⚠️','color'=>'var(--red,#b91c1c)','bg'=>'var(--red-lt,#fef2f2)','title'=>$kontrak_terlambat.' kontrak perlu perhatian',
        'desc'=>'Rata-rata SLA-nya masih di bawah target 90%. Lihat detail di menu "Rekap SLA".'];
} else {
    $statusInfo = ['icon'=>'✅','color'=>'var(--green-dk,#166534)','bg'=>'var(--green-lt,#f0fdf4)','title'=>'Semua kontrak dalam kondisi baik',
        'desc'=>'Rata-rata SLA seluruh kontrak sudah di atas target 90%.'];
}
?>

<!-- ── TOMBOL UTAMA: INPUT DATA SLA ──────────────────────── -->
<?php if ($canInput): ?>
<div class="card" style="border-left:4px solid var(--blue);">
    <div class="card-body" style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">
        <div style="min-width:0;">
            <div style="font-weight:700;font-size:15px;">Input SLA</div>
            <div style="font-size:12.5px;color:var(--g700);margin-top:2px;">
                <?= count($kontrakBelumInput) > 0 ? count($kontrakBelumInput) . ' kontrak masih ada data yang belum lengkap' : 'Pilih bidang dan project, lalu isi realisasi' ?>
            </div>
        </div>
        <a href="input_harian.php" class="btn btn-primary" style="font-size:16px;font-weight:800;padding:14px 32px;letter-spacing:.5px;">+ INPUT DATA SLA</a>
    </div>
</div>
<?php endif; ?>

<?php ob_start(); ?>
<!-- ── INFO BANNER (Ringkasan Cepat) ───────────────────────── -->
<div class="card" style="background:<?= $statusInfo['bg'] ?>;border-left:4px solid <?= $statusInfo['color'] ?>;">
    <div class="card-body" style="display:flex;align-items:center;gap:14px;">
        <div style="font-size:24px;line-height:1;"><?= $statusInfo['icon'] ?></div>
        <div style="flex:1;min-width:0;">
            <div style="font-weight:700;font-size:14px;color:<?= $statusInfo['color'] ?>;margin-bottom:2px;">
                <?= $statusInfo['title'] ?>
            </div>
            <div style="font-size:12.5px;color:var(--g700);line-height:1.5;">
                <?= $statusInfo['desc'] ?>
            </div>
        </div>
    </div>
</div>

<?php $blkBanner = ob_get_clean(); ?>
<?php ob_start(); ?>
<!-- ── RINGKASAN BULAN BERJALAN (Prioritas Tinggi) ─────────── -->
<div class="card">
    <div class="card-header" style="padding:12px 16px;">
        <div>
            <div class="card-title" style="font-size:13px;"><i class="bi bi-calendar-check" style="color:var(--blue);"></i> Rekap SLA Bulan Ini</div>
            <div class="card-subtitle" style="font-size:11px;">Periode <?= ucwords(strtolower($bulanIni)) ?> <?= $tahunIni ?></div>
        </div>
    </div>
    <div class="card-body" style="display:flex;flex-wrap:wrap;gap:10px;">
        <div class="kpi-card kpi-green" style="margin:0;">
            <div class="kpi-icon"><i class="bi bi-play-circle"></i></div>
            <div class="kpi-body">
                <div class="kpi-label">Total Kontrak Aktif</div>
                <div class="kpi-value"><?= $kontrak_aktif ?></div>
                <div class="kpi-sub">Berjalan periode ini</div>
            </div>
        </div>
        <div class="kpi-card kpi-<?= $sla_bulan_berjalan === null ? 'blue' : (progressClass($sla_bulan_berjalan)==='good'?'green':($sla_bulan_berjalan>=70?'amber':'red')) ?>" style="margin:0;">
            <div class="kpi-icon"><i class="bi bi-speedometer2"></i></div>
            <div class="kpi-body">
                <div class="kpi-label">SLA Bulan Berjalan</div>
                <div class="kpi-value"><?= $sla_bulan_berjalan !== null ? number_format($sla_bulan_berjalan,1).'%' : '-' ?></div>
                <div class="kpi-sub">Rata-rata seluruh kontrak</div>
            </div>
        </div>
        <div class="kpi-card kpi-green" style="margin:0;">
            <div class="kpi-icon"><i class="bi bi-check-circle"></i></div>
            <div class="kpi-body">
                <div class="kpi-label">Indikator Tercapai</div>
                <div class="kpi-value"><?= $indikator_tercapai ?></div>
                <div class="kpi-sub">≥ 100% pencapaian</div>
            </div>
        </div>
        <div class="kpi-card <?= $indikator_tidak_tercapai > 0 ? 'kpi-red' : 'kpi-green' ?>" style="margin:0;">
            <div class="kpi-icon"><i class="bi bi-x-circle"></i></div>
            <div class="kpi-body">
                <div class="kpi-label">Indikator Tidak Tercapai</div>
                <div class="kpi-value"><?= $indikator_tidak_tercapai ?></div>
                <div class="kpi-sub">&lt; 100% pencapaian</div>
            </div>
        </div>
    </div>
</div>

<?php $blkBulan = ob_get_clean(); ?>
<?php ob_start(); ?>
<!-- ── DATA BELUM LENGKAP ──────────────────────────────────── -->
<?php if (!empty($kontrakBelumInput)): ?>
<div class="card" style="border-left:4px solid #b8970a;">
    <div class="card-header" style="padding:12px 16px;">
        <div>
            <div class="card-title" style="font-size:13px;"><i class="bi bi-clock-history" style="color:#b8970a;"></i> Data Belum Lengkap</div>
            <div class="card-subtitle" style="font-size:11px;">Periode <?= ucwords(strtolower($bulanIni)) ?> <?= $tahunIni ?> &mdash; <?= count($kontrakBelumInput) ?> kontrak masih ada Periode 1/2 yang kosong</div>
        </div>
    </div>
    <div class="table-wrap">
        <table style="font-size:12px;">
            <thead>
                <tr><th>Project</th><th>Bidang</th><th style="text-align:center;">Periode 1</th><th style="text-align:center;">Periode 2</th><?php if ($canInput): ?><th></th><?php endif; ?></tr>
            </thead>
            <tbody>
            <?php foreach ($kontrakBelumInput as $b):
                $p1ok = (int)$b['terisi_p1'] >= (int)$b['total_indikator'];
                $p2ok = (int)$b['terisi_p2'] >= (int)$b['total_indikator'];
            ?>
                <tr>
                    <td style="max-width:260px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="<?= htmlspecialchars((string)($b['nama_kontrak'] ?? '')) ?>"><?= htmlspecialchars((string)($b['nama_kontrak'] ?? '')) ?></td>
                    <td><?= badgeJenisKontrak($b['jenis_kontrak'] ?? 'DISTRIBUSI') ?></td>
                    <td style="text-align:center;"><?= $p1ok ? '<span style="color:var(--pln-green);font-weight:700;">✓ Lengkap</span>' : '<span style="color:#b8970a;font-weight:700;">⏳ '.(int)$b['terisi_p1'].'/'.(int)$b['total_indikator'].'</span>' ?></td>
                    <td style="text-align:center;"><?= $p2ok ? '<span style="color:var(--pln-green);font-weight:700;">✓ Lengkap</span>' : '<span style="color:#b8970a;font-weight:700;">⏳ '.(int)$b['terisi_p2'].'/'.(int)$b['total_indikator'].'</span>' ?></td>
                    <?php if ($canInput): ?><td><a href="input_harian.php?kontrak_id=<?= $b['id'] ?>" class="btn btn-outline btn-sm">Lengkapi</a></td><?php endif; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php elseif ($kontrak_aktif > 0): ?>
<div class="card" style="border-left:4px solid var(--pln-green);">
    <div class="card-body" style="display:flex;align-items:center;gap:10px;font-size:13px;font-weight:600;color:#166534;">
        <span style="font-size:20px;">✅</span> Data Belum Lengkap: tidak ada &mdash; semua input SLA periode ini sudah lengkap.
    </div>
</div>
<?php endif; ?>
<?php $blkBelum = ob_get_clean(); ?>
<?php ob_start(); ?>
<!-- ── STATUS KELENGKAPAN DATA PER ULP ─────────────────────── -->
<?php if (!empty($ulpStatusRows)): ?>
<div class="card">
    <div class="card-header" style="padding:12px 16px;">
        <div>
            <div class="card-title" style="font-size:13px;"><i class="bi bi-clipboard-check" style="color:var(--blue);"></i> Status Kelengkapan Data ULP</div>
            <div class="card-subtitle" style="font-size:11px;">Periode <?= ucwords(strtolower($bulanIni)) ?> <?= $tahunIni ?> &mdash; membantu melihat pekerjaan yang belum selesai</div>
        </div>
    </div>
    <div class="card-body" style="display:flex;flex-wrap:wrap;gap:16px;font-size:13px;font-weight:700;padding-bottom:6px;">
        <span>🟢 Data lengkap: <?= $ulpStatus['lengkap'] ?> ULP</span>
        <span>🟡 Belum lengkap: <?= $ulpStatus['sebagian'] ?> ULP</span>
        <span>🔴 Belum input: <?= $ulpStatus['kosong'] ?> ULP</span>
    </div>
    <?php if (!empty($ulpBelumLengkap)): ?>
    <div class="table-wrap">
        <table style="font-size:12px;">
            <thead><tr><th>ULP</th><th>Project</th><th style="text-align:center;">Terisi</th><th style="text-align:center;">Status</th><?php if ($canInput): ?><th></th><?php endif; ?></tr></thead>
            <tbody>
            <?php foreach ($ulpBelumLengkap as $ub): ?>
                <tr>
                    <td style="font-weight:600;"><?= htmlspecialchars((string)($ub['nama_ulp'] ?? '')) ?></td>
                    <td style="max-width:260px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="<?= htmlspecialchars((string)($ub['nama_kontrak'] ?? '')) ?>"><?= htmlspecialchars((string)($ub['nama_kontrak'] ?? '')) ?></td>
                    <td style="text-align:center;"><?= (int)$ub['terisi'] ?>/<?= (int)$ub['total_ind'] ?></td>
                    <td style="text-align:center;"><?= $ub['status']==='sebagian' ? '🟡 Belum lengkap' : '🔴 Belum input' ?></td>
                    <?php if ($canInput): ?><td><a href="kontrak.php?act=edit&id=<?= (int)$ub['kid'] ?>&ulp_id=<?= (int)$ub['id'] ?>#target-realisasi" class="btn btn-outline btn-sm">Lengkapi</a></td><?php endif; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php $blkUlpStatus = ob_get_clean(); ?>
<?php ob_start(); ?>
<!-- ── PINTASAN LAPORAN + INFO RINGKAS ─────────────────────── -->
<?php
$pintasan = [
    ['href'=>'rekap_sla.php',      'icon'=>'bi-bar-chart-line', 'judul'=>'Rekap SLA',
     'nilai'=>$rekapTerekap . ' project',
     'info'=>$kontrakNoRekap > 0 ? $kontrakNoRekap . ' belum direkap' : 'Semua sudah direkap'],
    ['href'=>'rata_rata.php',      'icon'=>'bi-graph-up-arrow', 'judul'=>'Rata-Rata SLA',
     'nilai'=>$rekapTerekap > 0 ? number_format($avg_sla_overall, 1) . '%' : '-',
     'info'=>$rekapTerekap > 0 ? 'Terendah: ' . $katTerendah . ' ' . number_format($katAvg[$katTerendah], 1) . '%' : 'Belum ada data'],
    ['href'=>'laporan_grafik.php', 'icon'=>'bi-bar-chart-fill', 'judul'=>'Laporan Grafik',
     'nilai'=>$grafikPeriode . ' periode',
     'info'=>'Grafik siap presentasi'],
    ['href'=>'laporan.php',        'icon'=>'bi-funnel',         'judul'=>'Laporan SLA',
     'nilai'=>number_format($lapTotalBaris, 0, ',', '.') . ' data',
     'info'=>$lapBelumTcp . ' belum tercapai'],
];
?>
<div class="card">
    <div class="card-header" style="padding:12px 16px;">
        <div class="card-title" style="font-size:13px;"><i class="bi bi-grid-1x2" style="color:var(--blue);"></i> Laporan</div>
    </div>
    <div class="card-body" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;">
        <?php foreach ($pintasan as $p): ?>
        <a href="<?= $p['href'] ?>" class="pintasan-card">
            <div class="pintasan-judul"><i class="bi <?= $p['icon'] ?>"></i> <?= $p['judul'] ?></div>
            <div class="pintasan-nilai"><?= $p['nilai'] ?></div>
            <div class="pintasan-info"><?= htmlspecialchars($p['info']) ?></div>
        </a>
        <?php endforeach; ?>
    </div>
</div>
<style>
.pintasan-card { display:block; text-decoration:none; color:inherit; border:1px solid var(--g200,#e2e8f0); border-radius:10px; padding:12px 14px; transition:box-shadow .15s, transform .15s; }
.pintasan-card:hover { box-shadow:var(--shadow-md,0 4px 12px rgba(0,0,0,.12)); transform:translateY(-2px); }
.pintasan-judul { font-size:12.5px; font-weight:700; color:var(--g700); }
.pintasan-judul i { color:var(--blue); margin-right:4px; }
.pintasan-nilai { font-size:22px; font-weight:800; margin:6px 0 2px; }
.pintasan-info { font-size:11.5px; color:var(--g500); }
.dash-detail { margin-top:6px; }
.dash-detail > summary { cursor:pointer; list-style:none; padding:12px 16px; margin-bottom:14px; font-weight:700; font-size:13px; border:1px dashed var(--g200,#cbd5e1); border-radius:10px; }
.dash-detail > summary::-webkit-details-marker { display:none; }
.dash-detail > summary i { color:var(--blue); margin-right:6px; }
.dash-detail > summary span { font-weight:400; font-size:11.5px; color:var(--g500); margin-left:8px; }
.dash-detail[open] > summary { border-style:solid; }
</style>
<?php $blkLaporan = ob_get_clean(); ?>
<?php
// Susunan dashboard menurut role — hanya informasi yang relevan:
//  • Admin/Koordinator (petugas): tombol input, data belum lengkap, rekap bulan ini.
//  • Team Leader / Manager UL   : status, rekap bulan ini, data belum lengkap, laporan, lalu analisis lengkap.
//  • Super Admin                : semuanya.
if (isPetugas()) {
    echo $blkBelum, $blkUlpStatus, $blkBulan;
    include 'includes/footer.php';
    exit;
}
echo $blkBanner, $blkBulan, $blkLaporan, $blkBelum;
?>

<!-- ── ANALISIS LENGKAP (dilipat supaya halaman awal tidak penuh) ── -->
<details class="dash-detail" id="dashDetail">
    <summary><i class="bi bi-bar-chart-steps"></i> Analisis Lengkap <span>grafik, performa ULP, vendor &amp; unit kerja — klik untuk membuka</span></summary>
<?php echo $blkUlpStatus; ?>

<!-- ── KPI ROW ────────────────────────────────────────────── -->
<div class="kpi-grid">
    <div class="kpi-card kpi-blue">
        <div class="kpi-icon"><i class="bi bi-file-earmark-text"></i></div>
        <div class="kpi-body">
            <div class="kpi-label">Total Kontrak</div>
            <div class="kpi-value"><?= $total_kontrak ?></div>
            <div class="kpi-sub">Distribusi: <?= $kontrak_distribusi ?> &bull; Transmisi: <?= $kontrak_transmisi ?> &bull; Pembangkit: <?= $kontrak_pembangkit ?></div>
        </div>
    </div>
    <div class="kpi-card kpi-cyan">
        <div class="kpi-icon"><i class="bi bi-building"></i></div>
        <div class="kpi-body">
            <div class="kpi-label">Total ULP</div>
            <div class="kpi-value"><?= $total_ulp ?></div>
            <div class="kpi-sub">Unit Layanan Pelanggan</div>
        </div>
    </div>
    <div class="kpi-card kpi-<?= progressClass($avg_sla_teknis)==='good'?'green':($avg_sla_teknis>=70?'amber':'red') ?>">
        <div class="kpi-icon"><i class="bi bi-bar-chart-line"></i></div>
        <div class="kpi-body">
            <div class="kpi-label">Avg SLA Teknis</div>
            <div class="kpi-value"><?= $total_kontrak > 0 ? number_format($avg_sla_teknis,1).'%' : '-' ?></div>
            <div class="kpi-sub">Target ≥ 90%</div>
        </div>
    </div>
    <div class="kpi-card kpi-<?= progressClass($avg_sla_k3)==='good'?'green':($avg_sla_k3>=70?'amber':'red') ?>">
        <div class="kpi-icon"><i class="bi bi-shield-check"></i></div>
        <div class="kpi-body">
            <div class="kpi-label">Avg SLA K3</div>
            <div class="kpi-value"><?= $total_kontrak > 0 ? number_format($avg_sla_k3,1).'%' : '-' ?></div>
            <div class="kpi-sub">Keselamatan kerja</div>
        </div>
    </div>
    <div class="kpi-card kpi-<?= progressClass($avg_kecelakaan)==='good'?'green':($avg_kecelakaan>=70?'amber':'red') ?>">
        <div class="kpi-icon"><i class="bi bi-exclamation-octagon"></i></div>
        <div class="kpi-body">
            <div class="kpi-label">Avg SLA Kecelakaan</div>
            <div class="kpi-value"><?= $total_kontrak > 0 ? number_format($avg_kecelakaan,1).'%' : '-' ?></div>
            <div class="kpi-sub">Kecelakaan kerja</div>
        </div>
    </div>
    <div class="kpi-card kpi-<?= progressClass($avg_ilp)==='good'?'green':($avg_ilp>=70?'amber':'red') ?>">
        <div class="kpi-icon"><i class="bi bi-bank"></i></div>
        <div class="kpi-body">
            <div class="kpi-label">Avg SLA ILP</div>
            <div class="kpi-value"><?= $total_kontrak > 0 ? number_format($avg_ilp,1).'%' : '-' ?></div>
            <div class="kpi-sub">Integritas layanan publik</div>
        </div>
    </div>
    <div class="kpi-card kpi-<?= progressClass($overallAvg)==='good'?'green':($overallAvg>=70?'amber':'red') ?>">
        <div class="kpi-icon"><i class="bi bi-speedometer2"></i></div>
        <div class="kpi-body">
            <div class="kpi-label">Rata-Rata SLA Keseluruhan</div>
            <div class="kpi-value"><?= $total_kontrak > 0 ? number_format($overallAvg,1).'%' : '-' ?></div>
            <div class="kpi-sub">Gabungan Teknis, K3, Kecelakaan, ILP</div>
        </div>
    </div>
    <div class="kpi-card kpi-indigo">
        <div class="kpi-icon"><i class="bi bi-pencil-square"></i></div>
        <div class="kpi-body">
            <div class="kpi-label">Entry SLA</div>
            <div class="kpi-value"><?= $total_entries ?></div>
            <div class="kpi-sub">Indikator tercatat</div>
        </div>
    </div>
    <div class="kpi-card kpi-green">
        <div class="kpi-icon"><i class="bi bi-play-circle"></i></div>
        <div class="kpi-body">
            <div class="kpi-label">Kontrak Aktif</div>
            <div class="kpi-value"><?= $kontrak_aktif ?></div>
            <div class="kpi-sub">Periode <?= ucwords(strtolower($bulanIni)) ?> <?= $tahunIni ?></div>
        </div>
    </div>
    <div class="kpi-card <?= $kontrak_terlambat > 0 ? 'kpi-red' : 'kpi-green' ?>">
        <div class="kpi-icon"><i class="bi bi-exclamation-triangle"></i></div>
        <div class="kpi-body">
            <div class="kpi-label">Perlu Perhatian</div>
            <div class="kpi-value"><?= $kontrak_terlambat ?></div>
            <div class="kpi-sub">Rata-rata SLA &lt; 90%</div>
        </div>
    </div>
    <div class="kpi-card kpi-purple">
        <div class="kpi-icon"><i class="bi bi-people"></i></div>
        <div class="kpi-body">
            <div class="kpi-label">Pengguna</div>
            <div class="kpi-value"><?= $total_users ?></div>
            <div class="kpi-sub">Akun terdaftar</div>
        </div>
    </div>
</div>

<!-- ── RINGKASAN PER BIDANG (Distribusi / Transmisi / Pembangkit) ── -->
<div class="card">
    <div class="card-header" style="padding:12px 16px;">
        <div>
            <div class="card-title" style="font-size:13px;"><i class="bi bi-diagram-3" style="color:var(--blue);"></i> Ringkasan per Bidang</div>
            <div class="card-subtitle" style="font-size:11px;">Jumlah kontrak & rata-rata SLA tiap bidang</div>
        </div>
    </div>
    <div class="card-body" style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;">
        <?php foreach (['DISTRIBUSI'=>'⚡','TRANSMISI'=>'🗼','PEMBANGKIT'=>'🏭'] as $bd => $icon):
            $bs = $bidangSummary[$bd];
            $jml = $bs ? (int)$bs['jml_kontrak'] : 0;
            $rekapCnt = $bs ? (int)$bs['jml_rekap'] : 0;
            $avg = ($bs && $bs['avg_sla'] !== null) ? (float)$bs['avg_sla'] : null;
        ?>
        <div class="stat-card <?= $avg===null?'':($avg>=90?'green':($avg>=70?'yellow':'red')) ?>">
            <div class="stat-value <?= $avg===null?'':($avg>=90?'green':($avg>=70?'warn':'bad')) ?>"><?= $avg===null ? '-' : number_format($avg,1).'%' ?></div>
            <div class="stat-label"><?= $icon ?> <?= ucwords(strtolower($bd)) ?></div>
            <div style="margin-top:6px;font-size:11px;color:var(--text-light);">
                <?= $jml ?> kontrak &bull; <?= $rekapCnt ?> sudah terekap
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?php if (count($trendRows) > 0): ?>
<!-- ── BARIS 1: 2 CHART SLA BESAR ────────────────────────── -->
<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:14px;margin-bottom:14px;">
    <div class="card" style="margin-bottom:0;">
        <div class="card-header" style="padding:12px 16px;">
            <div>
                <div class="card-title" style="font-size:13px;"><i class="bi bi-graph-up-arrow" style="color:var(--blue);"></i> Tren SLA 12 Bulan Terakhir</div>
                <div class="card-subtitle" style="font-size:11px;">Perkembangan Avg SLA seluruh kontrak</div>
            </div>
        </div>
        <div style="padding:12px 16px;">
            <div class="chart-wrap" style="--chart-h:240px;"><canvas id="chartTrenSLA"></canvas></div>
        </div>
    </div>
    <div class="card" style="margin-bottom:0;">
        <div class="card-header" style="padding:12px 16px;">
            <div>
                <div class="card-title" style="font-size:13px;"><i class="bi bi-layers" style="color:var(--blue);"></i> Teknis vs K3 vs ILP</div>
                <div class="card-subtitle" style="font-size:11px;">Perbandingan tren per kategori SLA</div>
            </div>
        </div>
        <div style="padding:12px 16px;">
            <div class="chart-wrap" style="--chart-h:260px;"><canvas id="chartTeknis"></canvas></div>
        </div>
    </div>
</div>

<!-- ── BARIS 2: RATA-RATA KATEGORI ────────────────────────── -->
<div style="display:grid;grid-template-columns:1fr;gap:14px;margin-bottom:14px;">
    <div class="card" style="margin-bottom:0;">
        <div class="card-header" style="padding:12px 16px;">
            <div>
                <div class="card-title" style="font-size:13px;"><i class="bi bi-pie-chart" style="color:var(--blue);"></i> Rata-Rata per Kategori SLA</div>
                <div class="card-subtitle" style="font-size:11px;">Avg SLA Teknis, K3, Kecelakaan, ILP</div>
            </div>
        </div>
        <div style="padding:12px 16px;">
            <div class="chart-wrap" style="--chart-h:200px;"><canvas id="chartKategori"></canvas></div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ── BARIS 5: PENCAPAIAN TIAP ULP + TOP 5 INDIKATOR TERENDAH ── -->
<?php if (!empty($ulpPerforma) || !empty($top5Rendah)):
    $baris5ColCount = (!empty($ulpPerforma) ? 1 : 0) + (!empty($top5Rendah) ? 1 : 0);
?>
<div style="display:grid;grid-template-columns:repeat(<?= $baris5ColCount ?>,1fr);gap:14px;margin-bottom:14px;">
    <?php if (!empty($ulpPerforma)): ?>
    <div class="card" style="margin-bottom:0;">
        <div class="card-header" style="padding:12px 16px;">
            <div>
                <div class="card-title" style="font-size:13px;"><i class="bi bi-building-gear" style="color:var(--blue);"></i> Pencapaian Tiap ULP</div>
                <div class="card-subtitle" style="font-size:11px;">Rata-rata persen pencapaian seluruh indikator per ULP</div>
            </div>
        </div>
        <div style="padding:12px 16px;">
            <div class="chart-wrap" style="--chart-h:<?= max(160, min(720, count($ulpPerforma) * 40 + 50)) ?>px;"><canvas id="chartUlpPencapaian"></canvas></div>
        </div>
    </div>
    <?php endif; ?>
    <?php if (!empty($top5Rendah)): ?>
    <div class="card" style="margin-bottom:0;">
        <div class="card-header" style="padding:12px 16px;">
            <div>
                <div class="card-title" style="font-size:13px;"><i class="bi bi-exclamation-triangle" style="color:var(--red);"></i> Top 5 Indikator Nilai Terendah</div>
                <div class="card-subtitle" style="font-size:11px;">Indikator yang paling butuh perhatian</div>
            </div>
        </div>
        <div class="table-wrap">
            <table style="font-size:12px;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Kriteria</th>
                        <th>Kategori</th>
                        <th style="text-align:center;">Target</th>
                        <th style="text-align:center;">Realisasi</th>
                        <th style="text-align:center;">Pencapaian</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($top5Rendah as $i => $t): $pct = (float)$t['persen_pencapaian']; ?>
                    <tr>
                        <td style="color:#94a3b8;"><?= $i+1 ?></td>
                        <td>
                            <div style="font-weight:700;font-size:11px;max-width:180px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="<?= htmlspecialchars((string)($t['kriteria'] ?? '')) ?>">
                                <?= htmlspecialchars((string)($t['kriteria'] ?? '')) ?>
                            </div>
                            <div style="font-size:10px;color:#64748b;"><?= htmlspecialchars((string)($t['ruang_lingkup'] ?? '')) ?></div>
                        </td>
                        <td><span class="badge badge-teknis" style="font-size:10px;"><?= htmlspecialchars((string)($t['kategori'] ?? '')) ?></span></td>
                        <td style="text-align:center;font-size:11px;"><?= rtrim(rtrim(number_format($t['target'],2),'0'),'.') ?> <?= htmlspecialchars($t['satuan'] ?? '') ?></td>
                        <td style="text-align:center;font-size:11px;"><?= rtrim(rtrim(number_format($t['realisasi'],2),'0'),'.') ?> <?= htmlspecialchars($t['satuan'] ?? '') ?></td>
                        <td style="text-align:center;">
                            <span style="<?= pctBadgeStyle($pct) ?>font-size:11px;font-weight:700;padding:2px 8px;border-radius:6px;"><?= number_format($pct,1) ?>%</span>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php if (!empty($unitPerforma)): ?>
<!-- ── PERFORMA PER UNIT KERJA ─────────────────────────────── -->
<div class="card">
    <div class="card-header" style="padding:12px 16px;">
        <div>
            <div class="card-title" style="font-size:13px;"><i class="bi bi-diagram-3-fill" style="color:var(--blue);"></i> Performa per Unit Kerja</div>
            <div class="card-subtitle" style="font-size:11px;">Rata-rata SLA gabungan tiap unit kerja (OPGI/GP, dsb)</div>
        </div>
    </div>
    <div style="padding:12px 16px;">
        <?php $unitPerformaAdaData = array_filter($unitPerforma, fn($u) => $u['avg_sla'] !== null); ?>
        <?php if (!empty($unitPerformaAdaData)): ?>
        <div class="chart-wrap" style="--chart-h:<?= max(150, min(720, count($unitPerforma) * 42 + 50)) ?>px;"><canvas id="chartUnitKerja"></canvas></div>
        <?php else: ?>
        <div style="text-align:center;color:#94a3b8;font-size:12px;padding:20px 0;">
            <i class="bi bi-bar-chart" style="font-size:20px;display:block;margin-bottom:6px;"></i>
            Belum ada data rekap SLA untuk unit-unit ini.
        </div>
        <?php endif; ?>
    </div>
    <div class="table-wrap">
        <table style="font-size:12px;">
            <thead>
                <tr><th>Unit Kerja</th><th>Bidang</th><th style="text-align:center;">Jml Kontrak</th><th style="text-align:center;">Avg SLA</th></tr>
            </thead>
            <tbody>
            <?php foreach ($unitPerforma as $u): $ua = $u['avg_sla'] !== null ? (float)$u['avg_sla'] : null; ?>
                <tr>
                    <td><?= htmlspecialchars((string)($u['nama_unit'] ?? '')) ?></td>
                    <td><?= badgeJenisKontrak($u['jenis_kontrak'] ?? 'DISTRIBUSI') ?></td>
                    <td style="text-align:center;"><?= (int)$u['jml_kontrak'] ?></td>
                    <td style="text-align:center;"><?= $ua===null ? '-' : '<span style="'.pctBadgeStyle($ua).'font-weight:700;padding:2px 8px;border-radius:6px;">'.number_format($ua,1).'%</span>' ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php if (!empty($vendorPerforma)): ?>
<!-- ── BARIS 4: PERFORMA VENDOR ───────────────────────────── -->
<div class="card">
    <div class="card-header" style="padding:12px 16px;">
        <div>
            <div class="card-title" style="font-size:13px;"><i class="bi bi-building-gear" style="color:var(--blue);"></i> Performa Vendor</div>
            <div class="card-subtitle" style="font-size:11px;">Rata-rata pencapaian SLA per vendor pelaksana</div>
        </div>
    </div>
    <div style="padding:12px 16px;">
        <div class="chart-wrap" style="--chart-h:<?= max(150, min(720, count($vendorPerforma) * 42 + 50)) ?>px;"><canvas id="chartVendor"></canvas></div>
    </div>
    <div class="table-wrap">
        <table style="font-size:12px;">
            <thead>
                <tr>
                    <th>Vendor</th>
                    <th style="text-align:center;">Jumlah Kontrak</th>
                    <th style="text-align:center;">Avg SLA</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($vendorPerforma as $v): $avgV = (float)$v['avg_sla']; ?>
                <tr>
                    <td style="font-weight:600;"><?= htmlspecialchars(mb_strimwidth((string)($v['vendor'] ?? ''),0,50,'...')) ?></td>
                    <td style="text-align:center;"><?= $v['jml_kontrak'] ?></td>
                    <td style="text-align:center;"><span style="<?= pctBadgeStyle($avgV) ?>font-size:11px;font-weight:700;padding:2px 8px;border-radius:6px;"><?= number_format($avgV,1) ?>%</span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- ── RINGKASAN PER KONTRAK ──────────────────────────────── -->
<?php if (count($rekapAll) > 0): ?>
<div class="card">
    <div class="card-header" style="padding:10px 14px;">
        <div>
            <div class="card-title"><i class="bi bi-table" style="color:var(--blue);"></i> Ringkasan per Kontrak</div>
            <div class="card-subtitle"><?= count($rekapAll) ?> kontrak terekapitulasi</div>
        </div>
        <a href="rekap_sla.php" class="btn btn-outline btn-sm">Lihat Detail <i class="bi bi-arrow-right"></i></a>
    </div>
    <div class="table-wrap">
        <table style="font-size:12px;">
            <thead>
                <tr>
                    <th style="width:20px;">#</th>
                    <th>Kontrak</th>
                    <th>Bidang</th>
                    <th>Periode</th>
                    <th>Tahap</th>
                    <th style="text-align:center;">Teknis</th>
                    <th style="text-align:center;">K3</th>
                    <th style="text-align:center;">Kecelakaan</th>
                    <th style="text-align:center;">ILP</th>
                    <th style="text-align:center;">Avg SLA</th>
                    <th style="text-align:center;">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($rekapAll as $i => $r):
                $avg = (float)$r['avg_sla'];
                $cls = progressClass($avg);
            ?>
            <tr>
                <td style="color:#94a3b8;"><?= $i+1 ?></td>
                <td>
                    <div style="font-weight:700;font-size:11px;max-width:180px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="<?= htmlspecialchars((string)($r['nama_kontrak'] ?? '')) ?>">
                        <?= htmlspecialchars(mb_strimwidth((string)($r['nama_kontrak'] ?? ''),0,40,'...')) ?>
                    </div>
                </td>
                <td>
                    <span class="sla-badge-click" style="cursor:pointer;" onclick="openSlaDetail(<?= (int)$r['kid'] ?>)" title="Klik untuk lihat semua info SLA kontrak ini">
                        <?= badgeJenisKontrak($r['jenis_kontrak'] ?? 'DISTRIBUSI') ?>
                    </span>
                </td>
                <td style="white-space:nowrap;font-size:11px;"><?= $r['periode_bulan'] ?> <?= $r['tahun'] ?></td>
                <td><span class="badge badge-teknis" style="font-size:10px;"><?= $r['tahap'] ?></span></td>
                <?php foreach (['sla_teknis','sla_k3','sla_kecelakaan','sla_ilp'] as $col):
                    $pct = (float)($r[$col] ?? 0); ?>
                <td style="text-align:center;">
                    <span style="<?= pctBadgeStyle($pct) ?>font-size:11px;font-weight:700;padding:2px 7px;border-radius:6px;">
                        <?= number_format($pct,1) ?>%
                    </span>
                </td>
                <?php endforeach; ?>
                <td style="text-align:center;">
                    <span style="<?= pctBadgeStyle($avg) ?>font-size:12px;font-weight:800;padding:3px 9px;border-radius:8px;">
                        <?= number_format($avg,1) ?>%
                    </span>
                </td>
                <td style="text-align:center;">
                    <div style="display:flex;gap:4px;justify-content:center;">
                        <a href="input_sla.php?kontrak_id=<?= $r['kid'] ?>" class="btn btn-primary btn-sm" style="font-size:10px;padding:3px 8px;" title="Input SLA"><i class="bi bi-pencil"></i></a>
                        <a href="rekap_sla.php?kontrak_id=<?= $r['kid'] ?>" class="btn btn-outline btn-sm" style="font-size:10px;padding:3px 8px;" title="Rekap"><i class="bi bi-bar-chart-line"></i></a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php elseif ($total_kontrak > 0 && $kontrakNoRekap > 0): ?>
<div class="alert alert-info">
    Ada <?= $kontrakNoRekap ?> kontrak belum memiliki rekap SLA. <a href="input_sla.php">Input SLA sekarang →</a>
</div>
<?php endif; ?>

</details>

<?php if (count($trendRows) > 0):
    $labels = []; $avgSLA = [];
    $teknisArr = []; $k3Arr = []; $kecelakaanArr = []; $ilpArr = [];
    foreach ($trendRows as $r) {
        $labels[]        = ucwords(strtolower($r['periode_bulan'])) . ' ' . $r['tahun'] . ' • ' . ($r['nama_kontrak'] ?? '');
        $avgSLA[]        = round((float)$r['avg_sla'], 2);
        $teknisArr[]     = round((float)$r['sla_teknis'], 2);
        $k3Arr[]         = round((float)$r['sla_k3'], 2);
        $kecelakaanArr[] = round((float)$r['sla_kecelakaan'], 2);
        $ilpArr[]        = round((float)$r['sla_ilp'], 2);
    }
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script src="assets/js/chart-helpers.js"></script>
<script>
(function(){
    var labels        = <?= json_encode($labels) ?>;
    var avgSLA        = <?= json_encode($avgSLA) ?>;
    // 12 bulan terakhir saja untuk chart tren utama
    var labels12      = <?= json_encode(array_slice($labels, -12)) ?>;
    var avgSLA12      = <?= json_encode(array_slice($avgSLA, -12)) ?>;
    var teknisArr     = <?= json_encode($teknisArr) ?>;
    var k3Arr         = <?= json_encode($k3Arr) ?>;
    var kecelakaanArr = <?= json_encode($kecelakaanArr) ?>;
    var ilpArr        = <?= json_encode($ilpArr) ?>;

    SLAChart.init();

    // 1) Tren Avg SLA (12 bulan terakhir)
    SLAChart.line(document.getElementById('chartTrenSLA'), {
        labels: labels12,
        datasets: [{ label: 'Avg SLA', data: avgSLA12, borderColor: '#0066AE', backgroundColor: 'rgba(0,102,174,0.09)', fill: true }],
        ref: 100, tickLen: 18
    });

    // 2) Teknis vs K3 vs ILP vs Kecelakaan
    SLAChart.line(document.getElementById('chartTeknis'), {
        labels: labels,
        datasets: [
            { label: 'Teknis',     data: teknisArr,     borderColor: '#0066AE' },
            { label: 'K3',         data: k3Arr,         borderColor: '#10b981' },
            { label: 'ILP',        data: ilpArr,        borderColor: '#7c3aed', borderDash: [4, 3] },
            { label: 'Kecelakaan', data: kecelakaanArr, borderColor: '#f59e0b', borderDash: [2, 2] }
        ],
        legend: true, ref: 100, tickLen: 18
    });

    // 3) Rata-rata per kategori (horizontal bar)
    SLAChart.bar(document.getElementById('chartKategori'), {
        labels: ['Teknis', 'K3', 'Kecelakaan', 'ILP'],
        datasets: [{ label: 'Avg SLA', data: [<?= round($avg_sla_teknis,2) ?>, <?= round($avg_sla_k3,2) ?>, <?= round($avg_kecelakaan,2) ?>, <?= round($avg_ilp,2) ?>],
            backgroundColor: ['rgba(0,102,174,0.82)','rgba(16,185,129,0.82)','rgba(245,159,35,0.82)','rgba(124,58,237,0.82)'] }],
        horizontal: true, ref: 100
    });

    // 4) Pencapaian Tiap ULP
    var ulpEl = document.getElementById('chartUlpPencapaian');
    if (ulpEl) {
        var ulpPencapaian = <?= json_encode(array_map(fn($u)=>round((float)$u['avg_pencapaian'],2), $ulpPerforma)) ?>;
        SLAChart.bar(ulpEl, {
            labels: <?= json_encode(array_map(fn($u)=>(string)($u['nama_ulp'] ?? ''), $ulpPerforma)) ?>,
            datasets: [{ label: 'Pencapaian', data: ulpPencapaian, backgroundColor: SLAChart.colorsFor(ulpPencapaian) }],
            horizontal: true, ref: 100
        });
    }

    // 5) Performa per Unit Kerja
    var unitKerjaEl = document.getElementById('chartUnitKerja');
    if (unitKerjaEl) {
        var unitAvgSLA = <?= json_encode(array_map(fn($u)=>round((float)($u['avg_sla'] ?? 0),2), $unitPerforma)) ?>;
        SLAChart.bar(unitKerjaEl, {
            labels: <?= json_encode(array_map(function($u) {
                $bidangSingkat = ['DISTRIBUSI'=>'Distribusi','TRANSMISI'=>'Transmisi','PEMBANGKIT'=>'Pembangkit'][$u['jenis_kontrak'] ?? ''] ?? ($u['jenis_kontrak'] ?? '-');
                return (string)($u['nama_unit'] ?? '') . " ($bidangSingkat)";
            }, $unitPerforma)) ?>,
            datasets: [{ label: 'Avg SLA', data: unitAvgSLA, backgroundColor: SLAChart.colorsFor(unitAvgSLA) }],
            horizontal: true, ref: 100, tickLen: 34
        });
    }

    // 6) Performa Vendor
    var vendorEl = document.getElementById('chartVendor');
    if (vendorEl) {
        var vendorAvgSLA = <?= json_encode(array_map(fn($v)=>round((float)$v['avg_sla'],2), $vendorPerforma)) ?>;
        SLAChart.bar(vendorEl, {
            labels: <?= json_encode(array_map(fn($v)=>(string)($v['vendor'] ?? ''), $vendorPerforma)) ?>,
            datasets: [{ label: 'Avg SLA', data: vendorAvgSLA, backgroundColor: SLAChart.colorsFor(vendorAvgSLA) }],
            horizontal: true, ref: 100, tickLen: 34
        });
    }
})();
</script>
<?php endif; ?>

<!-- ── MODAL: DETAIL SLA (dibuka dari klik badge Jenis Kontrak) ──────── -->
<div class="modal-overlay" id="slaDetailModal">
    <div class="modal" style="max-width:920px;">
        <div class="modal-header">
            <span class="modal-title" id="slaDetailTitle">Detail SLA</span>
            <button class="modal-close" onclick="closeSlaDetail()">×</button>
        </div>
        <div class="modal-body" id="slaDetailBody">
            <div style="text-align:center;padding:30px;color:var(--g500);">Memuat data...</div>
        </div>
        <div class="modal-footer">
            <a href="#" id="slaDetailLinkRekap" class="btn btn-primary btn-sm">📊 Buka Rekap Lengkap</a>
            <button class="btn btn-outline btn-sm" onclick="closeSlaDetail()">Tutup</button>
        </div>
    </div>
</div>
<script>
function escSla(s) {
    return String(s ?? '').replace(/[&<>"']/g, function (c) {
        return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c];
    });
}
function pctColorSla(pct) {
    // Pakai CSS variable (bukan hex mentah) supaya warna kartu di modal
    // "Detail SLA" ini otomatis ikut menyesuaikan saat mode gelap aktif,
    // sama seperti perbaikan pctBadgeStyle() di includes/database.php.
    if (pct >= 90) return {bg:'var(--green-lt)', fg:'var(--green-dk)'};
    if (pct >= 70) return {bg:'var(--amber-lt)', fg:'var(--amber)'};
    return {bg:'var(--red-lt)', fg:'var(--red)'};
}
function pctChipSla(pct) {
    if (pct === null || pct === undefined) {
        return '<span style="background:#f1f5f9;color:#94a3b8;border:1px solid #e2e8f0;font-size:11px;font-weight:700;padding:2px 8px;border-radius:6px;white-space:nowrap;">⏳ Belum Dinilai</span>';
    }
    var c = pctColorSla(pct);
    return '<span style="background:'+c.bg+';color:'+c.fg+';font-size:11px;font-weight:700;padding:2px 8px;border-radius:6px;">'+Number(pct).toFixed(2)+'%</span>';
}
var KAT_LABEL_SLA = {
    TEKNIS: '⚡ SLA Teknis', K3: '🦺 SLA K3',
    KECELAKAAN: '⚠️ Kecelakaan Kerja', ILP: '🏛️ Integritas Layanan Publik (ILP)'
};

function openSlaDetail(kontrakId) {
    var modal = document.getElementById('slaDetailModal');
    var body  = document.getElementById('slaDetailBody');
    var title = document.getElementById('slaDetailTitle');
    var linkRekap = document.getElementById('slaDetailLinkRekap');
    title.textContent = 'Detail SLA';
    body.innerHTML = '<div style="text-align:center;padding:30px;color:var(--g500);">Memuat data...</div>';
    linkRekap.href = 'rekap_sla.php?kontrak_id=' + kontrakId;
    openAppModal('slaDetailModal');

    fetch('api.php?action=sla_detail&kontrak_id=' + kontrakId)
        .then(function (res) { return res.json(); })
        .then(function (data) {
            if (!data.ok) {
                body.innerHTML = '<div class="alert alert-danger">' + escSla(data.error || 'Data tidak ditemukan') + '</div>';
                return;
            }
            var k = data.kontrak, r = data.rekap;
            title.textContent = k.nama_kontrak + ' — ' + k.periode_bulan + ' ' + k.tahun;

            var html = '';
            html += '<div style="background:linear-gradient(135deg,#003087,#0055b3);color:#fff;border-radius:10px;padding:16px 18px;margin-bottom:16px;">';
            html += '  <div style="font-size:11px;opacity:.75;letter-spacing:.5px;">SERVICE LEVEL AGREEMENT (SLA)</div>';
            html += '  <div style="font-size:14px;font-weight:800;margin:4px 0 8px;">' + escSla(k.nama_kontrak) + '</div>';
            html += '  <div style="font-size:12px;opacity:.9;">' + k.jenis_kontrak_badge + ' &nbsp; PERIODE ' + escSla(k.periode_bulan) + ' ' + k.tahun + ' — ' + escSla(k.tahap) + '</div>';
            html += '  <div style="font-size:12px;opacity:.85;margin-top:4px;">Vendor: ' + escSla(k.vendor) + ' &bull; No. Kontrak: ' + escSla(k.no_kontrak_1 || '-') + '</div>';
            html += '</div>';

            var tc = pctColorSla(r.total_pencapaian);
            html += '<div style="border:2px solid ' + tc.fg + '33;background:' + tc.bg + ';border-radius:10px;padding:14px 18px;margin-bottom:12px;display:flex;align-items:center;justify-content:space-between;">';
            html += '  <div>';
            html += '    <div style="font-size:11px;font-weight:800;color:' + tc.fg + ';letter-spacing:.4px;">📌 TOTAL PERSENTASE PENCAPAIAN SLA</div>';
            html += '    <div style="font-size:11px;color:' + tc.fg + ';opacity:.85;margin-top:2px;">Rata-rata Teknis + K3 + Kecelakaan + ILP</div>';
            html += '  </div>';
            html += '  <div style="font-size:26px;font-weight:900;color:' + tc.fg + ';">' + Number(r.total_pencapaian).toFixed(2) + '%</div>';
            html += '</div>';

            html += '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px;">';
            [['SLA Teknis', r.sla_teknis], ['SLA K3', r.sla_k3], ['Kecelakaan', r.sla_kecelakaan], ['SLA ILP', r.sla_ilp]].forEach(function (item) {
                var c = pctColorSla(item[1]);
                html += '<div style="flex:1 1 130px;border:1px solid var(--border);border-radius:8px;padding:10px;text-align:center;">';
                html += '  <div style="font-size:10px;color:var(--g500);font-weight:700;">' + item[0] + '</div>';
                html += '  <div style="font-size:18px;font-weight:800;color:' + c.fg + ';">' + Number(item[1]).toFixed(2) + '%</div>';
                html += '</div>';
            });
            html += '</div>';

            ['TEKNIS','K3','KECELAKAAN','ILP'].forEach(function (kat) {
                var rows = data.entries[kat];
                if (!rows || !rows.length) return;
                html += '<div style="font-size:12px;font-weight:800;color:var(--g700);margin:14px 0 6px;">' + KAT_LABEL_SLA[kat] + '</div>';
                html += '<div class="table-wrap"><table style="font-size:11px;"><thead><tr>';
                html += '<th>Ruang Lingkup</th><th>Keterangan (belum tercapai)</th><th>Sat.</th><th>Polaritas<span class="help-tip" tabindex="0" data-tip="Positif: semakin tinggi realisasi semakin baik.&#10;Negatif: semakin rendah realisasi semakin baik.">?</span></th><th>Target</th><th>Realisasi</th><th>% Pencapaian</th><th>Nilai Bobot</th>';
                html += '</tr></thead><tbody>';
                rows.forEach(function (e) {
                    html += '<tr>';
                    html += '<td><div style="font-weight:700;">' + escSla(e.ruang_lingkup) + '</div><div style="font-size:10px;color:var(--text-light);">' + escSla(e.kriteria) + '</div></td>';
                    var ketCell = '<span style="color:#cbd5e1;">–</span>';
                    if (e.persen_pencapaian !== null && e.persen_pencapaian < 100) {
                        ketCell = e.keterangan ? escSla(e.keterangan) : '<span style="color:#f59e0b;font-style:italic;">Belum diisi keterangan</span>';
                    }
                    html += '<td style="max-width:220px;">' + ketCell + '</td>';
                    html += '<td>' + escSla(e.satuan) + '</td>';
                    html += '<td><span class="badge ' + (e.polaritas === 'Positif' ? 'badge-positif' : 'badge-negatif') + '">' + escSla(e.polaritas) + '</span></td>';
                    html += '<td>' + Number(e.target).toLocaleString('id-ID') + '</td>';
                    html += '<td>' + (e.realisasi === null ? '<span style="color:#cbd5e1;">–</span>' : Number(e.realisasi).toLocaleString('id-ID')) + '</td>';
                    html += '<td>' + pctChipSla(e.persen_pencapaian) + '</td>';
                    html += '<td><b>' + (e.nilai_bobot === null ? '<span style="color:#cbd5e1;">–</span>' : Number(e.nilai_bobot).toLocaleString('id-ID')) + '</b></td>';
                    html += '</tr>';
                });
                html += '</tbody></table></div>';
            });

            if (data.ulp && data.ulp.length) {
                html += '<div style="font-size:12px;font-weight:800;color:var(--g700);margin:14px 0 6px;">🏢 Resume Per ULP</div>';
                html += '<div class="table-wrap"><table style="font-size:11px;"><thead><tr><th>Nama ULP</th><th>Teknis</th><th>K3</th><th>Kecelakaan</th><th>ILP</th></tr></thead><tbody>';
                data.ulp.forEach(function (u) {
                    html += '<tr><td><b>' + escSla(u.nama_ulp) + '</b></td>';
                    ['TEKNIS','K3','KECELAKAAN','ILP'].forEach(function (kat) {
                        html += '<td>' + pctChipSla(u[kat] || 0) + '</td>';
                    });
                    html += '</tr>';
                });
                html += '</tbody></table></div>';
            }

            body.innerHTML = html;
        })
        .catch(function () {
            body.innerHTML = '<div class="alert alert-danger">Gagal memuat data SLA. Silakan coba lagi.</div>';
        });
}
function closeSlaDetail() {
    closeAppModal('slaDetailModal');
}
document.getElementById('slaDetailModal').addEventListener('click', function (e) {
    if (e.target === this) closeSlaDetail();
});
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeSlaDetail();
});
</script>

<script>
document.getElementById('dashDetail')?.addEventListener('toggle', function () {
    if (this.open) setTimeout(function () { window.dispatchEvent(new Event('resize')); }, 50);
});
</script>

<?php include 'includes/footer.php'; ?>